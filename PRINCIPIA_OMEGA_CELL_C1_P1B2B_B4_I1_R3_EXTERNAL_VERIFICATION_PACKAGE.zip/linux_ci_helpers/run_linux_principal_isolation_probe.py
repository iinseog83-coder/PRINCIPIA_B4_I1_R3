#!/usr/bin/env python3
"""
PRINCIPIA B4 ACT-I1 R3 — Dedicated Non-Sudo Linux Principal Isolation Probe (`Article 4` / Strategy 2)
Executed as `principia_verifier` BEFORE and AFTER cold replay on fresh `ubuntu-latest` VM (`RE1`, `RE2`).
Proves kernel-enforced `EACCES`/`EPERM` denial across 5 mutation/escalation vectors on `/opt/...` (`root:root` `0555`/`0444`).
"""

from __future__ import annotations

import argparse
import datetime
import errno
import grp
import hashlib
import json
import os
import pwd
import stat
import subprocess
from pathlib import Path


def sha256_file(p: Path) -> tuple[int, str]:
    b = p.read_bytes()
    return len(b), hashlib.sha256(b).hexdigest().upper()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--replay-id", required=True)
    ap.add_argument("--locked-bundle-root", type=Path, required=True)
    ap.add_argument("--out-json", type=Path, required=True)
    args = ap.parse_args()

    bundle_root = args.locked_bundle_root.resolve()
    target_lean = (
        bundle_root
        / "research"
        / "principia_omega_cell_c1_p1b2b_b4_higher_composition_lean4"
        / "OmegaCellC1P1B2BB4.lean"
    )
    target_oracle = (
        bundle_root
        / "research"
        / "principia_omega_cell_c1_p1b2b_b4_i1_verify_kit_r3"
        / "b4_i1_r3_precommitted_oracle.json"
    )

    uid = os.getuid()
    euid = os.geteuid()
    gid = os.getgid()
    egid = os.getegid()
    uname = pwd.getpwuid(uid).pw_name
    gnames = sorted({grp.getgrgid(g).gr_name for g in ([gid] + list(os.getgroups()))})
    forbidden_groups = {"root", "sudo", "wheel", "adm", "admin", "docker", "runner"}

    identity_ok = (
        uid != 0
        and euid != 0
        and uname == "principia_verifier"
        and len(forbidden_groups.intersection(gnames)) == 0
    )

    st_root = os.stat(bundle_root)
    st_lean = os.stat(target_lean)
    st_orc = os.stat(target_oracle)
    pre_lean_sz, pre_lean_sha = sha256_file(target_lean)
    pre_orc_sz, pre_orc_sha = sha256_file(target_oracle)

    ownership_and_mode_ok = (
        st_root.st_uid == 0
        and st_root.st_gid == 0
        and stat.S_IMODE(st_root.st_mode) == 0o555
        and st_lean.st_uid == 0
        and stat.S_IMODE(st_lean.st_mode) == 0o444
        and st_orc.st_uid == 0
        and stat.S_IMODE(st_orc.st_mode) == 0o444
    )

    probes = {}

    # Probe 1: Append/write to frozen B4 kernel file denied by kernel
    try:
        with open(target_lean, "ab") as f:
            f.write(b"-- tamper\n")
        probes["probe1_append_write_denied"] = {"denied": False, "error": "WRITE_UNEXPECTEDLY_SUCCEEDED"}
    except OSError as exc:
        probes["probe1_append_write_denied"] = {
            "denied": exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS),
            "errno": exc.errno,
            "errnoName": errno.errorcode.get(exc.errno, str(exc.errno)),
        }

    # Probe 2: Unlink/delete frozen precommitted R3 oracle denied by kernel
    try:
        os.unlink(target_oracle)
        probes["probe2_unlink_rm_denied"] = {"denied": False, "error": "UNLINK_UNEXPECTEDLY_SUCCEEDED"}
    except OSError as exc:
        probes["probe2_unlink_rm_denied"] = {
            "denied": exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS),
            "errno": exc.errno,
            "errnoName": errno.errorcode.get(exc.errno, str(exc.errno)),
        }

    # Probe 3: Rename/move frozen precommitted R3 oracle denied by kernel
    try:
        os.rename(target_oracle, str(target_oracle) + ".tampered")
        probes["probe3_rename_mv_denied"] = {"denied": False, "error": "RENAME_UNEXPECTEDLY_SUCCEEDED"}
    except OSError as exc:
        probes["probe3_rename_mv_denied"] = {
            "denied": exc.errno in (errno.EACCES, errno.EPERM, errno.EROFS),
            "errno": exc.errno,
            "errnoName": errno.errorcode.get(exc.errno, str(exc.errno)),
        }

    # Probe 4: chmod mode escalation on frozen oracle denied by kernel
    try:
        os.chmod(target_oracle, 0o666)
        probes["probe4_chmod_escalation_denied"] = {"denied": False, "error": "CHMOD_UNEXPECTEDLY_SUCCEEDED"}
    except OSError as exc:
        probes["probe4_chmod_escalation_denied"] = {
            "denied": exc.errno in (errno.EPERM, errno.EACCES, errno.EROFS),
            "errno": exc.errno,
            "errnoName": errno.errorcode.get(exc.errno, str(exc.errno)),
        }

    # Probe 5: Non-interactive sudo privilege escalation denied
    sudo_proc = subprocess.run(
        ["sudo", "-n", "true"],
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    probes["probe5_sudo_escalation_denied"] = {
        "denied": sudo_proc.returncode != 0,
        "sudoExitCode": sudo_proc.returncode,
    }

    post_lean_sz, post_lean_sha = sha256_file(target_lean)
    post_orc_sz, post_orc_sha = sha256_file(target_oracle)
    immut_ok = (
        (pre_lean_sz, pre_lean_sha) == (post_lean_sz, post_lean_sha)
        and (pre_orc_sz, pre_orc_sha) == (post_orc_sz, post_orc_sha)
    )

    all_probes_denied = all(p.get("denied") is True for p in probes.values())
    all_ok = identity_ok and ownership_and_mode_ok and all_probes_denied and immut_ok

    out = {
        "schemaId": "principia.omega.p1b2b.b4.act_i1_r3.linux_principal_isolation.v1",
        "replayId": args.replay_id,
        "verifiedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "principalIdentity": {
            "username": uname,
            "uid": uid,
            "euid": euid,
            "gid": gid,
            "egid": egid,
            "supplementaryGroups": gnames,
            "disjointFromRootRunnerAndSudoGroups": identity_ok,
        },
        "lockedBundleOwnershipAndPermissions": {
            "bundleRoot": str(bundle_root),
            "bundleRootOwnerUid": st_root.st_uid,
            "bundleRootModeOctal": oct(stat.S_IMODE(st_root.st_mode)),
            "targetKernelFileModeOctal": oct(stat.S_IMODE(st_lean.st_mode)),
            "targetOracleFileModeOctal": oct(stat.S_IMODE(st_orc.st_mode)),
            "verifiedRootOwned0555DirsAnd0444Files": ownership_and_mode_ok,
        },
        "fiveKernelDenialProbes": probes,
        "postProbeByteImmutability": {
            "targetKernelSha256Unchanged": (pre_lean_sha == post_lean_sha),
            "targetOracleSha256Unchanged": (pre_orc_sha == post_orc_sha),
        },
        "allPrincipalIsolationProbesPassed": all_ok,
    }
    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    args.out_json.write_bytes((json.dumps(out, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))
    print(f"LINUX_PRINCIPAL_ISOLATION id={args.replay_id} all_ok={all_ok} uid={uid} user={uname}")
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
