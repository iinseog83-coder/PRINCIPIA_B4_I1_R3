/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — Certified G56 Coupling Kernel (Formalization Act I0)
  Executable: AuditB3G56Axioms.lean (`I0-A10` Whitebox `Lean.Environment`, TCB & DAG Auditor)

  Audits 100% of `OmegaCellC1P1B2BB3` module-owned constants (including `private` helpers):
    1. Exact Lean version (`4.33.1`), strict module allowlist (`b3Modules7 ++ b2Modules5 ++ ancestorModules21`),
       and ZERO `GPED` / unauthorized `B4` / `P1C` modules.
    2. Zero `sorryAx`, zero `Lean.ofReduceBool` / `Lean.trustCompiler`, and zero custom `axiom`
       declarations (`⊆ {propext, Classical.choice, Quot.sound}`), reporting exact axioms used
       by every `B3` headline theorem (`i0_theorem_ledger.json`).
    3. Zero `unsafe`, zero `opaque`, and zero unjustified `partial` declarations across `B3`.
    4. Anti-circularity check (`Cone*(S_sem_B3) ∩ K_exec_all = ∅`): verifies that all 6 declarative
       `S_sem_B3` predicates contain ZERO references to any executable checker in `P1B1..B3`.
    5. Direct-lookup bypass ban: verifies that `B3` core evaluators contain ZERO direct calls to
       `lookupDagNode?` or `lookupPrimPrem?` (all proof verification goes through frozen `A0`/`B1`/`B2`/`G7` gates).
    6. Private constructor sealing (`F-B3-T17-02`, `F-B3-T18-01`): verifies at the `Lean.Environment`
       level that `G56QualifiedRecord` has `private` constructor (`isPrivateName = true`).
    7. Extracts the complete `OmegaCellC1P1B2BB3` declaration Dependency DAG (`i0_dependency_dag.json`)
       and full TCB audit receipt (`i0_axiom_and_tcb_audit.json`).
-/
import Lean
import OmegaCellC1P1B2BB3

open Lean
open OmegaCellC1P1B2BB3

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def b3Modules7 : List Name := [
  `OmegaCellC1P1B2BB3.B3_01_TransitionTypesAndPullback,
  `OmegaCellC1P1B2BB3.B3_02_SharedContextAndJointClosure,
  `OmegaCellC1P1B2BB3.B3_03_G7L1LossEquivalence,
  `OmegaCellC1P1B2BB3.B3_04_DiagnosticsAndMasterSoundness,
  `OmegaCellC1P1B2BB3.B3_05_ReificationAndTemporalInvalidation,
  `OmegaCellC1P1B2BB3.B3_06_SoundnessSuiteAndMutants,
  `OmegaCellC1P1B2BB3
]

def b2Modules5 : List Name := [
  `OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification,
  `OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure,
  `OmegaCellC1P1B2BB2.B2_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB2
]

def ancestorModules21 : List Name := [
  `OmegaCellC1P1A0.P1A0A_BaseChartGuard,
  `OmegaCellC1P1A0.P1A0B_TransportScopeLoss,
  `OmegaCellC1P1A0.P1A0C_CheckerQualification,
  `OmegaCellC1P1A0,
  `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
  `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness,
  `OmegaCellC1P1B1,
  `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
  `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
  `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
  `OmegaCellC1P1B2A,
  `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
  `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
  `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
  `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
  `OmegaCellC1P1B2BA0,
  `OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers,
  `OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure,
  `OmegaCellC1P1B2BB1.B1_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB1
]

def b3HeadlineTheorems : List (Name × String) := [
  -- I0-A1: Relational Transition Space & Pullback (B3_01)
  (`OmegaCellC1P1B2BB3.T_I0_A1_01_G5TransitionProjectionExact, "I0-A1"),
  (`OmegaCellC1P1B2BB3.T_I0_A1_02_G6RelationalWitnessBinding, "I0-A1"),
  (`OmegaCellC1P1B2BB3.T_I0_A1_03_PullbackCoupledTransitionCoherence, "I0-A1"),
  (`OmegaCellC1P1B2BB3.T_I0_A1_04_ContextAssignedEpochSemantics, "I0-A1"),
  (`OmegaCellC1P1B2BB3.T_I0_A1_05_G6ReflexKindNonUniquenessCounterexample, "I0-A1"),
  -- I0-A2 & I0-A3: Shared Context & Exact Joint Closure (B3_02)
  (`OmegaCellC1P1B2BB3.T_I0_A2_01_PacketContextExactSharedIdentity, "I0-A2"),
  (`OmegaCellC1P1B2BB3.T_I0_A2_02_SyntacticEnvDoesNotImplySemValidPrim, "I0-A2"),
  (`OmegaCellC1P1B2BB3.nodup_of_pairwise_strStrictLt, "I0-A3"),
  (`OmegaCellC1P1B2BB3.pairwise_strStrictLt_ext, "I0-A3"),
  (`OmegaCellC1P1B2BB3.canonSortStrs_eq_iff_mem, "I0-A3"),
  (`OmegaCellC1P1B2BB3.multiRootTransitivePrimDeps_append_eq, "I0-A3"),
  (`OmegaCellC1P1B2BB3.T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure, "I0-A3"),
  (`OmegaCellC1P1B2BB3.T_I0_A3_02_SemanticPremiseDistributionAndConfinement, "I0-A3"),
  (`OmegaCellC1P1B2BB3.T_I0_A3_03_JointProofRootsContainAllSubRoots, "I0-A3"),
  (`OmegaCellC1P1B2BB3.T_I0_A3_04_OutsideJointPremiseFormulaNonInterference, "I0-A3"),
  -- I0-A4: Multi-Item G7 L1 Loss Equivalence & Non-Circular Root Completeness (B3_03 & B3_04)
  (`OmegaCellC1P1B2BB3.T_I0_A4_01_RootCollectionCompleteness_NonCircular, "I0-A4"),
  (`OmegaCellC1P1B2BB3.T_I0_A4_02_SingleItemL1LossEquiv_Conditional_Sound, "I0-A4"),
  (`OmegaCellC1P1B2BB3.T_I0_A4_03_MultiItemConstrainedLossEquiv_CompleteSuiteSound, "I0-A4"),
  (`OmegaCellC1P1B2BB3.T_I0_A4_04_RetreatIncompatibleWithNonShrinkingG6Policy, "I0-A4"),
  (`OmegaCellC1P1B2BB3.T_I0_A4_05_TopLevelForcesConstrainedL1Path, "I0-A4"),
  -- I0-A5 & I0-A6: Diagnostic Reflection & Unified Master Conditional Soundness (B3_04)
  (`OmegaCellC1P1B2BB3.T_I0_A5_01_EvalDetailedNotApplicableIffNotApplicable, "I0-A5"),
  (`OmegaCellC1P1B2BB3.T_I0_A5_02_ProjectedVerdictEnforcesApplicableEvaluatedPass, "I0-A5"),
  (`OmegaCellC1P1B2BB3.T_I0_A5_03_CheckG56DiagnosticReflection, "I0-A5"),
  (`OmegaCellC1P1B2BB3.T_I0_A5_04_CoupledViolationSoundnessPreserved, "I0-A5"),
  (`OmegaCellC1P1B2BB3.T_I0_A6_G56_MasterConditionalSoundness, "I0-A6"),
  -- I0-A7 & I0-A8: 4-Way Dependent Reification & Order-Theoretic Monotone Invalidation (B3_05)
  (`OmegaCellC1P1B2BB3.T_I0_A7_EXISTENCE, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A7_TOTALITY, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A7_UNIQUENESS, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A7_ROUNDTRIP, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A7_CE01_ExistenceDoesNotImplyUniquenessOnUncanonicalRecord, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A7_ZeroAuthorityAndNoFullReflex, "I0-A7"),
  (`OmegaCellC1P1B2BB3.T_I0_A8_01_StepRetractionMonotone, "I0-A8"),
  (`OmegaCellC1P1B2BB3.T_I0_A8_02_FoldAppendRetractionSubset, "I0-A8"),
  (`OmegaCellC1P1B2BB3.T_I0_A8_03_CoupledActiveMonotoneInvalidation, "I0-A8"),
  (`OmegaCellC1P1B2BB3.T_I0_A8_04_RecordActiveMonotoneInvalidation, "I0-A8"),
  -- I0-A9: Complete 71-Case Soundness & 12-Mutant Kill Suites (B3_06)
  (`OmegaCellC1P1B2BB3.T_I0_A9_R0_PositiveSuite_All11VerifiedAndSound, "I0-A9"),
  (`OmegaCellC1P1B2BB3.T_I0_A9_R0_CounterexampleSuite_All27Verified, "I0-A9"),
  (`OmegaCellC1P1B2BB3.T_I0_A9_R1_Suite_All17Verified, "I0-A9"),
  (`OmegaCellC1P1B2BB3.T_I0_A9_I0_Suite_All16Verified, "I0-A9"),
  (`OmegaCellC1P1B2BB3.T_I0_A9_MutationFuzzSuite_All12Killed, "I0-A9"),
  (`OmegaCellC1P1B2BB3.T_I0_A9_All71AndAll12TablesComplete, "I0-A9")
]

def b3SemanticAnchors : List Name := [
  `OmegaCellC1P1B2BB3.G6TransitionCompatibleRel,
  `OmegaCellC1P1B2BB3.IsNonShrinkingG6Policy,
  `OmegaCellC1P1B2BB3.IsReferencedLossEquivNodeId,
  `OmegaCellC1P1B2BB3.SemValidG56TransitionBinding,
  `OmegaCellC1P1B2BB3.SemCompatibleG56Scope,
  `OmegaCellC1P1B2BB3.SemValidG56Coupling
]

def allExecutableCheckers : List Name := [
  `OmegaCellC1P1B1.checkG3Matrix,
  `OmegaCellC1P1B1.reifyTransportCode,
  `OmegaCellC1P1B2A.evalPartExprFuel,
  `OmegaCellC1P1B2A.evalStrictFormFuel,
  `OmegaCellC1P1B2A.evalPartExprGrid,
  `OmegaCellC1P1B2A.evalStrictFormGrid,
  `OmegaCellC1P1B2A.checkAlgDomCertBool,
  `OmegaCellC1P1B2A.checkExprDefUnderNzBool,
  `OmegaCellC1P1B2A.checkFormDefUnderNzBool,
  `OmegaCellC1P1B2A.checkGuardsPrefixDefinedAux,
  `OmegaCellC1P1B2A.verifyReachableDerivation,
  `OmegaCellC1P1B2A.checkCertifiedG7BundleBool,
  `OmegaCellC1P1B2BA0.intrinsicNzOfDom,
  `OmegaCellC1P1B2BA0.checkGuardsAndGoalDomDefBool,
  `OmegaCellC1P1B2BA0.isAtomicStrictFormBool,
  `OmegaCellC1P1B2BA0.checkBaseDomRetreatStepBool,
  `OmegaCellC1P1B2BA0.checkWellFormedParamSpecBool,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced,
  `OmegaCellC1P1B2BA0.exprUsesVarYBool,
  `OmegaCellC1P1B2BA0.formUsesVarYBool,
  `OmegaCellC1P1B2BB1.checkRatCoordWfBool,
  `OmegaCellC1P1B2BB1.evalPartExprRatCoord,
  `OmegaCellC1P1B2BB1.evalStrictFormRatCoord,
  `OmegaCellC1P1B2BB1.checkInG7DomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkGuardsSatRatCoordBool,
  `OmegaCellC1P1B2BB1.checkInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkNotInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkModelsExcisedRatCoordBool,
  `OmegaCellC1P1B2BB1.collectG5ProofRootIds,
  `OmegaCellC1P1B2BB1.deriveG5PrimDeps,
  `OmegaCellC1P1B2BB1.checkVerifiedObstructionBool,
  `OmegaCellC1P1B2BB1.checkRepairDomEqBool,
  `OmegaCellC1P1B2BB1.checkRetreatExactPartitionBool,
  `OmegaCellC1P1B2BB1.checkRefinementBool,
  `OmegaCellC1P1B2BB1.checkG5CoreProofsBool,
  `OmegaCellC1P1B2BB1.checkG5DischargeBool,
  `OmegaCellC1P1B2BB2.collectItemG6ProofRootIds,
  `OmegaCellC1P1B2BB2.collectG6ProofRootIds,
  `OmegaCellC1P1B2BB2.deriveG6PrimDeps,
  `OmegaCellC1P1B2BB2.checkG6ParamBindingWfBool,
  `OmegaCellC1P1B2BB2.checkG6ScopeLossRecordBool,
  `OmegaCellC1P1B2BB2.checkG6ItemScopeBool,
  `OmegaCellC1P1B2BB2.evalSingleG6Item,
  `OmegaCellC1P1B2BB2.evalG6ItemsList,
  `OmegaCellC1P1B2BB2.checkG6SuiteHeaderBasicBool,
  `OmegaCellC1P1B2BB2.evalG6SuiteCore,
  `OmegaCellC1P1B2BB2.checkG6Suite,
  `OmegaCellC1P1B2BB2.isG6SuiteVerifiedBool,
  `OmegaCellC1P1B2BB2.qualifyG6Isolated?,
  `OmegaCellC1P1B2BB3.checkG56PacketContextError?,
  `OmegaCellC1P1B2BB3.collectLossEquivRootIds,
  `OmegaCellC1P1B2BB3.collectScopeCompatLossRootIds,
  `OmegaCellC1P1B2BB3.collectG56JointProofRootIds,
  `OmegaCellC1P1B2BB3.deriveG56JointPrimDeps,
  `OmegaCellC1P1B2BB3.deriveScopeCompatL1PrimDeps,
  `OmegaCellC1P1B2BB3.checkDirectionalLocusCoverBool,
  `OmegaCellC1P1B2BB3.checkSingleL1LossEquivBool,
  `OmegaCellC1P1B2BB3.checkSingleL1LossEquivConstrainedBool,
  `OmegaCellC1P1B2BB3.checkSingleRetreatItemLossPair,
  `OmegaCellC1P1B2BB3.checkAllItemsRetreatLossConstrainedBool,
  `OmegaCellC1P1B2BB3.evalG56BindingDiag,
  `OmegaCellC1P1B2BB3.evalG56ScopeDiag,
  `OmegaCellC1P1B2BB3.evalG56DepsDiagValid,
  `OmegaCellC1P1B2BB3.evalG56DetailedR1,
  `OmegaCellC1P1B2BB3.projectCoupledVerdictR1,
  `OmegaCellC1P1B2BB3.checkG56Coupling,
  `OmegaCellC1P1B2BB3.checkG56PacketWithContext,
  `OmegaCellC1P1B2BB3.isG56CouplingVerifiedBool,
  `OmegaCellC1P1B2BB3.reifyVerifiedG56,
  `OmegaCellC1P1B2BB3.qualifyG56Coupled?,
  `OmegaCellC1P1B2BB3.checkActiveG56CouplingBool,
  `OmegaCellC1P1B2BB3.checkActiveG56RecordBool
]

def b3CoreEvaluators : List Name := [
  `OmegaCellC1P1B2BB3.checkDirectionalLocusCoverBool,
  `OmegaCellC1P1B2BB3.checkSingleL1LossEquivBool,
  `OmegaCellC1P1B2BB3.checkSingleL1LossEquivConstrainedBool,
  `OmegaCellC1P1B2BB3.checkSingleRetreatItemLossPair,
  `OmegaCellC1P1B2BB3.checkAllItemsRetreatLossConstrainedBool,
  `OmegaCellC1P1B2BB3.evalG56BindingDiag,
  `OmegaCellC1P1B2BB3.evalG56ScopeDiag,
  `OmegaCellC1P1B2BB3.evalG56DepsDiagValid,
  `OmegaCellC1P1B2BB3.evalG56DetailedR1,
  `OmegaCellC1P1B2BB3.projectCoupledVerdictR1,
  `OmegaCellC1P1B2BB3.checkG56Coupling,
  `OmegaCellC1P1B2BB3.reifyVerifiedG56,
  `OmegaCellC1P1B2BB3.qualifyG56Coupled?
]

def isCoreMod (m : Name) : Bool :=
  let r := m.getRoot
  r == `Init || r == `Std || r == `Lean

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

def isStructCtorPrivate (env : Environment) (indName : Name) : Bool :=
  match env.find? indName with
  | some (.inductInfo v) =>
      (!v.ctors.isEmpty) && v.ctors.all isPrivateName
  | _ => false

def constKindStr : ConstantInfo → String
  | .thmInfo _    => "theorem"
  | .defnInfo _   => "definition"
  | .inductInfo _ => "inductive"
  | .ctorInfo _   => "constructor"
  | .recInfo _    => "recursor"
  | .axiomInfo _  => "axiom"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _   => "quot"

def hasSubstr (s sub : String) : Bool :=
  (s.splitOn sub).length > 1

def isProjectDeclName (n : Name) : Bool :=
  let s := n.toString
  (s.startsWith "OmegaCellC1P1") &&
  !(hasSubstr s ".instDecidableEq" || hasSubstr s ".instRepr" ||
    hasSubstr s "._private" || s.endsWith ".rec" || s.endsWith ".casesOn" ||
    s.endsWith ".recOn" || s.endsWith ".noConfusion" || s.endsWith ".noConfusionType" ||
    s.endsWith ".inj" || s.endsWith ".injEq" || s.endsWith ".sizeOf_spec")

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def main : IO UInt32 := do
  initSearchPath (← findSysroot)
  let pubEnv ← importModules #[{ module := `OmegaCellC1P1B2BB3 }] {}
  let rawEnv ← importModules #[{ module := `OmegaCellC1P1B2BB3, importAll := true }] {}
  let env := rawEnv.setExporting false

  let allowedMods := b3Modules7 ++ b2Modules5 ++ ancestorModules21
  let mut unexpectedMods : List String := []
  let mut gpedMods : List String := []
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    let ms := m.toString
    if ms.startsWith "Gped" || ms.startsWith "Principia" then
      gpedMods := ms :: gpedMods
    if !(isCoreMod m || allowedMods.contains m) then
      unexpectedMods := ms :: unexpectedMods

  let mut pubB3Entries : List (Name × Name) := []
  for i in [:pubEnv.header.moduleNames.size] do
    let modName := pubEnv.header.moduleNames[i]!
    if b3Modules7.contains modName then
      for c in pubEnv.header.moduleData[i]!.constNames do
        match c with
        | .str (`OmegaCellC1P1B2BB3) nm =>
            if !(nm.startsWith "instDecidableEq" || nm.startsWith "instRepr" ||
                 nm.startsWith "_private" || nm.endsWith "_eq_1" || nm.endsWith "_cstage1") then
              pubB3Entries := (c, modName) :: pubB3Entries
        | _ => pure ()
  let sortedPubB3Entries := pubB3Entries.mergeSort (fun a b => a.1.toString < b.1.toString)
  let sortedPubB3 := sortedPubB3Entries.map (fun p => p.1.toString)

  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut b3OwnedConstCount : Nat := 0
  let mut badAxiomRefs : List String := []
  let mut sorryRefs : List String := []
  let mut customAxiomDefs : List String := []
  let mut nativeDecideTrustRefs : List String := []
  let mut unsafeConsts : List String := []
  let mut opaqueConsts : List String := []
  let mut unjustifiedPartialConsts : List String := []
  let mut justifiedUnsafeRecCount : Nat := 0

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if b3Modules7.contains m then
      let md := env.header.moduleData[i]!
      b3OwnedConstCount := b3OwnedConstCount + md.constNames.size
      for c in md.constNames do
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) c) env
        for a in axs do
          if a == `sorryAx then
            sorryRefs := c.toString :: sorryRefs
          if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
            nativeDecideTrustRefs := s!"{c} -> {a}" :: nativeDecideTrustRefs
          if !allowedAx.contains a then
            badAxiomRefs := s!"{c} -> {a}" :: badAxiomRefs
        match env.find? c with
        | none => badAxiomRefs := s!"MISSING:{c}" :: badAxiomRefs
        | some ci =>
            if ci.isUnsafe then
              unsafeConsts := c.toString :: unsafeConsts
            match ci with
            | .axiomInfo _  => customAxiomDefs := c.toString :: customAxiomDefs
            | .opaqueInfo _ => opaqueConsts := c.toString :: opaqueConsts
            | .defnInfo v   =>
                if v.safety == .partial then
                  match c with
                  | .str parent "_unsafe_rec" =>
                      match env.find? parent with
                      | some (.defnInfo pv) =>
                          if pv.safety == .safe then
                            justifiedUnsafeRecCount := justifiedUnsafeRecCount + 1
                          else
                            unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                      | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                  | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
            | _ => pure ()

  let mut missingHeadline : List String := []
  let mut headlineAxiomReport : List (String × Json) := []
  let mut theoremLedgerRows : Array Json := #[]
  for (thm, gateId) in b3HeadlineTheorems do
    match env.find? thm with
    | none => missingHeadline := thm.toString :: missingHeadline
    | some ci =>
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) thm) env
        let axStrs := (axs.toList.map Name.toString).mergeSort (· < ·)
        headlineAxiomReport := headlineAxiomReport ++ [(thm.toString, toJsonStrArr axStrs)]
        let modIdx? := env.getModuleIdxFor? thm
        let modStr := match modIdx? with
          | some idx => env.header.moduleNames[idx.toNat]!.toString
          | none     => "OmegaCellC1P1B2BB3"
        theoremLedgerRows := theoremLedgerRows.push (Json.mkObj [
          ("theoremName", Json.str thm.toString),
          ("gateId", Json.str gateId),
          ("module", Json.str modStr),
          ("kind", Json.str (constKindStr ci)),
          ("axioms", toJsonStrArr axStrs),
          ("zeroSorry", Json.bool (!axs.contains `sorryAx)),
          ("zeroCustomAxioms", Json.bool (axs.all allowedAx.contains))
        ])

  -- Build Declaration Dependency DAG across all public B3 declarations:
  let mut dagNodesJson : Array Json := #[]
  let mut dagEdgeCount : Nat := 0
  for (declName, modName) in sortedPubB3Entries do
    match env.find? declName with
    | none => pure ()
    | some ci =>
        let rawD := (directDeps env declName).toList.filter (fun d => d != declName && isProjectDeclName d)
        let b3Deps := ((rawD.filter (fun d => d.toString.startsWith "OmegaCellC1P1B2BB3.")).map Name.toString).mergeSort (· < ·) |>.eraseDups
        let ancDeps := ((rawD.filter (fun d => !d.toString.startsWith "OmegaCellC1P1B2BB3.")).map Name.toString).mergeSort (· < ·) |>.eraseDups
        dagEdgeCount := dagEdgeCount + b3Deps.length + ancDeps.length
        dagNodesJson := dagNodesJson.push (Json.mkObj [
          ("declaration", Json.str declName.toString),
          ("module", Json.str modName.toString),
          ("kind", Json.str (constKindStr ci)),
          ("directB3Deps", toJsonStrArr b3Deps),
          ("directAncestorDeps", toJsonStrArr ancDeps)
        ])

  let semCone := transitiveCone env b3SemanticAnchors
  let mut semCircularHits : List String := []
  for k in allExecutableCheckers do
    if semCone.contains k then
      semCircularHits := k.toString :: semCircularHits

  let mut directLookupBypassHits : List String := []
  for evFn in b3CoreEvaluators do
    let ddeps := directDeps env evFn
    if ddeps.contains `OmegaCellC1P1B2A.lookupDagNode? then
      directLookupBypassHits := s!"{evFn} -> lookupDagNode?" :: directLookupBypassHits
    if ddeps.contains `OmegaCellC1P1B2A.lookupPrimPrem? then
      directLookupBypassHits := s!"{evFn} -> lookupPrimPrem?" :: directLookupBypassHits

  let recordPrivateSealed := isStructCtorPrivate env `OmegaCellC1P1B2BB3.G56QualifiedRecord
  let leanVerExact := (Lean.versionString == "4.33.1")

  let allOk :=
    leanVerExact &&
    unexpectedMods.isEmpty &&
    gpedMods.isEmpty &&
    sorryRefs.isEmpty &&
    badAxiomRefs.isEmpty &&
    customAxiomDefs.isEmpty &&
    nativeDecideTrustRefs.isEmpty &&
    unsafeConsts.isEmpty &&
    opaqueConsts.isEmpty &&
    unjustifiedPartialConsts.isEmpty &&
    missingHeadline.isEmpty &&
    semCircularHits.isEmpty &&
    directLookupBypassHits.isEmpty &&
    recordPrivateSealed

  let evDir : System.FilePath := "../principia_omega_cell_c1_p1b2b_b3_g56_i0_evidence"

  let auditReport := Json.mkObj [
    ("auditSchema", Json.str "principia.omega.p1b2b.b3.i0_axiom_and_tcb_audit.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_FORMALIZATION_ACT_I0"),
    ("leanVersion", Json.str Lean.versionString),
    ("leanVersionExact_4_33_1", Json.bool leanVerExact),
    ("allChecksPassed", Json.bool allOk),
    ("b3ModuleCount", Json.num b3Modules7.length),
    ("allowedAncestorModuleCount", Json.num (b2Modules5.length + ancestorModules21.length)),
    ("b3OwnedConstantCount", Json.num b3OwnedConstCount),
    ("b3PublicDeclCount", Json.num sortedPubB3.length),
    ("headlineTheoremCount", Json.num b3HeadlineTheorems.length),
    ("missingHeadlineTheorems", toJsonStrArr missingHeadline),
    ("sorryAxReferences", toJsonStrArr sorryRefs),
    ("nativeDecideOrTrustCompilerRefs", toJsonStrArr nativeDecideTrustRefs),
    ("badAxiomRefs", toJsonStrArr badAxiomRefs),
    ("customAxiomDefs", toJsonStrArr customAxiomDefs),
    ("unsafeConsts", toJsonStrArr unsafeConsts),
    ("opaqueConsts", toJsonStrArr opaqueConsts),
    ("unjustifiedPartialConsts", toJsonStrArr unjustifiedPartialConsts),
    ("justifiedCompilerUnsafeRecCount", Json.num justifiedUnsafeRecCount),
    ("unexpectedModules", toJsonStrArr unexpectedMods),
    ("gpedModulesDetected", toJsonStrArr gpedMods),
    ("b3SemanticAnchors", toJsonStrArr (b3SemanticAnchors.map Name.toString)),
    ("b3SemanticConeSize", Json.num semCone.size),
    ("semanticCheckerCircularHits", toJsonStrArr semCircularHits),
    ("directLookupBypassHits", toJsonStrArr directLookupBypassHits),
    ("qualifiedRecordPrivateCtorSealed", Json.bool recordPrivateSealed),
    ("runtimeExecutionAuthority", Json.num 0),
    ("bSeriesExecutionAuthority", Json.num 0),
    ("officialRegistryAndB4P1CStatus", Json.str "HELD")
  ]

  let theoremLedgerJson := Json.mkObj [
    ("ledgerSchema", Json.str "principia.omega.p1b2b.b3.i0_theorem_ledger.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_FORMALIZATION_ACT_I0"),
    ("leanVersion", Json.str Lean.versionString),
    ("headlineTheoremCount", Json.num b3HeadlineTheorems.length),
    ("allZeroSorryAndStandardKernelAxiomsOnly", Json.bool (sorryRefs.isEmpty && badAxiomRefs.isEmpty && missingHeadline.isEmpty)),
    ("theorems", Json.arr theoremLedgerRows)
  ]

  let depDagJson := Json.mkObj [
    ("dagSchema", Json.str "principia.omega.p1b2b.b3.i0_dependency_dag.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_FORMALIZATION_ACT_I0"),
    ("leanVersion", Json.str Lean.versionString),
    ("moduleTopologicalOrder", toJsonStrArr (b3Modules7.map Name.toString)),
    ("publicDeclarationCount", Json.num dagNodesJson.size),
    ("projectDependencyEdgeCount", Json.num dagEdgeCount),
    ("semanticConeDisjointFromExecutableCheckers", Json.bool semCircularHits.isEmpty),
    ("nodes", Json.arr dagNodesJson)
  ]

  IO.FS.writeFile (evDir / "i0_axiom_and_tcb_audit.json") (auditReport.pretty ++ "\n")
  IO.FS.writeFile (evDir / "i0_theorem_ledger.json") (theoremLedgerJson.pretty ++ "\n")
  IO.FS.writeFile (evDir / "i0_dependency_dag.json") (depDagJson.pretty ++ "\n")

  IO.println auditReport.pretty
  return (if allOk then 0 else 1)
