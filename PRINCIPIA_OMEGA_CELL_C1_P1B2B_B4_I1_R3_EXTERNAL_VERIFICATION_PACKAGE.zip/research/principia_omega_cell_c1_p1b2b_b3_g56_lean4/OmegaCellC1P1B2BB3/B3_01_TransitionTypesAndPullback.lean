/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — G56 Certified Coupling Kernel (`Formalization Act I0`)
  Module: OmegaCellC1P1B2BB3.B3_01_TransitionTypesAndPullback

  Authorization: Human L4 Final Freeze (`SCOPED_STATIC_BASELINE_FROZEN`) & `FORMALIZATION_ACT_I0`
  Gates Covered:
    - `I0-A1`: Context-Assigned Evaluation Epoch (`F-B3-T17-01`), Relational `Ĝ6` Enhancement
      (`F-B3-T17-03`, `Q-B3-R1-01` — surjectivity onto full `T` NOT claimed and constructively
      refuted on `CE-R1-04`), Type-level `G56RelationalPullback`, and Theorems `T_I0_A1_01 .. 05`.
    - Core syntactic certificate, `L0/L1` per-item loss-equivalence (`F-B3-T18-02`), product
      `DiagnosticObservation` (`F-B3-T17-04`, `Q-B3-R1-02`), and 7-branch `G56CoupledVerdict` types.
    - Pure non-circular declarative semantics `S_sem_B3` (`0` executable checker calls!).
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1
import OmegaCellC1P1B2A
import OmegaCellC1P1B2BA0
import OmegaCellC1P1B2BB1
import OmegaCellC1P1B2BB2

namespace OmegaCellC1P1B2BB3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2

/-! ### 1. Transition Binding, Context-Assigned Epoch, & Relational Pullback (`I0-A1`) -/

/-- Core epoch-free 6-identifier transition key shared by `G5DischargeCert` and `G6ProtectedSuite`. -/
structure G56CoreTransitionKey where
  baseId     : String
  rflxCid    : String
  cellOldCid : String
  cellNewCid : String
  specOldId  : String
  specNewId  : String
  deriving DecidableEq, Repr

/-- **Mandatory Type 1 (`G56TransitionBinding` — `C-B3-01`, `F-B3-T17-01`)**:
    Canonical transition contract binding transition IDs, `assignedEvalEpoch`
    (`Context-Assigned Evaluation Epoch`), pre/post domain carriers, `reflexKind`,
    and `requiresRetreatHistory`. -/
structure G56TransitionBinding where
  baseId                 : String
  rflxCid                : String
  cellOldCid             : String
  cellNewCid             : String
  specOldId              : String
  specNewId              : String
  assignedEvalEpoch      : Nat
  domOld                 : G7DomTag
  guardsOld              : List StrictForm
  domNew                 : G7DomTag
  guardsNew              : List StrictForm
  reflexKind             : ReflexKind
  requiresRetreatHistory : Bool
  deriving DecidableEq, Repr

/-- Backward-compatible read-only projection alias for `assignedEvalEpoch`. -/
abbrev G56TransitionBinding.evaluationEpoch (b : G56TransitionBinding) : Nat :=
  b.assignedEvalEpoch

/-- Forgetful projection `G56TransitionBinding → G56CoreTransitionKey`. -/
def G56TransitionBinding.toCoreKey (b : G56TransitionBinding) : G56CoreTransitionKey where
  baseId     := b.baseId
  rflxCid    := b.rflxCid
  cellOldCid := b.cellOldCid
  cellNewCid := b.cellNewCid
  specOldId  := b.specOldId
  specNewId  := b.specNewId

/-- **`G5ContextAssignedEpochCert` (`F-B3-T17-01`, `R1-A1`)**:
    Pairs an unmodified frozen `G5DischargeCert` with an evaluation epoch supplied by the
    coupling context. Does NOT claim creation-epoch provenance or cross-epoch replay uniqueness (`HELD`). -/
structure G5ContextAssignedEpochCert where
  cert              : G5DischargeCert
  assignedEvalEpoch : Nat
  deriving DecidableEq, Repr

/-- Alias preserving `R0` name `G5EpochAdaptedCert`. -/
abbrev G5EpochAdaptedCert : Type := G5ContextAssignedEpochCert

/-- Total canonical projection `π5_core : G5DischargeCert → G56CoreTransitionKey`. -/
def projectG5CoreKey (c5 : G5DischargeCert) : G56CoreTransitionKey where
  baseId     := c5.baseId
  rflxCid    := c5.rflxCid
  cellOldCid := c5.cellOldCid
  cellNewCid := c5.cellNewCid
  specOldId  := c5.specOldId
  specNewId  := c5.specNewId

/-- Total canonical projection `π6_core : G6ProtectedSuite → G56CoreTransitionKey`. -/
def projectG6CoreKey (s6 : G6ProtectedSuite) : G56CoreTransitionKey where
  baseId     := s6.baseId
  rflxCid    := s6.rflxCid
  cellOldCid := s6.cellOldCid
  cellNewCid := s6.cellNewCid
  specOldId  := s6.specOldId
  specNewId  := s6.specNewId

/-- Total full transition projection `π5 : G5ContextAssignedEpochCert → G56TransitionBinding`. -/
def projectG5Transition (a5 : G5ContextAssignedEpochCert) : G56TransitionBinding where
  baseId                 := a5.cert.baseId
  rflxCid                := a5.cert.rflxCid
  cellOldCid             := a5.cert.cellOldCid
  cellNewCid             := a5.cert.cellNewCid
  specOldId              := a5.cert.specOldId
  specNewId              := a5.cert.specNewId
  assignedEvalEpoch      := a5.assignedEvalEpoch
  domOld                 := a5.cert.domOld
  guardsOld              := a5.cert.guardsOld
  domNew                 := a5.cert.domNew
  guardsNew              := a5.cert.guardsNew
  reflexKind             := a5.cert.reflexKind
  requiresRetreatHistory := a5.cert.requiresRetreatHistory

/-- Pure declarative alignment relation `R6(s6, b)` (`F-B3-T17-03`, `Q-B3-R1-01`; `0` checker calls).
    Note: `s6` alone does NOT determine `b.reflexKind` uniquely! -/
def G6TransitionCompatibleRel (s6 : G6ProtectedSuite) (b : G56TransitionBinding) : Prop :=
  projectG6CoreKey s6 = b.toCoreKey ∧
  s6.evaluationEpoch = b.assignedEvalEpoch ∧
  s6.items ≠ [] ∧
  (∀ item ∈ s6.items,
    item.specId = b.specNewId ∧
    item.oldNewState.specOldId = b.specOldId ∧
    item.oldNewState.specNewId = b.specNewId ∧
    item.oldNewState.domOld = b.domOld ∧
    item.oldNewState.guardsOld = b.guardsOld ∧
    item.oldNewState.domNew = b.domNew ∧
    item.oldNewState.guardsNew = b.guardsNew ∧
    item.protectedDomain = b.domNew ∧
    item.protectedGuards = b.guardsNew) ∧
  match b.reflexKind with
  | .repair =>
      b.requiresRetreatHistory = false ∧
      ∀ item ∈ s6.items, item.scopeLossRecord? = none
  | .refinement =>
      b.requiresRetreatHistory = false ∧
      ∀ item ∈ s6.items, item.scopeLossRecord? = none
  | .retreat =>
      b.requiresRetreatHistory = true ∧
      ∀ item ∈ s6.items,
        item.oldNewState.scopePolicy = .retreatWithLossAccounting ∧
        item.scopeLossRecord? ≠ none

/-- Relationally enhanced `G6` carrier `Ĝ6 = Σ (s6 : G6) (b : T), R6(s6, b)` (`F-B3-T17-03`). -/
structure RelationallyBoundG6Suite where
  suite   : G6ProtectedSuite
  binding : G56TransitionBinding
  hRel    : G6TransitionCompatibleRel suite binding

/-- Total 2nd-component projection `π̂6 : Ĝ6 → T` (`Q-B3-R1-01`: NEVER claimed surjective onto all `T`!). -/
def projectRelBoundG6 (g6hat : RelationallyBoundG6Suite) : G56TransitionBinding :=
  g6hat.binding

/-- Concrete Type-level relational pullback `P56 = Σ (a : G5^ep) (g : Ĝ6), π5(a) = π̂6(g)`. -/
def G56RelationalPullback : Type :=
  { pair : G5ContextAssignedEpochCert × RelationallyBoundG6Suite //
      projectG5Transition pair.1 = projectRelBoundG6 pair.2 }

/-- First pullback projection `p1 : P56 → G5^ep`. -/
def pullbackProjG5 (p : G56RelationalPullback) : G5ContextAssignedEpochCert :=
  p.1.1

/-- Second pullback projection `p2 : P56 → Ĝ6`. -/
def pullbackProjG6 (p : G56RelationalPullback) : RelationallyBoundG6Suite :=
  p.1.2

/-- Universal mediating map into `G56RelationalPullback` for any cone `(f5, f6)` with `π5 ∘ f5 = π̂6 ∘ f6`. -/
def liftToG56RelationalPullback {X : Type}
    (f5 : X → G5ContextAssignedEpochCert)
    (f6 : X → RelationallyBoundG6Suite)
    (hComm : ∀ x : X, projectG5Transition (f5 x) = projectRelBoundG6 (f6 x)) :
    X → G56RelationalPullback :=
  fun x => ⟨(f5 x, f6 x), hComm x⟩

/-! ### 2. Mandatory `I0-A1` Theorems (`T_I0_A1_01 .. T_I0_A1_05`) -/

/-- **`T_I0_A1_01` — G5 Transition Projection Exactness & Induced Kernel Equivalence**:
    (1) `(projectG5Transition a5).toCoreKey = projectG5CoreKey a5.cert`;
    (2) `(projectG5Transition a5).assignedEvalEpoch = a5.assignedEvalEpoch`;
    (3) Same-transition relation `projectG5Transition a1 = projectG5Transition a2` is an `Equivalence`. -/
theorem T_I0_A1_01_G5TransitionProjectionExact :
    (∀ a5 : G5ContextAssignedEpochCert,
       (projectG5Transition a5).toCoreKey = projectG5CoreKey a5.cert ∧
       (projectG5Transition a5).assignedEvalEpoch = a5.assignedEvalEpoch ∧
       (projectG5Transition a5).domOld = a5.cert.domOld ∧
       (projectG5Transition a5).guardsOld = a5.cert.guardsOld ∧
       (projectG5Transition a5).domNew = a5.cert.domNew ∧
       (projectG5Transition a5).guardsNew = a5.cert.guardsNew ∧
       (projectG5Transition a5).reflexKind = a5.cert.reflexKind ∧
       (projectG5Transition a5).requiresRetreatHistory = a5.cert.requiresRetreatHistory) ∧
    Equivalence (fun a1 a2 : G5ContextAssignedEpochCert =>
      projectG5Transition a1 = projectG5Transition a2) := by
  refine ⟨fun _ => ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩, ?_⟩
  exact {
    refl  := fun _ => rfl
    symm  := fun h => h.symm
    trans := fun h1 h2 => h1.trans h2
  }

/-- Constructive transition witness in `T` with NO compatible `G6ProtectedSuite` (`CE-R1-04`). -/
def inconsistentRepairRetreatBinding : G56TransitionBinding where
  baseId                 := "base_Q"
  rflxCid                := "rflx_ce_r1_04"
  cellOldCid             := "cell_old_04"
  cellNewCid             := "cell_new_04"
  specOldId              := "spec_old_04"
  specNewId              := "spec_new_04"
  assignedEvalEpoch      := 10
  domOld                 := .domQ
  guardsOld              := []
  domNew                 := .domQ
  guardsNew              := []
  reflexKind             := .repair
  requiresRetreatHistory := true

/-- **`T_I0_A1_02` — Relational `G6` Witness Binding & Non-Surjectivity Onto Full `T` (`Q-B3-R1-01`)**:
    (1) Every `g : RelationallyBoundG6Suite` projects via `projectRelBoundG6` to `g.binding` and
        carries `G6TransitionCompatibleRel g.suite (projectRelBoundG6 g)`;
    (2) `projectRelBoundG6` is surjective onto its relational image `{ b | ∃ s6, G6TransitionCompatibleRel s6 b }`;
    (3) `projectRelBoundG6` is NOT surjective onto full `G56TransitionBinding` (`CE-R1-04`). -/
theorem T_I0_A1_02_G6RelationalWitnessBinding :
    (∀ g : RelationallyBoundG6Suite,
       projectRelBoundG6 g = g.binding ∧
       G6TransitionCompatibleRel g.suite (projectRelBoundG6 g)) ∧
    (∀ b : G56TransitionBinding,
       (∃ s6 : G6ProtectedSuite, G6TransitionCompatibleRel s6 b) ↔
       (∃ g : RelationallyBoundG6Suite, projectRelBoundG6 g = b)) ∧
    (∃ b_bad : G56TransitionBinding,
       ∀ s6 : G6ProtectedSuite, ¬ G6TransitionCompatibleRel s6 b_bad) := by
  refine ⟨fun g => ⟨rfl, g.hRel⟩, ?_, ?_⟩
  · intro b
    constructor
    · rintro ⟨s6, hRel⟩
      exact ⟨⟨s6, b, hRel⟩, rfl⟩
    · rintro ⟨g, rfl⟩
      exact ⟨g.suite, g.hRel⟩
  · refine ⟨inconsistentRepairRetreatBinding, ?_⟩
    intro s6 hRel
    rcases hRel with ⟨_, _, _, _, hMode⟩
    dsimp [inconsistentRepairRetreatBinding] at hMode
    exact Bool.noConfusion hMode.1

/-- **`T_I0_A1_03` — Pullback Transition Coherence & Type-Level Universal Property**:
    (1) Every `p : G56RelationalPullback` equates `projectG5Transition (pullbackProjG5 p)` and
        `projectRelBoundG6 (pullbackProjG6 p)` and guarantees `G6TransitionCompatibleRel`;
    (2) For every type `X` and commuting cone `(f5, f6)`, `liftToG56RelationalPullback` is the
        UNIQUE mediating map `u : X → G56RelationalPullback` factoring `f5` and `f6`. -/
theorem T_I0_A1_03_PullbackCoupledTransitionCoherence :
    (∀ p : G56RelationalPullback,
       projectG5Transition (pullbackProjG5 p) = projectRelBoundG6 (pullbackProjG6 p) ∧
       G6TransitionCompatibleRel (pullbackProjG6 p).suite
         (projectG5Transition (pullbackProjG5 p))) ∧
    (∀ {X : Type} (f5 : X → G5ContextAssignedEpochCert)
       (f6 : X → RelationallyBoundG6Suite)
       (hComm : ∀ x : X, projectG5Transition (f5 x) = projectRelBoundG6 (f6 x)),
       let m := liftToG56RelationalPullback f5 f6 hComm
       (∀ x : X, pullbackProjG5 (m x) = f5 x ∧ pullbackProjG6 (m x) = f6 x) ∧
       (∀ m' : X → G56RelationalPullback,
         (∀ x : X, pullbackProjG5 (m' x) = f5 x ∧ pullbackProjG6 (m' x) = f6 x) →
         ∀ x : X, m' x = m x)) := by
  refine ⟨?_, ?_⟩
  · intro p
    refine ⟨p.2, ?_⟩
    unfold pullbackProjG5
    rw [p.2]
    exact (pullbackProjG6 p).hRel
  · intro X f5 f6 hComm
    refine ⟨fun _ => ⟨rfl, rfl⟩, ?_⟩
    intro m' hm' x
    apply Subtype.ext
    exact Prod.ext (hm' x).1 (hm' x).2

/-- **`T_I0_A1_04` — Context-Assigned Evaluation Epoch Semantics (`F-B3-T17-01`, `CE-R1-01`)**:
    Attaching distinct context epochs `e1 ≠ e2` to the same timeless `c5 : G5DischargeCert`
    produces distinct adapted pairs and distinct `G56TransitionBinding`s while leaving the
    underlying mathematical certificate `c5` and its core transition key untouched. -/
theorem T_I0_A1_04_ContextAssignedEpochSemantics
    (c5 : G5DischargeCert) (e1 e2 : Nat) :
    (⟨c5, e1⟩ : G5ContextAssignedEpochCert).cert = c5 ∧
    (⟨c5, e2⟩ : G5ContextAssignedEpochCert).cert = c5 ∧
    (projectG5Transition ⟨c5, e1⟩).toCoreKey = (projectG5Transition ⟨c5, e2⟩).toCoreKey ∧
    ((⟨c5, e1⟩ : G5ContextAssignedEpochCert) = ⟨c5, e2⟩ ↔ e1 = e2) ∧
    (projectG5Transition ⟨c5, e1⟩ = projectG5Transition ⟨c5, e2⟩ ↔ e1 = e2) := by
  refine ⟨rfl, rfl, rfl, ?_, ?_⟩
  · constructor
    · intro h; injection h
    · intro h; subst h; rfl
  · constructor
    · intro h
      exact congrArg G56TransitionBinding.assignedEvalEpoch h
    · intro h; subst h; rfl

/-- Constructive suite witness `s6` compatible with BOTH `.repair` and `.refinement` (`CE-R1-03`). -/
def a1AmbiguousSameScopeSuite : G6ProtectedSuite :=
  let φ : StrictForm := .pos (.add (.mul .varX .varX) (.const 1))
  let st : G6OldNewStateBinding := {
    specOldId               := "spec_amb_old"
    domOld                  := .domQ
    guardsOld               := []
    formOldInst             := φ
    oldBaselineProofNodeId? := none
    specNewId               := "spec_amb_new"
    domNew                  := .domQ
    guardsNew               := []
    newGuardsDefNodeId?     := none
    formNewInst             := φ
    postDomNonEmptyWitness  := ratCoordOfInt2 0 0
    scopePolicy             := .globalPostSameDom ⟨.sameBaseDom .domQ, none, [], [], none⟩
  }
  let item : G6ProtectedInvariantSpec := {
    invariantId      := "inv_amb_01"
    specId           := "spec_amb_new"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := .fixedStateForm φ
    parameterBinding := .noParam
    versionEpoch     := ⟨"v1", 1, 100, false⟩
    evidenceRoots    := ⟨.claimVerified "n_amb_01", ["n_amb_01"]⟩
    registryOrigin   := ⟨"reg_amb", "cell_amb_old", "rec_amb", false⟩
    oldNewState      := st
    scopeLossRecord? := none
  }
  { suiteVersion         := "g6_b2_v1"
    suiteCid             := "suite_amb_01"
    rflxCid              := "rflx_amb_01"
    cellOldCid           := "cell_amb_old"
    cellNewCid           := "cell_amb_new"
    baseId               := "base_Q"
    specOldId            := "spec_amb_old"
    specNewId            := "spec_amb_new"
    evaluationEpoch      := 10
    emptySuitePolicy     := .forbidEmptySuite
    declaredInvariantIds := ["inv_amb_01"]
    items                := [item]
    claimedPrimDeps      := ⟨[]⟩ }

def a1BindingRepair : G56TransitionBinding where
  baseId                 := "base_Q"
  rflxCid                := "rflx_amb_01"
  cellOldCid             := "cell_amb_old"
  cellNewCid             := "cell_amb_new"
  specOldId              := "spec_amb_old"
  specNewId              := "spec_amb_new"
  assignedEvalEpoch      := 10
  domOld                 := .domQ
  guardsOld              := []
  domNew                 := .domQ
  guardsNew              := []
  reflexKind             := .repair
  requiresRetreatHistory := false

def a1BindingRefinement : G56TransitionBinding :=
  { a1BindingRepair with reflexKind := .refinement }

/-- **`T_I0_A1_05` — Non-Uniqueness of `ReflexKind` from `G6ProtectedSuite` Alone (`F-B3-T17-03`, `CE-R1-03`)**:
    `a1AmbiguousSameScopeSuite` simultaneously satisfies `G6TransitionCompatibleRel` for
    `a1BindingRepair` (`.repair`) AND `a1BindingRefinement` (`.refinement`), proving that no
    function `G6ProtectedSuite → G56TransitionBinding` can recover a unique `ReflexKind` without
    relational binding! -/
theorem T_I0_A1_05_G6ReflexKindNonUniquenessCounterexample :
    a1BindingRepair ≠ a1BindingRefinement ∧
    a1BindingRepair.reflexKind = .repair ∧
    a1BindingRefinement.reflexKind = .refinement ∧
    G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRepair ∧
    G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRefinement := by
  refine ⟨?_, rfl, rfl, ?_, ?_⟩
  · intro h
    have hrk := congrArg G56TransitionBinding.reflexKind h
    nomatch hrk
  · unfold G6TransitionCompatibleRel
    refine ⟨rfl, rfl, ?_, ?_, rfl, ?_⟩
    · intro h; dsimp [a1AmbiguousSameScopeSuite] at h; nomatch h
    · intro item hMem
      dsimp [a1AmbiguousSameScopeSuite] at hMem
      rcases List.mem_singleton.mp hMem with rfl
      exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩
    · intro item hMem
      dsimp [a1AmbiguousSameScopeSuite] at hMem
      rcases List.mem_singleton.mp hMem with rfl
      rfl
  · unfold G6TransitionCompatibleRel
    refine ⟨rfl, rfl, ?_, ?_, rfl, ?_⟩
    · intro h; dsimp [a1AmbiguousSameScopeSuite] at h; nomatch h
    · intro item hMem
      dsimp [a1AmbiguousSameScopeSuite] at hMem
      rcases List.mem_singleton.mp hMem with rfl
      exact ⟨rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl, rfl⟩
    · intro item hMem
      dsimp [a1AmbiguousSameScopeSuite] at hMem
      rcases List.mem_singleton.mp hMem with rfl
      rfl

/-! ### 3. Shared Context, `L0/L1` Per-Item Loss Binding, Coupled Certificate, & Product Diagnostics -/

/-- **Mandatory Type 3 (`G56SharedContext` — `C-B3-02`, `I0-A2`)**:
    Single shared verification context holding fuel budgets, ONE `PrimPremiseEnv`, and ONE `G7DagContainer`. -/
structure G56SharedContext where
  fuelG5  : Nat
  fuelG6  : Nat
  primEnv : PrimPremiseEnv
  dagCont : G7DagContainer
  deriving DecidableEq, Repr

/-- Structural integrity predicate on `PrimPremiseEnv` (`I0-A2`: strictly distinct from `SemValidPrimId`!). -/
abbrev SyntacticValidPrimEnv (Γ : PrimPremiseEnv) : Prop :=
  checkPrimEnvIntegrityBool Γ = true

/-- Boundary packet wrapper used to reject split `Γ5 ≠ Γ6` or `C5 ≠ C6` submissions (`CE-G56-04`, `CE-G56-05`). -/
structure G56UntrustedCandidatePacket where
  g5ClaimedEnv  : PrimPremiseEnv
  g5ClaimedCont : G7DagContainer
  g6ClaimedEnv  : PrimPremiseEnv
  g6ClaimedCont : G7DagContainer
  deriving DecidableEq, Repr

/-- **Mandatory Type 4 (`G56JointPrimDeps` — `C-B3-05`, `I0-A3`)**:
    Records `D5`, `D6`, and canonical deduplicated strictly-sorted union `D56 = D5 ∪ D6`. -/
structure G56JointPrimDeps where
  g5PrimDepIds    : List String
  g6PrimDepIds    : List String
  jointPrimDepIds : List String
  deriving DecidableEq, Repr

/-- **Mandatory Type 5 (`G56EvidenceBinding` — `C-B3-08`, `F-B3-T18-03`)**:
    Provenance manifest binding `G5` obst CID, `G6` suite CID, `R5`, `R6`, and canonical joint
    proof roots (including any `L1` `G7` loss-equivalence witness roots `R_w`!). -/
structure G56EvidenceBinding where
  g5ObstCid       : String
  g6SuiteCid      : String
  g5ProofRootIds  : List String
  g6ProofRootIds  : List String
  jointProofRoots : List String
  deriving DecidableEq, Repr

/-- Directional `L1` `G7` cover witness proving `ModelsExcised L_src ρ → ModelsExcised L_dst ρ`
    on `(D_old, Γ_old)` (`F-B3-T17-05`, `F-B3-T18-02`). -/
structure G56DirectionalLocusCover where
  /-- Each target branch `B_k ∈ L_dst` paired with `defNodeId` proving
      `⟨D_old, specNewId, Γ_old ++ B_k, .eqZero (.const 0)⟩`. -/
  targetDefNodes : List (List StrictForm × String)
  /-- Each source branch `A_j ∈ L_src` paired with `(B_target, psiNodes)` where `B_target ∈ L_dst`
      and `psiNodes` proves `∀ ψ ∈ B_target, ⟨D_old, specNewId, Γ_old ++ A_j, ψ⟩`. -/
  branchCovers   : List (List StrictForm × List StrictForm × List (StrictForm × String))
  deriving DecidableEq, Repr

/-- Per-item bidirectional `L1` proof-carrying `G7` equivalence witness bound explicitly to
    `(boundInvariantId, boundG5Locus, boundItemLocus)` (`F-B3-T18-02`!). -/
structure G56LossEquivWitness where
  boundInvariantId : String
  boundG5Locus     : ExcisedLocus
  boundItemLocus   : ExcisedLocus
  l5ImpliesL6      : G56DirectionalLocusCover
  l6ImpliesL5      : G56DirectionalLocusCover
  deriving DecidableEq, Repr

/-- Per-item loss-locus agreement mode (`L0` syntactic equality vs `L1` proof-carrying `G7` equivalence). -/
inductive G56ItemLossAgreementMode where
  | l0SyntacticEq : G56ItemLossAgreementMode
  | l1CertifiedEq : G56LossEquivWitness → G56ItemLossAgreementMode
  deriving DecidableEq, Repr

/-- Per-item loss-equivalence binding entry (`F-B3-T18-02`: every `item ∈ s6.items` must be bound!). -/
structure G56ItemLossBinding where
  invariantId : String
  itemLocus   : ExcisedLocus
  mode        : G56ItemLossAgreementMode
  deriving DecidableEq, Repr

/-- **Mandatory Type 6 (`G56ScopeCompatibility` — `C-B3-07`, `F-B3-T17-05`, `F-B3-T18-02`)**:
    Mode tag witnessing how `c5.reflexKind` and every `G6` item's `scopePolicy` align on the
    shared pre/post domain carrier `(domOld, guardsOld) ↦ (domNew, guardsNew)`. -/
inductive G56ScopeCompatibility where
  | repairSameScope         : G56ScopeCompatibility
  | refinementSameScope     : G56ScopeCompatibility
  | refinementExpandedScope : G56ScopeCompatibility
  | retreatExactSharedLoss  :
      (sharedExcisedLocus : ExcisedLocus) →
      (itemLossBindings : List G56ItemLossBinding) →
      G56ScopeCompatibility
  deriving DecidableEq, Repr

/-- **Mandatory Type 2 (`G56CouplingCert` — `C-B3-01 .. C-B3-08`)**:
    Complete coupled `G56` certificate. -/
structure G56CouplingCert where
  certVersion          : String
  couplingCid          : String
  transitionBinding    : G56TransitionBinding
  g5Cert               : G5DischargeCert
  g6Suite              : G6ProtectedSuite
  scopeCompatibility   : G56ScopeCompatibility
  evidenceBinding      : G56EvidenceBinding
  claimedJointPrimDeps : G56JointPrimDeps
  deriving DecidableEq, Repr

/-- Deterministic binding & cross-transition / scope-policy / per-item loss mismatch reasons. -/
inductive G56BindingError where
  | nonCanonicalCouplingHeader : G56BindingError
  | mismatchedPrimEnv          : G56BindingError
  | mismatchedDagContainer     : G56BindingError
  | g5TransitionIdMismatch     : G56BindingError
  | g6TransitionIdMismatch     : G56BindingError
  | evaluationEpochMismatch    : G56BindingError
  | prePostCarrierMismatch     : (invId : String) → G56BindingError
  | reflexRetreatFlagMismatch  : G56BindingError
  | g5RetreatForbiddenByG6Pol  : (invId : String) → G56BindingError
  | scopeLossLocusMismatch     : (invId : String) → G56BindingError
  | scopePolicyModeMismatch    : (invId : String) → G56BindingError
  | evidenceManifestMismatch   : G56BindingError
  deriving DecidableEq, Repr

/-- Deterministic environment, container, certificate, joint-closure, or `D7 ⊆ D56` confinement errors. -/
inductive G56EvidenceError where
  | malformedSharedPrimEnv         : G56EvidenceError
  | malformedSharedContainer       : G56EvidenceError
  | g6SuiteInvalid                 : G6InvalidReason → G56EvidenceError
  | g5ClaimedPrimDepsMismatch      : G56EvidenceError
  | g6ClaimedPrimDepsMismatch      : G56EvidenceError
  | jointPrimDepsMismatch          : G56EvidenceError
  | lossEquivExtraPremiseNotInD56  : G56EvidenceError
  | invalidDiagnosticObservation   : G56EvidenceError
  deriving DecidableEq, Repr

/-- Companion `G6` summary tag preserved inside `.g5NotDischarged`. -/
inductive G56G6CompanionTag where
  | g6AlsoVerified   : (hasLoss : Bool) → G56G6CompanionTag
  | g6AlsoUnresolved : (unresolvedIds : List String) → G56G6CompanionTag
  | g6AlsoEmpty      : (unauthPolicyCid : String) → G56G6CompanionTag
  deriving DecidableEq, Repr

/-- Shared context structural status. -/
inductive G56ContextStatus where
  | contextValid             : G56ContextStatus
  | malformedPrimEnv         : G56ContextStatus
  | malformedContainer       : G56ContextStatus
  | malformedEnvAndContainer : G56ContextStatus
  deriving DecidableEq, Repr

/-- Detailed `G5` component status. -/
inductive G56G5Status where
  | g5Accepted      : (rk : ReflexKind) → (requiresRetreat : Bool) → G56G5Status
  | g5NotDischarged : (coreProofsBool : Bool) → (depsMatchedBool : Bool) → G56G5Status
  deriving DecidableEq, Repr

/-- Explicit reason why a downstream diagnostic sub-check is blocked (`Q-B3-R1-02`). -/
inductive DiagnosticBlockingReason where
  | malformedSharedPrimEnv       : DiagnosticBlockingReason
  | malformedSharedContainer     : DiagnosticBlockingReason
  | malformedEnvAndContainer     : DiagnosticBlockingReason
  | emptyG6SuiteNoItemCarriers   : DiagnosticBlockingReason
  | missingRetreatSubCertificate : DiagnosticBlockingReason
  deriving DecidableEq, Repr

/-- Three-state observation wrapper (`F-B3-T17-04`, `Q-B3-R1-02`, `I0-A5`):
    `blocked` is strictly distinct from BOTH `evaluated` (`Pass`/`Fail`) and `notApplicable`! -/
inductive DiagnosticObservation (α : Type) where
  | evaluated     : α → DiagnosticObservation α
  | blocked       : DiagnosticBlockingReason → DiagnosticObservation α
  | notApplicable : DiagnosticObservation α
  deriving DecidableEq, Repr

/-- Independent product of binding sub-checks (`D_binding` — zero first-error masking!). -/
structure G56BindingDiagnosticProduct where
  couplingHeaderCanonicalObs : DiagnosticObservation Bool
  g5TransitionMatchesObs     : DiagnosticObservation Bool
  g6CoreKeyMatchesObs        : DiagnosticObservation Bool
  g6EpochMatchesAssignedObs  : DiagnosticObservation Bool
  itemCarrierMismatchIdsObs  : DiagnosticObservation (List String)
  evidenceRootsMatchObs      : DiagnosticObservation Bool
  firstBindingError?         : Option G56BindingError
  deriving DecidableEq, Repr

/-- Independent product of all `3 + 1` dependency sub-checks (`D_deps` — `CE-R1-05` & `CE-R1-08`). -/
structure G56DependencyDiagnosticProduct where
  g5ClaimedMatchesDerivedObs  : DiagnosticObservation (Bool × List String × List String)
  g6ClaimedMatchesDerivedObs  : DiagnosticObservation (Bool × List String × List String)
  jointClaimedMatchesUnionObs : DiagnosticObservation (Bool × List String × List String)
  l1LossEquivDepsSubsetD56Obs : DiagnosticObservation (Bool × List String)
  deriving DecidableEq, Repr

/-- Independent product of scope-policy & per-item `L0`/`L1` loss-agreement checks (`D_scope`). -/
structure G56ScopeDiagnosticProduct where
  reflexRetreatFlagConsistentObs : DiagnosticObservation Bool
  itemPolicyIncompatibleIdsObs   : DiagnosticObservation (List String)
  lossAgreementCheckObs          : DiagnosticObservation (Bool × List String)
  firstScopeBindingError?        : Option G56BindingError
  deriving DecidableEq, Repr

/-- **Rectified `G56DetailedResultR1` (`F-B3-T17-04`, `Q-B3-R1-02`, `F-B3-T18-04`)**:
    Stores independent product observations across all diagnostic axes together with the
    evaluated input `(ctx, c56)` so applicability predicates `A_i(ctx, c56)` are reflected cleanly. -/
structure G56DetailedResultR1 where
  contextStatus : G56ContextStatus
  bindingDiag   : G56BindingDiagnosticProduct
  g5DiagObs     : DiagnosticObservation G56G5Status
  g6DiagObs     : DiagnosticObservation G6CheckVerdict
  depsDiag      : G56DependencyDiagnosticProduct
  scopeDiag     : G56ScopeDiagnosticProduct
  deriving DecidableEq, Repr

/-- **Mandatory Type 7 (`G56CoupledVerdict` — `C-B3-04`)**:
    7-branch deterministic top-level coupled verdict. -/
inductive G56CoupledVerdict where
  | invalidBinding  : G56BindingError → G56CoupledVerdict
  | invalidEvidence : G56EvidenceError → G56CoupledVerdict
  | g6Violated      : (violatedInvIds : List String) →
                      (unresolvedInvIds : List String) →
                      (g5DischargedBool : Bool) →
                      G56CoupledVerdict
  | g5NotDischarged : (g6CompanionTag : G56G6CompanionTag) → G56CoupledVerdict
  | g6Unresolved    : (unresolvedInvIds : List String) → G56CoupledVerdict
  | g6Empty         : (unauthPolicyCid : String) → G56CoupledVerdict
  | g56Verified     : (hasCertifiedScopeLoss : Bool) →
                      (requiresRetreatHistory : Bool) →
                      G56CoupledVerdict
  deriving DecidableEq, Repr

/-! ### 4. Pure Non-Circular Declarative Semantics `S_sem_B3` (`0` Executable Checker Calls!) -/

/-- Explicit non-shrinking `G6ScopePolicy` predicate (`F-B3-T17-05`, `0` checker calls). -/
def IsNonShrinkingG6Policy : G6ScopePolicy → Prop
  | .globalPostSameDom _           => True
  | .oldScopeInclusion _ _ _ _ _ _ => True
  | .retreatWithLossAccounting     => False

/-- Non-circular structural specification of `UsedProofRoots(w)` (`F-B3-T18-03`, `I0-A4`):
    Defines every `G7` proof node ID semantically required by a `G56LossEquivWitness` directly
    from the witness AST structure, with ZERO reference to `collectLossEquivRootIds`! -/
inductive IsReferencedLossEquivNodeId (w : G56LossEquivWitness) : String → Prop where
  | fwdTargetDef {B : List StrictForm} {nid : String} :
      (B, nid) ∈ w.l5ImpliesL6.targetDefNodes →
      IsReferencedLossEquivNodeId w nid
  | fwdCoverPsi {A B : List StrictForm} {ps : List (StrictForm × String)}
      {ψ : StrictForm} {nid : String} :
      (A, B, ps) ∈ w.l5ImpliesL6.branchCovers →
      (ψ, nid) ∈ ps →
      IsReferencedLossEquivNodeId w nid
  | bwdTargetDef {A : List StrictForm} {nid : String} :
      (A, nid) ∈ w.l6ImpliesL5.targetDefNodes →
      IsReferencedLossEquivNodeId w nid
  | bwdCoverPsi {B A : List StrictForm} {ps : List (StrictForm × String)}
      {ψ : StrictForm} {nid : String} :
      (B, A, ps) ∈ w.l6ImpliesL5.branchCovers →
      (ψ, nid) ∈ ps →
      IsReferencedLossEquivNodeId w nid

/-- **Mandatory Type 9 (`SemValidG56TransitionBinding` — `C-B3-01`, `M1`, `0` checker calls)**:
    Pure declarative specification that `b`, `c5`, and `s6` denote the exact same non-empty
    transition, context-assigned evaluation epoch, relational `G6` witness, and pre/post carriers. -/
structure SemValidG56TransitionBinding
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) (b : G56TransitionBinding) : Prop where
  canonicalNonEmptyIds :
    b.baseId = "base_Q" ∧
    b.rflxCid ≠ "" ∧
    b.cellOldCid ≠ "" ∧
    b.cellNewCid ≠ "" ∧
    b.specOldId ≠ "" ∧
    b.specNewId ≠ ""
  g5ProjectsToBinding :
    projectG5Transition ⟨c5, b.assignedEvalEpoch⟩ = b
  g6RelationallyCompatible :
    G6TransitionCompatibleRel s6 b

/-- Pure declarative `ReflexKind × G6ScopePolicy × Per-Item Loss Equivalence` compatibility
    (`C-B3-07`, `F-B3-T17-05`, `F-B3-T18-02`; `0` executable checker calls!). -/
def SemCompatibleG56Scope
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite)
    (b : G56TransitionBinding) (sc : G56ScopeCompatibility) : Prop :=
  match b.reflexKind, sc with
  | .repair, .repairSameScope =>
      b.requiresRetreatHistory = false ∧
      SemSameEffDom b.domOld b.guardsOld b.domNew b.guardsNew ∧
      (∀ item ∈ s6.items,
        IsNonShrinkingG6Policy item.oldNewState.scopePolicy ∧
        item.scopeLossRecord? = none)
  | .refinement, .refinementSameScope =>
      b.requiresRetreatHistory = false ∧
      (∃ rf ∈ c5.refinementCert?.toList, rf.scopeExpanded = false) ∧
      SemSameEffDom b.domOld b.guardsOld b.domNew b.guardsNew ∧
      (∀ item ∈ s6.items,
        IsNonShrinkingG6Policy item.oldNewState.scopePolicy ∧
        item.scopeLossRecord? = none)
  | .refinement, .refinementExpandedScope =>
      b.requiresRetreatHistory = false ∧
      (∃ rf ∈ c5.refinementCert?.toList, rf.scopeExpanded = true) ∧
      (∀ ρ : Env2, InEffDom b.domOld b.guardsOld ρ → InEffDom b.domNew b.guardsNew ρ) ∧
      (∃ ρ_exp : Env2, InEffDom b.domNew b.guardsNew ρ_exp ∧ ¬ InEffDom b.domOld b.guardsOld ρ_exp) ∧
      (∀ item ∈ s6.items,
        item.scopeLossRecord? = none ∧
        ∃ step oldDef o2n n2o pt_w,
          item.oldNewState.scopePolicy = .oldScopeInclusion step oldDef o2n n2o true (some pt_w))
  | .retreat, .retreatExactSharedLoss Φ_shared itemBinds =>
      b.requiresRetreatHistory = true ∧
      itemBinds.map (·.invariantId) = s6.items.map (·.invariantId) ∧
      SemExactScopeLossPartition b.domOld b.guardsOld b.domNew b.guardsNew Φ_shared ∧
      (∃ rt5 : G5RetreatPartitionCert,
        c5.retreatCert? = some rt5 ∧
        rt5.excisedBranches = Φ_shared) ∧
      (∀ item ∈ s6.items,
        item.oldNewState.scopePolicy = .retreatWithLossAccounting ∧
        ∃ lr6 : G6ScopeLossRecord,
          item.scopeLossRecord? = some lr6 ∧
          (∃ bind ∈ itemBinds,
            bind.invariantId = item.invariantId ∧
            bind.itemLocus = lr6.excisedBranches) ∧
          ∀ ρ : Env2, InEffDom b.domOld b.guardsOld ρ →
            (ModelsExcised Φ_shared ρ ↔ ModelsExcised lr6.excisedBranches ρ))
  | _, _ => False

/-- **Mandatory Type 10 (`SemValidG56Coupling` — `C-B3-06`, `C-B3-09`, `I0-A6`)**:
    Top-level non-circular declarative coupled specification (`0` executable checker calls). -/
structure SemValidG56Coupling (c56 : G56CouplingCert) : Prop where
  canonicalCouplingHeader :
    c56.certVersion = "g56_b3_v1" ∧ c56.couplingCid ≠ ""
  validTransitionBinding :
    SemValidG56TransitionBinding c56.g5Cert c56.g6Suite c56.transitionBinding
  validG5Discharge :
    SemValidG5Discharge c56.g5Cert
  validG6ProtectedSuite :
    SemValidG6ProtectedSuite c56.g6Suite
  compatibleScopeAndLoss :
    SemCompatibleG56Scope c56.g5Cert c56.g6Suite c56.transitionBinding c56.scopeCompatibility

end OmegaCellC1P1B2BB3
