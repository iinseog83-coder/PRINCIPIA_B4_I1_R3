/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — G56 Certified Coupling Kernel (`Formalization Act I0`)
  Module: OmegaCellC1P1B2BB3.B3_03_G7L1LossEquivalence

  Authorization: Human L4 Final Freeze (`SCOPED_STATIC_BASELINE_FROZEN`) & `FORMALIZATION_ACT_I0`
  Gates & Binding Conditions Covered:
    - `I0-A4`: `G7 L1` Proof-Carrying Loss Equivalence across ALL items of `G6ProtectedSuite`,
      exact binding to `(invariantId, g5Locus, itemLocus)` (`F-B3-T18-02`), non-circular proof-root
      completeness (`UsedProofRoots(w) ⊆ CollectedProofRoots(w)` — `F-B3-T18-03`), conservative
      dependency confinement `D7 ⊆ D56` (`Q-B3-R1-03`), and explicit non-shrinking policy
      impossibility under `Retreat` (`F-B3-T17-05`, `T_I0_A4_04_RetreatIncompatibleWithNonShrinkingG6Policy`).
-/
import OmegaCellC1P1B2BB3.B3_02_SharedContextAndJointClosure

namespace OmegaCellC1P1B2BB3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2

/-! ### 1. List Membership Helpers & Non-Circular Root Completeness (`F-B3-T18-03`) -/

private theorem mem_map_fst_exists_pair_b3 {α β : Type} :
    ∀ {L : List (α × β)} {x : α}, x ∈ L.map Prod.fst → ∃ y : β, (x, y) ∈ L
  | [], _, h => nomatch h
  | (_, b) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, List.mem_cons_self ..⟩
      · rcases mem_map_fst_exists_pair_b3 hTail with ⟨y, hy⟩
        exact ⟨y, List.mem_cons_of_mem _ hy⟩

private theorem mem_map_fst_exists_triple_b3 {α β γ : Type} :
    ∀ {L : List (α × β × γ)} {x : α},
      x ∈ L.map Prod.fst → ∃ (y : β) (z : γ), (x, y, z) ∈ L
  | [], _, h => nomatch h
  | (_, b, c) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, c, List.mem_cons_self ..⟩
      · rcases mem_map_fst_exists_triple_b3 hTail with ⟨y, z, hyz⟩
        exact ⟨y, z, List.mem_cons_of_mem _ hyz⟩

private theorem mem_foldr_cover_psi_ids_b3 :
    ∀ (L : List (List StrictForm × List StrictForm × List (StrictForm × String)))
      {A B : List StrictForm} {ps : List (StrictForm × String)}
      {ψ : StrictForm} {nid : String},
      (A, B, ps) ∈ L → (ψ, nid) ∈ ps →
      nid ∈ L.foldr (fun (_, _, q) acc => q.map Prod.snd ++ acc) []
  | [], _, _, _, _, _, hMem, _ => nomatch hMem
  | (_, _, _) :: tail, _, _, _, _, _, hMem, hPsi => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hMem with hEq | hRest
      · injection hEq with _ hPair
        injection hPair with _ hPs
        subst hPs
        exact List.mem_append_left _ (List.mem_map_of_mem hPsi)
      · exact List.mem_append_right _ (mem_foldr_cover_psi_ids_b3 tail hRest hPsi)

private theorem mem_foldr_itemBinds_roots :
    ∀ (itemBinds : List G56ItemLossBinding)
      {bind : G56ItemLossBinding} {w : G56LossEquivWitness} {nid : String},
      bind ∈ itemBinds →
      bind.mode = .l1CertifiedEq w →
      nid ∈ collectLossEquivRootIds w →
      nid ∈ itemBinds.foldr (fun b acc =>
        match b.mode with
        | .l0SyntacticEq   => acc
        | .l1CertifiedEq w' => collectLossEquivRootIds w' ++ acc) []
  | [], _, _, _, hIn, _, _ => nomatch hIn
  | hd :: tl, _, _, _, hIn, hMode, hNid => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hIn with rfl | hTail
      · rw [hMode]
        exact List.mem_append_left _ hNid
      · cases hd.mode with
        | l0SyntacticEq =>
            exact mem_foldr_itemBinds_roots tl hTail hMode hNid
        | l1CertifiedEq _ =>
            exact List.mem_append_right _ (mem_foldr_itemBinds_roots tl hTail hMode hNid)

/-- **`T_I0_A4_01` — Non-Circular Root Collection Completeness (`F-B3-T18-03`)**:
    (1) Every proof node ID satisfying the structural AST predicate `IsReferencedLossEquivNodeId w`
        (`UsedProofRoots(w)`) is guaranteed to belong to `collectLossEquivRootIds w`;
    (2) Whenever `bind ∈ itemBinds` carries `.l1CertifiedEq w`, every `IsReferencedLossEquivNodeId w nid`
        belongs to `collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ itemBinds)`, and every
        transitive premise of `nid` belongs to `deriveScopeCompatL1PrimDeps Γ C (...)`! -/
theorem T_I0_A4_01_RootCollectionCompleteness_NonCircular :
    (∀ (w : G56LossEquivWitness) (nid : String),
       IsReferencedLossEquivNodeId w nid →
       nid ∈ collectLossEquivRootIds w) ∧
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer)
       (Φ : ExcisedLocus) (itemBinds : List G56ItemLossBinding)
       (bind : G56ItemLossBinding) (w : G56LossEquivWitness) (nid : String),
       bind ∈ itemBinds →
       bind.mode = .l1CertifiedEq w →
       IsReferencedLossEquivNodeId w nid →
         nid ∈ collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ itemBinds) ∧
         (∀ pid ∈ extractTransitivePrimDeps Γ C nid,
           pid ∈ deriveScopeCompatL1PrimDeps Γ C (.retreatExactSharedLoss Φ itemBinds))) := by
  have hWitnessComplete :
      ∀ (w : G56LossEquivWitness) (nid : String),
        IsReferencedLossEquivNodeId w nid →
        nid ∈ collectLossEquivRootIds w := by
    intro w nid hRef
    unfold collectLossEquivRootIds
    rw [mem_canonSortStrs]
    cases hRef with
    | fwdTargetDef hMem =>
        apply List.mem_append_left
        unfold rawDirectionalCoverRootIds
        exact List.mem_append_left _ (List.mem_map_of_mem hMem)
    | fwdCoverPsi hCov hPsi =>
        apply List.mem_append_left
        unfold rawDirectionalCoverRootIds
        exact List.mem_append_right _
          (mem_foldr_cover_psi_ids_b3 w.l5ImpliesL6.branchCovers hCov hPsi)
    | bwdTargetDef hMem =>
        apply List.mem_append_right
        unfold rawDirectionalCoverRootIds
        exact List.mem_append_left _ (List.mem_map_of_mem hMem)
    | bwdCoverPsi hCov hPsi =>
        apply List.mem_append_right
        unfold rawDirectionalCoverRootIds
        exact List.mem_append_right _
          (mem_foldr_cover_psi_ids_b3 w.l6ImpliesL5.branchCovers hCov hPsi)
  refine ⟨hWitnessComplete, ?_⟩
  intro Γ C Φ itemBinds bind w nid hBind hMode hRef
  have hInW := hWitnessComplete w nid hRef
  have hInSc : nid ∈ collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ itemBinds) := by
    unfold collectScopeCompatLossRootIds
    rw [mem_canonSortStrs]
    exact mem_foldr_itemBinds_roots itemBinds hBind hMode hInW
  refine ⟨hInSc, ?_⟩
  intro pid hPid
  unfold deriveScopeCompatL1PrimDeps
  exact mem_multiRootTransitivePrimDeps Γ C hInSc hPid

/-! ### 2. Executable `L1` Directional, Single-Item, Constrained, & Suite-Wide Checkers (`I0-A4`) -/

/-- Check a single directional `G7` locus cover `L_src ⟹ L_dst` on `(D_old, Γ_old)` (`F-B3-T18-02`):
    1. Every target branch `B_k ∈ L_dst` is covered in `targetDefNodes` with a valid `G7` sequent
       proving `⟨D_old, specNewId, Γ_old ++ B_k, .eqZero (.const 0)⟩` (establishing telescopic
       definedness of `B_k` on `InEffDom D_old Γ_old`).
    2. Every source branch `A_j ∈ L_src` is covered in `branchCovers` without omission (`CE-I0-04`),
       selects an actual target branch `B_target ∈ L_dst` (`CE-I0-05`), and proves every `ψ ∈ B_target`
       under `Γ_old ++ A_j` via `checkGuardEntailmentListBool`. -/
def checkDirectionalLocusCoverBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (L_src L_dst : ExcisedLocus) (cov : G56DirectionalLocusCover) : Bool :=
  (cov.targetDefNodes.map Prod.fst == L_dst) &&
  cov.targetDefNodes.all (fun (B_k, defNid) =>
    checkExactG7SequentBool fuel Γ C defNid D_old specNewId (Γ_old ++ B_k) (.eqZero (.const 0))) &&
  (cov.branchCovers.map Prod.fst == L_src) &&
  cov.branchCovers.all (fun (A_j, B_target, psiNodes) =>
    L_dst.contains B_target &&
    checkGuardEntailmentListBool fuel Γ C D_old specNewId (Γ_old ++ A_j) B_target psiNodes)

/-- Unconstrained per-item `L1` equivalence checker (checks exact `(invId, L5, L6i)` binding and
    bidirectional `G7` covers; `D7 ⊆ D56` confinement is enforced by the constrained checker below). -/
def checkSingleL1LossEquivBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness) : Bool :=
  (w.boundInvariantId == invId) &&
  (w.boundG5Locus == L5) &&
  (w.boundItemLocus == L6i) &&
  checkDirectionalLocusCoverBool fuel Γ C D_old Γ_old specNewId L5 L6i w.l5ImpliesL6 &&
  checkDirectionalLocusCoverBool fuel Γ C D_old Γ_old specNewId L6i L5 w.l6ImpliesL5

/-- Constrained per-item `L1` equivalence checker (`Q-B3-R1-03`, `F-B3-T18-03`):
    Enforces conservative premise confinement `D7(w) ⊆ D56` together with `checkSingleL1LossEquivBool`. -/
def checkSingleL1LossEquivConstrainedBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness)
    (D56 : List String) : Bool :=
  (multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w)).all (fun p => D56.contains p) &&
  checkSingleL1LossEquivBool fuel Γ C D_old Γ_old specNewId invId L5 L6i w

/-- Check a single `(item, bind)` pair under `Retreat` (`F-B3-T18-02` item-level binding). -/
def checkSingleRetreatItemLossPair (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus)
    (item : G6ProtectedInvariantSpec) (bind : G56ItemLossBinding) :
    Option G56BindingError :=
  if item.oldNewState.scopePolicy != .retreatWithLossAccounting then
    some (.g5RetreatForbiddenByG6Pol item.invariantId)
  else
    match item.scopeLossRecord? with
    | none => some (.scopePolicyModeMismatch item.invariantId)
    | some lr6 =>
        if (bind.invariantId != item.invariantId) || (bind.itemLocus != lr6.excisedBranches) then
          some (.scopeLossLocusMismatch item.invariantId)
        else
          match bind.mode with
          | .l0SyntacticEq =>
              if lr6.excisedBranches == Φ_shared then none
              else some (.scopeLossLocusMismatch item.invariantId)
          | .l1CertifiedEq w =>
              if checkSingleL1LossEquivBool fuel Γ C D_old Γ_old specNewId
                   item.invariantId Φ_shared lr6.excisedBranches w then
                none
              else
                some (.scopeLossLocusMismatch item.invariantId)

/-- Exhaustive paired walk over `items` and `itemBinds` (`F-B3-T18-02`: never skips any item!). -/
def checkRetreatItemPairsLoop (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) :
    List G6ProtectedInvariantSpec → List G56ItemLossBinding →
    List String × Option G56BindingError
  | [], [] => ([], none)
  | item :: restItems, bind :: restBinds =>
      let curErr? := checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared item bind
      let (tailFailedIds, tailErr?) :=
        checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds
      match curErr? with
      | none     => (tailFailedIds, tailErr?)
      | some err => (item.invariantId :: tailFailedIds, some err)
  | item :: _, [] => ([item.invariantId], some (.scopeLossLocusMismatch item.invariantId))
  | [], bind :: _ => ([bind.invariantId], some (.scopeLossLocusMismatch bind.invariantId))

/-- Compute extra premises in `D7 \ D56` (`empty` iff `D7 ⊆ D56`). -/
def computeExtraL1PremisesOutsideD56 (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (sc : G56ScopeCompatibility) (D56 : List String) : List String :=
  (deriveScopeCompatL1PrimDeps Γ C sc).filter (fun p => !D56.contains p)

/-- Constrained suite-wide `Retreat` loss-equivalence check (`F-B3-T18-02` & `F-B3-T18-03`):
    Returns `true` ONLY when `itemBinds` covers `items` 1:1, EVERY `(item, bind)` pair passes
    `checkSingleRetreatItemLossPair`, AND `computeExtraL1PremisesOutsideD56` is empty (`D7 ⊆ D56`)! -/
def checkAllItemsRetreatLossConstrainedBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) (items : List G6ProtectedInvariantSpec)
    (itemBinds : List G56ItemLossBinding) (D56 : List String) : Bool :=
  (itemBinds.map (·.invariantId) == items.map (·.invariantId)) &&
  (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared items itemBinds).2.isNone &&
  (computeExtraL1PremisesOutsideD56 Γ C (.retreatExactSharedLoss Φ_shared itemBinds) D56).isEmpty

/-! ### 3. Soundness Proofs for Directional, Single-Item, & Suite-Wide `L1` Equivalence (`I0-A4`) -/

/-- Directional `G7` locus-cover soundness proved directly from `SemValidSequent` on referenced
    nodes (`0` reference to `collectLossEquivRootIds` — non-circular!). -/
private theorem checkDirectionalLocusCoverBool_sound_via_referenced
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {specNewId : String}
    {L_src L_dst : ExcisedLocus} {cov : G56DirectionalLocusCover}
    (hSeqSound : ∀ {nid : String} {guards : List StrictForm} {concl : StrictForm},
      ((∃ B, (B, nid) ∈ cov.targetDefNodes) ∨
       (∃ A B ps ψ, (A, B, ps) ∈ cov.branchCovers ∧ (ψ, nid) ∈ ps)) →
      checkExactG7SequentBool fuel Γ C nid D_old specNewId guards concl = true →
      SemValidSequent ⟨D_old, specNewId, guards, concl⟩)
    (hChk : checkDirectionalLocusCoverBool fuel Γ C D_old Γ_old specNewId L_src L_dst cov = true) :
    ∀ ρ : Env2, InEffDom D_old Γ_old ρ → ModelsExcised L_src ρ → ModelsExcised L_dst ρ := by
  unfold checkDirectionalLocusCoverBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨⟨⟨hDefMap, hDefAll⟩, hCovMap⟩, hCovAll⟩
  intro ρ hInOld hModSrc
  rcases hModSrc with ⟨A_j, hAjMem, hAjTel, hAjSat⟩
  rw [← eq_of_beq hCovMap] at hAjMem
  rcases mem_map_fst_exists_triple_b3 hAjMem with ⟨B_target, psiNodes, hTripleMem⟩
  have hBranchOk := List.all_eq_true.mp hCovAll (A_j, B_target, psiNodes) hTripleMem
  simp only [Bool.and_eq_true] at hBranchOk
  rcases hBranchOk with ⟨hTargetContains, hEntailOk⟩
  have hTargetMem : B_target ∈ L_dst := List.contains_iff_mem.mp hTargetContains
  -- 1. Telescopic definedness of `B_target` at `ρ ∈ InEffDom D_old Γ_old`:
  have hTargetInDefMap : B_target ∈ cov.targetDefNodes.map Prod.fst := by
    rw [eq_of_beq hDefMap]; exact hTargetMem
  rcases mem_map_fst_exists_pair_b3 hTargetInDefMap with ⟨defNid, hDefPairMem⟩
  have hDefSeqOk : checkExactG7SequentBool fuel Γ C defNid D_old specNewId
      (Γ_old ++ B_target) (.eqZero (.const 0)) = true :=
    List.all_eq_true.mp hDefAll (B_target, defNid) hDefPairMem
  have hDefSem := hSeqSound (Or.inl ⟨B_target, hDefPairMem⟩) hDefSeqOk
  have hAppTel : TelescopicGuardsDefined (Γ_old ++ B_target) ρ :=
    hDefSem.1 ρ hInOld.1
  have hBTargetTel : TelescopicGuardsDefined B_target ρ :=
    ((telescopicGuardsDefined_append_iff Γ_old B_target ρ).mp hAppTel).2 hInOld.2.2
  -- 2. Every `ψ ∈ B_target` is satisfied at `ρ` since `Γ_old ++ A_j` holds at `ρ`:
  unfold checkGuardEntailmentListBool at hEntailOk
  simp only [Bool.and_eq_true] at hEntailOk
  rcases hEntailOk with ⟨hPsiMap, hPsiAll⟩
  have hSatGammaAj : ∀ g ∈ Γ_old ++ A_j, ModelsStrictForm g ρ := by
    intro g hg
    rcases List.mem_append.mp hg with hgOld | hgAj
    · exact hInOld.2.2 g hgOld
    · exact hAjSat g hgAj
  refine ⟨B_target, hTargetMem, hBTargetTel, ?_⟩
  intro ψ hPsiInB
  rw [← eq_of_beq hPsiMap] at hPsiInB
  rcases mem_map_fst_exists_pair_b3 hPsiInB with ⟨psiNid, hPsiPairMem⟩
  have hPsiSeqOk : checkExactG7SequentBool fuel Γ C psiNid D_old specNewId
      (Γ_old ++ A_j) ψ = true :=
    List.all_eq_true.mp hPsiAll (ψ, psiNid) hPsiPairMem
  have hPsiSem := hSeqSound (Or.inr ⟨A_j, B_target, psiNodes, ψ, hTripleMem, hPsiPairMem⟩) hPsiSeqOk
  exact hPsiSem.2 ρ hInOld.1 hSatGammaAj

/-- **`T_I0_A4_02` — Single-Item Constrained `G7 L1` Loss-Equivalence Conditional Soundness**:
    Composes `T_I0_A4_01` (`UsedProofRoots(w) ⊆ collectLossEquivRootIds w`), conservative
    confinement `D7(w) ⊆ D56`, and `A0_05_4_SemanticDependencyClosure` to establish exact
    pointwise equivalence `∀ ρ ∈ D_old,eff, ModelsExcised L5 ρ ↔ ModelsExcised L6i ρ` under
    ONLY `∀ p ∈ D56, SemValidPrimId Γ p`! -/
theorem T_I0_A4_02_SingleItemL1LossEquiv_Conditional_Sound
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness) (D56 : List String)
    (hCont : ValidContainer C)
    (hChk  : checkSingleL1LossEquivConstrainedBool fuel Γ C D_old Γ_old specNewId
               invId L5 L6i w D56 = true)
    (hPrem : ∀ p ∈ D56, SemValidPrimId Γ p) :
    w.boundInvariantId = invId ∧
    w.boundG5Locus = L5 ∧
    w.boundItemLocus = L6i ∧
    (∀ p ∈ multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w), p ∈ D56) ∧
    (∀ ρ : Env2, InEffDom D_old Γ_old ρ →
      (ModelsExcised L5 ρ ↔ ModelsExcised L6i ρ)) := by
  unfold checkSingleL1LossEquivConstrainedBool checkSingleL1LossEquivBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨hSubBool, ⟨⟨⟨⟨hInvEq, hL5Eq⟩, hL6Eq⟩, hFwd⟩, hBwd⟩⟩
  have hSub : ∀ p ∈ multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w), p ∈ D56 := by
    intro p hp
    exact List.contains_iff_mem.mp (List.all_eq_true.mp hSubBool p hp)
  have hPremW : ∀ p ∈ multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w),
      SemValidPrimId Γ p :=
    fun p hp => hPrem p (hSub p hp)
  have hRootSound : ∀ {nid : String} {guards : List StrictForm} {concl : StrictForm},
      IsReferencedLossEquivNodeId w nid →
      checkExactG7SequentBool fuel Γ C nid D_old specNewId guards concl = true →
      SemValidSequent ⟨D_old, specNewId, guards, concl⟩ := by
    intro nid guards concl hRef hSeq
    have hInRoots := T_I0_A4_01_RootCollectionCompleteness_NonCircular.1 w nid hRef
    unfold checkExactG7SequentBool at hSeq
    exact A0_05_4_SemanticDependencyClosure fuel Γ C (collectLossEquivRootIds w)
      hCont hPremW nid hInRoots ⟨D_old, specNewId, guards, concl⟩ (eq_of_beq hSeq)
  have hFwdSound := checkDirectionalLocusCoverBool_sound_via_referenced
    (fun hDisj hSeq => by
      rcases hDisj with ⟨B, hMem⟩ | ⟨A, B, ps, ψ, h1, h2⟩
      · exact hRootSound (.fwdTargetDef hMem) hSeq
      · exact hRootSound (.fwdCoverPsi h1 h2) hSeq)
    hFwd
  have hBwdSound := checkDirectionalLocusCoverBool_sound_via_referenced
    (fun hDisj hSeq => by
      rcases hDisj with ⟨A, hMem⟩ | ⟨B, A, ps, ψ, h1, h2⟩
      · exact hRootSound (.bwdTargetDef hMem) hSeq
      · exact hRootSound (.bwdCoverPsi h1 h2) hSeq)
    hBwd
  refine ⟨eq_of_beq hInvEq, eq_of_beq hL5Eq, eq_of_beq hL6Eq, hSub, ?_⟩
  intro ρ hInOld
  exact ⟨hFwdSound ρ hInOld, hBwdSound ρ hInOld⟩

private theorem checkRetreatItemPairsLoop_none_iff_all
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) :
    ∀ (items : List G6ProtectedInvariantSpec) (binds : List G56ItemLossBinding),
      binds.map (·.invariantId) = items.map (·.invariantId) →
      (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared items binds).2 = none →
      ∀ item ∈ items, ∃ bind ∈ binds,
        checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared item bind = none
  | [], [], _, _, _, hIn => nomatch hIn
  | _ :: _, [], hMap, _, _, _ => nomatch hMap
  | [], _ :: _, hMap, _, _, _ => nomatch hMap
  | it :: restItems, bd :: restBinds, hMap, hNone, item, hMem => by
      simp only [List.map_cons] at hMap
      injection hMap with _ hTailMap
      unfold checkRetreatItemPairsLoop at hNone
      dsimp only at hNone
      cases hCur : checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared it bd with
      | some err =>
          rw [hCur] at hNone
          cases checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds
          nomatch hNone
      | none =>
          rw [hCur] at hNone
          cases hLoop : checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds with
          | mk fIds tErr =>
              rw [hLoop] at hNone
              dsimp only at hNone
              rcases List.mem_cons.mp hMem with rfl | hRestMem
              · exact ⟨bd, List.mem_cons_self .., hCur⟩
              · have hTailNone :
                    (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds).2 = none := by
                  rw [hLoop]; exact hNone
                rcases checkRetreatItemPairsLoop_none_iff_all fuel Γ C D_old Γ_old specNewId Φ_shared
                  restItems restBinds hTailMap hTailNone item hRestMem with ⟨b', hb'Mem, hb'Ok⟩
                exact ⟨b', List.mem_cons_of_mem bd hb'Mem, hb'Ok⟩

/-- **`T_I0_A4_03` — Multi-Item Suite-Wide Constrained `Retreat` Loss-Equivalence Soundness (`F-B3-T18-02`)**:
    Whenever `checkAllItemsRetreatLossConstrainedBool` returns `true` under `ValidContainer C`
    and `∀ p ∈ D56, SemValidPrimId Γ p`, EVERY `item ∈ items` is bound to a matching `bind ∈ itemBinds`
    with `scopePolicy = .retreatWithLossAccounting`, `scopeLossRecord? = some lr6`, `D7 ⊆ D56`, and
    pointwise equivalence `∀ ρ ∈ D_old,eff, ModelsExcised Φ_shared ρ ↔ ModelsExcised lr6.excisedBranches ρ`! -/
theorem T_I0_A4_03_MultiItemConstrainedLossEquiv_CompleteSuiteSound
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) (items : List G6ProtectedInvariantSpec)
    (itemBinds : List G56ItemLossBinding) (D56 : List String)
    (hCont : ValidContainer C)
    (hChk  : checkAllItemsRetreatLossConstrainedBool fuel Γ C D_old Γ_old specNewId
               Φ_shared items itemBinds D56 = true)
    (hPrem : ∀ p ∈ D56, SemValidPrimId Γ p) :
    itemBinds.map (·.invariantId) = items.map (·.invariantId) ∧
    (∀ p ∈ deriveScopeCompatL1PrimDeps Γ C (.retreatExactSharedLoss Φ_shared itemBinds), p ∈ D56) ∧
    (∀ item ∈ items,
      item.oldNewState.scopePolicy = .retreatWithLossAccounting ∧
      ∃ lr6 : G6ScopeLossRecord,
        item.scopeLossRecord? = some lr6 ∧
        (∃ bind ∈ itemBinds,
          bind.invariantId = item.invariantId ∧
          bind.itemLocus = lr6.excisedBranches) ∧
        ∀ ρ : Env2, InEffDom D_old Γ_old ρ →
          (ModelsExcised Φ_shared ρ ↔ ModelsExcised lr6.excisedBranches ρ)) := by
  unfold checkAllItemsRetreatLossConstrainedBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨⟨hMapB, hLoopNoneB⟩, hExtraEmpty⟩
  have hMapEq : itemBinds.map (·.invariantId) = items.map (·.invariantId) := eq_of_beq hMapB
  have hLoopNone :
      (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared items itemBinds).2 = none :=
    Option.isNone_iff_eq_none.mp hLoopNoneB
  have hSubAll :
      ∀ p ∈ deriveScopeCompatL1PrimDeps Γ C (.retreatExactSharedLoss Φ_shared itemBinds),
        p ∈ D56 := by
    intro p hp
    unfold computeExtraL1PremisesOutsideD56 at hExtraEmpty
    have hNil := List.isEmpty_iff.mp hExtraEmpty
    cases hContains : D56.contains p with
    | true => exact List.contains_iff_mem.mp hContains
    | false =>
        have hNotContains : (!D56.contains p) = true := by rw [hContains]; rfl
        have hInFilter : p ∈ (deriveScopeCompatL1PrimDeps Γ C
            (.retreatExactSharedLoss Φ_shared itemBinds)).filter (fun q => !D56.contains q) :=
          List.mem_filter.mpr ⟨hp, hNotContains⟩
        rw [hNil] at hInFilter
        nomatch hInFilter
  refine ⟨hMapEq, hSubAll, ?_⟩
  intro item hItemMem
  rcases checkRetreatItemPairsLoop_none_iff_all fuel Γ C D_old Γ_old specNewId Φ_shared
      items itemBinds hMapEq hLoopNone item hItemMem with ⟨bind, hBindMem, hPairNone⟩
  unfold checkSingleRetreatItemLossPair at hPairNone
  by_cases hPolNe : (item.oldNewState.scopePolicy != .retreatWithLossAccounting) = true
  · rw [if_pos hPolNe] at hPairNone; nomatch hPairNone
  · rw [if_neg hPolNe] at hPairNone
    have hPolEq : item.oldNewState.scopePolicy = .retreatWithLossAccounting := by
      cases hb : (item.oldNewState.scopePolicy == .retreatWithLossAccounting) with
      | true  => exact eq_of_beq hb
      | false => simp [bne, hb] at hPolNe
    refine ⟨hPolEq, ?_⟩
    cases hLr : item.scopeLossRecord? with
    | none => rw [hLr] at hPairNone; nomatch hPairNone
    | some lr6 =>
        rw [hLr] at hPairNone
        dsimp only at hPairNone
        by_cases hHdrNe :
            ((bind.invariantId != item.invariantId) || (bind.itemLocus != lr6.excisedBranches)) = true
        · rw [if_pos hHdrNe] at hPairNone; nomatch hPairNone
        · rw [if_neg hHdrNe] at hPairNone
          have hIdEq : bind.invariantId = item.invariantId := by
            cases hb : (bind.invariantId == item.invariantId) with
            | true  => exact eq_of_beq hb
            | false => simp [bne, hb] at hHdrNe
          have hLocEq : bind.itemLocus = lr6.excisedBranches := by
            cases hb : (bind.itemLocus == lr6.excisedBranches) with
            | true  => exact eq_of_beq hb
            | false => simp [bne, hb] at hHdrNe
          refine ⟨lr6, rfl, ⟨bind, hBindMem, hIdEq, hLocEq⟩, ?_⟩
          cases hMode : bind.mode with
          | l0SyntacticEq =>
              rw [hMode] at hPairNone
              dsimp only at hPairNone
              by_cases hSyn : (lr6.excisedBranches == Φ_shared) = true
              · rw [eq_of_beq hSyn]
                intro _ _
                exact Iff.rfl
              · rw [if_neg hSyn] at hPairNone
                nomatch hPairNone
          | l1CertifiedEq w =>
              rw [hMode] at hPairNone
              dsimp only at hPairNone
              by_cases hL1Ok :
                  checkSingleL1LossEquivBool fuel Γ C D_old Γ_old specNewId
                    item.invariantId Φ_shared lr6.excisedBranches w = true
              · -- Derive `D7(w) ⊆ D56` from `hSubAll` and `T_I0_A4_01`:
                have hSubWBool :
                    (multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w)).all
                      (fun p => D56.contains p) = true := by
                  apply List.all_eq_true.mpr
                  intro p hpW
                  rcases (mem_multiRootTransitivePrimDeps_iff Γ C (collectLossEquivRootIds w) p).mp hpW with
                    ⟨nid, hNidW, hPidNid⟩
                  have hNidSc : nid ∈ collectScopeCompatLossRootIds
                      (.retreatExactSharedLoss Φ_shared itemBinds) := by
                    unfold collectScopeCompatLossRootIds
                    rw [mem_canonSortStrs]
                    exact mem_foldr_itemBinds_roots itemBinds hBindMem hMode hNidW
                  have hpSc : p ∈ deriveScopeCompatL1PrimDeps Γ C
                      (.retreatExactSharedLoss Φ_shared itemBinds) :=
                    mem_multiRootTransitivePrimDeps Γ C hNidSc hPidNid
                  exact List.contains_iff_mem.mpr (hSubAll p hpSc)
                have hConstrOk :
                    checkSingleL1LossEquivConstrainedBool fuel Γ C D_old Γ_old specNewId
                      item.invariantId Φ_shared lr6.excisedBranches w D56 = true := by
                  unfold checkSingleL1LossEquivConstrainedBool
                  rw [hSubWBool, hL1Ok]
                  rfl
                exact (T_I0_A4_02_SingleItemL1LossEquiv_Conditional_Sound
                  fuel Γ C D_old Γ_old specNewId item.invariantId Φ_shared lr6.excisedBranches
                  w D56 hCont hConstrOk hPrem).2.2.2.2
              · rw [if_neg hL1Ok] at hPairNone
                nomatch hPairNone

/-- **`T_I0_A4_04` — Mathematical Impossibility of Pairing `G5 Retreat` with Any Non-Shrinking `G6ScopePolicy`
    (`F-B3-T17-05` / `T_B3_R1_A8a`)**:
    Under `SemValidG5Discharge c5` with `c5.reflexKind = .retreat` and `IsNonShrinkingG6Policy st.scopePolicy`
    on matching carriers `(domOld, guardsOld, domNew, guardsNew)`, `SemValidG6ScopeRelation st lossOpt`
    is provably `False` across ALL `lossOpt : Option G6ScopeLossRecord`! -/
theorem T_I0_A4_04_RetreatIncompatibleWithNonShrinkingG6Policy
    (c5 : G5DischargeCert) (st : G6OldNewStateBinding) (lossOpt : Option G6ScopeLossRecord)
    (hG5      : SemValidG5Discharge c5)
    (hRet     : c5.reflexKind = .retreat)
    (hNonShk  : IsNonShrinkingG6Policy st.scopePolicy)
    (hCarrier : st.domOld = c5.domOld ∧ st.guardsOld = c5.guardsOld ∧
                st.domNew = c5.domNew ∧ st.guardsNew = c5.guardsNew) :
    ¬ SemValidG6ScopeRelation st lossOpt := by
  intro hScope
  have hBr := hG5.branchExactDischarge
  rw [hRet] at hBr
  unfold SemValidRetreatDischarge at hBr
  rcases hBr with ⟨_, _, _, hRetOpt⟩
  cases hRt : c5.retreatCert? with
  | none => rw [hRt] at hRetOpt; exact hRetOpt
  | some rt =>
      rw [hRt] at hRetOpt
      dsimp only at hRetOpt
      rcases hRetOpt with ⟨_, _, _, hInOldLoss, _, hNotInNewLoss, _, _⟩
      rcases hCarrier with ⟨hdOld, hgOld, hdNew, hgNew⟩
      unfold SemValidG6ScopeRelation at hScope
      cases hPol : st.scopePolicy with
      | retreatWithLossAccounting =>
          rw [hPol] at hNonShk
          exact hNonShk
      | globalPostSameDom r =>
          rw [hPol] at hScope
          cases lossOpt with
          | some _ => exact hScope
          | none =>
              dsimp only at hScope
              rw [hdOld, hgOld, hdNew, hgNew] at hScope
              exact hNotInNewLoss ((hScope (ratCoordToEnv2 rt.strictLossWitness)).mp hInOldLoss)
      | oldScopeInclusion step oldDef o2n n2o scopeExp expWit? =>
          rw [hPol] at hScope
          cases lossOpt with
          | some _ => exact hScope
          | none =>
              dsimp only at hScope
              have hIncl := hScope.1
              rw [hdOld, hgOld, hdNew, hgNew] at hIncl
              exact hNotInNewLoss (hIncl (ratCoordToEnv2 rt.strictLossWitness) hInOldLoss)

end OmegaCellC1P1B2BB3
