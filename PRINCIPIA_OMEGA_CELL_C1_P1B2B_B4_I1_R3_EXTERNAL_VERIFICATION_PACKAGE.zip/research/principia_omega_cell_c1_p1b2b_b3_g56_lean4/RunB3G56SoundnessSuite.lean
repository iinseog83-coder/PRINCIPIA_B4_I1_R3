/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — Certified G56 Coupling Kernel (Formalization Act I0)
  Executable: RunB3G56SoundnessSuite.lean (`I0-A9` Soundness & Mutation Fuzzing Verifier)

  Compares live Lean `4.33.1` kernel evaluations of all `71` unfolded soundness cases
  (`60` specification identifiers across `R0`, `R1`, `I0`) and all `12` whitebox mutation
  fuzzing targets (`MUT-I0-01..12`) directly against the pre-committed oracle manifest
  `../principia_omega_cell_c1_p1b2b_b3_g56_i0_evidence/i0_precommitted_test_oracles.json`
  (`0` post-hoc oracle edits) and emits:
    - `i0_soundness_receipts.json`
    - `i0_mutation_receipts.json`
-/
import Lean
import OmegaCellC1P1B2BB3

open Lean
open OmegaCellC1P1B2BB3

structure OracleSpecEntry where
  caseId          : String
  suiteGroup      : String
  expectedVerdict : String
  expectedQual    : Bool

structure MutOracleSpecEntry where
  mutantId       : String
  faultDesc      : String
  expectedKillBy : String

def parseOracleGroup (oraclesObj : Json) (grp : String) : Except String (List OracleSpecEntry) := do
  let arrJson ← oraclesObj.getObjVal? grp
  let arr ← arrJson.getArr?
  let mut out : List OracleSpecEntry := []
  for item in arr do
    let cid ← (← item.getObjVal? "id").getStr?
    let expV ← (← item.getObjVal? "expectedVerdict").getStr?
    let expQ ← (← item.getObjVal? "qualifiesRecord").getBool?
    out := out ++ [⟨cid, grp, expV, expQ⟩]
  return out

def parseMutOracles (oraclesObj : Json) : Except String (List MutOracleSpecEntry) := do
  let arrJson ← oraclesObj.getObjVal? "MUTATION_FUZZ"
  let arr ← arrJson.getArr?
  let mut out : List MutOracleSpecEntry := []
  for item in arr do
    let mid ← (← item.getObjVal? "id").getStr?
    let flt ← (← item.getObjVal? "fault").getStr?
    let kby ← (← item.getObjVal? "expectedKillBy").getStr?
    out := out ++ [⟨mid, flt, kby⟩]
  return out

def main : IO UInt32 := do
  let evDir : System.FilePath := "../principia_omega_cell_c1_p1b2b_b3_g56_i0_evidence"
  let oraclePath := evDir / "i0_precommitted_test_oracles.json"
  let rawOracleText ← IO.FS.readFile oraclePath
  let oracleJson ← match Json.parse rawOracleText with
    | .ok j    => pure j
    | .error e => throw (IO.userError s!"Failed to parse precommitted oracle JSON: {e}")

  let oraclesObj ← match oracleJson.getObjVal? "oracles" with
    | .ok o    => pure o
    | .error e => throw (IO.userError s!"Missing 'oracles' object: {e}")

  let groups := ["R0_POS", "R0_CE", "R1_POS", "R1_CE", "I0_POS", "I0_CE"]
  let mut expected71 : List OracleSpecEntry := []
  for g in groups do
    match parseOracleGroup oraclesObj g with
    | .ok xs   => expected71 := expected71 ++ xs
    | .error e => throw (IO.userError s!"Error parsing group {g}: {e}")

  let expectedMut12 ← match parseMutOracles oraclesObj with
    | .ok xs   => pure xs
    | .error e => throw (IO.userError s!"Error parsing MUTATION_FUZZ: {e}")

  let actual71 := evaluateAll71SoundnessCases
  let actual12 := evaluateAll12Mutants

  let mut soundnessJsonRows : Array Json := #[]
  let mut soundnessMismatches : List String := []
  let mut passedCount : Nat := 0

  if expected71.length != actual71.length then
    soundnessMismatches := s!"COUNT_MISMATCH: expected={expected71.length}, actual={actual71.length}" :: soundnessMismatches

  for (exp, act) in expected71.zip actual71 do
    let idOk := (exp.caseId == act.caseId) && (exp.suiteGroup == act.suiteGroup)
    let vOk  := (exp.expectedVerdict == act.actualVerdict)
    let qOk  := (exp.expectedQual == act.qualifiesRecord)
    let ok   := idOk && vOk && qOk
    if ok then
      passedCount := passedCount + 1
    else
      soundnessMismatches :=
        s!"{exp.caseId}: expected=({exp.expectedVerdict}, {exp.expectedQual}), actual=({act.actualVerdict}, {act.qualifiesRecord})" ::
        soundnessMismatches
    soundnessJsonRows := soundnessJsonRows.push (Json.mkObj [
      ("id", Json.str act.caseId),
      ("suiteGroup", Json.str act.suiteGroup),
      ("expectedOracleVerdict", Json.str exp.expectedVerdict),
      ("actualLeanVerdict", Json.str act.actualVerdict),
      ("expectedQualifiesRecord", Json.bool exp.expectedQual),
      ("actualQualifiesRecord", Json.bool act.qualifiesRecord),
      ("matchedPrecommittedOracle", Json.bool ok)
    ])

  let mut mutJsonRows : Array Json := #[]
  let mut mutFailures : List String := []
  let mut killedCount : Nat := 0

  if expectedMut12.length != actual12.length then
    mutFailures := s!"MUT_COUNT_MISMATCH: expected={expectedMut12.length}, actual={actual12.length}" :: mutFailures

  for (expM, actM) in expectedMut12.zip actual12 do
    let idOk := (expM.mutantId == actM.mutantId) && (expM.expectedKillBy == actM.targetCaseId)
    let ok   := idOk && actM.killed
    if ok then
      killedCount := killedCount + 1
    else
      mutFailures := s!"{actM.mutantId}: killed={actM.killed}, idOk={idOk}" :: mutFailures
    mutJsonRows := mutJsonRows.push (Json.mkObj [
      ("mutantId", Json.str actM.mutantId),
      ("injectedFault", Json.str expM.faultDesc),
      ("adversarialKillVector", Json.str actM.targetCaseId),
      ("mutantFalseAccept", Json.bool actM.mutantFalseAccept),
      ("canonicalCheckerRejects", Json.bool actM.canonicalRejects),
      ("killed", Json.bool ok)
    ])

  let soundnessAllOk := soundnessMismatches.isEmpty && (passedCount == 71)
  let mutAllOk       := mutFailures.isEmpty && (killedCount == 12)

  let soundnessReceipt := Json.mkObj [
    ("receiptSchema", Json.str "principia.omega.p1b2b.b3.i0_soundness_receipts.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_FORMALIZATION_ACT_I0"),
    ("leanVersion", Json.str Lean.versionString),
    ("precommittedOracleFile", Json.str "i0_precommitted_test_oracles.json"),
    ("postHocOracleEdits", Json.num 0),
    ("specIdentifierCount", Json.num 60),
    ("unfoldedCaseCount", Json.num actual71.length),
    ("passedCaseCount", Json.num passedCount),
    ("allSoundnessOraclesMatched", Json.bool soundnessAllOk),
    ("mismatches", Json.arr (soundnessMismatches.toArray.map Json.str)),
    ("cases", Json.arr soundnessJsonRows)
  ]

  let mutReceipt := Json.mkObj [
    ("receiptSchema", Json.str "principia.omega.p1b2b.b3.i0_mutation_receipts.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_FORMALIZATION_ACT_I0"),
    ("leanVersion", Json.str Lean.versionString),
    ("totalMutants", Json.num actual12.length),
    ("killedMutants", Json.num killedCount),
    ("survivedMutants", Json.num (actual12.length - killedCount)),
    ("allMutantsKilled", Json.bool mutAllOk),
    ("failures", Json.arr (mutFailures.toArray.map Json.str)),
    ("mutants", Json.arr mutJsonRows)
  ]

  IO.FS.writeFile (evDir / "i0_soundness_receipts.json") (soundnessReceipt.pretty ++ "\n")
  IO.FS.writeFile (evDir / "i0_mutation_receipts.json") (mutReceipt.pretty ++ "\n")

  IO.println (Json.mkObj [
    ("soundnessCasesPassed", Json.str s!"{passedCount}/{actual71.length}"),
    ("mutantsKilled", Json.str s!"{killedCount}/{actual12.length}"),
    ("allPassed", Json.bool (soundnessAllOk && mutAllOk)),
    ("soundnessMismatches", Json.arr (soundnessMismatches.toArray.map Json.str)),
    ("mutationFailures", Json.arr (mutFailures.toArray.map Json.str))
  ]).pretty

  return (if soundnessAllOk && mutAllOk then 0 else 1)
