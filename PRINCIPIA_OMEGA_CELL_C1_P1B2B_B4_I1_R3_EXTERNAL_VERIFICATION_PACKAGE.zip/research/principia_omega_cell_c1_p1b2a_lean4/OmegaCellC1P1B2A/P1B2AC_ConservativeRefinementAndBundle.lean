/-
  PRINCIPIA Ω-CELL-C1-P1B2A — Isolated Minimal Guarded Derivation & Certified G7 DAG Kernel
  Module: OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1B2A_R1` Scoped Mechanization Qualification):
    1. `B-Ref-1~3` Conservative Refinement of `P1A0` Witness Receipts (`Masterstroke B2A-4`, `T-B2A-04`):
       - Constructs canonical compiler `iotaP1A0Witness` (`ι_wit`) from frozen `P1A0`
         `WitnessReceipt RatClaimId RatSubdomId RatProofCert` into `P1B2AWitnessReceipt`
         WITHOUT calling `verifyRatClaimBool`.
       - Proves exact boolean biconditional `verifyP1B2AWitnessStandaloneBool (ι_wit w) = verifyRatClaimBool w`
         for ALL `w` (`B-Ref-1` forward acceptance + `B-Ref-2` scoped rejection preservation on `Im(ι_wit)`),
         exact `PrimDeps*` and `ModelsStrictPred` equivalence (`B-Ref-3`), AND strict language
         extension outside `Im(ι_wit)` (`rwNewSeqRecip` accepted by `P1B2A`, `∉ Im(ι_wit)`).
    2. Official `CertifiedG7Bundle`, `SubjectKey`, Ledger Standing, & Whitebox Bridge (`T-B2A-07`):
       - Binds full derivation DAG, `ReflexSubjectKey`, `PrimEnvSnapshot`, `PrimDeps*`, and
         `checkCertifiedG7BundleBool` inside `SlotWitness CertifiedG7Bundle ... .verified`.
       - Proves `CertifiedG7(b) ∧ SemValid(PrimDeps*(b)) ⟹ ModelsStrict(Goal(b))` (`Tribunal §6`),
         blocks detached/forged header spoofing, and proves immediate deactivation under premise retraction.
    3. Fibered Pullback Coupling `G2348 ×_{SubjectKey} G7` with `G1 / G56` Strictly Unchecked
       (`Masterstroke B2A-5`, `Tribunal §6 & §7`, `T-B2A-08`):
       - Instantiates frozen `P1B1` `ReflexQualification` at `(.unchecked, .verified, .unchecked, .verified)`
         with enforced `SubjectKey` pullback equality `subjectKeyOfB1Summary = bundle.subjectKey`.
       - Proves joint `SemStructuralValid` + `ModelsStrictForm` across `Repair`, `Retreat`
         (certifying `x * (1/x) - 1 = 0` on `ℚ \ {0}`!), and `Refinement`, rejects cross-subject
         certificate splicing (`Tribunal §6`), preserves `grantFlag = .noGrantFromMathCheck`, and
         proves `FullReflexAdmitted` (`G1/G56 = .verified`) remains uninhabited (`Empty`).
-/
import OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG

namespace OmegaCellC1P1B2A

open OmegaCellC1P1A0
open OmegaCellC1P1B1

/-! ### 1. Canonical Witness Refinement `iotaP1A0Witness` (`B-Ref-1~3`) & `T-B2A-04` -/

/-- ` canonSortStrs L = L` whenever `isStrictCanonStrList L = true` (8-line exact fixed-point lemma). -/
theorem canonSortStrs_eq_of_isStrictCanon :
    ∀ (L : List String), isStrictCanonStrList L = true → canonSortStrs L = L
  | [], _ => rfl
  | [_], _ => rfl
  | a :: b :: rest, h => by
      simp only [isStrictCanonStrList, Bool.and_eq_true] at h
      have ih := canonSortStrs_eq_of_isStrictCanon (b :: rest) h.2
      unfold canonSortStrs
      rw [ih]
      have hNe : (a == b) = false := by
        cases hb : (a == b) with
        | false => rfl
        | true =>
            have heq := eq_of_beq hb
            subst heq
            rw [strStrictLt_irrefl] at h
            nomatch h.1
      unfold insertCanonStr
      rw [hNe, if_pos h.1]
      rfl

/-- Syntactic `P1B2A` witness receipt extending `P1A0` receipts with full `G7DagContainer` proofs. -/
structure P1B2AWitnessReceipt where
  witCid         : String
  cellId         : String
  specId         : String
  domTag         : G7DomTag
  guards         : List StrictForm
  goalForm       : StrictForm
  directPremises : List String
  expiresEpoch   : Nat
  dagContainer   : G7DagContainer
  rootNodeId     : String
  evalFuel       : Nat
  deriving DecidableEq, Repr

/-- Synthesize placeholder primitive environment entries from direct premise IDs for standalone checking. -/
def synthTrivPrimEnv (pids : List String) (domTag : G7DomTag) (specId : String) : PrimPremiseEnv :=
  pids.map (fun pid => ⟨pid, domTag, specId, .nonneg (.const 0), []⟩)

/-- Lift a `P1A0` `PremDag` into a `PrimPremiseEnv` preserving exact `(premId, parentPremIds)` topology. -/
def liftPremDagToEnv (dag : PremDag) (domTag : G7DomTag) (specId : String) : PrimPremiseEnv :=
  dag.map (fun entry => ⟨entry.1, domTag, specId, .nonneg (.const 0), entry.2⟩)

theorem toPremDag_liftPremDagToEnv (dag : PremDag) (domTag : G7DomTag) (specId : String) :
    toPremDag (liftPremDagToEnv dag domTag specId) = dag := by
  unfold toPremDag liftPremDagToEnv
  induction dag with
  | nil => rfl
  | cons e es ih =>
      simp only [List.map_cons]
      rw [ih]

private theorem lookup_synthTrivPrimEnv (domTag : G7DomTag) (specId : String) :
    ∀ (pids : List String) {pid : String},
      pid ∈ pids →
      lookupPrimPrem? (synthTrivPrimEnv pids domTag specId) pid =
        some ⟨pid, domTag, specId, .nonneg (.const 0), []⟩
  | [], _, hMem => nomatch hMem
  | a :: as, pid, hMem => by
      unfold lookupPrimPrem? synthTrivPrimEnv
      simp only [List.map_cons, List.find?]
      if hEq : (a == pid) = true then
        rw [hEq, eq_of_beq hEq]
      else
        have hFalse : (a == pid) = false := Bool.eq_false_iff.mpr hEq
        rw [hFalse]
        rcases List.mem_cons.mp hMem with rfl | hRest
        · exact False.elim (hEq (beq_self_eq_true pid))
        · exact lookup_synthTrivPrimEnv domTag specId as hRest

/-- Standalone `P1B2A` witness verifier checking spec admissibility, canonical premises,
    `ValidContainer`, exact direct-premise binding, and full `G7` reachable derivation acceptance. -/
def verifyP1B2AWitnessStandaloneBool (rw : P1B2AWitnessReceipt) : Bool :=
  (rw.specId == "spec_v1" || rw.specId == "spec_v2") &&
  isStrictCanonStrList rw.directPremises &&
  checkContainerIntegrityBool rw.dagContainer &&
  (collectDirectPrimRefsOfNodes rw.dagContainer
     (extractReachableNodeIds rw.dagContainer rw.rootNodeId) ==
    rw.directPremises) &&
  (verifyReachableDerivation rw.evalFuel
     (synthTrivPrimEnv rw.directPremises rw.domTag rw.specId)
     rw.dagContainer rw.rootNodeId ==
    .accept ⟨rw.domTag, rw.specId, rw.guards, rw.goalForm⟩)

/-- Translate `P1A0` `RatClaimId` to `StrictForm`. -/
def translateRatClaimId : RatClaimId → StrictForm
  | .sqNonneg => .nonneg (.mul .varX .varX)
  | .sqPos    => .pos (.mul .varX .varX)

/-- Translate `P1A0` `RatSubdomId` to `(guards, guardWfCerts)` over `.domQ`. -/
def translateRatSubdomId : RatSubdomId → List StrictForm × List GuardWfWitness
  | .allRat     => ([], [])
  | .nonzeroRat => ([.neqZero .varX], [.totalPolyWf])

/-- Translate `P1A0` `RatProofCert` to genuine `P1B2A` `AlgDomCert` (zero calls to `verifyRatClaimBool`!). -/
def translateRatProofCert : RatProofCert → AlgDomCert
  | .sumOfSquaresId     => .polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩
  | .nonzeroSqStrictPos => .guardedReciprocal (.nonzeroSqStrictPos .varX)
  | .bogusAllRatSqPos   => .polyPositivstellensatz ⟨0, 0, [], [], [], []⟩

/-- **`Masterstroke B2A-4` — Canonical Witness Translation `iotaP1A0Witness` (`ι_wit`)**:
    Purely syntactic compilation from frozen `P1A0` `WitnessReceipt` into `P1B2AWitnessReceipt`. -/
def iotaP1A0Witness (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert) :
    P1B2AWitnessReceipt :=
  let (gs, wfs) := translateRatSubdomId w.subdomId
  let goal      := translateRatClaimId w.claimId
  let cert      := translateRatProofCert w.proofCert
  let gCert : GuardedDomainCert := {
    domTag               := .domQ
    guards               := gs
    goalForm             := goal
    guardWfCerts         := wfs
    guardContextEvidence := .citedPremiseCtx w.directPremises
    goalDeriv            := .certStep goal cert
  }
  let rootNode : G7DagNode := {
    nodeId     := "n_iota_root"
    topoRank   := 0
    domTag     := .domQ
    specId     := w.specId
    guards     := gs
    conclusion := goal
    step       := .guardedDomStep gCert
  }
  { witCid         := w.witCid
    cellId         := w.cellId
    specId         := w.specId
    domTag         := .domQ
    guards         := gs
    goalForm       := goal
    directPremises := w.directPremises
    expiresEpoch   := w.expiresEpoch
    dagContainer   := ⟨[rootNode]⟩
    rootNodeId     := "n_iota_root"
    evalFuel       := 3 }

/-- Expressive new `P1B2A` witness outside `Im(ι_wit)` certifying sequential guard
    `γ₁ : x ≠ 0, γ₂ : 1/x > 0 ⊢ x > 0` (`Tribunal §4` B-Ref-2 language extension witness). -/
def rwNewSeqRecip : P1B2AWitnessReceipt where
  witCid         := "w_new_seq_recip"
  cellId         := "g0"
  specId         := "spec_v1"
  domTag         := .domQ
  guards         := certSeqRecipPos.guards
  goalForm       := certSeqRecipPos.goalForm
  directPremises := []
  expiresEpoch   := 100
  dagContainer   := ⟨[⟨"n_seq", 0, .domQ, "spec_v1", certSeqRecipPos.guards,
                       certSeqRecipPos.goalForm, .guardedDomStep certSeqRecipPos⟩]⟩
  rootNodeId     := "n_seq"
  evalFuel       := 3

private theorem checkGuardCtx_synth_true {pids : List String} {domTag : G7DomTag}
    {specId : String} {C : G7DagContainer}
    (hCanon : isStrictCanonStrList pids = true) :
    checkGuardCtxEvidenceBool domTag specId 0 (synthTrivPrimEnv pids domTag specId) C
      (.citedPremiseCtx pids) = true := by
  unfold checkGuardCtxEvidenceBool
  dsimp only
  rw [hCanon]
  simp only [Bool.true_and]
  apply List.all_eq_true.mpr
  intro pid hp
  rw [lookup_synthTrivPrimEnv domTag specId pids hp]
  simp [checkFormDefUnderNzBool, checkExprDefUnderNzBool]

private theorem iota_parentRefs_empty (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert) :
    (extractStepFootprint
      (.guardedDomStep
        { domTag               := .domQ
          guards               := (translateRatSubdomId w.subdomId).1
          goalForm             := translateRatClaimId w.claimId
          guardWfCerts         := (translateRatSubdomId w.subdomId).2
          guardContextEvidence := .citedPremiseCtx w.directPremises
          goalDeriv            := .certStep (translateRatClaimId w.claimId)
                                    (translateRatProofCert w.proofCert) })).parentNodeRefs = [] := by
  cases w.subdomId <;> rfl

private theorem iota_directRefs_eq (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert)
    (hCanon : isStrictCanonStrList w.directPremises = true) :
    collectDirectPrimRefsOfNodes (iotaP1A0Witness w).dagContainer
      (extractReachableNodeIds (iotaP1A0Witness w).dagContainer "n_iota_root") =
    w.directPremises := by
  have hIdem : canonSortStrs w.directPremises = w.directPremises :=
    canonSortStrs_eq_of_isStrictCanon w.directPremises hCanon
  have hParNil := iota_parentRefs_empty w
  have hReach : extractReachableNodeIds (iotaP1A0Witness w).dagContainer "n_iota_root" =
      ["n_iota_root"] := by
    have hMax : maxTopoRank (iotaP1A0Witness w).dagContainer = 0 := rfl
    unfold extractReachableNodeIds
    rw [hMax]
    simp only [transNodeIter, expandNodeStep, lookupDagNode?, iotaP1A0Witness,
               List.foldr, List.find?]
    have hEq : ("n_iota_root" == "n_iota_root") = true := rfl
    rw [hEq]; dsimp only
    rw [hParNil]
    rfl
  rw [hReach]
  unfold collectDirectPrimRefsOfNodes iotaP1A0Witness lookupDagNode?
  dsimp only [List.foldr, List.find?]
  have hFind : ("n_iota_root" == "n_iota_root") = true := rfl
  rw [hFind]; dsimp only
  cases w.subdomId <;>
    (simp only [translateRatSubdomId, extractStepFootprint, extractDerivFootprint,
                extractGuardWfFootprint, extractSingleGuardWfFootprint,
                extractGuardCtxFootprint, unionFootprint,
                List.nil_append, List.append_nil, canonSortStrs];
     repeat rw [hIdem])

/-- **`T-B2A-04` — Conservative Refinement of `P1A0` Witness Transport (`B-Ref-1~3` + Extension)**:
    (1) **`B-Ref-1 & B-Ref-2` (Exact Canonical Acceptance & Rejection Preservation)**:
        For EVERY `w : WitnessReceipt RatClaimId RatSubdomId RatProofCert`,
        `verifyP1B2AWitnessStandaloneBool (iotaP1A0Witness w) = verifyRatClaimBool w`
        (`LegacyAccept(w) ⟹ NewAccept(ι_wit(w))` AND `LegacyReject(w) ⟹ NewReject(ι_wit(w))`);
    (2) **`B-Ref-3a` (Exact Transitive `PrimDeps*` Preservation)**:
        For EVERY `dag : PremDag` and canonical `w`, `extractTransitivePrimDeps` on `iotaP1A0Witness w`
        equals `depsStarCanon dag w.directPremises` identically;
    (3) **`B-Ref-3b` (Exact Subdomain & Strict Formula Semantic Equivalence)**:
        For EVERY `w` and `x : Rat`, `(∀ γ ∈ (iotaP1A0Witness w).guards, ModelsStrictForm γ (x, 0)) ↔ evalRatSubdom w.subdomId x`
        AND `ModelsStrictForm (iotaP1A0Witness w).goalForm (x, 0) ↔ ModelsStrictPred (evalRatClaimPred w.specId w.claimId) x`;
    (4) **Proper Expressive Extension Outside `Im(ι_wit)` (`Tribunal §4`)**:
        `verifyP1B2AWitnessStandaloneBool rwNewSeqRecip = true` while `∀ w, iotaP1A0Witness w ≠ rwNewSeqRecip`. -/
theorem T_B2A_04_conservative_refinement_of_P1A0_witness_transport :
    -- (1) B-Ref-1 & B-Ref-2: Exact boolean biconditional across ALL P1A0 receipts
    (∀ w : WitnessReceipt RatClaimId RatSubdomId RatProofCert,
      verifyP1B2AWitnessStandaloneBool (iotaP1A0Witness w) = verifyRatClaimBool w) ∧
    -- (2) B-Ref-3a: Exact PrimDeps* equality across arbitrary PremDag
    (∀ (dag : PremDag) (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert),
      isStrictCanonStrList w.directPremises = true →
      extractTransitivePrimDeps (liftPremDagToEnv dag .domQ w.specId)
        (iotaP1A0Witness w).dagContainer "n_iota_root" =
      depsStarCanon dag w.directPremises) ∧
    -- (3) B-Ref-3b: Exact point-for-point subdomain & claim semantic equivalence on ℚ
    (∀ (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert) (x : Rat),
      ((∀ γ ∈ (iotaP1A0Witness w).guards, ModelsStrictForm γ (x, 0)) ↔
        evalRatSubdom w.subdomId x) ∧
      (ModelsStrictForm (iotaP1A0Witness w).goalForm (x, 0) ↔
        ModelsStrictPred (evalRatClaimPred w.specId w.claimId) x)) ∧
    -- (4) Strict expressive extension outside Im(iotaP1A0Witness)
    (verifyP1B2AWitnessStandaloneBool rwNewSeqRecip = true ∧
     ∀ w : WitnessReceipt RatClaimId RatSubdomId RatProofCert,
       iotaP1A0Witness w ≠ rwNewSeqRecip) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro w
    unfold verifyP1B2AWitnessStandaloneBool verifyRatClaimBool
    have hSpecEq : (iotaP1A0Witness w).specId = w.specId := rfl
    have hPremsEq : (iotaP1A0Witness w).directPremises = w.directPremises := rfl
    rw [hSpecEq, hPremsEq]
    cases hSpec : (w.specId == "spec_v1" || w.specId == "spec_v2") with
    | false => rfl
    | true =>
        cases hCanon : isStrictCanonStrList w.directPremises with
        | false => rfl
        | true =>
            have hSpecNe : (w.specId != "") = true := by
              simp only [Bool.or_eq_true] at hSpec
              rcases hSpec with h1 | h2
              · rw [eq_of_beq h1]; rfl
              · rw [eq_of_beq h2]; rfl
            have hCont : checkContainerIntegrityBool (iotaP1A0Witness w).dagContainer = true := by
              have hParNil := iota_parentRefs_empty w
              unfold checkContainerIntegrityBool iotaP1A0Witness
              dsimp only [List.map, nodupStrsBool, List.contains, List.elem, Bool.not_false,
                          Bool.true_and, List.all_cons, List.all_nil]
              rw [hParNil]
              have hNidNe : ("n_iota_root" != "") = true := rfl
              rw [hNidNe, hSpecNe]
              rfl
            have hRefs : (collectDirectPrimRefsOfNodes (iotaP1A0Witness w).dagContainer
                (extractReachableNodeIds (iotaP1A0Witness w).dagContainer "n_iota_root") ==
                w.directPremises) = true :=
              beq_iff_eq.mpr (iota_directRefs_eq w hCanon)
            have hRootEq : (iotaP1A0Witness w).rootNodeId = "n_iota_root" := rfl
            rw [hRootEq, hCont, hRefs]
            simp only [Bool.true_and]
            have hCtxOk := checkGuardCtx_synth_true (domTag := .domQ) (specId := w.specId)
              (C := (iotaP1A0Witness w).dagContainer) hCanon
            unfold verifyReachableDerivation verifyNodeFuel lookupDagNode?
            unfold iotaP1A0Witness at hCtxOk ⊢
            dsimp only [List.find?]
            have hIdEq : ("n_iota_root" == "n_iota_root") = true := rfl
            have hIdBne : ("n_iota_root" != "n_iota_root") = false := rfl
            rw [hIdEq]; dsimp only
            rw [hIdBne]
            unfold checkNodeStepLocal
            dsimp only
            rw [hCtxOk]
            simp only [Bool.or_eq_true] at hSpec
            rcases hSpec with hSp1 | hSp2
            · rw [eq_of_beq hSp1]
              cases w.claimId <;> cases w.subdomId <;> cases w.proofCert <;> rfl
            · rw [eq_of_beq hSp2]
              cases w.claimId <;> cases w.subdomId <;> cases w.proofCert <;> rfl
  · intro dag w hCanon
    unfold extractTransitivePrimDeps
    dsimp only
    rw [iota_directRefs_eq w hCanon, toPremDag_liftPremDagToEnv]
  · intro w x
    refine ⟨?_, ?_⟩
    · unfold iotaP1A0Witness
      cases w.subdomId with
      | allRat =>
          dsimp [translateRatSubdomId, evalRatSubdom]
          exact ⟨fun _ => trivial, fun _ _ h => False.elim (List.not_mem_nil h)⟩
      | nonzeroRat =>
          dsimp [translateRatSubdomId, evalRatSubdom]
          constructor
          · intro hAll
            have hm := hAll (.neqZero .varX) (List.mem_cons_self ..)
            rcases hm.2 with ⟨v, hrel, hne⟩
            cases hrel
            exact hne
          · intro hne γ hMem
            rcases List.mem_cons.mp hMem with rfl | hNil
            · exact And.intro ⟨x, .varX (x, 0)⟩ ⟨x, .varX (x, 0), hne⟩
            · nomatch hNil
    · unfold iotaP1A0Witness
      cases w.claimId with
      | sqNonneg =>
          dsimp [translateRatClaimId, evalRatClaimPred, ratSqNonnegPred, ModelsStrictForm,
                 ModelsStrictPred, toStrictPred, FormDefined, FormRawSat]
          constructor
          · rintro ⟨_, v, hrel, hle⟩
            cases hrel with
            | mul h1 h2 => cases h1; cases h2; exact ⟨trivial, hle⟩
          · rintro ⟨_, hle⟩
            exact ⟨⟨x * x, .mul (.varX (x, 0)) (.varX (x, 0))⟩,
                   ⟨x * x, .mul (.varX (x, 0)) (.varX (x, 0)), hle⟩⟩
      | sqPos =>
          dsimp [translateRatClaimId, evalRatClaimPred, ratSqPosPred, ModelsStrictForm,
                 ModelsStrictPred, toStrictPred, FormDefined, FormRawSat]
          constructor
          · rintro ⟨_, v, hrel, hlt⟩
            cases hrel with
            | mul h1 h2 => cases h1; cases h2; exact ⟨trivial, hlt⟩
          · rintro ⟨_, hlt⟩
            exact ⟨⟨x * x, .mul (.varX (x, 0)) (.varX (x, 0))⟩,
                   ⟨x * x, .mul (.varX (x, 0)) (.varX (x, 0)), hlt⟩⟩
  · refine ⟨by decide, ?_⟩
    intro w hEq
    have hGoal : translateRatClaimId w.claimId = .pos .varX :=
      congrArg P1B2AWitnessReceipt.goalForm hEq
    cases hc : w.claimId with
    | sqNonneg => rw [hc] at hGoal; nomatch hGoal
    | sqPos =>
        rw [hc] at hGoal
        injection hGoal with hSub
        nomatch hSub

/-! ### 2. Official `CertifiedG7Bundle`, `SubjectKey`, Ledger Standing, & `T-B2A-07` -/

/-- Canonical cross-stage `ReflexSubjectKey` binding `P1B1` (`G2348`) and `P1B2A` (`G7`)
    (`Tribunal §6` Cross-Term Axis). -/
structure ReflexSubjectKey where
  rflxCid       : String
  pathKey       : StructuralPathKey
  targetCellCid : String
  baseId        : String
  targetDomId   : String
  targetSpecId  : String
  deriving DecidableEq, Repr

/-- Official `CertifiedG7Bundle` binding full derivation container, `SubjectKey`, `PrimDeps*`,
    and fuel certificate (`Tribunal §1, §6, §7`). -/
structure CertifiedG7Bundle where
  bundleCid       : String
  subjectKey      : ReflexSubjectKey
  primEnvSnapshot : PrimPremiseEnv
  dagSnapshot     : G7DagContainer
  rootNodeId      : String
  claimedDomTag   : G7DomTag
  claimedGoal     : StrictForm
  claimedPrimDeps : List String
  fuelCert        : Nat
  expiresEpoch    : Nat
  deriving DecidableEq, Repr

/-- Official `G7` bundle verifier (`checkCertifiedG7BundleBool`). -/
def checkCertifiedG7BundleBool (b : CertifiedG7Bundle) : Bool :=
  (b.bundleCid != "") &&
  (b.subjectKey.rflxCid != "") &&
  (b.subjectKey.baseId == "base_Q") &&
  (g7DomTagToId? b.claimedDomTag == some b.subjectKey.targetDomId) &&
  checkPrimEnvIntegrityBool b.primEnvSnapshot &&
  checkContainerIntegrityBool b.dagSnapshot &&
  isStrictCanonStrList b.claimedPrimDeps &&
  (b.claimedPrimDeps ==
    extractTransitivePrimDeps b.primEnvSnapshot b.dagSnapshot b.rootNodeId) &&
  (verifyReachableDerivation b.fuelCert b.primEnvSnapshot b.dagSnapshot b.rootNodeId ==
    .accept ⟨b.claimedDomTag, b.subjectKey.targetSpecId, [], b.claimedGoal⟩)

/-- Proof-bearing `G7` verified slot (`SlotWitness` from frozen `P1B1`!). -/
abbrev G7VerifiedSlot : Type :=
  SlotWitness CertifiedG7Bundle checkCertifiedG7BundleBool .verified

/-- Dynamic ledger activity check for a `CertifiedG7Bundle` against `StructuralLedgerEvent` log `L`. -/
def checkActiveG7BundleBool (L : List StructuralLedgerEvent) (b : CertifiedG7Bundle) : Bool :=
  let ep := (foldStructuralLedger L).epistemic
  checkCertifiedG7BundleBool b &&
  b.claimedPrimDeps.all (fun p => !ep.retractedPremises.contains p) &&
  decide (ep.currentEpoch < b.expiresEpoch)

/-- **`Tribunal §6` Boxed Whitebox Theorem (`certifiedG7Bundle_whitebox_sound`)**:
    `checkCertifiedG7BundleBool b = true` + `SemValidPrimId` on `b.claimedPrimDeps` implies
    `∀ ρ ∈ inG7Dom b.claimedDomTag, ModelsStrictForm b.claimedGoal ρ`! -/
theorem certifiedG7Bundle_whitebox_sound (b : CertifiedG7Bundle)
    (hCert : checkCertifiedG7BundleBool b = true)
    (hPremValid : ∀ p ∈ b.claimedPrimDeps, SemValidPrimId b.primEnvSnapshot p) :
    ∀ ρ : Env2, inG7Dom b.claimedDomTag ρ → ModelsStrictForm b.claimedGoal ρ := by
  unfold checkCertifiedG7BundleBool at hCert
  simp only [Bool.and_eq_true] at hCert
  rcases hCert with ⟨⟨⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, _⟩, _⟩, hCont⟩, _⟩, hDepsEq⟩, hVerAcc⟩
  have hDeps : b.claimedPrimDeps =
      extractTransitivePrimDeps b.primEnvSnapshot b.dagSnapshot b.rootNodeId :=
    eq_of_beq hDepsEq
  have hAcc : verifyReachableDerivation b.fuelCert b.primEnvSnapshot b.dagSnapshot b.rootNodeId =
      .accept ⟨b.claimedDomTag, b.subjectKey.targetSpecId, [], b.claimedGoal⟩ :=
    eq_of_beq hVerAcc
  have hSem := verifyReachable_master_sound b.fuelCert b.primEnvSnapshot b.dagSnapshot
    b.rootNodeId _ hCont hAcc (by rwa [← hDeps])
  intro ρ hDom
  exact hSem.2 ρ hDom (fun _ h => nomatch h)

/-- Concrete `CertifiedG7Bundle` 1: `Repair` (`g0 → g2` on `"dom_Q"`, proving `x^2 ≥ 0` + `"p1_leaf"`). -/
def bundlePosRepairG2 : CertifiedG7Bundle where
  bundleCid       := "g7_pos_repair_g2"
  subjectKey      := {
    rflxCid       := astPosRepair.rflxCid
    pathKey       := derivePathKey astPosRepair
    targetCellCid := astPosRepair.cellNewCid
    baseId        := astPosRepair.baseId
    targetDomId   := astPosRepair.domNewId
    targetSpecId  := astPosRepair.specNewId
  }
  primEnvSnapshot := [ ⟨"p0_anc", .domQ, "spec_v2", .nonneg (.const 1), []⟩
                     , ⟨"p1_leaf", .domQ, "spec_v2", .pos (.const 1), ["p0_anc"]⟩ ]
  dagSnapshot     := ⟨[ ⟨"n_lem", 0, .domQ, "spec_v2", [], .pos (.const 1),
                          .directDerivStep (.primPrem "p1_leaf" (.pos (.const 1)))⟩
                      , ⟨"n_root", 1, .domQ, "spec_v2", [], .nonneg (.mul .varX .varX),
                          .guardedDomStep ⟨.domQ, [], .nonneg (.mul .varX .varX), [],
                            .citedParentNodeCtx ["n_lem"],
                            .certStep (.nonneg (.mul .varX .varX))
                              (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)⟩⟩ ]⟩
  rootNodeId      := "n_root"
  claimedDomTag   := .domQ
  claimedGoal     := .nonneg (.mul .varX .varX)
  claimedPrimDeps := ["p0_anc", "p1_leaf"]
  fuelCert        := 5
  expiresEpoch    := 100

/-- Concrete `CertifiedG7Bundle` 2: `Retreat` (`g0 → g1` on `"dom_Q_nonzero"`, proving `x * (1/x) - 1 = 0`!). -/
def bundlePosRetreatG1 : CertifiedG7Bundle where
  bundleCid       := "g7_pos_retreat_g1"
  subjectKey      := {
    rflxCid       := astPosRetreat.rflxCid
    pathKey       := derivePathKey astPosRetreat
    targetCellCid := astPosRetreat.cellNewCid
    baseId        := astPosRetreat.baseId
    targetDomId   := astPosRetreat.domNewId
    targetSpecId  := astPosRetreat.specNewId
  }
  primEnvSnapshot := []
  dagSnapshot     := ⟨[ ⟨"n_recip_g1", 0, .domQNonzero, "spec_v2", [],
                          .eqZero (.sub (.mul .varX (.div (.const 1) .varX)) (.const 1)),
                          .directDerivStep (.certStep
                            (.eqZero (.sub (.mul .varX (.div (.const 1) .varX)) (.const 1)))
                            (.guardedReciprocal (.mulRecipCancel .varX)))⟩ ]⟩
  rootNodeId      := "n_recip_g1"
  claimedDomTag   := .domQNonzero
  claimedGoal     := .eqZero (.sub (.mul .varX (.div (.const 1) .varX)) (.const 1))
  claimedPrimDeps := []
  fuelCert        := 4
  expiresEpoch    := 100

/-- Concrete `CertifiedG7Bundle` 3: `Refinement` (`g1 → g2` on `"dom_Q"` chained after `Retreat`). -/
def bundlePosRefineStep2G2 : CertifiedG7Bundle where
  bundleCid       := "g7_pos_refine2_g2"
  subjectKey      := {
    rflxCid       := astPosRefinementStep2.rflxCid
    pathKey       := derivePathKey astPosRefinementStep2
    targetCellCid := astPosRefinementStep2.cellNewCid
    baseId        := astPosRefinementStep2.baseId
    targetDomId   := astPosRefinementStep2.domNewId
    targetSpecId  := astPosRefinementStep2.specNewId
  }
  primEnvSnapshot := []
  dagSnapshot     := ⟨[ ⟨"n_fresh_g2", 0, .domQ, "spec_v2", [], .nonneg (.mul .varX .varX),
                          .directDerivStep (.certStep (.nonneg (.mul .varX .varX))
                            (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩))⟩ ]⟩
  rootNodeId      := "n_fresh_g2"
  claimedDomTag   := .domQ
  claimedGoal     := .nonneg (.mul .varX .varX)
  claimedPrimDeps := []
  fuelCert        := 4
  expiresEpoch    := 100

/-- **`T-B2A-07` — Official `CertifiedG7Bundle`, Verifier Binding, Premise-Spoofing Rejection,
    & Dynamic Transitive Retraction Law**:
    (1) Unforgeability: every `G7VerifiedSlot` yields a full `CertifiedG7Bundle` passing
        `checkCertifiedG7BundleBool = true`, whereas omitting transitive `"p0_anc"` from
        `claimedPrimDeps` or spoofing `claimedGoal` deterministically fails (`= false`);
    (2) Whitebox Master Bridge: `checkCertifiedG7BundleBool b = true` + `SemValidPrimId` on
        `b.claimedPrimDeps` guarantees `ModelsStrictForm b.claimedGoal` across `inG7Dom b.claimedDomTag`;
    (3) Dynamic Retraction Law: `bundlePosRepairG2` is active at `L = []`, yet appending
        `.retractPremise "p0_anc"` (an indirect ancestor reached via `guardContextEvidence → n_lem → p1_leaf → p0_anc`!)
        immediately flips `checkActiveG7BundleBool` to `false`. -/
theorem T_B2A_07_certifiedG7Bundle_official_checker_and_ledger_binding :
    -- (1) Proof-bearing slot extraction + positive bundle verification + spoofed header rejection
    (∀ _slot : G7VerifiedSlot, ∃ b : CertifiedG7Bundle, checkCertifiedG7BundleBool b = true) ∧
    (checkCertifiedG7BundleBool bundlePosRepairG2 = true ∧
     checkCertifiedG7BundleBool bundlePosRetreatG1 = true ∧
     checkCertifiedG7BundleBool { bundlePosRepairG2 with claimedPrimDeps := ["p1_leaf"] } = false ∧
     checkCertifiedG7BundleBool { bundlePosRepairG2 with claimedGoal := .pos (.mul .varX .varX) } = false) ∧
    -- (2) Universal Whitebox Master Soundness (`Tribunal §6` Boxed Law)
    (∀ (b : CertifiedG7Bundle),
      checkCertifiedG7BundleBool b = true →
      (∀ p ∈ b.claimedPrimDeps, SemValidPrimId b.primEnvSnapshot p) →
        ∀ ρ : Env2, inG7Dom b.claimedDomTag ρ → ModelsStrictForm b.claimedGoal ρ) ∧
    -- (3) Universal & concrete transitive premise retraction deactivation
    (∀ (L : List StructuralLedgerEvent) (b : CertifiedG7Bundle) (pRet : String),
      pRet ∈ b.claimedPrimDeps →
      pRet ∈ (foldStructuralLedger L).epistemic.retractedPremises →
        checkActiveG7BundleBool L b = false) ∧
    (checkActiveG7BundleBool [] bundlePosRepairG2 = true ∧
     checkActiveG7BundleBool [.retractPremise "p0_anc"] bundlePosRepairG2 = false) := by
  refine ⟨fun slot => verified_slot_has_checked_cert slot,
          ⟨by decide, by decide, by decide, by decide⟩,
          fun b hC hP => certifiedG7Bundle_whitebox_sound b hC hP,
          ?_,
          ⟨by decide, by decide⟩⟩
  intro L b pRet hpDep hpRet
  dsimp only [checkActiveG7BundleBool]
  have hCont : (foldStructuralLedger L).epistemic.retractedPremises.contains pRet = true :=
    List.contains_iff_mem.mpr hpRet
  have hAllFalse : (b.claimedPrimDeps.all
      (fun p => !(foldStructuralLedger L).epistemic.retractedPremises.contains p)) = false := by
    cases hAll : b.claimedPrimDeps.all
        (fun p => !(foldStructuralLedger L).epistemic.retractedPremises.contains p) with
    | false => rfl
    | true =>
        have hpOk := List.all_eq_true.mp hAll pRet hpDep
        rw [hCont] at hpOk
        nomatch hpOk
  rw [hAllFalse]
  simp

/-! ### 3. Fibered Pullback Coupling `G2348 ×_{SubjectKey} G7` & `T-B2A-08` (`G1/G56` Unchecked) -/

/-- Project `P1B1` `CheckedG2348Summary` onto canonical `ReflexSubjectKey`. -/
def subjectKeyOfB1Summary (s : CheckedG2348Summary) : ReflexSubjectKey where
  rflxCid       := s.rflxCid
  pathKey       := s.pathKey
  targetCellCid := s.cellNewCid
  baseId        := s.baseId
  targetDomId   := s.domNewId
  targetSpecId  := s.specNewId

/-- Partial 4-slot qualification spine with `s2348 = .verified` and `sG7 = .verified`, while
    `sG1 = .unchecked` and `sG56 = .unchecked` (`__G1_G5_G6_UNCHECKED`!). -/
abbrev B1AndG7Spine : Type :=
  ReflexQualification
    checkUnauthStageCertBool
    checkUnauthStageCertBool
    checkCertifiedG7BundleBool
    .unchecked .verified .unchecked .verified

/-- Extract `CheckedG2348Summary` from `B1AndG7Spine`. -/
def extractB1G7Summary (sp : B1AndG7Spine) : CheckedG2348Summary :=
  match sp.slot2348 with
  | .mkVerified c => c.1

/-- Extract `CertifiedG7Bundle` from `B1AndG7Spine`. -/
def extractB1G7Bundle (sp : B1AndG7Spine) : CertifiedG7Bundle :=
  match sp.slotG7 with
  | .mkVerified c => c.1

/-- **`Masterstroke B2A-5` — Pullback-Coupled `P1B1 × G7` Qualification (`CoupledB1G7Qualification`)**:
    Enforces `subjectKeyOfB1Summary (extractB1G7Summary spine) = (extractB1G7Bundle spine).subjectKey`
    at the type level so individually valid `G2348` and `G7` certificates for different cells/domains/specs
    can NEVER be spliced together (`Tribunal §6` Cross-Term Axis)! -/
structure CoupledB1G7Qualification where
  spine           : B1AndG7Spine
  subject_coupled : subjectKeyOfB1Summary (extractB1G7Summary spine) =
                    (extractB1G7Bundle spine).subjectKey

/-- Explicit coupling rejection reasons. -/
inductive CouplingRejectErr where
  | invalidStructuralVerdict : CouplingRejectErr
  | invalidG7Bundle          : CouplingRejectErr
  | crossSubjectMismatch     : CouplingRejectErr
  deriving DecidableEq, Repr

/-- Computable coupler binding `StructuralQualification` (`P1B1`) with `CertifiedG7Bundle` (`P1B2A`). -/
def coupleStructuralAndG7 (sq : StructuralQualification) (b : CertifiedG7Bundle) :
    Except CouplingRejectErr CoupledB1G7Qualification :=
  if hb : checkCertifiedG7BundleBool b = true then
    if hSubj : subjectKeyOfB1Summary (extractSummary sq) = b.subjectKey then
      .ok {
        spine := {
          slotG1    := .mkUnchecked
          slot2348  := sq.slot2348
          slotG56   := .mkUnchecked
          slotG7    := .mkVerified ⟨b, hb⟩
          grantFlag := sq.grantFlag
        }
        subject_coupled := by
          cases hs : sq.slot2348 with
          | mkVerified c =>
              dsimp [extractB1G7Summary, extractB1G7Bundle, extractSummary] at hSubj ⊢
              rw [hs] at hSubj
              exact hSubj
      }
    else
      .error .crossSubjectMismatch
  else
    .error .invalidG7Bundle

/-- End-to-end pure check running `P1B1` `checkStructuralReflex` + `P1B2A` `coupleStructuralAndG7`. -/
def checkAndCoupleB1G7 (fuel : Nat) (regId : String) (store : StructuralStore)
    (L : List StructuralLedgerEvent) (ast : StructuralReflexAST) (b : CertifiedG7Bundle) :
    Except CouplingRejectErr CoupledB1G7Qualification :=
  match checkStructuralReflex fuel regId store L ast with
  | .structuralAccept sq => coupleStructuralAndG7 sq b
  | _                    => .error .invalidStructuralVerdict

private theorem checkStructuralReflex_summary_eq {fuel : Nat} {regId : String}
    {store : StructuralStore} {L : List StructuralLedgerEvent} {ast : StructuralReflexAST}
    {sq : StructuralQualification}
    (hChk : checkStructuralReflex fuel regId store L ast = .structuralAccept sq) :
    subjectKeyOfB1Summary (extractSummary sq) =
      ⟨ast.rflxCid, derivePathKey ast, ast.cellNewCid, ast.baseId, ast.domNewId, ast.specNewId⟩ := by
  cases fuel with
  | zero => unfold checkStructuralReflex at hChk; nomatch hChk
  | succ f' =>
      unfold checkStructuralReflex at hChk
      if hCid : (ast.rflxCid == "") = true then
        rw [dif_pos hCid] at hChk; nomatch hChk
      else
        rw [dif_neg hCid] at hChk
        cases hcOld : store.lookupCell? ast.cellOldCid with
        | none => rw [hcOld] at hChk; nomatch hChk
        | some cOld =>
            rw [hcOld] at hChk
            cases hcNew : store.lookupCell? ast.cellNewCid with
            | none => rw [hcNew] at hChk; nomatch hChk
            | some cNew =>
                rw [hcNew] at hChk
                cases hObst : store.lookupObst? ast.obstCid with
                | none => rw [hObst] at hChk; nomatch hChk
                | some obst =>
                    rw [hObst] at hChk; dsimp only at hChk
                    if hG2 : (!(cOld.baseId == ast.baseId && cNew.baseId == ast.baseId &&
                                cOld.domId == ast.domOldId && cNew.domId == ast.domNewId &&
                                cOld.specId == ast.specOldId && cNew.specId == ast.specNewId &&
                                obst.cellCid == ast.cellOldCid && obst.specId == ast.specOldId)) = true then
                      rw [if_pos hG2] at hChk; nomatch hChk
                    else
                      rw [if_neg hG2] at hChk
                      cases hG3 : checkG3Matrix obst.inpKind ast.reflexKind with
                      | error e => rw [hG3] at hChk; cases e <;> nomatch hChk
                      | ok _ =>
                          rw [hG3] at hChk
                          cases hG4 : reifyTransportCode (f' + 1) regId ast.baseId ast.domOldId
                              ast.domNewId ast.specOldId ast.specNewId cOld.prov cNew.prov
                              ast.reflexKind ast.transportCode with
                          | error e => rw [hG4] at hChk; cases e <;> nomatch hChk
                          | ok _ =>
                              rw [hG4] at hChk; dsimp only at hChk
                              if hDup : (((foldStructuralLedger L).epistemic.committedLineages.map
                                          (·.pathKey)).contains (derivePathKey ast)) = true then
                                rw [if_pos hDup] at hChk; nomatch hChk
                              else
                                rw [if_neg hDup] at hChk
                                cases hPar : ast.parentPathKey? with
                                | none =>
                                    rw [hPar] at hChk; dsimp only at hChk
                                    if hRet : (ast.claimedHistRetreat != (ast.reflexKind == .retreat)) = true then
                                      rw [if_pos hRet] at hChk; nomatch hChk
                                    else
                                      rw [if_neg hRet] at hChk
                                      injection hChk with hsq
                                      rw [← hsq]
                                      rfl
                                | some parKey =>
                                    rw [hPar] at hChk; dsimp only at hChk
                                    cases hFind : (foldStructuralLedger L).epistemic.committedLineages.find?
                                        (fun e => e.pathKey == parKey) with
                                    | none => rw [hFind] at hChk; nomatch hChk
                                    | some parEntry =>
                                        rw [hFind] at hChk; dsimp only at hChk
                                        if hCont : (!(parEntry.baseId == ast.baseId &&
                                                      parEntry.cellNewCid == ast.cellOldCid &&
                                                      parEntry.domNewId == ast.domOldId &&
                                                      parEntry.specNewId == ast.specOldId)) = true then
                                          rw [if_pos hCont] at hChk; nomatch hChk
                                        else
                                          rw [if_neg hCont] at hChk
                                          if hRet : (ast.claimedHistRetreat !=
                                              (parEntry.historicalRetreat || (ast.reflexKind == .retreat))) = true then
                                            rw [if_pos hRet] at hChk; nomatch hChk
                                          else
                                            rw [if_neg hRet] at hChk
                                            injection hChk with hsq
                                            rw [← hsq]
                                            rfl

/-- **`T-B2A-08` — Coupled Structural (`P1B1`) + `G7` (`P1B2A`) Qualification, Cross-Subject
    Splicing Firewall, `Zero-Mint` Grant Invariance, & Unchecked `G1 / G56` Boundary**:
    (1) **Joint Master Soundness**: Whenever `checkAndCoupleB1G7` succeeds with `cq` under
        `RegistryContextValid regId`, `StoreLookupConsistent store`, and valid `PrimDeps*`,
        BOTH `SemStructuralValid regId store L ast` AND universal `ModelsStrictForm` on `b.claimedGoal`
        hold, with exact `SubjectKey` alignment to `ast` and `cq.spine.grantFlag = .noGrantFromMathCheck`;
    (2) **3 Positive Coupled Witnesses**: `Repair` (`g0 → g2` on `ℚ`), `Retreat` (`g0 → g1` on
        `ℚ \ {0}` certifying `x * (1/x) - 1 = 0`!), and chained `Refinement` (`g1 → g2` on `ℚ`)
        all evaluate to `.isOk = true`;
    (3) **Cross-Term `SubjectKey` Splicing Firewall (`Tribunal §6`)**: coupling valid `astPosRetreat`
        (`"g1"`, `"dom_Q_nonzero"`) with valid `bundlePosRepairG2` (`"g2"`, `"dom_Q"`) is
        deterministically rejected with `.error .crossSubjectMismatch`;
    (4) **Strict Scope Ceiling (`__G1_G5_G6_UNCHECKED`, `__P1B2B_P1C_NOT_AUTHORIZED`)**:
        `FullReflexAdmitted checkUnauthStageCertBool checkUnauthStageCertBool checkCertifiedG7BundleBool`
        is provably uninhabited (`Empty`) in `P1B2A`! -/
theorem T_B2A_08_coupled_structural_and_G7_qualification_with_G1_G56_unchecked :
    let L1 : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
    -- (1) Joint P1B1 + G7 Master Soundness & SubjectKey Binding
    (∀ (fuel : Nat) (regId : String) (store : StructuralStore)
       (L : List StructuralLedgerEvent) (ast : StructuralReflexAST)
       (b : CertifiedG7Bundle) (cq : CoupledB1G7Qualification),
      RegistryContextValid regId →
      StoreLookupConsistent store →
      checkAndCoupleB1G7 fuel regId store L ast b = .ok cq →
      (∀ p ∈ b.claimedPrimDeps, SemValidPrimId b.primEnvSnapshot p) →
        SemStructuralValid regId store L ast ∧
        cq.spine.grantFlag = .noGrantFromMathCheck ∧
        b.subjectKey.targetCellCid = ast.cellNewCid ∧
        b.subjectKey.targetDomId = ast.domNewId ∧
        b.subjectKey.targetSpecId = ast.specNewId ∧
        (∀ ρ : Env2, inG7Dom b.claimedDomTag ρ → ModelsStrictForm b.claimedGoal ρ)) ∧
    -- (2) Three positive end-to-end coupled qualifications (Repair, Retreat, Refinement)
    ((checkAndCoupleB1G7 4 "reg_Q_v1" stdStructStore [] astPosRepair bundlePosRepairG2).isOk = true ∧
     (checkAndCoupleB1G7 4 "reg_Q_v1" stdStructStore [] astPosRetreat bundlePosRetreatG1).isOk = true ∧
     (checkAndCoupleB1G7 4 "reg_Q_v1" stdStructStore L1 astPosRefinementStep2 bundlePosRefineStep2G2).isOk = true) ∧
    -- (3) Cross-subject splicing attack rejected (valid Retreat structural + valid Repair G7)
    (checkAndCoupleB1G7 4 "reg_Q_v1" stdStructStore [] astPosRetreat bundlePosRepairG2 =
       .error .crossSubjectMismatch) ∧
    -- (4) FullReflexAdmitted (G1/G56 = .verified) remains provably Empty in P1B2A
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool checkUnauthStageCertBool checkCertifiedG7BundleBool) := by
  dsimp only
  let L1 : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
  refine ⟨?_, ⟨?_, ?_, ?_⟩, ?_, ?_⟩
  · intro fuel regId store L ast b cq hReg hStore hOk hPrems
    unfold checkAndCoupleB1G7 at hOk
    cases hStr : checkStructuralReflex fuel regId store L ast with
    | rejectInvalid _ _ => rw [hStr] at hOk; nomatch hOk
    | rejectRefuted _   => rw [hStr] at hOk; nomatch hOk
    | unsupportedHeld _ => rw [hStr] at hOk; nomatch hOk
    | unavailableHeld _ => rw [hStr] at hOk; nomatch hOk
    | resourceHeld _    => rw [hStr] at hOk; nomatch hOk
    | structuralAccept sq =>
        rw [hStr] at hOk; dsimp only at hOk
        have hB1 := T_B1_05_structural_master_soundness_and_consistency.2
          fuel regId store L ast sq hReg hStore hStr
        have hSumKey := checkStructuralReflex_summary_eq hStr
        unfold coupleStructuralAndG7 at hOk
        if hb : checkCertifiedG7BundleBool b = true then
          rw [dif_pos hb] at hOk
          if hSubj : subjectKeyOfB1Summary (extractSummary sq) = b.subjectKey then
            rw [dif_pos hSubj] at hOk
            injection hOk with hcq
            have hgf : cq.spine.grantFlag = .noGrantFromMathCheck := by
              rw [← hcq]
            rw [hSumKey] at hSubj
            have hCell : b.subjectKey.targetCellCid = ast.cellNewCid :=
              (congrArg ReflexSubjectKey.targetCellCid hSubj).symm
            have hDom : b.subjectKey.targetDomId = ast.domNewId :=
              (congrArg ReflexSubjectKey.targetDomId hSubj).symm
            have hSpec : b.subjectKey.targetSpecId = ast.specNewId :=
              (congrArg ReflexSubjectKey.targetSpecId hSubj).symm
            exact ⟨hB1.1, hgf, hCell, hDom, hSpec,
                   certifiedG7Bundle_whitebox_sound b hb hPrems⟩
          else
            rw [dif_neg hSubj] at hOk; nomatch hOk
        else
          rw [dif_neg hb] at hOk; nomatch hOk
  · simp [checkAndCoupleB1G7, checkStructuralReflex, stdStructStore, astPosRepair,
          checkG3Matrix, reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, derivePathKey,
          coupleStructuralAndG7, extractSummary, subjectKeyOfB1Summary,
          bundlePosRepairG2, Except.isOk, Except.toBool]
    decide
  · simp [checkAndCoupleB1G7, checkStructuralReflex, stdStructStore, astPosRetreat,
          checkG3Matrix, reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, derivePathKey,
          coupleStructuralAndG7, extractSummary, subjectKeyOfB1Summary,
          bundlePosRetreatG1, Except.isOk, Except.toBool]
    decide
  · simp [checkAndCoupleB1G7, entryCommittedRetreatStep1, checkStructuralReflex,
          stdStructStore, astPosRefinementStep2, astPosRetreat,
          checkG3Matrix, reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, stepStructuralLedger, stepEpistemicState,
          derivePathKey, coupleStructuralAndG7, extractSummary, subjectKeyOfB1Summary,
          bundlePosRefineStep2G2, Except.isOk, Except.toBool]
    decide
  · simp [checkAndCoupleB1G7, checkStructuralReflex, stdStructStore, astPosRetreat,
          checkG3Matrix, reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, derivePathKey,
          coupleStructuralAndG7, extractSummary, subjectKeyOfB1Summary,
          bundlePosRepairG2, astPosRepair]
    decide
  · rintro ⟨full⟩
    rcases verified_slot_has_checked_cert full.slotG1 with ⟨_, hbad⟩
    contradiction

end OmegaCellC1P1B2A
