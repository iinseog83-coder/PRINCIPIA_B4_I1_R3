/-
  PRINCIPIA Ω-CELL-C1-P1B2A — Isolated Minimal Guarded Derivation & Certified G7 DAG Kernel
  Module: OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1B2A_R1` Scoped Mechanization Qualification):
    1. Strict 3-State Partial Rational Expressions (`PartExpr`), Fuel-Bounded Evaluation
       (`evalPartExprFuel`), & Non-Refuting `ResourceHeld` (`F-B2A-03`, `T-B2A-01`):
       - Separates declarative `PartExprDefined` / `PartExprEvalRel` over `ℚ²` (`0` checker calls)
         from computable 3-state `PartEvalRes` (`val`, `undefinedDivZero`, `resourceHeld`).
       - Proves `ResourceHeld ⇏ False` and proves `resourceHeld` yields neither semantic truth
         nor semantic counterexample (`ValidCounterexamplePoint`).
    2. Total Polynomial Sub-AST (`PolyExpr`), Tropical Degree Valuation (`tropDegBound`),
       Partial-Division Firewall (`promoteToPolyExpr?`), & Canonical `ℤ[x, y] ↪ ℚ[x, y]` Normalizer:
       - `promoteToPolyExpr?` rejects every AST containing `.div`, blocking definedness laundering
         such as `(x / x) - 1 = 0` or `0 * (1 / x) = 0` at `x = 0`.
       - Canonical bivariate Horner ring `Poly2` (`List (List Int)`) evaluates in `O(1)` pure
         kernel `decide` (`0` `Nat.gcd` bottlenecks) while proving exact `ℚ[x, y]` ring-homomorphism
         soundness (`evalPoly2 (toPoly2 P) ρ = evalPolyExpr P ρ` for all `ρ ∈ ℚ²`), with positive
         integer clearing factor `lhsScale > 0` supporting arbitrary rational SOS/Farkas weights.
    3. Strict Partial Formulas (`StrictForm`), `strictMPStep` Definedness Preservation, &
       4 Algebraic / Domain Certificate Families (`T-B2A-01`, `T-B2A-03`):
       - Cert 1: `PolyPositivstellensatzCert` (scaled SOS + active guard multiplier identity over
         infinite `ℚ` / `ℚ \ {0}` / `ℚ²`, strictly gated by `promoteToPolyExpr?`).
       - Cert 2: `LinearFarkasOrderCert` (scaled rational Farkas cone multipliers + pos-to-neq).
       - Cert 3: `GuardedReciprocalCert` (partial rational reciprocal laws gated by verified
         active nonzero / positive denominator guards).
       - Cert 4: `FiniteGridExhaustiveCert` (exhaustive point evaluation strictly quarantined to
         `.domFiniteGrid` and deterministically rejected on all infinite domains `T-B2A-03`).
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1

namespace OmegaCellC1P1B2A

open OmegaCellC1P1A0
open OmegaCellC1P1B1

/-! ### 1. Constructive `Rat` Ring & Order Lemmas (Zero `Classical.choice`) -/

private theorem rat_add_add_comm (a b c d : Rat) :
    (a + b) + (c + d) = (a + c) + (b + d) := by
  rw [Rat.add_assoc a b (c + d), ← Rat.add_assoc b c d, Rat.add_comm b c,
      Rat.add_assoc c b d, ← Rat.add_assoc a c (b + d)]

private theorem rat_eq_of_sub_eq_zero {a b : Rat} (h : a - b = 0) : a = b := by
  have h1 : (a - b) + b = 0 + b := congrArg (· + b) h
  rw [Rat.sub_add_cancel, Rat.zero_add] at h1
  exact h1

private theorem rat_lt_of_lt_of_le {a b c : Rat} (hab : a < b) (hbc : b ≤ c) : a < c :=
  Rat.not_le.mp (fun hca => Rat.not_lt.mpr (Rat.le_trans hbc hca) hab)

private theorem rat_add_pos_of_pos_of_nonneg {a b : Rat} (ha : 0 < a) (hb : 0 ≤ b) :
    0 < a + b := by
  have h1 : (0 : Rat) + 0 < a + 0 := Rat.add_lt_add_right.mpr ha
  have h2 : a + 0 ≤ a + b := Rat.add_le_add_left.mpr hb
  rw [Rat.add_zero, Rat.add_zero] at h1
  rw [Rat.add_zero] at h2
  exact rat_lt_of_lt_of_le h1 h2

private theorem rat_add_pos_of_nonneg_of_pos {a b : Rat} (ha : 0 ≤ a) (hb : 0 < b) :
    0 < a + b := by
  rw [Rat.add_comm]
  exact rat_add_pos_of_pos_of_nonneg hb ha

private theorem rat_recip_pos_iff (d : Rat) : 0 < (1 : Rat) / d ↔ 0 < d := by
  rw [Rat.div_def, Rat.one_mul]
  exact Rat.inv_pos

private theorem rat_mul_recip_eq_one {d : Rat} (hne : d ≠ 0) :
    d * ((1 : Rat) / d) = 1 := by
  rw [Rat.div_def, Rat.one_mul]
  exact Rat.mul_inv_cancel d hne

private theorem rat_div_self_eq_one {d : Rat} (hne : d ≠ 0) :
    d / d = 1 := by
  rw [Rat.div_def]
  exact Rat.mul_inv_cancel d hne

private theorem rat_recip_ne_zero {d : Rat} (hne : d ≠ 0) :
    (1 : Rat) / d ≠ 0 := by
  intro hz
  have h1 : d * ((1 : Rat) / d) = 1 := rat_mul_recip_eq_one hne
  rw [hz, Rat.mul_zero] at h1
  exact rat_one_ne_zero h1.symm

private theorem rat_scale_eq_zero_iff {k : Int} (hk : 0 < k) {v : Rat} :
    (k : Rat) * v = 0 ↔ v = 0 := by
  have hk_pos : (0 : Rat) < (k : Rat) := Rat.intCast_pos.mpr hk
  have hk_ne : (k : Rat) ≠ 0 := Rat.ne_of_gt hk_pos
  constructor
  · intro hz
    rcases Rat.mul_eq_zero.mp hz with hbad | hv
    · exact False.elim (hk_ne hbad)
    · exact hv
  · intro hv
    rw [hv, Rat.mul_zero]

private theorem rat_nonneg_of_pos_mul_nonneg {k : Int} (hk : 0 < k) {v : Rat}
    (hmul : 0 ≤ (k : Rat) * v) : 0 ≤ v := by
  have hk_pos : (0 : Rat) < (k : Rat) := Rat.intCast_pos.mpr hk
  if hv : 0 ≤ v then
    exact hv
  else
    have hv_lt : v < 0 := Rat.not_le.mp hv
    have hneg_pos : 0 < -v := by
      have h1 : v + (-v) < 0 + (-v) := Rat.add_lt_add_right.mpr hv_lt
      rwa [Rat.add_neg_cancel, Rat.zero_add] at h1
    have hprod_pos : 0 < (k : Rat) * (-v) := Rat.mul_pos hk_pos hneg_pos
    rw [Rat.mul_neg] at hprod_pos
    have hsum : 0 < (k : Rat) * v + -((k : Rat) * v) :=
      rat_add_pos_of_nonneg_of_pos hmul hprod_pos
    rw [Rat.add_neg_cancel] at hsum
    exact False.elim (Rat.lt_irrefl hsum)

private theorem rat_pos_of_pos_mul_pos {k : Int} (hk : 0 < k) {v : Rat}
    (hmul : 0 < (k : Rat) * v) : 0 < v := by
  have hle : 0 ≤ v := rat_nonneg_of_pos_mul_nonneg hk (Rat.le_of_lt hmul)
  have hne : v ≠ 0 := by
    intro hz
    rw [hz, Rat.mul_zero] at hmul
    exact Rat.lt_irrefl hmul
  exact Rat.lt_of_le_of_ne hle (Ne.symm hne)

/-! ### 2. `G7DomTag` (Infinite vs Finite Domain Tags) & 2-Variable Rational Environment -/

/-- Two-variable rational evaluation point `(x, y) ∈ ℚ × ℚ` (`1D` domains fix `y = 0`). -/
abbrev Env2 : Type := Rat × Rat

/-- Syntactic domain tags separating infinite algebraic domains from finite exhaustive grids (`T-B2A-03`). -/
inductive G7DomTag where
  | domQ          : G7DomTag
  | domQNonzero   : G7DomTag
  | domQ2         : G7DomTag
  | domFiniteGrid : List (Int × Int) → G7DomTag
  deriving DecidableEq, Repr

/-- Boolean classifier separating infinite domains (`true`) from finite enumerated domains (`false`). -/
def isInfiniteDomTagBool : G7DomTag → Bool
  | .domQ            => true
  | .domQNonzero     => true
  | .domQ2           => true
  | .domFiniteGrid _ => false

/-- Optional canonical `P1B1` domain string identifier (`dom_Q`, `dom_Q_nonzero`, `dom_Q2`). -/
def g7DomTagToId? : G7DomTag → Option String
  | .domQ            => some "dom_Q"
  | .domQNonzero     => some "dom_Q_nonzero"
  | .domQ2           => some "dom_Q2"
  | .domFiniteGrid _ => none

/-- Bridge from `P1B1` `KernelDomTagV1` into `G7DomTag`. -/
def liftKernelDomTag (t : KernelDomTagV1) : G7DomTag :=
  match t with
  | .domQ        => .domQ
  | .domQNonzero => .domQNonzero

/-- Lift a `DomTagCarrier t` point (`Rat` or `RatNonzero`) into `Env2` (`(x, 0)`). -/
def liftCarrierToEnv2 : {t : KernelDomTagV1} → DomTagCarrier t → Env2
  | .domQ,        x => (x, 0)
  | .domQNonzero, y => (y.1, 0)

/-- Embed an integer grid point `(ix, iy)` into `Env2 = Rat × Rat`. -/
def gridPtToEnv2 (p : Int × Int) : Env2 :=
  ((p.1 : Rat), (p.2 : Rat))

/-- Independent declarative domain membership `inG7Dom tag ρ` (`0` checker calls). -/
def inG7Dom : G7DomTag → Env2 → Prop
  | .domQ,            ρ => ρ.2 = 0
  | .domQNonzero,     ρ => ρ.1 ≠ 0 ∧ ρ.2 = 0
  | .domQ2,           _ => True
  | .domFiniteGrid L, ρ => ∃ p ∈ L, gridPtToEnv2 p = ρ

theorem liftCarrierToEnv2_inG7Dom (t : KernelDomTagV1) (u : DomTagCarrier t) :
    inG7Dom (liftKernelDomTag t) (liftCarrierToEnv2 u) := by
  cases t with
  | domQ        => rfl
  | domQNonzero => exact ⟨u.2, rfl⟩

/-! ### 3. Strict Partial Rational Expressions (`PartExpr`) & Fuel-Bounded 3-State Evaluation -/

/-- Syntactic partial rational expression AST supporting integer literals and partial `.div`
    (any rational literal `a / b` is represented cleanly as `.div (.const a) (.const b)`). -/
inductive PartExpr where
  | const : Int → PartExpr
  | varX  : PartExpr
  | varY  : PartExpr
  | neg   : PartExpr → PartExpr
  | add   : PartExpr → PartExpr → PartExpr
  | sub   : PartExpr → PartExpr → PartExpr
  | mul   : PartExpr → PartExpr → PartExpr
  | div   : PartExpr → PartExpr → PartExpr
  deriving DecidableEq, Repr

/-- Independent declarative partial evaluation relation over `ℚ²` (`0` checker calls).
    `.div e1 e2` evaluates ONLY when `e1`, `e2` evaluate AND `v2 ≠ 0` (`Rat.inv_zero` bypassed!). -/
inductive PartExprEvalRel : PartExpr → Env2 → Rat → Prop where
  | const (c : Int) (ρ : Env2) :
      PartExprEvalRel (.const c) ρ (c : Rat)
  | varX (ρ : Env2) :
      PartExprEvalRel .varX ρ ρ.1
  | varY (ρ : Env2) :
      PartExprEvalRel .varY ρ ρ.2
  | neg {e : PartExpr} {ρ : Env2} {v : Rat} :
      PartExprEvalRel e ρ v →
      PartExprEvalRel (.neg e) ρ (-v)
  | add {e1 e2 : PartExpr} {ρ : Env2} {v1 v2 : Rat} :
      PartExprEvalRel e1 ρ v1 → PartExprEvalRel e2 ρ v2 →
      PartExprEvalRel (.add e1 e2) ρ (v1 + v2)
  | sub {e1 e2 : PartExpr} {ρ : Env2} {v1 v2 : Rat} :
      PartExprEvalRel e1 ρ v1 → PartExprEvalRel e2 ρ v2 →
      PartExprEvalRel (.sub e1 e2) ρ (v1 - v2)
  | mul {e1 e2 : PartExpr} {ρ : Env2} {v1 v2 : Rat} :
      PartExprEvalRel e1 ρ v1 → PartExprEvalRel e2 ρ v2 →
      PartExprEvalRel (.mul e1 e2) ρ (v1 * v2)
  | div {e1 e2 : PartExpr} {ρ : Env2} {v1 v2 : Rat} :
      PartExprEvalRel e1 ρ v1 → PartExprEvalRel e2 ρ v2 → v2 ≠ 0 →
      PartExprEvalRel (.div e1 e2) ρ (v1 / v2)

/-- Strict partial definedness predicate (`∃ v, PartExprEvalRel e ρ v`). -/
def PartExprDefined (e : PartExpr) (ρ : Env2) : Prop :=
  ∃ v : Rat, PartExprEvalRel e ρ v

/-- Functional determinism of `PartExprEvalRel`. -/
theorem partExprEvalRel_unique {e : PartExpr} {ρ : Env2} {v1 v2 : Rat}
    (h1 : PartExprEvalRel e ρ v1) (h2 : PartExprEvalRel e ρ v2) :
    v1 = v2 := by
  induction h1 generalizing v2 with
  | const _ _ => cases h2; rfl
  | varX _    => cases h2; rfl
  | varY _    => cases h2; rfl
  | neg _ ih  =>
      cases h2 with
      | neg ha => rw [ih ha]
  | add _ _ ih1 ih2 =>
      cases h2 with
      | add ha hb => rw [ih1 ha, ih2 hb]
  | sub _ _ ih1 ih2 =>
      cases h2 with
      | sub ha hb => rw [ih1 ha, ih2 hb]
  | mul _ _ ih1 ih2 =>
      cases h2 with
      | mul ha hb => rw [ih1 ha, ih2 hb]
  | div _ _ _ ih1 ih2 =>
      cases h2 with
      | div ha hb _ => rw [ih1 ha, ih2 hb]

/-- Computable 3-state partial expression evaluation outcome separating `val`, `undefinedDivZero`,
    and non-refuting `resourceHeld`. -/
inductive PartEvalRes where
  | val              : Rat → PartEvalRes
  | undefinedDivZero : PartEvalRes
  | resourceHeld     : Nat → PartEvalRes
  deriving DecidableEq, Repr

/-- Fuel-bounded computable partial expression evaluator over `Env2`. -/
def evalPartExprFuel : Nat → PartExpr → Env2 → PartEvalRes
  | 0,     _,          _ => .resourceHeld 0
  | _ + 1, .const c,   _ => .val (c : Rat)
  | _ + 1, .varX,      ρ => .val ρ.1
  | _ + 1, .varY,      ρ => .val ρ.2
  | f + 1, .neg e,     ρ =>
      match evalPartExprFuel f e ρ with
      | .val v            => .val (-v)
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .add e1 e2, ρ =>
      match evalPartExprFuel f e1 ρ with
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
      | .val v1           =>
          match evalPartExprFuel f e2 ρ with
          | .val v2           => .val (v1 + v2)
          | .undefinedDivZero => .undefinedDivZero
          | .resourceHeld k   => .resourceHeld k
  | f + 1, .sub e1 e2, ρ =>
      match evalPartExprFuel f e1 ρ with
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
      | .val v1           =>
          match evalPartExprFuel f e2 ρ with
          | .val v2           => .val (v1 - v2)
          | .undefinedDivZero => .undefinedDivZero
          | .resourceHeld k   => .resourceHeld k
  | f + 1, .mul e1 e2, ρ =>
      match evalPartExprFuel f e1 ρ with
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
      | .val v1           =>
          match evalPartExprFuel f e2 ρ with
          | .val v2           => .val (v1 * v2)
          | .undefinedDivZero => .undefinedDivZero
          | .resourceHeld k   => .resourceHeld k
  | f + 1, .div e1 e2, ρ =>
      match evalPartExprFuel f e1 ρ with
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
      | .val v1           =>
          match evalPartExprFuel f e2 ρ with
          | .undefinedDivZero => .undefinedDivZero
          | .resourceHeld k   => .resourceHeld k
          | .val v2           =>
              if v2 == 0 then .undefinedDivZero else .val (v1 / v2)

/-- Soundness of `evalPartExprFuel`: `.val v` guarantees `PartExprEvalRel`; `.undefinedDivZero`
    guarantees `¬ PartExprDefined`. -/
theorem evalPartExprFuel_sound :
    ∀ (fuel : Nat) (e : PartExpr) (ρ : Env2),
      (∀ v : Rat, evalPartExprFuel fuel e ρ = .val v → PartExprEvalRel e ρ v) ∧
      (evalPartExprFuel fuel e ρ = .undefinedDivZero → ¬ PartExprDefined e ρ)
  | 0, _, _ => And.intro (fun _ h => nomatch h) (fun h => nomatch h)
  | _ + 1, .const c, ρ =>
      And.intro (fun _ h => by injection h with hv; subst hv; exact .const c ρ) (fun h => nomatch h)
  | _ + 1, .varX, ρ =>
      And.intro (fun _ h => by injection h with hv; subst hv; exact .varX ρ) (fun h => nomatch h)
  | _ + 1, .varY, ρ =>
      And.intro (fun _ h => by injection h with hv; subst hv; exact .varY ρ) (fun h => nomatch h)
  | f + 1, .neg e, ρ => by
      have ih := evalPartExprFuel_sound f e ρ
      refine ⟨?_, ?_⟩
      · intro v h
        unfold evalPartExprFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | val v1 =>
            rw [hr] at h; injection h with hv; subst hv
            exact .neg (ih.1 v1 hr)
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld k   => rw [hr] at h; nomatch h
      · intro h ⟨v, hrel⟩
        cases hrel with
        | neg ha =>
            unfold evalPartExprFuel at h
            cases hr : evalPartExprFuel f e ρ with
            | val _            => rw [hr] at h; nomatch h
            | undefinedDivZero => exact ih.2 hr ⟨_, ha⟩
            | resourceHeld _   => rw [hr] at h; nomatch h
  | f + 1, .add e1 e2, ρ => by
      have ih1 := evalPartExprFuel_sound f e1 ρ
      have ih2 := evalPartExprFuel_sound f e2 ρ
      refine ⟨?_, ?_⟩
      · intro v h
        unfold evalPartExprFuel at h
        cases hr1 : evalPartExprFuel f e1 ρ with
        | undefinedDivZero => rw [hr1] at h; nomatch h
        | resourceHeld _   => rw [hr1] at h; nomatch h
        | val v1 =>
            rw [hr1] at h
            cases hr2 : evalPartExprFuel f e2 ρ with
            | undefinedDivZero => rw [hr2] at h; nomatch h
            | resourceHeld _   => rw [hr2] at h; nomatch h
            | val v2 =>
                rw [hr2] at h; injection h with hv; subst hv
                exact .add (ih1.1 v1 hr1) (ih2.1 v2 hr2)
      · intro h ⟨v, hrel⟩
        cases hrel with
        | add ha hb =>
            unfold evalPartExprFuel at h
            cases hr1 : evalPartExprFuel f e1 ρ with
            | undefinedDivZero => exact ih1.2 hr1 ⟨_, ha⟩
            | resourceHeld _   => rw [hr1] at h; nomatch h
            | val v1 =>
                rw [hr1] at h
                cases hr2 : evalPartExprFuel f e2 ρ with
                | val _            => rw [hr2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 hr2 ⟨_, hb⟩
                | resourceHeld _   => rw [hr2] at h; nomatch h
  | f + 1, .sub e1 e2, ρ => by
      have ih1 := evalPartExprFuel_sound f e1 ρ
      have ih2 := evalPartExprFuel_sound f e2 ρ
      refine ⟨?_, ?_⟩
      · intro v h
        unfold evalPartExprFuel at h
        cases hr1 : evalPartExprFuel f e1 ρ with
        | undefinedDivZero => rw [hr1] at h; nomatch h
        | resourceHeld _   => rw [hr1] at h; nomatch h
        | val v1 =>
            rw [hr1] at h
            cases hr2 : evalPartExprFuel f e2 ρ with
            | undefinedDivZero => rw [hr2] at h; nomatch h
            | resourceHeld _   => rw [hr2] at h; nomatch h
            | val v2 =>
                rw [hr2] at h; injection h with hv; subst hv
                exact .sub (ih1.1 v1 hr1) (ih2.1 v2 hr2)
      · intro h ⟨v, hrel⟩
        cases hrel with
        | sub ha hb =>
            unfold evalPartExprFuel at h
            cases hr1 : evalPartExprFuel f e1 ρ with
            | undefinedDivZero => exact ih1.2 hr1 ⟨_, ha⟩
            | resourceHeld _   => rw [hr1] at h; nomatch h
            | val v1 =>
                rw [hr1] at h
                cases hr2 : evalPartExprFuel f e2 ρ with
                | val _            => rw [hr2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 hr2 ⟨_, hb⟩
                | resourceHeld _   => rw [hr2] at h; nomatch h
  | f + 1, .mul e1 e2, ρ => by
      have ih1 := evalPartExprFuel_sound f e1 ρ
      have ih2 := evalPartExprFuel_sound f e2 ρ
      refine ⟨?_, ?_⟩
      · intro v h
        unfold evalPartExprFuel at h
        cases hr1 : evalPartExprFuel f e1 ρ with
        | undefinedDivZero => rw [hr1] at h; nomatch h
        | resourceHeld _   => rw [hr1] at h; nomatch h
        | val v1 =>
            rw [hr1] at h
            cases hr2 : evalPartExprFuel f e2 ρ with
            | undefinedDivZero => rw [hr2] at h; nomatch h
            | resourceHeld _   => rw [hr2] at h; nomatch h
            | val v2 =>
                rw [hr2] at h; injection h with hv; subst hv
                exact .mul (ih1.1 v1 hr1) (ih2.1 v2 hr2)
      · intro h ⟨v, hrel⟩
        cases hrel with
        | mul ha hb =>
            unfold evalPartExprFuel at h
            cases hr1 : evalPartExprFuel f e1 ρ with
            | undefinedDivZero => exact ih1.2 hr1 ⟨_, ha⟩
            | resourceHeld _   => rw [hr1] at h; nomatch h
            | val v1 =>
                rw [hr1] at h
                cases hr2 : evalPartExprFuel f e2 ρ with
                | val _            => rw [hr2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 hr2 ⟨_, hb⟩
                | resourceHeld _   => rw [hr2] at h; nomatch h
  | f + 1, .div e1 e2, ρ => by
      have ih1 := evalPartExprFuel_sound f e1 ρ
      have ih2 := evalPartExprFuel_sound f e2 ρ
      refine ⟨?_, ?_⟩
      · intro v h
        unfold evalPartExprFuel at h
        cases hr1 : evalPartExprFuel f e1 ρ with
        | undefinedDivZero => rw [hr1] at h; nomatch h
        | resourceHeld _   => rw [hr1] at h; nomatch h
        | val v1 =>
            rw [hr1] at h
            cases hr2 : evalPartExprFuel f e2 ρ with
            | undefinedDivZero => rw [hr2] at h; nomatch h
            | resourceHeld _   => rw [hr2] at h; nomatch h
            | val v2 =>
                rw [hr2] at h; dsimp only at h
                if hz : (v2 == 0) = true then
                  rw [if_pos hz] at h; nomatch h
                else
                  rw [if_neg hz] at h
                  injection h with hv; subst hv
                  have hne : v2 ≠ 0 := fun heq => hz (beq_iff_eq.mpr heq)
                  exact .div (ih1.1 v1 hr1) (ih2.1 v2 hr2) hne
      · intro h ⟨v, hrel⟩
        cases hrel with
        | div ha hb hne =>
            unfold evalPartExprFuel at h
            cases hr1 : evalPartExprFuel f e1 ρ with
            | undefinedDivZero => exact ih1.2 hr1 ⟨_, ha⟩
            | resourceHeld _   => rw [hr1] at h; nomatch h
            | val v1 =>
                rw [hr1] at h
                cases hr2 : evalPartExprFuel f e2 ρ with
                | undefinedDivZero => exact ih2.2 hr2 ⟨_, hb⟩
                | resourceHeld _   => rw [hr2] at h; nomatch h
                | val v2 =>
                    rw [hr2] at h; dsimp only at h
                    have hv2_eq := partExprEvalRel_unique (ih2.1 v2 hr2) hb
                    subst hv2_eq
                    if hz : (v2 == 0) = true then
                      exact hne (eq_of_beq hz)
                    else
                      rw [if_neg hz] at h; nomatch h

/-! ### 4. Total Polynomial Sub-AST, Tropical Degree Bound, `promoteToPolyExpr?`, & Horner Normalizer -/

/-- Total polynomial AST over `ℤ[x, y] ↪ ℚ[x, y]` (`0` partial division constructors). -/
inductive PolyExpr where
  | pConst : Int → PolyExpr
  | pVarX  : PolyExpr
  | pVarY  : PolyExpr
  | pNeg   : PolyExpr → PolyExpr
  | pAdd   : PolyExpr → PolyExpr → PolyExpr
  | pSub   : PolyExpr → PolyExpr → PolyExpr
  | pMul   : PolyExpr → PolyExpr → PolyExpr
  deriving DecidableEq, Repr

/-- Total semantic evaluation of `PolyExpr` on `Env2 = ℚ × ℚ`. -/
def evalPolyExpr : PolyExpr → Env2 → Rat
  | .pConst c,   _ => (c : Rat)
  | .pVarX,      ρ => ρ.1
  | .pVarY,      ρ => ρ.2
  | .pNeg p,     ρ => -(evalPolyExpr p ρ)
  | .pAdd p1 p2, ρ => evalPolyExpr p1 ρ + evalPolyExpr p2 ρ
  | .pSub p1 p2, ρ => evalPolyExpr p1 ρ - evalPolyExpr p2 ρ
  | .pMul p1 p2, ρ => evalPolyExpr p1 ρ * evalPolyExpr p2 ρ

/-- Tropical `(max, +)` degree bound valuation (`Masterstroke B2A-3`). -/
def tropDegBound : PolyExpr → Nat
  | .pConst _   => 0
  | .pVarX      => 1
  | .pVarY      => 1
  | .pNeg p     => tropDegBound p
  | .pAdd p1 p2 => Nat.max (tropDegBound p1) (tropDegBound p2)
  | .pSub p1 p2 => Nat.max (tropDegBound p1) (tropDegBound p2)
  | .pMul p1 p2 => tropDegBound p1 + tropDegBound p2

/-- Canonical syntactic embedding `PolyExpr ↪ PartExpr`. -/
def polyToPartExpr : PolyExpr → PartExpr
  | .pConst c   => .const c
  | .pVarX      => .varX
  | .pVarY      => .varY
  | .pNeg p     => .neg (polyToPartExpr p)
  | .pAdd p1 p2 => .add (polyToPartExpr p1) (polyToPartExpr p2)
  | .pSub p1 p2 => .sub (polyToPartExpr p1) (polyToPartExpr p2)
  | .pMul p1 p2 => .mul (polyToPartExpr p1) (polyToPartExpr p2)

/-- **`F-B2A-03` Partial-Division Firewall (`promoteToPolyExpr?`)**:
    Rejects any `PartExpr` containing `.div` (`none`), preventing polynomial ring cancellation
    from laundering undefined partial divisions such as `(x / x) - 1` or `0 * (1 / x)`. -/
def promoteToPolyExpr? : PartExpr → Option PolyExpr
  | .const c   => some (.pConst c)
  | .varX      => some .pVarX
  | .varY      => some .pVarY
  | .neg e     =>
      match promoteToPolyExpr? e with
      | some p => some (.pNeg p)
      | none   => none
  | .add e1 e2 =>
      match promoteToPolyExpr? e1, promoteToPolyExpr? e2 with
      | some p1, some p2 => some (.pAdd p1 p2)
      | _,       _       => none
  | .sub e1 e2 =>
      match promoteToPolyExpr? e1, promoteToPolyExpr? e2 with
      | some p1, some p2 => some (.pSub p1 p2)
      | _,       _       => none
  | .mul e1 e2 =>
      match promoteToPolyExpr? e1, promoteToPolyExpr? e2 with
      | some p1, some p2 => some (.pMul p1 p2)
      | _,       _       => none
  | .div _ _   => none

/-- Every `polyToPartExpr p` evaluates strictly everywhere to `evalPolyExpr p ρ`. -/
theorem polyToPartExpr_evalRel (p : PolyExpr) (ρ : Env2) :
    PartExprEvalRel (polyToPartExpr p) ρ (evalPolyExpr p ρ) := by
  induction p with
  | pConst c        => exact .const c ρ
  | pVarX           => exact .varX ρ
  | pVarY           => exact .varY ρ
  | pNeg p ih       => exact .neg ih
  | pAdd _ _ i1 i2  => exact .add i1 i2
  | pSub _ _ i1 i2  => exact .sub i1 i2
  | pMul _ _ i1 i2  => exact .mul i1 i2

/-- Exact section-retraction and universal-definedness law for `promoteToPolyExpr?`. -/
theorem promoteToPolyExpr?_sound {e : PartExpr} {p : PolyExpr}
    (h : promoteToPolyExpr? e = some p) :
    polyToPartExpr p = e ∧
    ∀ ρ : Env2, PartExprEvalRel e ρ (evalPolyExpr p ρ) ∧ PartExprDefined e ρ := by
  have heq : polyToPartExpr p = e := by
    induction e generalizing p with
    | const c => injection h with hp; subst hp; rfl
    | varX    => injection h with hp; subst hp; rfl
    | varY    => injection h with hp; subst hp; rfl
    | neg e1 ih =>
        unfold promoteToPolyExpr? at h
        cases hm : promoteToPolyExpr? e1 with
        | none    => rw [hm] at h; nomatch h
        | some p1 => rw [hm] at h; injection h with hp; subst hp; dsimp [polyToPartExpr]; rw [ih hm]
    | add e1 e2 ih1 ih2 =>
        unfold promoteToPolyExpr? at h
        cases hm1 : promoteToPolyExpr? e1 with
        | none    => rw [hm1] at h; nomatch h
        | some p1 =>
            rw [hm1] at h
            cases hm2 : promoteToPolyExpr? e2 with
            | none    => rw [hm2] at h; nomatch h
            | some p2 =>
                rw [hm2] at h; injection h with hp; subst hp
                dsimp [polyToPartExpr]; rw [ih1 hm1, ih2 hm2]
    | sub e1 e2 ih1 ih2 =>
        unfold promoteToPolyExpr? at h
        cases hm1 : promoteToPolyExpr? e1 with
        | none    => rw [hm1] at h; nomatch h
        | some p1 =>
            rw [hm1] at h
            cases hm2 : promoteToPolyExpr? e2 with
            | none    => rw [hm2] at h; nomatch h
            | some p2 =>
                rw [hm2] at h; injection h with hp; subst hp
                dsimp [polyToPartExpr]; rw [ih1 hm1, ih2 hm2]
    | mul e1 e2 ih1 ih2 =>
        unfold promoteToPolyExpr? at h
        cases hm1 : promoteToPolyExpr? e1 with
        | none    => rw [hm1] at h; nomatch h
        | some p1 =>
            rw [hm1] at h
            cases hm2 : promoteToPolyExpr? e2 with
            | none    => rw [hm2] at h; nomatch h
            | some p2 =>
                rw [hm2] at h; injection h with hp; subst hp
                dsimp [polyToPartExpr]; rw [ih1 hm1, ih2 hm2]
    | div _ _ => nomatch h
  refine ⟨heq, ?_⟩
  intro ρ
  rw [← heq]
  exact ⟨polyToPartExpr_evalRel p ρ, ⟨evalPolyExpr p ρ, polyToPartExpr_evalRel p ρ⟩⟩

/-- Univariate Horner polynomial `∑ c_i x^i` with `Int` coefficients (`O(1)` kernel `decide`!). -/
abbrev Poly1 : Type := List Int

/-- Evaluate `Poly1` at `x : Rat` via Horner's rule. -/
def evalPoly1 : Poly1 → Rat → Rat
  | [],      _ => 0
  | c :: cs, x => (c : Rat) + x * evalPoly1 cs x

/-- Componentwise addition of `Poly1`. -/
def poly1Add : Poly1 → Poly1 → Poly1
  | [],      bs      => bs
  | as,      []      => as
  | a :: as, b :: bs => (a + b) :: poly1Add as bs

/-- Negation of `Poly1`. -/
def poly1Neg : Poly1 → Poly1
  | []      => []
  | a :: as => (-a) :: poly1Neg as

/-- Scalar multiplication `k * P(x)` on `Poly1`. -/
def poly1Scale (k : Int) : Poly1 → Poly1
  | []      => []
  | a :: as => (k * a) :: poly1Scale k as

/-- Cauchy product on `Poly1`. -/
def poly1Mul : Poly1 → Poly1 → Poly1
  | [],      _  => []
  | a :: as, bs => poly1Add (poly1Scale a bs) (0 :: poly1Mul as bs)

private theorem evalPoly1_add : ∀ (p q : Poly1) (x : Rat),
    evalPoly1 (poly1Add p q) x = evalPoly1 p x + evalPoly1 q x
  | [],      bs,      x => (Rat.zero_add (evalPoly1 bs x)).symm
  | a :: as, [],      x => (Rat.add_zero ((a : Rat) + x * evalPoly1 as x)).symm
  | a :: as, b :: bs, x => by
      dsimp [poly1Add, evalPoly1]
      rw [Rat.intCast_add, evalPoly1_add as bs x, Rat.mul_add]
      exact rat_add_add_comm (a : Rat) (b : Rat) (x * evalPoly1 as x) (x * evalPoly1 bs x)

private theorem evalPoly1_neg : ∀ (p : Poly1) (x : Rat),
    evalPoly1 (poly1Neg p) x = -(evalPoly1 p x)
  | [],      _ => Rat.neg_zero.symm
  | a :: as, x => by
      dsimp [poly1Neg, evalPoly1]
      rw [evalPoly1_neg as x, Rat.mul_neg, Rat.neg_add]

private theorem evalPoly1_scale (k : Int) : ∀ (p : Poly1) (x : Rat),
    evalPoly1 (poly1Scale k p) x = (k : Rat) * evalPoly1 p x
  | [],      _ => (Rat.mul_zero (k : Rat)).symm
  | a :: as, x => by
      dsimp [poly1Scale, evalPoly1]
      rw [Rat.intCast_mul, evalPoly1_scale k as x, ← Rat.mul_assoc x (k : Rat) _,
          Rat.mul_comm x (k : Rat), Rat.mul_assoc (k : Rat) x _, ← Rat.mul_add]

private theorem evalPoly1_mul : ∀ (p q : Poly1) (x : Rat),
    evalPoly1 (poly1Mul p q) x = evalPoly1 p x * evalPoly1 q x
  | [],      bs, x => (Rat.zero_mul (evalPoly1 bs x)).symm
  | a :: as, bs, x => by
      dsimp [poly1Mul]
      rw [evalPoly1_add, evalPoly1_scale]
      dsimp [evalPoly1]
      rw [Rat.zero_add, evalPoly1_mul as bs x, ← Rat.mul_assoc x _ _, ← Rat.add_mul]

/-- Bivariate Horner polynomial `∑ P_j(x) y^j` over `ℤ[x][y]`. -/
abbrev Poly2 : Type := List Poly1

/-- Evaluate `Poly2` at `ρ = (x, y) ∈ ℚ²` via outer Horner's rule. -/
def evalPoly2 : Poly2 → Env2 → Rat
  | [],        _ => 0
  | row :: ps, ρ => evalPoly1 row ρ.1 + ρ.2 * evalPoly2 ps ρ

/-- Addition on `Poly2`. -/
def poly2Add : Poly2 → Poly2 → Poly2
  | [],      qs      => qs
  | ps,      []      => ps
  | p :: ps, q :: qs => poly1Add p q :: poly2Add ps qs

/-- Negation on `Poly2`. -/
def poly2Neg : Poly2 → Poly2
  | []      => []
  | p :: ps => poly1Neg p :: poly2Neg ps

/-- Subtraction `P - Q` on `Poly2`. -/
def poly2Sub (P Q : Poly2) : Poly2 :=
  poly2Add P (poly2Neg Q)

/-- Scale `Poly2` by a univariate `Poly1` coefficient `c(x)`. -/
def poly2Scale1 (c : Poly1) : Poly2 → Poly2
  | []      => []
  | p :: ps => poly1Mul c p :: poly2Scale1 c ps

/-- Cauchy product on `Poly2`. -/
def poly2Mul : Poly2 → Poly2 → Poly2
  | [],      _  => []
  | p :: ps, qs => poly2Add (poly2Scale1 p qs) ([] :: poly2Mul ps qs)

/-- Pure `Int` zero-polynomial test (`all coefficients == 0`, reduces by `rfl` / `decide`!). -/
def isZeroPoly2Bool (P : Poly2) : Bool :=
  P.all (fun row => row.all (fun c => c == 0))

/-- Compile `PolyExpr` into `Poly2` over `ℤ[x, y]`. -/
def toPoly2 : PolyExpr → Poly2
  | .pConst c   => [[c]]
  | .pVarX      => [[0, 1]]
  | .pVarY      => [[], [1]]
  | .pNeg p     => poly2Neg (toPoly2 p)
  | .pAdd p1 p2 => poly2Add (toPoly2 p1) (toPoly2 p2)
  | .pSub p1 p2 => poly2Sub (toPoly2 p1) (toPoly2 p2)
  | .pMul p1 p2 => poly2Mul (toPoly2 p1) (toPoly2 p2)

private theorem evalPoly2_add : ∀ (P Q : Poly2) (ρ : Env2),
    evalPoly2 (poly2Add P Q) ρ = evalPoly2 P ρ + evalPoly2 Q ρ
  | [],      qs,      ρ => (Rat.zero_add (evalPoly2 qs ρ)).symm
  | p :: ps, [],      ρ => (Rat.add_zero (evalPoly1 p ρ.1 + ρ.2 * evalPoly2 ps ρ)).symm
  | p :: ps, q :: qs, ρ => by
      dsimp [poly2Add, evalPoly2]
      rw [evalPoly1_add, evalPoly2_add ps qs ρ, Rat.mul_add]
      exact rat_add_add_comm (evalPoly1 p ρ.1) (evalPoly1 q ρ.1)
        (ρ.2 * evalPoly2 ps ρ) (ρ.2 * evalPoly2 qs ρ)

private theorem evalPoly2_neg : ∀ (P : Poly2) (ρ : Env2),
    evalPoly2 (poly2Neg P) ρ = -(evalPoly2 P ρ)
  | [],      _ => Rat.neg_zero.symm
  | p :: ps, ρ => by
      dsimp [poly2Neg, evalPoly2]
      rw [evalPoly1_neg, evalPoly2_neg ps ρ, Rat.mul_neg, Rat.neg_add]

private theorem evalPoly2_scale1 (c : Poly1) : ∀ (P : Poly2) (ρ : Env2),
    evalPoly2 (poly2Scale1 c P) ρ = evalPoly1 c ρ.1 * evalPoly2 P ρ
  | [],      ρ => (Rat.mul_zero (evalPoly1 c ρ.1)).symm
  | p :: ps, ρ => by
      dsimp [poly2Scale1, evalPoly2]
      rw [evalPoly1_mul, evalPoly2_scale1 c ps ρ, ← Rat.mul_assoc ρ.2 _ _,
          Rat.mul_comm ρ.2 (evalPoly1 c ρ.1), Rat.mul_assoc (evalPoly1 c ρ.1) ρ.2 _,
          ← Rat.mul_add]

private theorem evalPoly2_mul : ∀ (P Q : Poly2) (ρ : Env2),
    evalPoly2 (poly2Mul P Q) ρ = evalPoly2 P ρ * evalPoly2 Q ρ
  | [],      qs, ρ => (Rat.zero_mul (evalPoly2 qs ρ)).symm
  | p :: ps, qs, ρ => by
      dsimp [poly2Mul]
      rw [evalPoly2_add, evalPoly2_scale1]
      dsimp [evalPoly2, evalPoly1]
      rw [Rat.zero_add, evalPoly2_mul ps qs ρ, ← Rat.mul_assoc ρ.2 _ _, ← Rat.add_mul]

/-- Exact ring homomorphism law: `evalPoly2 (toPoly2 p) ρ = evalPolyExpr p ρ` for all `ρ ∈ ℚ²`. -/
theorem toPoly2_eval_eq (p : PolyExpr) (ρ : Env2) :
    evalPoly2 (toPoly2 p) ρ = evalPolyExpr p ρ := by
  induction p with
  | pConst c =>
      dsimp [toPoly2, evalPoly2, evalPoly1, evalPolyExpr]
      rw [Rat.mul_zero, Rat.add_zero, Rat.mul_zero, Rat.add_zero]
  | pVarX =>
      dsimp [toPoly2, evalPoly2, evalPoly1, evalPolyExpr]
      rw [Rat.mul_zero, Rat.add_zero, Rat.mul_one, Rat.zero_add,
          Rat.mul_zero, Rat.add_zero]
  | pVarY =>
      dsimp [toPoly2, evalPoly2, evalPoly1, evalPolyExpr]
      rw [Rat.mul_zero, Rat.add_zero, Rat.mul_zero, Rat.add_zero,
          Rat.mul_one, Rat.zero_add]
  | pNeg q ih =>
      dsimp [toPoly2, evalPolyExpr]
      rw [evalPoly2_neg, ih]
  | pAdd q1 q2 ih1 ih2 =>
      dsimp [toPoly2, evalPolyExpr]
      rw [evalPoly2_add, ih1, ih2]
  | pSub q1 q2 ih1 ih2 =>
      dsimp [toPoly2, poly2Sub, evalPolyExpr]
      rw [evalPoly2_add, evalPoly2_neg, ih1, ih2, Rat.sub_eq_add_neg]
  | pMul q1 q2 ih1 ih2 =>
      dsimp [toPoly2, evalPolyExpr]
      rw [evalPoly2_mul, ih1, ih2]

private theorem evalPoly1_isZero : ∀ (row : Poly1) (x : Rat),
    row.all (fun c => c == 0) = true → evalPoly1 row x = 0
  | [],      _, _ => rfl
  | c :: cs, x, h => by
      simp only [List.all_cons, Bool.and_eq_true] at h
      dsimp [evalPoly1]
      rw [eq_of_beq h.1, evalPoly1_isZero cs x h.2]
      have hz0 : ((0 : Int) : Rat) = 0 := rfl
      rw [hz0, Rat.mul_zero, Rat.add_zero]

private theorem evalPoly2_isZero : ∀ (P : Poly2) (ρ : Env2),
    isZeroPoly2Bool P = true → evalPoly2 P ρ = 0
  | [],        _, _ => rfl
  | row :: ps, ρ, h => by
      unfold isZeroPoly2Bool at h
      simp only [List.all_cons, Bool.and_eq_true] at h
      dsimp [evalPoly2]
      rw [evalPoly1_isZero row ρ.1 h.1, evalPoly2_isZero ps ρ h.2, Rat.mul_zero, Rat.add_zero]

/-- Computable polynomial ring identity checker `polyExprEqBool p q` (`O(1)` pure `Int` `decide`!). -/
def polyExprEqBool (p q : PolyExpr) : Bool :=
  isZeroPoly2Bool (poly2Sub (toPoly2 p) (toPoly2 q))

/-- Soundness of `polyExprEqBool`: `polyExprEqBool p q = true` guarantees `evalPolyExpr p ρ = evalPolyExpr q ρ`
    for ALL `ρ : Env2` (`ℚ²`). -/
theorem polyExprEqBool_sound {p q : PolyExpr} (h : polyExprEqBool p q = true) (ρ : Env2) :
    evalPolyExpr p ρ = evalPolyExpr q ρ := by
  have hz := evalPoly2_isZero (poly2Sub (toPoly2 p) (toPoly2 q)) ρ h
  dsimp [poly2Sub] at hz
  rw [evalPoly2_add, evalPoly2_neg, toPoly2_eval_eq, toPoly2_eval_eq, ← Rat.sub_eq_add_neg] at hz
  exact rat_eq_of_sub_eq_zero hz

/-! ### 5. Strict Partial Formulas (`StrictForm`), `strictMPStep`, & Computable Grid Evaluation -/

/-- Syntactic formulas of strict partial rational logic (`F-B2A-01`, `F-B2A-03`). -/
inductive StrictForm where
  | eqZero    : PartExpr → StrictForm
  | nonneg    : PartExpr → StrictForm
  | pos       : PartExpr → StrictForm
  | neqZero   : PartExpr → StrictForm
  | conj      : StrictForm → StrictForm → StrictForm
  | impStrict : StrictForm → StrictForm → StrictForm
  deriving DecidableEq, Repr

/-- Independent declarative strict definedness of a `StrictForm` (`0` checker calls).
    Note (`Tribunal §4`): `impStrict φ ψ` requires BOTH `φ` and `ψ` to be defined at `ρ`. -/
def FormDefined : StrictForm → Env2 → Prop
  | .eqZero e,      ρ => PartExprDefined e ρ
  | .nonneg e,      ρ => PartExprDefined e ρ
  | .pos e,         ρ => PartExprDefined e ρ
  | .neqZero e,     ρ => PartExprDefined e ρ
  | .conj φ ψ,      ρ => FormDefined φ ρ ∧ FormDefined ψ ρ
  | .impStrict φ ψ, ρ => FormDefined φ ρ ∧ FormDefined ψ ρ

/-- Independent declarative raw satisfaction of a `StrictForm` (`0` checker calls). -/
def FormRawSat : StrictForm → Env2 → Prop
  | .eqZero e,      ρ => ∃ v : Rat, PartExprEvalRel e ρ v ∧ v = 0
  | .nonneg e,      ρ => ∃ v : Rat, PartExprEvalRel e ρ v ∧ 0 ≤ v
  | .pos e,         ρ => ∃ v : Rat, PartExprEvalRel e ρ v ∧ 0 < v
  | .neqZero e,     ρ => ∃ v : Rat, PartExprEvalRel e ρ v ∧ v ≠ 0
  | .conj φ ψ,      ρ => FormRawSat φ ρ ∧ FormRawSat ψ ρ
  | .impStrict φ ψ, ρ => FormRawSat φ ρ → FormRawSat ψ ρ

/-- Canonical projection into frozen `P1A0` `StrictPred Env2`. -/
def toStrictPred (φ : StrictForm) : StrictPred Env2 where
  defined := FormDefined φ
  rawSat  := FormRawSat φ

/-- Official strict satisfaction `ModelsStrictForm φ ρ := FormDefined φ ρ ∧ FormRawSat φ ρ`
    (definitionally equal to `ModelsStrictPred (toStrictPred φ) ρ`). -/
def ModelsStrictForm (φ : StrictForm) (ρ : Env2) : Prop :=
  ModelsStrictPred (toStrictPred φ) ρ

/-- **`F-B2A-03` Strict Modus Ponens Soundness (`strictMPStep_sound`)**:
    Strict satisfaction of `φ` AND strict satisfaction of `φ ⇒_strict ψ` (including strict
    definedness of `φ ⇒_strict ψ`) implies `ModelsStrictForm ψ ρ`. -/
theorem strictMPStep_sound {φ ψ : StrictForm} {ρ : Env2}
    (hAnt : ModelsStrictForm φ ρ)
    (hImp : ModelsStrictForm (.impStrict φ ψ) ρ) :
    ModelsStrictForm ψ ρ :=
  ⟨hImp.1.2, hImp.2 hAnt.2⟩

/-- Computable 4-state formula evaluation result for finite-domain checking & diagnostics. -/
inductive FormEvalRes where
  | satTrue         : FormEvalRes
  | satDefinedFalse : FormEvalRes
  | undefinedTerm   : FormEvalRes
  | resourceHeld    : Nat → FormEvalRes
  deriving DecidableEq, Repr

/-- Fuel-bounded computable strict formula evaluator (`evalStrictFormFuel`). -/
def evalStrictFormFuel : Nat → StrictForm → Env2 → FormEvalRes
  | 0,     _,              _ => .resourceHeld 0
  | f + 1, .eqZero e,      ρ =>
      match evalPartExprFuel f e ρ with
      | .val v            => if v == 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .nonneg e,      ρ =>
      match evalPartExprFuel f e ρ with
      | .val v            => if decide (0 ≤ v) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .pos e,         ρ =>
      match evalPartExprFuel f e ρ with
      | .val v            => if decide (0 < v) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .neqZero e,     ρ =>
      match evalPartExprFuel f e ρ with
      | .val v            => if v != 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .conj φ ψ,      ρ =>
      match evalStrictFormFuel f φ ρ, evalStrictFormFuel f ψ ρ with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satTrue         => .satTrue
      | _,                _                => .satDefinedFalse
  | f + 1, .impStrict φ ψ, ρ =>
      match evalStrictFormFuel f φ ρ, evalStrictFormFuel f ψ ρ with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satDefinedFalse => .satDefinedFalse
      | _,                _                => .satTrue

/-- Soundness of `evalStrictFormFuel`: `.satTrue` implies `ModelsStrictForm φ ρ`;
    `.satDefinedFalse` implies `FormDefined φ ρ ∧ ¬ FormRawSat φ ρ`. -/
theorem evalStrictFormFuel_sound :
    ∀ (fuel : Nat) (φ : StrictForm) (ρ : Env2),
      (evalStrictFormFuel fuel φ ρ = .satTrue → ModelsStrictForm φ ρ) ∧
      (evalStrictFormFuel fuel φ ρ = .satDefinedFalse → FormDefined φ ρ ∧ ¬ FormRawSat φ ρ)
  | 0, _, _ => And.intro (fun h => nomatch h) (fun h => nomatch h)
  | f + 1, .eqZero e, ρ => by
      have he := evalPartExprFuel_sound f e ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : (v == 0) = true then
              exact And.intro ⟨v, he.1 v hr⟩ ⟨v, he.1 v hr, eq_of_beq hv⟩
            else
              rw [if_neg hv] at h; nomatch h
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : (v == 0) = true then
              rw [if_pos hv] at h; nomatch h
            else
              refine And.intro ⟨v, he.1 v hr⟩ ?_
              rintro ⟨v', hrel', hz⟩
              have heq := partExprEvalRel_unique (he.1 v hr) hrel'
              subst heq; subst hz; exact hv rfl
  | f + 1, .nonneg e, ρ => by
      have he := evalPartExprFuel_sound f e ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : decide (0 ≤ v) = true then
              exact And.intro ⟨v, he.1 v hr⟩ ⟨v, he.1 v hr, of_decide_eq_true hv⟩
            else
              rw [if_neg hv] at h; nomatch h
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : decide (0 ≤ v) = true then
              rw [if_pos hv] at h; nomatch h
            else
              refine And.intro ⟨v, he.1 v hr⟩ ?_
              rintro ⟨v', hrel', hle⟩
              have heq := partExprEvalRel_unique (he.1 v hr) hrel'
              subst heq; exact hv (decide_eq_true hle)
  | f + 1, .pos e, ρ => by
      have he := evalPartExprFuel_sound f e ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : decide (0 < v) = true then
              exact And.intro ⟨v, he.1 v hr⟩ ⟨v, he.1 v hr, of_decide_eq_true hv⟩
            else
              rw [if_neg hv] at h; nomatch h
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : decide (0 < v) = true then
              rw [if_pos hv] at h; nomatch h
            else
              refine And.intro ⟨v, he.1 v hr⟩ ?_
              rintro ⟨v', hrel', hlt⟩
              have heq := partExprEvalRel_unique (he.1 v hr) hrel'
              subst heq; exact hv (decide_eq_true hlt)
  | f + 1, .neqZero e, ρ => by
      have he := evalPartExprFuel_sound f e ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : (v != 0) = true then
              have hne : v ≠ 0 := by intro hz; subst hz; contradiction
              exact And.intro ⟨v, he.1 v hr⟩ ⟨v, he.1 v hr, hne⟩
            else
              rw [if_neg hv] at h; nomatch h
      · intro h; unfold evalStrictFormFuel at h
        cases hr : evalPartExprFuel f e ρ with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val v =>
            rw [hr] at h; dsimp only at h
            if hv : (v != 0) = true then
              rw [if_pos hv] at h; nomatch h
            else
              have hz : v = 0 := by
                cases hb : (v == 0) with
                | true  => exact eq_of_beq hb
                | false => simp [bne, hb] at hv
              refine And.intro ⟨v, he.1 v hr⟩ ?_
              rintro ⟨v', hrel', hne⟩
              have heq := partExprEvalRel_unique (he.1 v hr) hrel'
              subst heq; exact hne hz
  | f + 1, .conj φ ψ, ρ => by
      have ih1 := evalStrictFormFuel_sound f φ ρ
      have ih2 := evalStrictFormFuel_sound f ψ ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases h1 : evalStrictFormFuel f φ ρ with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | satTrue         => exact And.intro ⟨(ih1.1 h1).1, (ih2.1 h2).1⟩ ⟨(ih1.1 h1).2, (ih2.1 h2).2⟩
            | satDefinedFalse => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
      · intro h; unfold evalStrictFormFuel at h
        cases h1 : evalStrictFormFuel f φ ρ with
        | resourceHeld _ => rw [h1] at h; nomatch h
        | undefinedTerm  =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse => exact And.intro ⟨(ih1.1 h1).1, (ih2.2 h2).1⟩ (fun hc => (ih2.2 h2).2 hc.2)
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.2 h1).1, (ih2.1 h2).1⟩ (fun hc => (ih1.2 h1).2 hc.1)
            | satDefinedFalse => exact And.intro ⟨(ih1.2 h1).1, (ih2.2 h2).1⟩ (fun hc => (ih1.2 h1).2 hc.1)
  | f + 1, .impStrict φ ψ, ρ => by
      have ih1 := evalStrictFormFuel_sound f φ ρ
      have ih2 := evalStrictFormFuel_sound f ψ ρ
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormFuel at h
        cases h1 : evalStrictFormFuel f φ ρ with
        | resourceHeld _ => rw [h1] at h; nomatch h
        | undefinedTerm  =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | satDefinedFalse => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.1 h1).1, (ih2.1 h2).1⟩ (fun _ => (ih2.1 h2).2)
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.2 h1).1, (ih2.1 h2).1⟩ (fun _ => (ih2.1 h2).2)
            | satDefinedFalse =>
                exact And.intro ⟨(ih1.2 h1).1, (ih2.2 h2).1⟩ (fun hf => False.elim ((ih1.2 h1).2 hf))
      · intro h; unfold evalStrictFormFuel at h
        cases h1 : evalStrictFormFuel f φ ρ with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormFuel f ψ ρ with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse =>
                exact And.intro ⟨(ih1.1 h1).1, (ih2.2 h2).1⟩ (fun himp => (ih2.2 h2).2 (himp (ih1.1 h1).2))

/-! ### 6. Fast Pure-`Int` Grid Evaluator for `FiniteGridExhaustiveCert` (`0` `Nat.gcd` Bottlenecks!) -/

/-- Exact unreduced rational pair `(num, den)` (`0 < den`) for `O(1)` pure-`Int` grid evaluation! -/
structure SynFrac where
  num : Int
  den : Int
  deriving DecidableEq, Repr

/-- Computable 3-state grid expression evaluator over `Int × Int` points (`by decide` friendly!). -/
inductive SynEvalRes where
  | val              : SynFrac → SynEvalRes
  | undefinedDivZero : SynEvalRes
  | resourceHeld     : Nat → SynEvalRes
  deriving DecidableEq, Repr

def evalPartExprGrid : Nat → PartExpr → (Int × Int) → SynEvalRes
  | 0,     _,          _ => .resourceHeld 0
  | _ + 1, .const c,   _ => .val ⟨c, 1⟩
  | _ + 1, .varX,      p => .val ⟨p.1, 1⟩
  | _ + 1, .varY,      p => .val ⟨p.2, 1⟩
  | f + 1, .neg e,     p =>
      match evalPartExprGrid f e p with
      | .val r            => .val ⟨-r.num, r.den⟩
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .add e1 e2, p =>
      match evalPartExprGrid f e1 p, evalPartExprGrid f e2 p with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.den + b.num * a.den, a.den * b.den⟩
  | f + 1, .sub e1 e2, p =>
      match evalPartExprGrid f e1 p, evalPartExprGrid f e2 p with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.den - b.num * a.den, a.den * b.den⟩
  | f + 1, .mul e1 e2, p =>
      match evalPartExprGrid f e1 p, evalPartExprGrid f e2 p with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.num, a.den * b.den⟩
  | f + 1, .div e1 e2, p =>
      match evalPartExprGrid f e1 p, evalPartExprGrid f e2 p with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b =>
          if b.num == 0 then .undefinedDivZero
          else if decide (0 < b.num) then .val ⟨a.num * b.den, a.den * b.num⟩
          else .val ⟨-(a.num * b.den), a.den * (-b.num)⟩

def evalStrictFormGrid : Nat → StrictForm → (Int × Int) → FormEvalRes
  | 0,     _,              _ => .resourceHeld 0
  | f + 1, .eqZero e,      p =>
      match evalPartExprGrid f e p with
      | .val r            => if r.num == 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .nonneg e,      p =>
      match evalPartExprGrid f e p with
      | .val r            => if decide (0 ≤ r.num) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .pos e,         p =>
      match evalPartExprGrid f e p with
      | .val r            => if decide (0 < r.num) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .neqZero e,     p =>
      match evalPartExprGrid f e p with
      | .val r            => if r.num != 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .conj φ ψ,      p =>
      match evalStrictFormGrid f φ p, evalStrictFormGrid f ψ p with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satTrue         => .satTrue
      | _,                _                => .satDefinedFalse
  | f + 1, .impStrict φ ψ, p =>
      match evalStrictFormGrid f φ p, evalStrictFormGrid f ψ p with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satDefinedFalse => .satDefinedFalse
      | _,                _                => .satTrue

/-- Semantic equivalence relation `SynFracRep r v` (`0 < r.den ∧ (r.den : Rat) * v = (r.num : Rat)`). -/
def SynFracRep (r : SynFrac) (v : Rat) : Prop :=
  0 < r.den ∧ (r.den : Rat) * v = (r.num : Rat)

private theorem synFracRep_val {r : SynFrac} (hd : 0 < r.den) :
    SynFracRep r ((r.num : Rat) / (r.den : Rat)) := by
  refine ⟨hd, ?_⟩
  have hd_ne : (r.den : Rat) ≠ 0 := Rat.ne_of_gt (Rat.intCast_pos.mpr hd)
  rw [Rat.div_def, ← Rat.mul_assoc, Rat.mul_comm (r.den : Rat) (r.num : Rat),
      Rat.mul_assoc, Rat.mul_inv_cancel (r.den : Rat) hd_ne, Rat.mul_one]

private theorem evalPartExprGrid_sound :
    ∀ (fuel : Nat) (e : PartExpr) (p : Int × Int) (r : SynFrac),
      evalPartExprGrid fuel e p = .val r →
      ∃ v : Rat, PartExprEvalRel e (gridPtToEnv2 p) v ∧ SynFracRep r v
  | 0, _, _, _, h => nomatch h
  | _ + 1, .const c, p, r, h => by
      injection h with hr; subst hr
      exact ⟨(c : Rat), .const c (gridPtToEnv2 p), ⟨show (0 : Int) < 1 by decide, Rat.one_mul (c : Rat)⟩⟩
  | _ + 1, .varX, p, r, h => by
      injection h with hr; subst hr
      exact ⟨(p.1 : Rat), .varX (gridPtToEnv2 p), ⟨show (0 : Int) < 1 by decide, Rat.one_mul (p.1 : Rat)⟩⟩
  | _ + 1, .varY, p, r, h => by
      injection h with hr; subst hr
      exact ⟨(p.2 : Rat), .varY (gridPtToEnv2 p), ⟨show (0 : Int) < 1 by decide, Rat.one_mul (p.2 : Rat)⟩⟩
  | f + 1, .neg e, p, r, h => by
      unfold evalPartExprGrid at h
      cases he : evalPartExprGrid f e p with
      | undefinedDivZero => rw [he] at h; nomatch h
      | resourceHeld _   => rw [he] at h; nomatch h
      | val a =>
          rw [he] at h; injection h with hr; subst hr
          rcases evalPartExprGrid_sound f e p a he with ⟨v, hrel, hd, heq⟩
          refine ⟨-v, .neg hrel, hd, ?_⟩
          dsimp only
          rw [Rat.mul_neg, heq, Rat.intCast_neg]
  | f + 1, .add e1 e2, p, r, h => by
      unfold evalPartExprGrid at h
      cases h1 : evalPartExprGrid f e1 p with
      | undefinedDivZero => rw [h1] at h; nomatch h
      | resourceHeld _   => rw [h1] at h; nomatch h
      | val a =>
          rw [h1] at h
          cases h2 : evalPartExprGrid f e2 p with
          | undefinedDivZero => rw [h2] at h; nomatch h
          | resourceHeld _   => rw [h2] at h; nomatch h
          | val b =>
              rw [h2] at h; injection h with hr; subst hr
              rcases evalPartExprGrid_sound f e1 p a h1 with ⟨v1, hr1, hda, hea⟩
              rcases evalPartExprGrid_sound f e2 p b h2 with ⟨v2, hr2, hdb, heb⟩
              refine ⟨v1 + v2, .add hr1 hr2, Int.mul_pos hda hdb, ?_⟩
              dsimp only
              rw [Rat.intCast_mul, Rat.intCast_add, Rat.intCast_mul, Rat.intCast_mul, Rat.mul_add]
              have t1 : (a.den : Rat) * (b.den : Rat) * v1 = (a.num : Rat) * (b.den : Rat) := by
                rw [Rat.mul_comm (a.den : Rat) (b.den : Rat), Rat.mul_assoc, hea, Rat.mul_comm]
              have t2 : (a.den : Rat) * (b.den : Rat) * v2 = (b.num : Rat) * (a.den : Rat) := by
                rw [Rat.mul_assoc, heb, Rat.mul_comm]
              rw [t1, t2]
  | f + 1, .sub e1 e2, p, r, h => by
      unfold evalPartExprGrid at h
      cases h1 : evalPartExprGrid f e1 p with
      | undefinedDivZero => rw [h1] at h; nomatch h
      | resourceHeld _   => rw [h1] at h; nomatch h
      | val a =>
          rw [h1] at h
          cases h2 : evalPartExprGrid f e2 p with
          | undefinedDivZero => rw [h2] at h; nomatch h
          | resourceHeld _   => rw [h2] at h; nomatch h
          | val b =>
              rw [h2] at h; injection h with hr; subst hr
              rcases evalPartExprGrid_sound f e1 p a h1 with ⟨v1, hr1, hda, hea⟩
              rcases evalPartExprGrid_sound f e2 p b h2 with ⟨v2, hr2, hdb, heb⟩
              refine ⟨v1 - v2, .sub hr1 hr2, Int.mul_pos hda hdb, ?_⟩
              dsimp only
              rw [Rat.intCast_mul, Rat.intCast_sub, Rat.intCast_mul, Rat.intCast_mul,
                  Rat.sub_eq_add_neg, Rat.mul_add, Rat.mul_neg]
              have t1 : (a.den : Rat) * (b.den : Rat) * v1 = (a.num : Rat) * (b.den : Rat) := by
                rw [Rat.mul_comm (a.den : Rat) (b.den : Rat), Rat.mul_assoc, hea, Rat.mul_comm]
              have t2 : (a.den : Rat) * (b.den : Rat) * v2 = (b.num : Rat) * (a.den : Rat) := by
                rw [Rat.mul_assoc, heb, Rat.mul_comm]
              rw [t1, t2, ← Rat.sub_eq_add_neg]
  | f + 1, .mul e1 e2, p, r, h => by
      unfold evalPartExprGrid at h
      cases h1 : evalPartExprGrid f e1 p with
      | undefinedDivZero => rw [h1] at h; nomatch h
      | resourceHeld _   => rw [h1] at h; nomatch h
      | val a =>
          rw [h1] at h
          cases h2 : evalPartExprGrid f e2 p with
          | undefinedDivZero => rw [h2] at h; nomatch h
          | resourceHeld _   => rw [h2] at h; nomatch h
          | val b =>
              rw [h2] at h; injection h with hr; subst hr
              rcases evalPartExprGrid_sound f e1 p a h1 with ⟨v1, hr1, hda, hea⟩
              rcases evalPartExprGrid_sound f e2 p b h2 with ⟨v2, hr2, hdb, heb⟩
              refine ⟨v1 * v2, .mul hr1 hr2, Int.mul_pos hda hdb, ?_⟩
              dsimp only
              rw [Rat.intCast_mul, Rat.intCast_mul, Rat.mul_assoc (a.den : Rat),
                  ← Rat.mul_assoc (b.den : Rat) v1 v2, Rat.mul_comm (b.den : Rat) v1,
                  Rat.mul_assoc v1 (b.den : Rat) v2, heb, ← Rat.mul_assoc, hea]
  | f + 1, .div e1 e2, p, r, h => by
      unfold evalPartExprGrid at h
      cases h1 : evalPartExprGrid f e1 p with
      | undefinedDivZero => rw [h1] at h; nomatch h
      | resourceHeld _   => rw [h1] at h; nomatch h
      | val a =>
          rw [h1] at h
          cases h2 : evalPartExprGrid f e2 p with
          | undefinedDivZero => rw [h2] at h; nomatch h
          | resourceHeld _   => rw [h2] at h; nomatch h
          | val b =>
              rw [h2] at h; dsimp only at h
              rcases evalPartExprGrid_sound f e1 p a h1 with ⟨v1, hr1, hda, hea⟩
              rcases evalPartExprGrid_sound f e2 p b h2 with ⟨v2, hr2, hdb, heb⟩
              if hbz : (b.num == 0) = true then
                rw [if_pos hbz] at h; nomatch h
              else
                rw [if_neg hbz] at h
                have hbnum_ne : b.num ≠ 0 := fun hz => hbz (beq_iff_eq.mpr hz)
                have hv2_ne : v2 ≠ 0 := by
                  intro hz
                  rw [hz, Rat.mul_zero] at heb
                  exact hbnum_ne (Rat.intCast_eq_zero_iff.mp heb.symm)
                have hCore : ((a.den : Rat) * (b.num : Rat)) * (v1 / v2) =
                    (a.num : Rat) * (b.den : Rat) := by
                  rw [← heb, Rat.div_def]
                  have hSwap : ((a.den : Rat) * ((b.den : Rat) * v2)) * (v1 * v2⁻¹) =
                      (b.den : Rat) * ((a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                    calc
                      ((a.den : Rat) * ((b.den : Rat) * v2)) * (v1 * v2⁻¹)
                        = ((a.den : Rat) * (b.den : Rat) * v2) * (v1 * v2⁻¹) := by
                            rw [Rat.mul_assoc (a.den : Rat) (b.den : Rat) v2]
                      _ = ((b.den : Rat) * (a.den : Rat) * v2) * (v1 * v2⁻¹) := by
                            rw [Rat.mul_comm (a.den : Rat) (b.den : Rat)]
                      _ = ((b.den : Rat) * (a.den : Rat)) * (v2 * (v1 * v2⁻¹)) := by
                            rw [Rat.mul_assoc ((b.den : Rat) * (a.den : Rat)) v2 (v1 * v2⁻¹)]
                      _ = ((b.den : Rat) * (a.den : Rat)) * ((v2 * v1) * v2⁻¹) := by
                            rw [Rat.mul_assoc v2 v1 v2⁻¹]
                      _ = ((b.den : Rat) * (a.den : Rat)) * ((v1 * v2) * v2⁻¹) := by
                            rw [Rat.mul_comm v2 v1]
                      _ = ((b.den : Rat) * (a.den : Rat)) * (v1 * (v2 * v2⁻¹)) := by
                            rw [Rat.mul_assoc v1 v2 v2⁻¹]
                      _ = ((b.den : Rat) * (a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                            rw [← Rat.mul_assoc ((b.den : Rat) * (a.den : Rat)) v1 (v2 * v2⁻¹)]
                      _ = (b.den : Rat) * ((a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                            rw [Rat.mul_assoc (b.den : Rat) (a.den : Rat) v1]
                  rw [hSwap, hea, Rat.mul_inv_cancel v2 hv2_ne, Rat.mul_one, Rat.mul_comm]
                if hbpos : decide (0 < b.num) = true then
                  rw [if_pos hbpos] at h; injection h with hr; subst hr
                  refine ⟨v1 / v2, .div hr1 hr2 hv2_ne,
                          Int.mul_pos hda (of_decide_eq_true hbpos), ?_⟩
                  dsimp only
                  rw [Rat.intCast_mul, Rat.intCast_mul]
                  exact hCore
                else
                  rw [if_neg hbpos] at h; injection h with hr; subst hr
                  have hnotpos : ¬ (0 < b.num) := fun hp => hbpos (decide_eq_true hp)
                  have hbneg : 0 < -b.num := by omega
                  refine ⟨v1 / v2, .div hr1 hr2 hv2_ne, Int.mul_pos hda hbneg, ?_⟩
                  dsimp only
                  rw [Rat.intCast_mul, Rat.intCast_neg, Rat.intCast_neg, Rat.intCast_mul,
                      Rat.mul_neg, Rat.neg_mul ((a.den : Rat) * (b.num : Rat)) (v1 / v2), hCore]

private theorem evalStrictFormGrid_sound :
    ∀ (fuel : Nat) (φ : StrictForm) (p : Int × Int),
      (evalStrictFormGrid fuel φ p = .satTrue → ModelsStrictForm φ (gridPtToEnv2 p)) ∧
      (evalStrictFormGrid fuel φ p = .satDefinedFalse →
        FormDefined φ (gridPtToEnv2 p) ∧ ¬ FormRawSat φ (gridPtToEnv2 p))
  | 0, _, _ => And.intro (fun h => nomatch h) (fun h => nomatch h)
  | f + 1, .eqZero e, p => by
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hz : (r.num == 0) = true then
              rw [eq_of_beq hz] at heq
              have hz0 : ((0 : Int) : Rat) = 0 := rfl
              rw [hz0] at heq
              exact And.intro ⟨v, hrel⟩ ⟨v, hrel, (rat_scale_eq_zero_iff hd).mp heq⟩
            else
              rw [if_neg hz] at h; nomatch h
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hz : (r.num == 0) = true then
              rw [if_pos hz] at h; nomatch h
            else
              refine And.intro ⟨v, hrel⟩ ?_
              rintro ⟨v', hrel', hv0⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv; rw [hv0, Rat.mul_zero] at heq
              exact hz (beq_iff_eq.mpr (Rat.intCast_eq_zero_iff.mp heq.symm))
  | f + 1, .nonneg e, p => by
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hnn : decide (0 ≤ r.num) = true then
              have hr_nn : (0 : Rat) ≤ (r.num : Rat) := Rat.intCast_nonneg.mpr (of_decide_eq_true hnn)
              rw [← heq] at hr_nn
              exact And.intro ⟨v, hrel⟩ ⟨v, hrel, rat_nonneg_of_pos_mul_nonneg hd hr_nn⟩
            else
              rw [if_neg hnn] at h; nomatch h
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hnn : decide (0 ≤ r.num) = true then
              rw [if_pos hnn] at h; nomatch h
            else
              refine And.intro ⟨v, hrel⟩ ?_
              rintro ⟨v', hrel', hv_nn⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv
              have hd_nn : (0 : Rat) ≤ (r.den : Rat) := Rat.le_of_lt (Rat.intCast_pos.mpr hd)
              have hprod : (0 : Rat) ≤ (r.den : Rat) * v := Rat.mul_nonneg hd_nn hv_nn
              rw [heq] at hprod
              exact hnn (decide_eq_true (Rat.intCast_nonneg.mp hprod))
  | f + 1, .pos e, p => by
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hp : decide (0 < r.num) = true then
              have hr_pos : (0 : Rat) < (r.num : Rat) := Rat.intCast_pos.mpr (of_decide_eq_true hp)
              rw [← heq] at hr_pos
              exact And.intro ⟨v, hrel⟩ ⟨v, hrel, rat_pos_of_pos_mul_pos hd hr_pos⟩
            else
              rw [if_neg hp] at h; nomatch h
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hp : decide (0 < r.num) = true then
              rw [if_pos hp] at h; nomatch h
            else
              refine And.intro ⟨v, hrel⟩ ?_
              rintro ⟨v', hrel', hv_pos⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv
              have hprod : (0 : Rat) < (r.den : Rat) * v :=
                Rat.mul_pos (Rat.intCast_pos.mpr hd) hv_pos
              rw [heq] at hprod
              exact hp (decide_eq_true (Rat.intCast_pos.mp hprod))
  | f + 1, .neqZero e, p => by
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hne : (r.num != 0) = true then
              have hv_ne : v ≠ 0 := by
                intro hz; rw [hz, Rat.mul_zero] at heq
                have hr0 : r.num = 0 := Rat.intCast_eq_zero_iff.mp heq.symm
                rw [hr0] at hne; contradiction
              exact And.intro ⟨v, hrel⟩ ⟨v, hrel, hv_ne⟩
            else
              rw [if_neg hne] at h; nomatch h
      · intro h; unfold evalStrictFormGrid at h
        cases hr : evalPartExprGrid f e p with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases evalPartExprGrid_sound f e p r hr with ⟨v, hrel, hd, heq⟩
            if hne : (r.num != 0) = true then
              rw [if_pos hne] at h; nomatch h
            else
              have hr0 : r.num = 0 := by
                cases hb : (r.num == 0) with
                | true  => exact eq_of_beq hb
                | false => simp [bne, hb] at hne
              rw [hr0] at heq
              have hz0 : ((0 : Int) : Rat) = 0 := rfl
              rw [hz0] at heq
              have hv0 : v = 0 := (rat_scale_eq_zero_iff hd).mp heq
              refine And.intro ⟨v, hrel⟩ ?_
              rintro ⟨v', hrel', hv_ne⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv; exact hv_ne hv0
  | f + 1, .conj φ ψ, p => by
      have ih1 := evalStrictFormGrid_sound f φ p
      have ih2 := evalStrictFormGrid_sound f ψ p
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases h1 : evalStrictFormGrid f φ p with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | satTrue         => exact And.intro ⟨(ih1.1 h1).1, (ih2.1 h2).1⟩ ⟨(ih1.1 h1).2, (ih2.1 h2).2⟩
            | satDefinedFalse => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
      · intro h; unfold evalStrictFormGrid at h
        cases h1 : evalStrictFormGrid f φ p with
        | resourceHeld _ => rw [h1] at h; nomatch h
        | undefinedTerm  =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse => exact And.intro ⟨(ih1.1 h1).1, (ih2.2 h2).1⟩ (fun hc => (ih2.2 h2).2 hc.2)
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.2 h1).1, (ih2.1 h2).1⟩ (fun hc => (ih1.2 h1).2 hc.1)
            | satDefinedFalse => exact And.intro ⟨(ih1.2 h1).1, (ih2.2 h2).1⟩ (fun hc => (ih1.2 h1).2 hc.1)
  | f + 1, .impStrict φ ψ, p => by
      have ih1 := evalStrictFormGrid_sound f φ p
      have ih2 := evalStrictFormGrid_sound f ψ p
      refine ⟨?_, ?_⟩
      · intro h; unfold evalStrictFormGrid at h
        cases h1 : evalStrictFormGrid f φ p with
        | resourceHeld _ => rw [h1] at h; nomatch h
        | undefinedTerm  =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | satDefinedFalse => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.1 h1).1, (ih2.1 h2).1⟩ (fun _ => (ih2.1 h2).2)
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => exact And.intro ⟨(ih1.2 h1).1, (ih2.1 h2).1⟩ (fun _ => (ih2.1 h2).2)
            | satDefinedFalse =>
                exact And.intro ⟨(ih1.2 h1).1, (ih2.2 h2).1⟩ (fun hf => False.elim ((ih1.2 h1).2 hf))
      · intro h; unfold evalStrictFormGrid at h
        cases h1 : evalStrictFormGrid f φ p with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormGrid f ψ p with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse =>
                exact And.intro ⟨(ih1.1 h1).1, (ih2.2 h2).1⟩ (fun himp => (ih2.2 h2).2 (himp (ih1.1 h1).2))

/-! ### 7. Four Algebraic & Domain Certificate Families (`AlgDomCert`) & `T-B2A-01` / `T-B2A-03` -/

/-- **Cert Family 1: `PolyPositivstellensatzCert`** (Scaled SOS + Active Guard Identity Certificate):
    Certifies `eqZero e`, `nonneg e`, or `pos e` over ANY domain (including infinite `ℚ`, `ℚ\{0}`, `ℚ²`)
    by clearing denominators with `lhsScale > 0` (`Int`) and verifying exact polynomial ring identity:
    `lhsScale * P(x,y) ≡ c₀ + ∑ c_i S_i(x,y)^2 + ∑ m_j G_j(x,y) + ∑ μ_k H_k(x,y) + ∑ Q_l E_l`. -/
structure PolyPositivstellensatzCert where
  lhsScale   : Int
  constTerm  : Int
  sqTerms    : List (Int × PolyExpr)
  nonnegMult : List (Nat × Int)
  posMult    : List (Nat × Int)
  eqMult     : List (Nat × PolyExpr)
  deriving DecidableEq, Repr

/-- **Cert Family 2: `LinearFarkasOrderCert`** (Scaled Farkas Cone Multiplier Certificate). -/
inductive LinearFarkasOrderCert where
  | coneNonneg       : (lhsScale constTerm : Int) → (nonnegWeights : List (Nat × Int)) →
                       (posWeights : List (Nat × Int)) → LinearFarkasOrderCert
  | conePos          : (lhsScale constTerm : Int) → (nonnegWeights : List (Nat × Int)) →
                       (posWeights : List (Nat × Int)) → LinearFarkasOrderCert
  | neqOfPosGuard    : (guardIdx : Nat) → LinearFarkasOrderCert
  | neqOfNegPosGuard : (guardIdx : Nat) → LinearFarkasOrderCert
  deriving DecidableEq, Repr

/-- **Cert Family 3: `GuardedReciprocalCert`** (Partial Division / Clearing-Denominators Certificate). -/
inductive GuardedReciprocalCert where
  | mulRecipCancel          : (den : PartExpr) → GuardedReciprocalCert
  | selfDivCancel           : (den : PartExpr) → GuardedReciprocalCert
  | recipPosOfPos           : (den : PartExpr) → GuardedReciprocalCert
  | posOfNeqZeroAndRecipPos : (den : PartExpr) → GuardedReciprocalCert
  | recipSqPosOfNeqZero     : (den : PartExpr) → GuardedReciprocalCert
  | nonzeroSqStrictPos      : (den : PartExpr) → GuardedReciprocalCert
  deriving DecidableEq, Repr

/-- **Cert Family 4: `FiniteGridExhaustiveCert`** (Finite Grid Exhaustive Evaluation Certificate):
    Deterministically REJECTED on all infinite domains (`.domQ`, `.domQNonzero`, `.domQ2`) (`T-B2A-03`). -/
structure FiniteGridExhaustiveCert where
  evalFuel : Nat
  deriving DecidableEq, Repr

/-- Unified 4-species algebraic & domain certificate sum (`Tribunal §1 & §5`). -/
inductive AlgDomCert where
  | polyPositivstellensatz : PolyPositivstellensatzCert → AlgDomCert
  | linearFarkasOrder      : LinearFarkasOrderCert → AlgDomCert
  | guardedReciprocal      : GuardedReciprocalCert → AlgDomCert
  | finiteGridExhaustive   : FiniteGridExhaustiveCert → AlgDomCert
  deriving DecidableEq, Repr

/-- Assemble SOS sum `∑ c_i * (S_i * S_i)` as a `PolyExpr`. -/
def buildSosPoly : List (Int × PolyExpr) → PolyExpr
  | []             => .pConst 0
  | (c, s) :: rest => .pAdd (.pMul (.pConst c) (.pMul s s)) (buildSosPoly rest)

private theorem buildSosPoly_nonneg : ∀ (terms : List (Int × PolyExpr)) (ρ : Env2),
    terms.all (fun cs => decide (0 ≤ cs.1)) = true →
    0 ≤ evalPolyExpr (buildSosPoly terms) ρ
  | [],             _, _ => Rat.le_refl
  | (c, s) :: rest, ρ, h => by
      simp only [List.all_cons, Bool.and_eq_true] at h
      dsimp [buildSosPoly, evalPolyExpr]
      have hc : (0 : Rat) ≤ (c : Rat) := Rat.intCast_nonneg.mpr (of_decide_eq_true h.1)
      have hsq : 0 ≤ evalPolyExpr s ρ * evalPolyExpr s ρ := rat_sq_nonneg (evalPolyExpr s ρ)
      exact Rat.add_nonneg (Rat.mul_nonneg hc hsq) (buildSosPoly_nonneg rest ρ h.2)

def lookupNonnegPolyGuard? (guards : List StrictForm) (idx : Nat) : Option PolyExpr :=
  match guards[idx]? with
  | some (.nonneg g) => promoteToPolyExpr? g
  | _                => none

def lookupPosPolyGuard? (guards : List StrictForm) (idx : Nat) : Option PolyExpr :=
  match guards[idx]? with
  | some (.pos g) => promoteToPolyExpr? g
  | _             => none

def lookupEqZeroPolyGuard? (guards : List StrictForm) (idx : Nat) : Option PolyExpr :=
  match guards[idx]? with
  | some (.eqZero g) => promoteToPolyExpr? g
  | _                => none

def buildWeightedGuardPoly (lookup? : Nat → Option PolyExpr) :
    List (Nat × Int) → Option PolyExpr
  | []              => some (.pConst 0)
  | (idx, w) :: rest =>
      match lookup? idx, buildWeightedGuardPoly lookup? rest with
      | some gp, some tail => some (.pAdd (.pMul (.pConst w) gp) tail)
      | _,       _         => none

def buildEqIdealPoly (guards : List StrictForm) : List (Nat × PolyExpr) → Option PolyExpr
  | []               => some (.pConst 0)
  | (idx, mp) :: rest =>
      match lookupEqZeroPolyGuard? guards idx, buildEqIdealPoly guards rest with
      | some ep, some tail => some (.pAdd (.pMul mp ep) tail)
      | _,       _         => none

private theorem list_getElem?_mem {α : Type} : ∀ (L : List α) (i : Nat) (x : α),
    L[i]? = some x → x ∈ L
  | [],      _, _, h     => nomatch h
  | a :: _,  0, x, h     => by injection h with hx; subst hx; exact List.mem_cons_self ..
  | a :: as, k + 1, x, h => List.mem_cons_of_mem a (list_getElem?_mem as k x h)

private theorem nonnegGuardPoly_val_nonneg {guards : List StrictForm} {ρ : Env2}
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ)
    {idx : Nat} {gp : PolyExpr} (hL : lookupNonnegPolyGuard? guards idx = some gp) :
    0 ≤ evalPolyExpr gp ρ := by
  unfold lookupNonnegPolyGuard? at hL
  cases hg : guards[idx]? with
  | none   => rw [hg] at hL; nomatch hL
  | some γ =>
      rw [hg] at hL
      cases γ with
      | nonneg ge =>
          have hmem := list_getElem?_mem guards idx (.nonneg ge) hg
          rcases (hSat (.nonneg ge) hmem).2 with ⟨v, hrel, hle⟩
          have hp := (promoteToPolyExpr?_sound hL).2 ρ
          have hv := partExprEvalRel_unique hp.1 hrel
          rwa [hv]
      | eqZero _    => nomatch hL
      | pos _       => nomatch hL
      | neqZero _   => nomatch hL
      | conj _ _    => nomatch hL
      | impStrict _ _ => nomatch hL

private theorem posGuardPoly_val_pos {guards : List StrictForm} {ρ : Env2}
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ)
    {idx : Nat} {gp : PolyExpr} (hL : lookupPosPolyGuard? guards idx = some gp) :
    0 < evalPolyExpr gp ρ := by
  unfold lookupPosPolyGuard? at hL
  cases hg : guards[idx]? with
  | none   => rw [hg] at hL; nomatch hL
  | some γ =>
      rw [hg] at hL
      cases γ with
      | pos ge =>
          have hmem := list_getElem?_mem guards idx (.pos ge) hg
          rcases (hSat (.pos ge) hmem).2 with ⟨v, hrel, hlt⟩
          have hp := (promoteToPolyExpr?_sound hL).2 ρ
          have hv := partExprEvalRel_unique hp.1 hrel
          rwa [hv]
      | eqZero _    => nomatch hL
      | nonneg _    => nomatch hL
      | neqZero _   => nomatch hL
      | conj _ _    => nomatch hL
      | impStrict _ _ => nomatch hL

private theorem eqGuardPoly_val_zero {guards : List StrictForm} {ρ : Env2}
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ)
    {idx : Nat} {ep : PolyExpr} (hL : lookupEqZeroPolyGuard? guards idx = some ep) :
    evalPolyExpr ep ρ = 0 := by
  unfold lookupEqZeroPolyGuard? at hL
  cases hg : guards[idx]? with
  | none   => rw [hg] at hL; nomatch hL
  | some γ =>
      rw [hg] at hL
      cases γ with
      | eqZero ge =>
          have hmem := list_getElem?_mem guards idx (.eqZero ge) hg
          rcases (hSat (.eqZero ge) hmem).2 with ⟨v, hrel, hz⟩
          have hp := (promoteToPolyExpr?_sound hL).2 ρ
          have hv := partExprEvalRel_unique hp.1 hrel
          rwa [hv]
      | nonneg _    => nomatch hL
      | pos _       => nomatch hL
      | neqZero _   => nomatch hL
      | conj _ _    => nomatch hL
      | impStrict _ _ => nomatch hL

private theorem weightedNonnegGuard_nonneg (guards : List StrictForm) (ρ : Env2)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∀ (ws : List (Nat × Int)) (out : PolyExpr),
      ws.all (fun iw => decide (0 ≤ iw.2)) = true →
      buildWeightedGuardPoly (lookupNonnegPolyGuard? guards) ws = some out →
      0 ≤ evalPolyExpr out ρ
  | [], _, _, hB => by
      injection hB with ho; subst ho; exact Rat.le_refl
  | (idx, w) :: rest, out, hW, hB => by
      simp only [List.all_cons, Bool.and_eq_true] at hW
      unfold buildWeightedGuardPoly at hB
      cases h1 : lookupNonnegPolyGuard? guards idx with
      | none    => rw [h1] at hB; nomatch hB
      | some gp =>
          rw [h1] at hB
          cases h2 : buildWeightedGuardPoly (lookupNonnegPolyGuard? guards) rest with
          | none      => rw [h2] at hB; nomatch hB
          | some tail =>
              rw [h2] at hB; injection hB with ho; subst ho
              dsimp [evalPolyExpr]
              exact Rat.add_nonneg
                (Rat.mul_nonneg (Rat.intCast_nonneg.mpr (of_decide_eq_true hW.1))
                  (nonnegGuardPoly_val_nonneg hSat h1))
                (weightedNonnegGuard_nonneg guards ρ hSat rest tail hW.2 h2)

private theorem weightedPosGuard_nonneg (guards : List StrictForm) (ρ : Env2)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∀ (ws : List (Nat × Int)) (out : PolyExpr),
      ws.all (fun iw => decide (0 ≤ iw.2)) = true →
      buildWeightedGuardPoly (lookupPosPolyGuard? guards) ws = some out →
      0 ≤ evalPolyExpr out ρ
  | [], _, _, hB => by
      injection hB with ho; subst ho; exact Rat.le_refl
  | (idx, w) :: rest, out, hW, hB => by
      simp only [List.all_cons, Bool.and_eq_true] at hW
      unfold buildWeightedGuardPoly at hB
      cases h1 : lookupPosPolyGuard? guards idx with
      | none    => rw [h1] at hB; nomatch hB
      | some gp =>
          rw [h1] at hB
          cases h2 : buildWeightedGuardPoly (lookupPosPolyGuard? guards) rest with
          | none      => rw [h2] at hB; nomatch hB
          | some tail =>
              rw [h2] at hB; injection hB with ho; subst ho
              dsimp [evalPolyExpr]
              have hgp : 0 ≤ evalPolyExpr gp ρ := Rat.le_of_lt (posGuardPoly_val_pos hSat h1)
              exact Rat.add_nonneg
                (Rat.mul_nonneg (Rat.intCast_nonneg.mpr (of_decide_eq_true hW.1)) hgp)
                (weightedPosGuard_nonneg guards ρ hSat rest tail hW.2 h2)

private theorem weightedPosGuard_strict_pos (guards : List StrictForm) (ρ : Env2)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∀ (ws : List (Nat × Int)) (out : PolyExpr),
      ws.all (fun iw => decide (0 ≤ iw.2)) = true →
      ws.any (fun iw => decide (0 < iw.2)) = true →
      buildWeightedGuardPoly (lookupPosPolyGuard? guards) ws = some out →
      0 < evalPolyExpr out ρ
  | [], _, _, hAny, _ => nomatch hAny
  | (idx, w) :: rest, out, hAll, hAny, hB => by
      simp only [List.all_cons, Bool.and_eq_true] at hAll
      simp only [List.any_cons, Bool.or_eq_true] at hAny
      unfold buildWeightedGuardPoly at hB
      cases h1 : lookupPosPolyGuard? guards idx with
      | none    => rw [h1] at hB; nomatch hB
      | some gp =>
          rw [h1] at hB
          cases h2 : buildWeightedGuardPoly (lookupPosPolyGuard? guards) rest with
          | none      => rw [h2] at hB; nomatch hB
          | some tail =>
              rw [h2] at hB; injection hB with ho; subst ho
              dsimp [evalPolyExpr]
              have hgp_pos : 0 < evalPolyExpr gp ρ := posGuardPoly_val_pos hSat h1
              have htail_nn : 0 ≤ evalPolyExpr tail ρ :=
                weightedPosGuard_nonneg guards ρ hSat rest tail hAll.2 h2
              rcases hAny with hw_pos | hrest_any
              · exact rat_add_pos_of_pos_of_nonneg
                  (Rat.mul_pos (Rat.intCast_pos.mpr (of_decide_eq_true hw_pos)) hgp_pos) htail_nn
              · have hhead_nn : 0 ≤ (w : Rat) * evalPolyExpr gp ρ :=
                  Rat.mul_nonneg (Rat.intCast_nonneg.mpr (of_decide_eq_true hAll.1))
                    (Rat.le_of_lt hgp_pos)
                exact rat_add_pos_of_nonneg_of_pos hhead_nn
                  (weightedPosGuard_strict_pos guards ρ hSat rest tail hAll.2 hrest_any h2)

private theorem eqIdealPoly_zero (guards : List StrictForm) (ρ : Env2)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∀ (ms : List (Nat × PolyExpr)) (out : PolyExpr),
      buildEqIdealPoly guards ms = some out →
      evalPolyExpr out ρ = 0
  | [], _, hB => by injection hB with ho; subst ho; rfl
  | (idx, mp) :: rest, out, hB => by
      unfold buildEqIdealPoly at hB
      cases h1 : lookupEqZeroPolyGuard? guards idx with
      | none    => rw [h1] at hB; nomatch hB
      | some ep =>
          rw [h1] at hB
          cases h2 : buildEqIdealPoly guards rest with
          | none      => rw [h2] at hB; nomatch hB
          | some tail =>
              rw [h2] at hB; injection hB with ho; subst ho
              dsimp [evalPolyExpr]
              rw [eqGuardPoly_val_zero hSat h1, Rat.mul_zero,
                  eqIdealPoly_zero guards ρ hSat rest tail h2, Rat.add_zero]

/-- Computable verifier for `PolyPositivstellensatzCert` (`O(1)` pure `Int` `decide`!). -/
def checkPolyPositivCertBool (guards : List StrictForm) (goal : StrictForm)
    (cert : PolyPositivstellensatzCert) : Bool :=
  decide (0 < cert.lhsScale) &&
  match buildWeightedGuardPoly (lookupNonnegPolyGuard? guards) cert.nonnegMult,
        buildWeightedGuardPoly (lookupPosPolyGuard? guards) cert.posMult,
        buildEqIdealPoly guards cert.eqMult with
  | some nnPoly, some posPoly, some eqPoly =>
      let rhs := PolyExpr.pAdd (.pConst cert.constTerm)
                   (.pAdd (buildSosPoly cert.sqTerms)
                     (.pAdd nnPoly (.pAdd posPoly eqPoly)))
      match goal with
      | .eqZero e =>
          match promoteToPolyExpr? e with
          | some pe =>
              (cert.constTerm == 0) &&
              cert.sqTerms.isEmpty &&
              cert.nonnegMult.isEmpty &&
              cert.posMult.isEmpty &&
              polyExprEqBool (.pMul (.pConst cert.lhsScale) pe) eqPoly
          | none => false
      | .nonneg e =>
          match promoteToPolyExpr? e with
          | some pe =>
              decide (0 ≤ cert.constTerm) &&
              cert.sqTerms.all (fun cs => decide (0 ≤ cs.1)) &&
              cert.nonnegMult.all (fun iw => decide (0 ≤ iw.2)) &&
              cert.posMult.all (fun iw => decide (0 ≤ iw.2)) &&
              polyExprEqBool (.pMul (.pConst cert.lhsScale) pe) rhs
          | none => false
      | .pos e =>
          match promoteToPolyExpr? e with
          | some pe =>
              decide (0 ≤ cert.constTerm) &&
              cert.sqTerms.all (fun cs => decide (0 ≤ cs.1)) &&
              cert.nonnegMult.all (fun iw => decide (0 ≤ iw.2)) &&
              cert.posMult.all (fun iw => decide (0 ≤ iw.2)) &&
              (decide (0 < cert.constTerm) || cert.posMult.any (fun iw => decide (0 < iw.2))) &&
              polyExprEqBool (.pMul (.pConst cert.lhsScale) pe) rhs
          | none => false
      | _ => false
  | _, _, _ => false

/-- Computable verifier for `LinearFarkasOrderCert`. -/
def checkLinearFarkasCertBool (guards : List StrictForm) (goal : StrictForm)
    (cert : LinearFarkasOrderCert) : Bool :=
  match cert, goal with
  | .coneNonneg sc c0 nnW posW, .nonneg e =>
      checkPolyPositivCertBool guards (.nonneg e) ⟨sc, c0, [], nnW, posW, []⟩
  | .conePos sc c0 nnW posW, .pos e =>
      checkPolyPositivCertBool guards (.pos e) ⟨sc, c0, [], nnW, posW, []⟩
  | .neqOfPosGuard idx, .neqZero e =>
      match guards[idx]?, promoteToPolyExpr? e with
      | some (.pos g), some pe =>
          match promoteToPolyExpr? g with
          | some pg => polyExprEqBool pe pg
          | none    => false
      | _, _ => false
  | .neqOfNegPosGuard idx, .neqZero e =>
      match guards[idx]?, promoteToPolyExpr? e with
      | some (.pos g), some pe =>
          match promoteToPolyExpr? g with
          | some pg => polyExprEqBool (.pNeg pe) pg
          | none    => false
      | _, _ => false
  | _, _ => false

/-- Computable verifier for `GuardedReciprocalCert` (checks active guards OR intrinsic `domQNonzero`). -/
def hasActiveNonzeroDenBool (domTag : G7DomTag) (guards : List StrictForm) (den : PartExpr) : Bool :=
  ((domTag == .domQNonzero) && (den == .varX)) ||
  guards.contains (.neqZero den) ||
  guards.contains (.pos den)

def checkGuardedRecipCertBool (domTag : G7DomTag) (guards : List StrictForm) (goal : StrictForm)
    (cert : GuardedReciprocalCert) : Bool :=
  match cert with
  | .mulRecipCancel den =>
      hasActiveNonzeroDenBool domTag guards den &&
      (goal == .eqZero (.sub (.mul den (.div (.const 1) den)) (.const 1)))
  | .selfDivCancel den =>
      hasActiveNonzeroDenBool domTag guards den &&
      (goal == .eqZero (.sub (.div den den) (.const 1)))
  | .recipPosOfPos den =>
      guards.contains (.pos den) &&
      (goal == .pos (.div (.const 1) den))
  | .posOfNeqZeroAndRecipPos den =>
      hasActiveNonzeroDenBool domTag guards den &&
      guards.contains (.pos (.div (.const 1) den)) &&
      (goal == .pos den)
  | .recipSqPosOfNeqZero den =>
      hasActiveNonzeroDenBool domTag guards den &&
      (goal == .pos (.mul (.div (.const 1) den) (.div (.const 1) den)))
  | .nonzeroSqStrictPos den =>
      hasActiveNonzeroDenBool domTag guards den &&
      (goal == .pos (.mul den den))

/-- Computable verifier for `FiniteGridExhaustiveCert` (`T-B2A-03` finite-vs-infinite gate). -/
def checkFiniteGridCertBool (domTag : G7DomTag) (guards : List StrictForm) (goal : StrictForm)
    (cert : FiniteGridExhaustiveCert) : Bool :=
  if isInfiniteDomTagBool domTag then
    false
  else
    match domTag with
    | .domFiniteGrid pts =>
        pts.all (fun p =>
          if guards.all (fun γ => evalStrictFormGrid cert.evalFuel γ p == .satTrue) then
            evalStrictFormGrid cert.evalFuel goal p == .satTrue
          else if guards.any (fun γ => evalStrictFormGrid cert.evalFuel γ p == .satDefinedFalse) then
            true
          else
            false)
    | _ => false

/-- Unified computable dispatcher for all 4 `AlgDomCert` families. -/
def checkAlgDomCertBool (domTag : G7DomTag) (guards : List StrictForm) (goal : StrictForm)
    (cert : AlgDomCert) : Bool :=
  match cert with
  | .polyPositivstellensatz c => checkPolyPositivCertBool guards goal c
  | .linearFarkasOrder c      => checkLinearFarkasCertBool guards goal c
  | .guardedReciprocal c      => checkGuardedRecipCertBool domTag guards goal c
  | .finiteGridExhaustive c   => checkFiniteGridCertBool domTag guards goal c

private theorem checkPolyPositivCert_sound {guards : List StrictForm} {goal : StrictForm}
    {cert : PolyPositivstellensatzCert} {ρ : Env2}
    (hChk : checkPolyPositivCertBool guards goal cert = true)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ModelsStrictForm goal ρ := by
  unfold checkPolyPositivCertBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨hScaleD, hBody⟩
  have hScale : 0 < cert.lhsScale := of_decide_eq_true hScaleD
  cases hNN : buildWeightedGuardPoly (lookupNonnegPolyGuard? guards) cert.nonnegMult with
  | none => rw [hNN] at hBody; nomatch hBody
  | some nnPoly =>
      rw [hNN] at hBody
      cases hPos : buildWeightedGuardPoly (lookupPosPolyGuard? guards) cert.posMult with
      | none => rw [hPos] at hBody; nomatch hBody
      | some posPoly =>
          rw [hPos] at hBody
          cases hEq : buildEqIdealPoly guards cert.eqMult with
          | none => rw [hEq] at hBody; nomatch hBody
          | some eqPoly =>
              rw [hEq] at hBody
              dsimp only at hBody
              cases goal with
              | eqZero e =>
                  dsimp only at hBody
                  cases hpe : promoteToPolyExpr? e with
                  | none => rw [hpe] at hBody; nomatch hBody
                  | some pe =>
                      rw [hpe] at hBody
                      simp only [Bool.and_eq_true] at hBody
                      rcases hBody with ⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hpolyEq⟩
                      have hp := (promoteToPolyExpr?_sound hpe).2 ρ
                      have hval := polyExprEqBool_sound hpolyEq ρ
                      dsimp [evalPolyExpr] at hval
                      rw [eqIdealPoly_zero guards ρ hSat cert.eqMult eqPoly hEq] at hval
                      exact And.intro hp.2 ⟨evalPolyExpr pe ρ, hp.1,
                        (rat_scale_eq_zero_iff hScale).mp hval⟩
              | nonneg e =>
                  dsimp only at hBody
                  cases hpe : promoteToPolyExpr? e with
                  | none => rw [hpe] at hBody; nomatch hBody
                  | some pe =>
                      rw [hpe] at hBody
                      simp only [Bool.and_eq_true] at hBody
                      rcases hBody with ⟨⟨⟨⟨hc0, hsq⟩, hnnW⟩, hposW⟩, hpolyEq⟩
                      have hp := (promoteToPolyExpr?_sound hpe).2 ρ
                      have hval := polyExprEqBool_sound hpolyEq ρ
                      dsimp [evalPolyExpr] at hval
                      rw [eqIdealPoly_zero guards ρ hSat cert.eqMult eqPoly hEq, Rat.add_zero] at hval
                      have h1 : (0 : Rat) ≤ (cert.constTerm : Rat) :=
                        Rat.intCast_nonneg.mpr (of_decide_eq_true hc0)
                      have h2 : 0 ≤ evalPolyExpr (buildSosPoly cert.sqTerms) ρ :=
                        buildSosPoly_nonneg cert.sqTerms ρ hsq
                      have h3 : 0 ≤ evalPolyExpr nnPoly ρ :=
                        weightedNonnegGuard_nonneg guards ρ hSat _ _ hnnW hNN
                      have h4 : 0 ≤ evalPolyExpr posPoly ρ :=
                        weightedPosGuard_nonneg guards ρ hSat _ _ hposW hPos
                      have hrhs : 0 ≤ (cert.lhsScale : Rat) * evalPolyExpr pe ρ := by
                        rw [hval]
                        exact Rat.add_nonneg h1 (Rat.add_nonneg h2 (Rat.add_nonneg h3 h4))
                      exact And.intro hp.2 ⟨evalPolyExpr pe ρ, hp.1,
                        rat_nonneg_of_pos_mul_nonneg hScale hrhs⟩
              | pos e =>
                  dsimp only at hBody
                  cases hpe : promoteToPolyExpr? e with
                  | none => rw [hpe] at hBody; nomatch hBody
                  | some pe =>
                      rw [hpe] at hBody
                      simp only [Bool.and_eq_true, Bool.or_eq_true] at hBody
                      rcases hBody with ⟨⟨⟨⟨⟨hc0, hsq⟩, hnnW⟩, hposW⟩, hstrict⟩, hpolyEq⟩
                      have hp := (promoteToPolyExpr?_sound hpe).2 ρ
                      have hval := polyExprEqBool_sound hpolyEq ρ
                      dsimp [evalPolyExpr] at hval
                      rw [eqIdealPoly_zero guards ρ hSat cert.eqMult eqPoly hEq, Rat.add_zero] at hval
                      have h1 : (0 : Rat) ≤ (cert.constTerm : Rat) :=
                        Rat.intCast_nonneg.mpr (of_decide_eq_true hc0)
                      have h2 : 0 ≤ evalPolyExpr (buildSosPoly cert.sqTerms) ρ :=
                        buildSosPoly_nonneg cert.sqTerms ρ hsq
                      have h3 : 0 ≤ evalPolyExpr nnPoly ρ :=
                        weightedNonnegGuard_nonneg guards ρ hSat _ _ hnnW hNN
                      have h4 : 0 ≤ evalPolyExpr posPoly ρ :=
                        weightedPosGuard_nonneg guards ρ hSat _ _ hposW hPos
                      have hrhs : 0 < (cert.lhsScale : Rat) * evalPolyExpr pe ρ := by
                        rw [hval]
                        rcases hstrict with hc0_pos | hpos_any
                        · exact rat_add_pos_of_pos_of_nonneg
                            (Rat.intCast_pos.mpr (of_decide_eq_true hc0_pos))
                            (Rat.add_nonneg h2 (Rat.add_nonneg h3 h4))
                        · have hp_strict : 0 < evalPolyExpr posPoly ρ :=
                            weightedPosGuard_strict_pos guards ρ hSat _ _ hposW hpos_any hPos
                          exact rat_add_pos_of_nonneg_of_pos h1
                            (rat_add_pos_of_nonneg_of_pos h2 (rat_add_pos_of_nonneg_of_pos h3 hp_strict))
                      exact And.intro hp.2 ⟨evalPolyExpr pe ρ, hp.1,
                        rat_pos_of_pos_mul_pos hScale hrhs⟩
              | neqZero _     => nomatch hBody
              | conj _ _      => nomatch hBody
              | impStrict _ _ => nomatch hBody

private theorem guardNeqOrPos_eval {domTag : G7DomTag} {guards : List StrictForm}
    {den : PartExpr} {ρ : Env2}
    (hOr : hasActiveNonzeroDenBool domTag guards den = true)
    (hDom : inG7Dom domTag ρ)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∃ vd : Rat, PartExprEvalRel den ρ vd ∧ vd ≠ 0 := by
  unfold hasActiveNonzeroDenBool at hOr
  simp only [Bool.or_eq_true, Bool.and_eq_true, List.contains_iff_mem] at hOr
  rcases hOr with (⟨hDomNz, hDenX⟩ | hneq) | hpos
  · rw [eq_of_beq hDomNz] at hDom
    rw [eq_of_beq hDenX]
    exact ⟨ρ.1, .varX ρ, hDom.1⟩
  · exact (hSat (.neqZero den) hneq).2
  · rcases (hSat (.pos den) hpos).2 with ⟨vd, hrel, hlt⟩
    exact ⟨vd, hrel, Rat.ne_of_gt hlt⟩

/-- **Universal Soundness of All 4 Algebraic & Domain Certificates (`checkAlgDomCert_sound`)**:
    Whenever `checkAlgDomCertBool domTag guards goal cert = true`, for EVERY `ρ ∈ inG7Dom domTag`
    satisfying `∀ γ ∈ guards, ModelsStrictForm γ ρ`, `ModelsStrictForm goal ρ` holds! -/
theorem checkAlgDomCert_sound {domTag : G7DomTag} {guards : List StrictForm}
    {goal : StrictForm} {cert : AlgDomCert} {ρ : Env2}
    (hChk : checkAlgDomCertBool domTag guards goal cert = true)
    (hDom : inG7Dom domTag ρ)
    (hSat : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ModelsStrictForm goal ρ := by
  cases cert with
  | polyPositivstellensatz c =>
      exact checkPolyPositivCert_sound hChk hSat
  | linearFarkasOrder c =>
      dsimp only [checkAlgDomCertBool, checkLinearFarkasCertBool] at hChk
      cases c with
      | coneNonneg sc c0 nnW posW =>
          cases goal with
          | nonneg e => exact checkPolyPositivCert_sound hChk hSat
          | eqZero _    => nomatch hChk
          | pos _       => nomatch hChk
          | neqZero _   => nomatch hChk
          | conj _ _    => nomatch hChk
          | impStrict _ _ => nomatch hChk
      | conePos sc c0 nnW posW =>
          cases goal with
          | pos e => exact checkPolyPositivCert_sound hChk hSat
          | eqZero _    => nomatch hChk
          | nonneg _    => nomatch hChk
          | neqZero _   => nomatch hChk
          | conj _ _    => nomatch hChk
          | impStrict _ _ => nomatch hChk
      | neqOfPosGuard idx =>
          cases goal with
          | neqZero e =>
              dsimp only at hChk
              cases hg : guards[idx]? with
              | none => rw [hg] at hChk; nomatch hChk
              | some γ =>
                  rw [hg] at hChk
                  cases γ with
                  | pos ge =>
                      cases hpe : promoteToPolyExpr? e with
                      | none => rw [hpe] at hChk; nomatch hChk
                      | some pe =>
                          rw [hpe] at hChk; dsimp only at hChk
                          cases hpg : promoteToPolyExpr? ge with
                          | none => rw [hpg] at hChk; nomatch hChk
                          | some pg =>
                              rw [hpg] at hChk; dsimp only at hChk
                              have hp_e := (promoteToPolyExpr?_sound hpe).2 ρ
                              have hp_g := (promoteToPolyExpr?_sound hpg).2 ρ
                              rcases (hSat (.pos ge) (list_getElem?_mem guards idx (.pos ge) hg)).2 with
                                ⟨vg, hrelg, hlt⟩
                              have hvg := partExprEvalRel_unique hp_g.1 hrelg
                              have hpe_eq := polyExprEqBool_sound hChk ρ
                              rw [← hvg, ← hpe_eq] at hlt
                              exact And.intro hp_e.2 ⟨evalPolyExpr pe ρ, hp_e.1, Rat.ne_of_gt hlt⟩
                  | _ => nomatch hChk
          | _ => nomatch hChk
      | neqOfNegPosGuard idx =>
          cases goal with
          | neqZero e =>
              dsimp only at hChk
              cases hg : guards[idx]? with
              | none => rw [hg] at hChk; nomatch hChk
              | some γ =>
                  rw [hg] at hChk
                  cases γ with
                  | pos ge =>
                      cases hpe : promoteToPolyExpr? e with
                      | none => rw [hpe] at hChk; nomatch hChk
                      | some pe =>
                          rw [hpe] at hChk; dsimp only at hChk
                          cases hpg : promoteToPolyExpr? ge with
                          | none => rw [hpg] at hChk; nomatch hChk
                          | some pg =>
                              rw [hpg] at hChk; dsimp only at hChk
                              have hp_e := (promoteToPolyExpr?_sound hpe).2 ρ
                              have hp_g := (promoteToPolyExpr?_sound hpg).2 ρ
                              rcases (hSat (.pos ge) (list_getElem?_mem guards idx (.pos ge) hg)).2 with
                                ⟨vg, hrelg, hlt⟩
                              have hvg := partExprEvalRel_unique hp_g.1 hrelg
                              have hpe_eq := polyExprEqBool_sound hChk ρ
                              dsimp [evalPolyExpr] at hpe_eq
                              rw [← hvg, ← hpe_eq] at hlt
                              have hne : evalPolyExpr pe ρ ≠ 0 := by
                                intro hz; rw [hz, Rat.neg_zero] at hlt; exact Rat.lt_irrefl hlt
                              exact And.intro hp_e.2 ⟨evalPolyExpr pe ρ, hp_e.1, hne⟩
                  | _ => nomatch hChk
          | _ => nomatch hChk
  | guardedReciprocal c =>
      unfold checkAlgDomCertBool checkGuardedRecipCertBool at hChk
      cases c with
      | mulRecipCancel den =>
          simp only [Bool.and_eq_true] at hChk
          rw [eq_of_beq hChk.2]
          rcases guardNeqOrPos_eval hChk.1 hDom hSat with ⟨vd, hrel, hne⟩
          have ho1 : ((1 : Int) : Rat) = 1 := rfl
          have hsub : PartExprEvalRel (.sub (.mul den (.div (.const 1) den)) (.const 1)) ρ
              (vd * (((1 : Int) : Rat) / vd) - ((1 : Int) : Rat)) :=
            .sub (.mul hrel (.div (.const 1 ρ) hrel hne)) (.const 1 ρ)
          have hz : vd * (((1 : Int) : Rat) / vd) - ((1 : Int) : Rat) = 0 := by
            rw [ho1, rat_mul_recip_eq_one hne, Rat.sub_self]
          exact And.intro ⟨_, hsub⟩ ⟨_, hsub, hz⟩
      | selfDivCancel den =>
          simp only [Bool.and_eq_true] at hChk
          rw [eq_of_beq hChk.2]
          rcases guardNeqOrPos_eval hChk.1 hDom hSat with ⟨vd, hrel, hne⟩
          have ho1 : ((1 : Int) : Rat) = 1 := rfl
          have hsub : PartExprEvalRel (.sub (.div den den) (.const 1)) ρ
              (vd / vd - ((1 : Int) : Rat)) :=
            .sub (.div hrel hrel hne) (.const 1 ρ)
          have hz : vd / vd - ((1 : Int) : Rat) = 0 := by
            rw [ho1, rat_div_self_eq_one hne, Rat.sub_self]
          exact And.intro ⟨_, hsub⟩ ⟨_, hsub, hz⟩
      | recipPosOfPos den =>
          simp only [Bool.and_eq_true, List.contains_iff_mem] at hChk
          rw [eq_of_beq hChk.2]
          rcases (hSat (.pos den) hChk.1).2 with ⟨vd, hrel, hlt⟩
          have hne : vd ≠ 0 := Rat.ne_of_gt hlt
          have hdiv : PartExprEvalRel (.div (.const 1) den) ρ (((1 : Int) : Rat) / vd) :=
            .div (.const 1 ρ) hrel hne
          exact And.intro ⟨_, hdiv⟩ ⟨_, hdiv, (rat_recip_pos_iff vd).mpr hlt⟩
      | posOfNeqZeroAndRecipPos den =>
          simp only [Bool.and_eq_true, List.contains_iff_mem] at hChk
          rw [eq_of_beq hChk.2]
          rcases guardNeqOrPos_eval hChk.1.1 hDom hSat with ⟨vd, hrel, hne⟩
          rcases (hSat (.pos (.div (.const 1) den)) hChk.1.2).2 with ⟨vr, hrelr, hltr⟩
          have hdiv : PartExprEvalRel (.div (.const 1) den) ρ (((1 : Int) : Rat) / vd) :=
            .div (.const 1 ρ) hrel hne
          have hvr := partExprEvalRel_unique hdiv hrelr
          rw [← hvr] at hltr
          exact And.intro ⟨vd, hrel⟩ ⟨vd, hrel, (rat_recip_pos_iff vd).mp hltr⟩
      | recipSqPosOfNeqZero den =>
          simp only [Bool.and_eq_true] at hChk
          rw [eq_of_beq hChk.2]
          rcases guardNeqOrPos_eval hChk.1 hDom hSat with ⟨vd, hrel, hne⟩
          have hdiv : PartExprEvalRel (.div (.const 1) den) ρ (((1 : Int) : Rat) / vd) :=
            .div (.const 1 ρ) hrel hne
          have hsq : PartExprEvalRel (.mul (.div (.const 1) den) (.div (.const 1) den)) ρ
              ((((1 : Int) : Rat) / vd) * (((1 : Int) : Rat) / vd)) := .mul hdiv hdiv
          have hpos : 0 < (((1 : Int) : Rat) / vd) * (((1 : Int) : Rat) / vd) :=
            (rat_sq_pos_iff_ne_zero ((1 : Rat) / vd)).mpr (rat_recip_ne_zero hne)
          exact And.intro ⟨_, hsq⟩ ⟨_, hsq, hpos⟩
      | nonzeroSqStrictPos den =>
          simp only [Bool.and_eq_true] at hChk
          rw [eq_of_beq hChk.2]
          rcases guardNeqOrPos_eval hChk.1 hDom hSat with ⟨vd, hrel, hne⟩
          have hsq : PartExprEvalRel (.mul den den) ρ (vd * vd) := .mul hrel hrel
          exact And.intro ⟨_, hsq⟩ ⟨_, hsq, (rat_sq_pos_iff_ne_zero vd).mpr hne⟩
  | finiteGridExhaustive c =>
      unfold checkAlgDomCertBool checkFiniteGridCertBool at hChk
      cases domTag with
      | domQ        => nomatch hChk
      | domQNonzero => nomatch hChk
      | domQ2       => nomatch hChk
      | domFiniteGrid pts =>
          dsimp [isInfiniteDomTagBool] at hChk
          rcases hDom with ⟨p, hpMem, rfl⟩
          have hpt := List.all_eq_true.mp hChk p hpMem
          if hgAll : (guards.all (fun γ => evalStrictFormGrid c.evalFuel γ p == .satTrue)) = true then
            rw [if_pos hgAll] at hpt
            exact (evalStrictFormGrid_sound c.evalFuel goal p).1 (eq_of_beq hpt)
          else
            rw [if_neg hgAll] at hpt
            if hgFalse : (guards.any (fun γ => evalStrictFormGrid c.evalFuel γ p == .satDefinedFalse)) = true then
              rcases List.any_eq_true.mp hgFalse with ⟨γ, hmem, hgf⟩
              have hnot := (evalStrictFormGrid_sound c.evalFuel γ p).2 (eq_of_beq hgf)
              exact False.elim (hnot.2 (hSat γ hmem).2)
            else
              rw [if_neg hgFalse] at hpt; nomatch hpt

/-! ### 8. Concrete Test Expressions & Theorems `T-B2A-01` and `T-B2A-03` -/

/-- Undefined-at-zero partial expression `(x / x) - 1` (`F-B2A-03` definedness-laundering probe). -/
def exprDivSelfMinusOne : PartExpr :=
  .sub (.div .varX .varX) (.const 1)

/-- Undefined-at-zero partial expression `0 * (1 / x)` (`F-B2A-03` zero-cancellation probe). -/
def exprZeroTimesRecip : PartExpr :=
  .mul (.const 0) (.div (.const 1) .varX)

/-- Total bivariate binomial target `(x + y)^2 - (x^2 + y^2)` (`CE-C1-03` on `ℚ²`). -/
def exprBinomialDiff : PartExpr :=
  .sub (.mul (.add .varX .varY) (.add .varX .varY))
       (.add (.mul .varX .varX) (.mul .varY .varY))

/-- **`T-B2A-01` — Partial Term Definedness Preservation, `promoteToPolyExpr?` Firewall,
    `strictMPStep` Soundness, & Non-Refuting `ResourceHeld` Separation**:
    (1) `promoteToPolyExpr?` guarantees universal `PartExprDefined` across `ℚ²`, while rejecting
        partial-division expressions `exprDivSelfMinusOne` (`(x/x) - 1`) and `exprZeroTimesRecip`
        (`0 * (1/x)`), both of which are strictly `¬ PartExprDefined` at `(0, 0)` despite naive
        algebraic cancellation;
    (2) `strictMPStep` preserves both `FormDefined` and `FormRawSat` (`ModelsStrictForm`), whereas
        an implication with an undefined consequent `(x = 0) ⇒_strict (1/x > 0)` is strictly NOT
        satisfied at `(0, 0)`;
    (3) `ResourceHeld` (`fuel = 0` on valid formula `0 ≤ x^2`) returns `.resourceHeld 0`, which
        implies NEITHER `False` NOR `¬ ModelsStrictForm` NOR `ValidCounterexamplePoint` (indeed,
        at `fuel = 4`, the exact same formula evaluates to `.satTrue`). -/
theorem T_B2A_01_partial_definedness_poly_firewall_and_resource_safety :
    -- (1) Total polynomial promotion firewall vs partial division undefinedness at 0
    (∀ (e : PartExpr) (p : PolyExpr) (ρ : Env2),
      promoteToPolyExpr? e = some p → PartExprDefined e ρ) ∧
    (promoteToPolyExpr? exprDivSelfMinusOne = none ∧
      ¬ PartExprDefined exprDivSelfMinusOne (0, 0)) ∧
    (promoteToPolyExpr? exprZeroTimesRecip = none ∧
      ¬ PartExprDefined exprZeroTimesRecip (0, 0)) ∧
    -- (2) Strict Modus Ponens definedness + truth preservation, and undefined-consequent block
    (∀ (φ ψ : StrictForm) (ρ : Env2),
      ModelsStrictForm φ ρ → ModelsStrictForm (.impStrict φ ψ) ρ → ModelsStrictForm ψ ρ) ∧
    ¬ ModelsStrictForm (.impStrict (.eqZero .varX) (.pos (.div (.const 1) .varX))) (0, 0) ∧
    -- (3) ResourceHeld non-refutation & fuel-increase recovery
    (let φSq : StrictForm := .nonneg (.mul .varX .varX)
     evalStrictFormFuel 0 φSq (0, 0) = .resourceHeld 0 ∧
     evalStrictFormFuel 4 φSq (0, 0) = .satTrue ∧
     ModelsStrictForm φSq (0, 0) ∧
     ¬ ValidCounterexamplePoint (inG7Dom .domQ) (toStrictPred φSq) (0, 0)) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro e p ρ hp
    exact ((promoteToPolyExpr?_sound hp).2 ρ).2
  · refine ⟨rfl, ?_⟩
    rintro ⟨v, hrel⟩
    cases hrel with
    | sub hdiv _ =>
        cases hdiv with
        | div _ hx hne =>
            cases hx
            exact hne rfl
  · refine ⟨rfl, ?_⟩
    rintro ⟨v, hrel⟩
    cases hrel with
    | mul _ hdiv =>
        cases hdiv with
        | div _ hx hne =>
            cases hx
            exact hne rfl
  · exact fun _ _ _ hA hI => strictMPStep_sound hA hI
  · intro himp
    rcases himp.1.2 with ⟨v, hdiv⟩
    cases hdiv with
    | div _ hx hne =>
        cases hx
        exact hne rfl
  · dsimp only
    have hsat4 : evalStrictFormFuel 4 (.nonneg (.mul .varX .varX)) (0, 0) = .satTrue := by
      simp [evalStrictFormFuel, evalPartExprFuel, Rat.mul_zero]
    have hm : ModelsStrictForm (.nonneg (.mul .varX .varX)) (0, 0) :=
      (evalStrictFormFuel_sound 4 (.nonneg (.mul .varX .varX)) (0, 0)).1 hsat4
    refine ⟨rfl, hsat4, hm, ?_⟩
    intro hce
    exact hce.2.2 hm.2

/-- **`T-B2A-03` — Universal Soundness of 4 Algebraic/Domain Certificates & Strict Separation
    of Finite Exhaustive Evaluation from Infinite Domains**:
    (1) Universal soundness holds for all 4 `AlgDomCert` families across `inG7Dom`;
    (2) Concrete positive acceptance for all 4 families (`O(1)` pure `decide`!):
        - `PolyPositivstellensatzCert`: `(x + y)^2 - (x^2 + y^2) ≥ 0` under guard `x * y ≥ 0` on `ℚ²`;
        - `LinearFarkasOrderCert`: `2 * x + y > 0` under guards `x ≥ 0` and `y > 0` on `ℚ²`
          (and fractional weight `x + (1/2) y > 0` via `lhsScale = 2` -> `2(x + y) = 2x + 2y > 0`);
        - `GuardedReciprocalCert`: `x * (1 / x) - 1 = 0` under guard `x ≠ 0` on `ℚ`;
        - `FiniteGridExhaustiveCert`: `x^2 > 0` on finite grid `[(-1, 0), (1, 0)]`;
    (3) Strict Finite-vs-Infinite Quarantine: `FiniteGridExhaustiveCert` is deterministically
        rejected (`= false`) on EVERY infinite domain (`.domQ`, `.domQNonzero`, `.domQ2`), so
        finite point sampling can NEVER certify an infinite domain! -/
theorem T_B2A_03_four_certificates_soundness_and_finite_infinite_separation :
    -- (1) Universal soundness across all 4 certificate families
    (∀ (domTag : G7DomTag) (guards : List StrictForm) (goal : StrictForm)
       (cert : AlgDomCert) (ρ : Env2),
      checkAlgDomCertBool domTag guards goal cert = true →
      inG7Dom domTag ρ →
      (∀ γ ∈ guards, ModelsStrictForm γ ρ) →
        ModelsStrictForm goal ρ) ∧
    -- (2) Concrete positive acceptance for all 4 families
    (checkAlgDomCertBool .domQ2 [.nonneg (.mul .varX .varY)] (.nonneg exprBinomialDiff)
        (.polyPositivstellensatz ⟨1, 0, [], [(0, 2)], [], []⟩) = true ∧
     checkAlgDomCertBool .domQ2 [.nonneg .varX, .pos .varY]
        (.pos (.add (.mul (.const 2) .varX) .varY))
        (.linearFarkasOrder (.conePos 1 0 [(0, 2)] [(1, 1)])) = true ∧
     checkAlgDomCertBool .domQ [.neqZero .varX]
        (.eqZero (.sub (.mul .varX (.div (.const 1) .varX)) (.const 1)))
        (.guardedReciprocal (.mulRecipCancel .varX)) = true ∧
     checkAlgDomCertBool (.domFiniteGrid [(-1, 0), (1, 0)]) []
        (.pos (.mul .varX .varX))
        (.finiteGridExhaustive ⟨5⟩) = true) ∧
    -- (3) Deterministic rejection of FiniteGridExhaustiveCert on all infinite domains
    (∀ (guards : List StrictForm) (goal : StrictForm) (fc : FiniteGridExhaustiveCert),
      checkAlgDomCertBool .domQ guards goal (.finiteGridExhaustive fc) = false ∧
      checkAlgDomCertBool .domQNonzero guards goal (.finiteGridExhaustive fc) = false ∧
      checkAlgDomCertBool .domQ2 guards goal (.finiteGridExhaustive fc) = false) := by
  refine ⟨fun _ _ _ _ _ hC hD hG => checkAlgDomCert_sound hC hD hG,
          ⟨by decide, by decide, by decide, by decide⟩,
          fun _ _ _ => ⟨rfl, rfl, rfl⟩⟩

end OmegaCellC1P1B2A
