/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  Module: OmegaCellC1P1B2BA0.A0_03_TelescopicPartition

  Authorized Scope (`A0_ISOLATED_LEAN_MECHANIZATION_APPROVED`, `A0-GUARD-02`):
    - `A0-03` (`L_B2B_TelescopicPartition`):
      1. Pure declarative `ExcisedLocus`, `ModelsExcised`, and `SemExactScopeLossPartition`
         (Coverage, Disjointness, Sub-Domain Containment, and Exact Set-Difference Equation
          `D_old \ D_new = D_old ∩ ModelsExcised(Φ)`).
      2. Definedness-conditional exclusive dichotomy (`atomicComplement_defined_xor`) for
         atomic `StrictForm` guards over `Rat` (`0` `Classical.choice`).
      3. Exhaustive 5-way `BaseDomRetreatStep` (`sameBaseDom`, `qToQNonzero`, `q2ToQ`,
         `q2ToQNonzero`, `finiteGridSub`) exact base partition theorem.
      4. Sequential prefix-defined delta-guard complement `buildDeltaExcisedBranches` +
         `L_B2B_TelescopicPartition` + direct `G7` `verifyReachableDerivation` bridge.
      5. Concrete rational witnesses & counterexamples (`A0-GUARD-02`):
         - Admissible sequential partial-division retreat `[x ≠ 0, 1/x > 0]` on `ℚ`:
           kernel-verified via frozen `verifyReachableDerivation` AND proved to capture
           BOTH the undefined point `x = 0` (`[x = 0]`) AND negative rationals `x = -2`
           (`[x ≠ 0, -1/x ≥ 0]`) while accepting `x = 2`!
         - Inadmissible unguarded `[1/x > 0]` counterexample (`F-B2B-T2-01`):
           proved to miss `x = 0` under raw dual AND rejected by frozen `G7` verifier!
         - Partial-loss hiding counterexample (`x > 10` claiming `x < 0` — `F-B2B-T1-02`):
           proved to violate `SemExactScopeLossPartition` at `x = 5`!
-/
import OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm

namespace OmegaCellC1P1B2BA0

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A

/-! ### 1. Constructive `Rat` Negation-Order Dichotomies (`0` `Classical.choice`) -/

private theorem rat_lt_of_lt_le {a b c : Rat} (hab : a < b) (hbc : b ≤ c) : a < c :=
  Rat.not_le.mp (fun hca => Rat.not_lt.mpr (Rat.le_trans hbc hca) hab)

private theorem rat_not_neg_nonneg_of_pos {v : Rat} (hv : 0 < v) : ¬ (0 ≤ -v) := by
  intro hnn
  have h1 : (0 : Rat) + 0 < v + 0 := Rat.add_lt_add_right.mpr hv
  have h2 : v + 0 ≤ v + (-v) := Rat.add_le_add_left.mpr hnn
  rw [Rat.add_zero, Rat.add_zero] at h1
  rw [Rat.add_zero, Rat.add_neg_cancel] at h2
  exact Rat.lt_irrefl (rat_lt_of_lt_le h1 h2)

private theorem rat_neg_nonneg_of_not_pos {v : Rat} (hnpos : ¬ (0 < v)) : 0 ≤ -v := by
  have hvle : v ≤ 0 := Rat.not_lt.mp hnpos
  have h1 : v + (-v) ≤ 0 + (-v) := Rat.add_le_add_right.mpr hvle
  rwa [Rat.add_neg_cancel, Rat.zero_add] at h1

private theorem rat_not_neg_pos_of_nonneg {v : Rat} (hnn : 0 ≤ v) : ¬ (0 < -v) := by
  intro hpos
  have h1 : (0 : Rat) + 0 < (-v) + 0 := Rat.add_lt_add_right.mpr hpos
  have h2 : (-v) + 0 ≤ (-v) + v := Rat.add_le_add_left.mpr hnn
  rw [Rat.add_zero, Rat.add_zero] at h1
  rw [Rat.add_zero, Rat.add_comm (-v) v, Rat.add_neg_cancel] at h2
  exact Rat.lt_irrefl (rat_lt_of_lt_le h1 h2)

private theorem rat_neg_pos_of_not_nonneg {v : Rat} (hnnn : ¬ (0 ≤ v)) : 0 < -v := by
  have hvlt : v < 0 := Rat.not_le.mp hnnn
  have h1 : v + (-v) < 0 + (-v) := Rat.add_lt_add_right.mpr hvlt
  rwa [Rat.add_neg_cancel, Rat.zero_add] at h1

/-! ### 2. Pure Semantic Scope-Loss Partition (`S_sem` — `0` Checker Calls) -/

/-- Disjunctive union of telescopic guard branches representing an excised domain locus. -/
abbrev ExcisedLocus : Type := List (List StrictForm)

/-- Strict satisfaction of a single excised guard-conjunction branch `E` at `ρ` (`0` checker calls). -/
def ModelsExcisedBranch (E : List StrictForm) (ρ : Env2) : Prop :=
  TelescopicGuardsDefined E ρ ∧ ∀ ψ ∈ E, ModelsStrictForm ψ ρ

/-- Strict satisfaction of the disjunctive union `Φ = [E₁, ..., E_r]` at `ρ` (`0` checker calls). -/
def ModelsExcised (Φ : ExcisedLocus) (ρ : Env2) : Prop :=
  ∃ E ∈ Φ, ModelsExcisedBranch E ρ

/-- **`SemExactScopeLossPartition` (`F-B2B-T1-02` & `F-B2B-T2-01` Target Semantics)**:
    Conjoins Disjointness, Exhaustive Coverage, Sub-Domain Containment, and the exact
    pointwise set-difference biconditional `D_old \ D_new = D_old ∩ ModelsExcised(Φ)`. -/
structure SemExactScopeLossPartition
    (D_old : G7DomTag) (Γ_old : List StrictForm)
    (D_new : G7DomTag) (Γ_new : List StrictForm)
    (Φ : ExcisedLocus) : Prop where
  disjoint_new_excised :
    ∀ ρ : Env2, ¬ (InEffDom D_new Γ_new ρ ∧ ModelsExcised Φ ρ)
  old_covered_by_new_or_excised :
    ∀ ρ : Env2, InEffDom D_old Γ_old ρ → InEffDom D_new Γ_new ρ ∨ ModelsExcised Φ ρ
  new_subset_old :
    ∀ ρ : Env2, InEffDom D_new Γ_new ρ → InEffDom D_old Γ_old ρ
  exact_set_difference :
    ∀ ρ : Env2,
      (InEffDom D_old Γ_old ρ ∧ ¬ InEffDom D_new Γ_new ρ) ↔
      (InEffDom D_old Γ_old ρ ∧ ModelsExcised Φ ρ)

/-- Helper constructor deriving `exact_set_difference` automatically from the first 3 clauses. -/
theorem mkSemExactScopeLossPartition
    {D_old : G7DomTag} {Γ_old : List StrictForm}
    {D_new : G7DomTag} {Γ_new : List StrictForm}
    {Φ : ExcisedLocus}
    (hDisj : ∀ ρ : Env2, ¬ (InEffDom D_new Γ_new ρ ∧ ModelsExcised Φ ρ))
    (hCov  : ∀ ρ : Env2, InEffDom D_old Γ_old ρ → InEffDom D_new Γ_new ρ ∨ ModelsExcised Φ ρ)
    (hSub  : ∀ ρ : Env2, InEffDom D_new Γ_new ρ → InEffDom D_old Γ_old ρ) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_new Φ where
  disjoint_new_excised := hDisj
  old_covered_by_new_or_excised := hCov
  new_subset_old := hSub
  exact_set_difference := by
    intro ρ
    constructor
    · rintro ⟨hOld, hNotNew⟩
      rcases hCov ρ hOld with hNew | hExc
      · exact False.elim (hNotNew hNew)
      · exact ⟨hOld, hExc⟩
    · rintro ⟨hOld, hExc⟩
      refine ⟨hOld, ?_⟩
      intro hNew
      exact hDisj ρ ⟨hNew, hExc⟩

/-! ### 3. Telescopic Concatenation & Atomic Guard Complement Dichotomy -/

theorem telescopicGuardsDefined_append_iff (Γ1 Γ2 : List StrictForm) (ρ : Env2) :
    TelescopicGuardsDefined (Γ1 ++ Γ2) ρ ↔
      (TelescopicGuardsDefined Γ1 ρ ∧
       ((∀ γ ∈ Γ1, ModelsStrictForm γ ρ) → TelescopicGuardsDefined Γ2 ρ)) := by
  induction Γ1 with
  | nil =>
      dsimp [TelescopicGuardsDefined]
      constructor
      · intro h2
        exact ⟨trivial, fun _ => h2⟩
      · intro h
        exact h.2 (fun _ hm => nomatch hm)
  | cons γ γs ih =>
      dsimp [TelescopicGuardsDefined]
      constructor
      · rintro ⟨hDef, hNext⟩
        refine ⟨⟨hDef, fun hM => ((ih).mp (hNext hM)).1⟩, ?_⟩
        intro hAll
        have hM : ModelsStrictForm γ ρ := hAll γ (List.mem_cons_self ..)
        exact ((ih).mp (hNext hM)).2 (fun g hg => hAll g (List.mem_cons_of_mem γ hg))
      · rintro ⟨⟨hDef, hTel1⟩, hImp2⟩
        refine ⟨hDef, fun hM => (ih).mpr ⟨hTel1 hM, ?_⟩⟩
        intro hRest
        apply hImp2
        intro g hg
        rcases List.mem_cons.mp hg with rfl | hTail
        · exact hM
        · exact hRest g hTail

/-- Syntactic test for atomic `StrictForm` literals (`.eqZero`, `.neqZero`, `.pos`, `.nonneg`). -/
def isAtomicStrictFormBool : StrictForm → Bool
  | .eqZero _  => true
  | .neqZero _ => true
  | .pos _     => true
  | .nonneg _  => true
  | _          => false

/-- Exact `Rat` linear-order / equality syntactic dual for an atomic `StrictForm`. -/
def atomicComplement : StrictForm → StrictForm
  | .eqZero e  => .neqZero e
  | .neqZero e => .eqZero e
  | .pos e     => .nonneg (.neg e)
  | .nonneg e  => .pos (.neg e)
  | φ          => φ

/-- **Definedness-Conditional Exclusive Dichotomy (`atomicComplement_defined_xor`)**:
    Whenever `isAtomicStrictFormBool δ = true` AND `FormDefined δ ρ` holds,
    `FormDefined (atomicComplement δ) ρ` ALSO holds, and `ModelsStrictForm δ ρ` vs
    `ModelsStrictForm (atomicComplement δ) ρ` form a strict constructive XOR! -/
theorem atomicComplement_defined_xor {δ : StrictForm} {ρ : Env2}
    (hAtom : isAtomicStrictFormBool δ = true) (hDef : FormDefined δ ρ) :
    FormDefined (atomicComplement δ) ρ ∧
    ((ModelsStrictForm δ ρ ∧ ¬ ModelsStrictForm (atomicComplement δ) ρ) ∨
     (¬ ModelsStrictForm δ ρ ∧ ModelsStrictForm (atomicComplement δ) ρ)) := by
  cases δ with
  | conj _ _ => nomatch hAtom
  | impStrict _ _ => nomatch hAtom
  | eqZero e =>
      rcases hDef with ⟨v, hv⟩
      dsimp [atomicComplement, FormDefined]
      refine ⟨⟨v, hv⟩, ?_⟩
      if hz : v = 0 then
        left
        refine ⟨⟨⟨v, hv⟩, ⟨v, hv, hz⟩⟩, ?_⟩
        rintro ⟨_, ⟨v', hv', hne⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hne hz
      else
        right
        refine ⟨?_, ⟨⟨v, hv⟩, ⟨v, hv, hz⟩⟩⟩
        rintro ⟨_, ⟨v', hv', hz'⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hz hz'
  | neqZero e =>
      rcases hDef with ⟨v, hv⟩
      dsimp [atomicComplement, FormDefined]
      refine ⟨⟨v, hv⟩, ?_⟩
      if hz : v = 0 then
        right
        refine ⟨?_, ⟨⟨v, hv⟩, ⟨v, hv, hz⟩⟩⟩
        rintro ⟨_, ⟨v', hv', hne⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hne hz
      else
        left
        refine ⟨⟨⟨v, hv⟩, ⟨v, hv, hz⟩⟩, ?_⟩
        rintro ⟨_, ⟨v', hv', hz'⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hz hz'
  | pos e =>
      rcases hDef with ⟨v, hv⟩
      have hNeg : PartExprEvalRel (.neg e) ρ (-v) := .neg hv
      dsimp [atomicComplement, FormDefined]
      refine ⟨⟨-v, hNeg⟩, ?_⟩
      if hp : 0 < v then
        left
        refine ⟨⟨⟨v, hv⟩, ⟨v, hv, hp⟩⟩, ?_⟩
        rintro ⟨_, ⟨v', hv', hnn⟩⟩
        have heq := partExprEvalRel_unique hNeg hv'
        subst heq
        exact rat_not_neg_nonneg_of_pos hp hnn
      else
        right
        have hnn : 0 ≤ -v := rat_neg_nonneg_of_not_pos hp
        refine ⟨?_, ⟨⟨-v, hNeg⟩, ⟨-v, hNeg, hnn⟩⟩⟩
        rintro ⟨_, ⟨v', hv', hp'⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hp hp'
  | nonneg e =>
      rcases hDef with ⟨v, hv⟩
      have hNeg : PartExprEvalRel (.neg e) ρ (-v) := .neg hv
      dsimp [atomicComplement, FormDefined]
      refine ⟨⟨-v, hNeg⟩, ?_⟩
      if hnn : 0 ≤ v then
        left
        refine ⟨⟨⟨v, hv⟩, ⟨v, hv, hnn⟩⟩, ?_⟩
        rintro ⟨_, ⟨v', hv', hp'⟩⟩
        have heq := partExprEvalRel_unique hNeg hv'
        subst heq
        exact rat_not_neg_pos_of_nonneg hnn hp'
      else
        right
        have hp : 0 < -v := rat_neg_pos_of_not_nonneg hnn
        refine ⟨?_, ⟨⟨-v, hNeg⟩, ⟨-v, hNeg, hp⟩⟩⟩
        rintro ⟨_, ⟨v', hv', hnn'⟩⟩
        have heq := partExprEvalRel_unique hv hv'
        subst heq
        exact hnn hnn'

/-! ### 4. Exhaustive 5-Case `BaseDomRetreatStep` & Base Partition Theorem -/

/-- Closed constructive taxonomy of base-domain tag retreats across all 4 `G7DomTag` constructors. -/
inductive BaseDomRetreatStep where
  | sameBaseDom   : (D : G7DomTag) → BaseDomRetreatStep
  | qToQNonzero   : BaseDomRetreatStep
  | q2ToQ         : BaseDomRetreatStep
  | q2ToQNonzero  : BaseDomRetreatStep
  | finiteGridSub : (L_old L_new : List (Int × Int)) → BaseDomRetreatStep
  deriving DecidableEq, Repr

/-- Check that `step` validly connects `D_old` to `D_new` (including `L_new ⊆ L_old` for grids). -/
def checkBaseDomRetreatStepBool (step : BaseDomRetreatStep) (D_old D_new : G7DomTag) : Bool :=
  match step with
  | .sameBaseDom D => (D_old == D) && (D_new == D)
  | .qToQNonzero   => (D_old == .domQ) && (D_new == .domQNonzero)
  | .q2ToQ         => (D_old == .domQ2) && (D_new == .domQ)
  | .q2ToQNonzero  => (D_old == .domQ2) && (D_new == .domQNonzero)
  | .finiteGridSub L_old L_new =>
      (D_old == .domFiniteGrid L_old) &&
      (D_new == .domFiniteGrid L_new) &&
      L_new.all (fun p => L_old.contains p)

/-- Canonical total-polynomial excised branches generated by `step` atop `Γ_old`. -/
def buildBaseExcisedBranches (step : BaseDomRetreatStep) (Γ_old : List StrictForm) : ExcisedLocus :=
  match step with
  | .sameBaseDom _ => []
  | .qToQNonzero   => [Γ_old ++ [.eqZero .varX]]
  | .q2ToQ         => [Γ_old ++ [.neqZero .varY]]
  | .q2ToQNonzero  => [Γ_old ++ [.neqZero .varY], Γ_old ++ [.eqZero .varY, .eqZero .varX]]
  | .finiteGridSub L_old L_new =>
      (L_old.filter (fun p => !L_new.contains p)).map (fun p =>
        Γ_old ++ [.eqZero (.sub .varX (.const p.1)), .eqZero (.sub .varY (.const p.2))])

private theorem gridPtToEnv2_inj {p q : Int × Int} (h : gridPtToEnv2 p = gridPtToEnv2 q) :
    p = q := by
  unfold gridPtToEnv2 at h
  injection h with hx hy
  have hx' : p.1 = q.1 := Rat.intCast_inj.mp hx
  have hy' : p.2 = q.2 := Rat.intCast_inj.mp hy
  cases p; cases q
  dsimp at hx' hy'
  subst hx'; subst hy'
  rfl

private theorem sub_const_eqZero_iff (v : Rat) (c : Int) (e : PartExpr) {ρ : Env2}
    (he : PartExprEvalRel e ρ v) :
    ModelsStrictForm (.eqZero (.sub e (.const c))) ρ ↔ v = (c : Rat) := by
  have hSub : PartExprEvalRel (.sub e (.const c)) ρ (v - (c : Rat)) := .sub he (.const c ρ)
  constructor
  · rintro ⟨_, ⟨u, hu, hz⟩⟩
    have heq := partExprEvalRel_unique hSub hu
    rw [← heq] at hz
    have h1 : (v - (c : Rat)) + (c : Rat) = 0 + (c : Rat) := congrArg (· + (c : Rat)) hz
    rwa [Rat.sub_add_cancel, Rat.zero_add] at h1
  · intro hvEq
    refine ⟨⟨v - (c : Rat), hSub⟩, ⟨v - (c : Rat), hSub, ?_⟩⟩
    rw [hvEq, Rat.sub_self]

/-- **Stage-1 Base Domain Retreat Exact Partition (`baseDomRetreat_exact_partition`)**:
    Across ALL 5 constructors of `BaseDomRetreatStep`, `(D_old, Γ_old)` partitions cleanly and
    without undefined points into `(D_new, Γ_old)` XOR `ModelsExcised (buildBaseExcisedBranches step Γ_old)`. -/
theorem baseDomRetreat_exact_partition {step : BaseDomRetreatStep} {D_old D_new : G7DomTag}
    (Γ_old : List StrictForm)
    (hStep : checkBaseDomRetreatStepBool step D_old D_new = true) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_old (buildBaseExcisedBranches step Γ_old) := by
  cases step with
  | sameBaseDom D =>
      unfold checkBaseDomRetreatStepBool at hStep
      simp only [Bool.and_eq_true] at hStep
      rw [eq_of_beq hStep.1, eq_of_beq hStep.2]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨_, ⟨_, hMem, _⟩⟩; nomatch hMem
      · intro ρ hOld; exact Or.inl hOld
      · intro ρ hNew; exact hNew
  | qToQNonzero =>
      unfold checkBaseDomRetreatStepBool at hStep
      simp only [Bool.and_eq_true] at hStep
      rw [eq_of_beq hStep.1, eq_of_beq hStep.2]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨hNew, ⟨E, hEMem, hE⟩⟩
        rcases List.mem_cons.mp hEMem with rfl | hNil
        · have hx0 : ModelsStrictForm (.eqZero .varX) ρ :=
            hE.2 (.eqZero .varX) (List.mem_append_right _ (List.mem_cons_self ..))
          rcases hx0.2 with ⟨v, hv, hz⟩
          cases hv
          exact hNew.1.1 hz
        · nomatch hNil
      · intro ρ ⟨hDomQ, hTelOld, hSatOld⟩
        if hx : ρ.1 = 0 then
          right
          refine ⟨Γ_old ++ [.eqZero .varX], List.mem_cons_self .., ?_, ?_⟩
          · rw [telescopicGuardsDefined_append_iff]
            exact ⟨hTelOld, fun _ => ⟨⟨ρ.1, .varX ρ⟩, fun _ => trivial⟩⟩
          · intro ψ hPsi
            rcases List.mem_append.mp hPsi with hInOld | hInTail
            · exact hSatOld ψ hInOld
            · rcases List.mem_cons.mp hInTail with rfl | hNil
              · exact ⟨⟨ρ.1, .varX ρ⟩, ⟨ρ.1, .varX ρ, hx⟩⟩
              · nomatch hNil
        else
          exact Or.inl ⟨⟨hx, hDomQ⟩, hTelOld, hSatOld⟩
      · intro ρ ⟨hDomNz, hTelOld, hSatOld⟩
        exact ⟨hDomNz.2, hTelOld, hSatOld⟩
  | q2ToQ =>
      unfold checkBaseDomRetreatStepBool at hStep
      simp only [Bool.and_eq_true] at hStep
      rw [eq_of_beq hStep.1, eq_of_beq hStep.2]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨hNew, ⟨E, hEMem, hE⟩⟩
        rcases List.mem_cons.mp hEMem with rfl | hNil
        · have hyNe : ModelsStrictForm (.neqZero .varY) ρ :=
            hE.2 (.neqZero .varY) (List.mem_append_right _ (List.mem_cons_self ..))
          rcases hyNe.2 with ⟨v, hv, hne⟩
          cases hv
          exact hne hNew.1
        · nomatch hNil
      · intro ρ ⟨_, hTelOld, hSatOld⟩
        if hy : ρ.2 = 0 then
          exact Or.inl ⟨hy, hTelOld, hSatOld⟩
        else
          right
          refine ⟨Γ_old ++ [.neqZero .varY], List.mem_cons_self .., ?_, ?_⟩
          · rw [telescopicGuardsDefined_append_iff]
            exact ⟨hTelOld, fun _ => ⟨⟨ρ.2, .varY ρ⟩, fun _ => trivial⟩⟩
          · intro ψ hPsi
            rcases List.mem_append.mp hPsi with hInOld | hInTail
            · exact hSatOld ψ hInOld
            · rcases List.mem_cons.mp hInTail with rfl | hNil
              · exact ⟨⟨ρ.2, .varY ρ⟩, ⟨ρ.2, .varY ρ, hy⟩⟩
              · nomatch hNil
      · intro ρ ⟨_, hTelOld, hSatOld⟩
        exact ⟨trivial, hTelOld, hSatOld⟩
  | q2ToQNonzero =>
      unfold checkBaseDomRetreatStepBool at hStep
      simp only [Bool.and_eq_true] at hStep
      rw [eq_of_beq hStep.1, eq_of_beq hStep.2]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨hNew, ⟨E, hEMem, hE⟩⟩
        rcases List.mem_cons.mp hEMem with rfl | hRest
        · have hyNe : ModelsStrictForm (.neqZero .varY) ρ :=
            hE.2 (.neqZero .varY) (List.mem_append_right _ (List.mem_cons_self ..))
          rcases hyNe.2 with ⟨v, hv, hne⟩
          cases hv
          exact hne hNew.1.2
        · rcases List.mem_cons.mp hRest with rfl | hNil
          · have hx0 : ModelsStrictForm (.eqZero .varX) ρ :=
              hE.2 (.eqZero .varX)
                (List.mem_append_right _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
            rcases hx0.2 with ⟨v, hv, hz⟩
            cases hv
            exact hNew.1.1 hz
          · nomatch hNil
      · intro ρ ⟨_, hTelOld, hSatOld⟩
        if hy : ρ.2 = 0 then
          if hx : ρ.1 = 0 then
            right
            refine ⟨Γ_old ++ [.eqZero .varY, .eqZero .varX],
              List.mem_cons_of_mem _ (List.mem_cons_self ..), ?_, ?_⟩
            · rw [telescopicGuardsDefined_append_iff]
              exact ⟨hTelOld, fun _ => ⟨⟨ρ.2, .varY ρ⟩, fun _ => ⟨⟨ρ.1, .varX ρ⟩, fun _ => trivial⟩⟩⟩
            · intro ψ hPsi
              rcases List.mem_append.mp hPsi with hInOld | hInTail
              · exact hSatOld ψ hInOld
              · rcases List.mem_cons.mp hInTail with rfl | hInTail2
                · exact ⟨⟨ρ.2, .varY ρ⟩, ⟨ρ.2, .varY ρ, hy⟩⟩
                · rcases List.mem_cons.mp hInTail2 with rfl | hNil
                  · exact ⟨⟨ρ.1, .varX ρ⟩, ⟨ρ.1, .varX ρ, hx⟩⟩
                  · nomatch hNil
          else
            exact Or.inl ⟨⟨hx, hy⟩, hTelOld, hSatOld⟩
        else
          right
          refine ⟨Γ_old ++ [.neqZero .varY], List.mem_cons_self .., ?_, ?_⟩
          · rw [telescopicGuardsDefined_append_iff]
            exact ⟨hTelOld, fun _ => ⟨⟨ρ.2, .varY ρ⟩, fun _ => trivial⟩⟩
          · intro ψ hPsi
            rcases List.mem_append.mp hPsi with hInOld | hInTail
            · exact hSatOld ψ hInOld
            · rcases List.mem_cons.mp hInTail with rfl | hNil
              · exact ⟨⟨ρ.2, .varY ρ⟩, ⟨ρ.2, .varY ρ, hy⟩⟩
              · nomatch hNil
      · intro ρ ⟨_, hTelOld, hSatOld⟩
        exact ⟨trivial, hTelOld, hSatOld⟩
  | finiteGridSub L_old L_new =>
      unfold checkBaseDomRetreatStepBool at hStep
      simp only [Bool.and_eq_true] at hStep
      rcases hStep with ⟨⟨hOldEq, hNewEq⟩, hSubList⟩
      rw [eq_of_beq hOldEq, eq_of_beq hNewEq]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨⟨⟨pNew, hpNewMem, hpNewEq⟩, _, _⟩, ⟨E, hEMem, hE⟩⟩
        dsimp [buildBaseExcisedBranches] at hEMem
        rcases List.mem_map.mp hEMem with ⟨pExc, hpExcFilt, rfl⟩
        rcases List.mem_filter.mp hpExcFilt with ⟨_, hNotInNew⟩
        have hxEq : ModelsStrictForm (.eqZero (.sub .varX (.const pExc.1))) ρ :=
          hE.2 _ (List.mem_append_right _ (List.mem_cons_self ..))
        have hyEq : ModelsStrictForm (.eqZero (.sub .varY (.const pExc.2))) ρ :=
          hE.2 _ (List.mem_append_right _ (List.mem_cons_of_mem _ (List.mem_cons_self ..)))
        have hxVal : ρ.1 = (pExc.1 : Rat) :=
          (sub_const_eqZero_iff ρ.1 pExc.1 .varX (.varX ρ)).mp hxEq
        have hyVal : ρ.2 = (pExc.2 : Rat) :=
          (sub_const_eqZero_iff ρ.2 pExc.2 .varY (.varY ρ)).mp hyEq
        have hPtEq : gridPtToEnv2 pExc = gridPtToEnv2 pNew := by
          rw [hpNewEq]
          cases ρ
          dsimp [gridPtToEnv2] at hxVal hyVal ⊢
          rw [hxVal, hyVal]
        have hpSame : pExc = pNew := gridPtToEnv2_inj hPtEq
        subst hpSame
        have hCont : L_new.contains pExc = true := List.contains_iff_mem.mpr hpNewMem
        rw [hCont] at hNotInNew
        nomatch hNotInNew
      · rintro ρ ⟨⟨pOld, hpOldMem, hpOldEq⟩, hTelOld, hSatOld⟩
        cases hInNew : L_new.contains pOld with
        | true =>
            left
            exact ⟨⟨pOld, List.contains_iff_mem.mp hInNew, hpOldEq⟩, hTelOld, hSatOld⟩
        | false =>
            right
            let E_p := Γ_old ++ [.eqZero (.sub .varX (.const pOld.1)),
                                  .eqZero (.sub .varY (.const pOld.2))]
            refine ⟨E_p, ?_, ?_, ?_⟩
            · dsimp [buildBaseExcisedBranches]
              apply List.mem_map.mpr
              refine ⟨pOld, List.mem_filter.mpr ⟨hpOldMem, ?_⟩, rfl⟩
              rw [hInNew]; rfl
            · rw [telescopicGuardsDefined_append_iff]
              refine ⟨hTelOld, fun _ => ?_⟩
              exact ⟨⟨ρ.1 - (pOld.1 : Rat), .sub (.varX ρ) (.const pOld.1 ρ)⟩,
                fun _ => ⟨⟨ρ.2 - (pOld.2 : Rat), .sub (.varY ρ) (.const pOld.2 ρ)⟩, fun _ => trivial⟩⟩
            · intro ψ hPsi
              rcases List.mem_append.mp hPsi with hInOld | hInTail
              · exact hSatOld ψ hInOld
              · have hx0 : ρ.1 = (pOld.1 : Rat) := by
                  rw [← hpOldEq]; rfl
                have hy0 : ρ.2 = (pOld.2 : Rat) := by
                  rw [← hpOldEq]; rfl
                rcases List.mem_cons.mp hInTail with rfl | hInTail2
                · exact (sub_const_eqZero_iff ρ.1 pOld.1 .varX (.varX ρ)).mpr hx0
                · rcases List.mem_cons.mp hInTail2 with rfl | hNil
                  · exact (sub_const_eqZero_iff ρ.2 pOld.2 .varY (.varY ρ)).mpr hy0
                  · nomatch hNil
      · rintro ρ ⟨⟨pNew, hpNewMem, hpNewEq⟩, hTelOld, hSatOld⟩
        have hpInOld : L_old.contains pNew = true := List.all_eq_true.mp hSubList pNew hpNewMem
        exact ⟨⟨pNew, List.contains_iff_mem.mp hpInOld, hpNewEq⟩, hTelOld, hSatOld⟩

/-! ### 5. Stage-2 Telescopic Delta-Guard Complement & `L_B2B_TelescopicPartition` -/

/-- Sequential De Morgan complement branches `[prefix ++ [δ̄₁], prefix ++ [δ₁, δ̄₂], ...]`. -/
def buildDeltaExcisedBranches (prefixGuards : List StrictForm) : List StrictForm → ExcisedLocus
  | []      => []
  | δ :: δs => (prefixGuards ++ [atomicComplement δ]) ::
               buildDeltaExcisedBranches (prefixGuards ++ [δ]) δs

private theorem delta_branches_exact_ind (D : G7DomTag) :
    ∀ (ΔΓ prefixG : List StrictForm),
      (∀ δ ∈ ΔΓ, isAtomicStrictFormBool δ = true) →
      (∀ ρ : Env2, inG7Dom D ρ → TelescopicGuardsDefined (prefixG ++ ΔΓ) ρ) →
      SemExactScopeLossPartition D prefixG D (prefixG ++ ΔΓ)
        (buildDeltaExcisedBranches prefixG ΔΓ)
  | [], prefixG, _, _ => by
      rw [List.append_nil]
      apply mkSemExactScopeLossPartition
      · rintro ρ ⟨_, ⟨_, hMem, _⟩⟩; nomatch hMem
      · intro ρ hOld; exact Or.inl hOld
      · intro ρ hNew; exact hNew
  | δ :: δs, prefixG, hAtoms, hPrefixDef => by
      have hAtomHead : isAtomicStrictFormBool δ = true := hAtoms δ (List.mem_cons_self ..)
      have hAtomTail : ∀ g ∈ δs, isAtomicStrictFormBool g = true :=
        fun g hg => hAtoms g (List.mem_cons_of_mem δ hg)
      have hAssocEq : ∀ ρ : Env2, (prefixG ++ [δ]) ++ δs = prefixG ++ (δ :: δs) :=
        fun _ => List.append_assoc prefixG [δ] δs
      have ih := delta_branches_exact_ind D δs (prefixG ++ [δ]) hAtomTail (by
        intro ρ hDom
        rw [hAssocEq ρ]
        exact hPrefixDef ρ hDom)
      apply mkSemExactScopeLossPartition
      · -- Disjointness
        rintro ρ ⟨hNew, ⟨E, hEMem, hE⟩⟩
        have hNewAssoc : InEffDom D ((prefixG ++ [δ]) ++ δs) ρ := by
          unfold InEffDom at hNew ⊢
          rw [hAssocEq ρ]
          exact hNew
        rcases List.mem_cons.mp hEMem with rfl | hRestMem
        · have hDeltaM : ModelsStrictForm δ ρ :=
            hNew.2.2 δ (List.mem_append_right _ (List.mem_cons_self ..))
          have hCompM : ModelsStrictForm (atomicComplement δ) ρ :=
            hE.2 (atomicComplement δ) (List.mem_append_right _ (List.mem_cons_self ..))
          have hXor := atomicComplement_defined_xor hAtomHead hDeltaM.1
          rcases hXor.2 with ⟨_, hNotComp⟩ | ⟨hNotDelta, _⟩
          · exact hNotComp hCompM
          · exact hNotDelta hDeltaM
        · exact ih.disjoint_new_excised ρ ⟨hNewAssoc, ⟨E, hRestMem, hE⟩⟩
      · -- Exhaustive Coverage (Zero Undefined Leakage!)
        intro ρ ⟨hDom, hTelPre, hSatPre⟩
        have hFullTel : TelescopicGuardsDefined (prefixG ++ (δ :: δs)) ρ :=
          hPrefixDef ρ hDom
        have hDeltaTel : TelescopicGuardsDefined (δ :: δs) ρ :=
          ((telescopicGuardsDefined_append_iff prefixG (δ :: δs) ρ).mp hFullTel).2 hSatPre
        have hDeltaDef : FormDefined δ ρ := hDeltaTel.1
        rcases atomicComplement_defined_xor hAtomHead hDeltaDef with ⟨hCompDef, hXor⟩
        rcases hXor with ⟨hDeltaTrue, _⟩ | ⟨_, hCompTrue⟩
        · -- δ holds at ρ -> pass to inductive tail on (prefixG ++ [δ])
          have hMidEff : InEffDom D (prefixG ++ [δ]) ρ := by
            refine ⟨hDom, ?_, ?_⟩
            · rw [telescopicGuardsDefined_append_iff]
              exact ⟨hTelPre, fun _ => ⟨hDeltaDef, fun _ => trivial⟩⟩
            · intro g hg
              rcases List.mem_append.mp hg with hInP | hInS
              · exact hSatPre g hInP
              · rcases List.mem_cons.mp hInS with rfl | hNil
                · exact hDeltaTrue
                · nomatch hNil
          rcases ih.old_covered_by_new_or_excised ρ hMidEff with hNewAssoc | ⟨E, hEMem, hE⟩
          · left
            unfold InEffDom at hNewAssoc ⊢
            rw [← hAssocEq ρ]
            exact hNewAssoc
          · exact Or.inr ⟨E, List.mem_cons_of_mem _ hEMem, hE⟩
        · -- δ̄ holds at ρ -> captured by head excised branch (prefixG ++ [atomicComplement δ])!
          right
          refine ⟨prefixG ++ [atomicComplement δ], List.mem_cons_self .., ?_, ?_⟩
          · rw [telescopicGuardsDefined_append_iff]
            exact ⟨hTelPre, fun _ => ⟨hCompDef, fun _ => trivial⟩⟩
          · intro ψ hPsi
            rcases List.mem_append.mp hPsi with hInP | hInC
            · exact hSatPre ψ hInP
            · rcases List.mem_cons.mp hInC with rfl | hNil
              · exact hCompTrue
              · nomatch hNil
      · -- Sub-domain containment
        intro ρ ⟨hDom, _, hSatAll⟩
        have hFullTel : TelescopicGuardsDefined (prefixG ++ (δ :: δs)) ρ :=
          hPrefixDef ρ hDom
        exact ⟨hDom, ((telescopicGuardsDefined_append_iff prefixG (δ :: δs) ρ).mp hFullTel).1,
          fun g hg => hSatAll g (List.mem_append_left _ hg)⟩

/-- Canonical 2-stage excised locus `B_base ++ B_delta`. -/
def buildCanonicalRetreatExcised (step : BaseDomRetreatStep)
    (Γ_old ΔΓ : List StrictForm) : ExcisedLocus :=
  buildBaseExcisedBranches step Γ_old ++ buildDeltaExcisedBranches Γ_old ΔΓ

/-- **`A0-03` (`L_B2B_TelescopicPartition`) — Exact 2-Stage Telescopic Scope-Loss Partition**:
    Combines ALL 5 `BaseDomRetreatStep` transitions with sequential prefix-defined atomic
    delta-guards `ΔΓ` and effective-domain equivalence `Γ_new ↔ Γ_old ++ ΔΓ`, establishing:
    (1) Mutual Exclusivity (`Disjointness`),
    (2) Old-Domain Exhaustive Coverage (with zero undefined leakage!),
    (3) Sub-Domain Containment (`D_new,eff ⊆ D_old,eff`), and
    (4) Exact Set-Difference Equation `D_old,eff \ D_new,eff = D_old,eff ∩ ModelsExcised(B_canon)`. -/
theorem L_B2B_TelescopicPartition
    {step : BaseDomRetreatStep} {D_old D_new : G7DomTag}
    {Γ_old ΔΓ Γ_new : List StrictForm}
    (hStep      : checkBaseDomRetreatStepBool step D_old D_new = true)
    (hAtoms     : ΔΓ.all isAtomicStrictFormBool = true)
    (hPrefixDef : ∀ ρ : Env2, inG7Dom D_new ρ → TelescopicGuardsDefined (Γ_old ++ ΔΓ) ρ)
    (hGuardConn : SemSameEffDom D_new Γ_new D_new (Γ_old ++ ΔΓ)) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_new
      (buildCanonicalRetreatExcised step Γ_old ΔΓ) := by
  have hBase := baseDomRetreat_exact_partition Γ_old hStep
  have hDelta := delta_branches_exact_ind D_new ΔΓ Γ_old
    (fun δ hMem => List.all_eq_true.mp hAtoms δ hMem) hPrefixDef
  apply mkSemExactScopeLossPartition
  · -- Disjointness
    rintro ρ ⟨hNew, ⟨E, hEMem, hE⟩⟩
    have hNewDelta : InEffDom D_new (Γ_old ++ ΔΓ) ρ := (hGuardConn ρ).mp hNew
    have hMid : InEffDom D_new Γ_old ρ := hDelta.new_subset_old ρ hNewDelta
    rcases List.mem_append.mp hEMem with hInBase | hInDelta
    · exact hBase.disjoint_new_excised ρ ⟨hMid, ⟨E, hInBase, hE⟩⟩
    · exact hDelta.disjoint_new_excised ρ ⟨hNewDelta, ⟨E, hInDelta, hE⟩⟩
  · -- Exhaustive Coverage
    intro ρ hOld
    rcases hBase.old_covered_by_new_or_excised ρ hOld with hMid | ⟨E, hEMem, hE⟩
    · rcases hDelta.old_covered_by_new_or_excised ρ hMid with hNewDelta | ⟨E, hEMem, hE⟩
      · exact Or.inl ((hGuardConn ρ).mpr hNewDelta)
      · exact Or.inr ⟨E, List.mem_append_right _ hEMem, hE⟩
    · exact Or.inr ⟨E, List.mem_append_left _ hEMem, hE⟩
  · -- Sub-domain containment
    intro ρ hNew
    exact hBase.new_subset_old ρ (hDelta.new_subset_old ρ ((hGuardConn ρ).mp hNew))

/-- Direct `G7` Kernel Bridge for `L_B2B_TelescopicPartition`:
    Verifying a single prefix-definedness node `prefixDefNodeId` via frozen `verifyReachableDerivation`
    automatically supplies the `hPrefixDef` hypothesis of `L_B2B_TelescopicPartition`! -/
theorem L_B2B_TelescopicPartition_from_G7
    {fuel : Nat} {Γ_env : PrimPremiseEnv} {C : G7DagContainer} {prefixDefNodeId specId : String}
    {step : BaseDomRetreatStep} {D_old D_new : G7DomTag}
    {Γ_old ΔΓ Γ_new : List StrictForm} {goalDummy : StrictForm}
    (hCont     : ValidContainer C)
    (hStep     : checkBaseDomRetreatStepBool step D_old D_new = true)
    (hAtoms    : ΔΓ.all isAtomicStrictFormBool = true)
    (hG7Def    : verifyReachableDerivation fuel Γ_env C prefixDefNodeId =
                   .accept ⟨D_new, specId, Γ_old ++ ΔΓ, goalDummy⟩)
    (hPrem     : ∀ p ∈ extractTransitivePrimDeps Γ_env C prefixDefNodeId, SemValidPrimId Γ_env p)
    (hGuardConn : SemSameEffDom D_new Γ_new D_new (Γ_old ++ ΔΓ)) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_new
      (buildCanonicalRetreatExcised step Γ_old ΔΓ) := by
  have hSem := verifyReachable_master_sound fuel Γ_env C prefixDefNodeId
    ⟨D_new, specId, Γ_old ++ ΔΓ, goalDummy⟩ hCont hG7Def hPrem
  exact L_B2B_TelescopicPartition hStep hAtoms hSem.1 hGuardConn

/-! ### 6. Concrete Rational Witnesses & Counterexamples (`A0-GUARD-02` Mandatory Suite) -/

/-- Admissible sequential partial-division guards `[x ≠ 0, 1/x > 0]` on `ℚ`. -/
def deltaSeqRecipGuards : List StrictForm :=
  [.neqZero .varX, .pos (.div (.const 1) .varX)]

/-- Concrete `G7DagContainer` certifying prefix definedness of `[x ≠ 0, 1/x > 0]` on `.domQ`. -/
def containerSeqRecipPrefixDef : G7DagContainer where
  nodes := [
    { nodeId     := "n_seq_prefix_def"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_a0"
      guards     := deltaSeqRecipGuards
      conclusion := .eqZero (.const 0)
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := deltaSeqRecipGuards
        goalForm             := .eqZero (.const 0)
        guardWfCerts         := [.totalPolyWf, .prefixGuardDenomWf .varX]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.eqZero (.const 0))
                                  (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)
      } }
  ]

/-- Inadmissible unguarded `[1/x > 0]` container (lacks `x ≠ 0` prefix guard — `F-B2B-T2-01`). -/
def containerInvalidRawRecip : G7DagContainer where
  nodes := [
    { nodeId     := "n_bad_raw_recip"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_a0"
      guards     := [.pos (.div (.const 1) .varX)]
      conclusion := .eqZero (.const 0)
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.pos (.div (.const 1) .varX)]
        goalForm             := .eqZero (.const 0)
        guardWfCerts         := [.totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.eqZero (.const 0))
                                  (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)
      } }
  ]

/-- **`A0-03a` — Admissible `[x ≠ 0, 1/x > 0]` Partition Witness (`A0-GUARD-02`)**:
    (1) Frozen `verifyReachableDerivation` accepts `containerSeqRecipPrefixDef`;
    (2) `SemExactScopeLossPartition` holds for `D_old = .domQ, Γ_old = [] → D_new = .domQ, Γ_new = [x ≠ 0, 1/x > 0]`;
    (3) Canonical excised locus `[[x = 0], [x ≠ 0, -1/x ≥ 0]]` explicitly classifies:
        - `ρ = (0, 0)` (the division-by-zero point!) into `ModelsExcised`,
        - `ρ = (-2, 0)` (negative rational!) into `ModelsExcised`, and
        - `ρ = (2, 0)` (positive rational!) into `InEffDom .domQ deltaSeqRecipGuards`! -/
theorem A0_03a_seqRecip_exact_partition_and_point_classification :
    let Φ := buildCanonicalRetreatExcised (.sameBaseDom .domQ) [] deltaSeqRecipGuards
    verifyReachableDerivation 3 [] containerSeqRecipPrefixDef "n_seq_prefix_def" =
      .accept ⟨.domQ, "spec_a0", deltaSeqRecipGuards, .eqZero (.const 0)⟩ ∧
    SemExactScopeLossPartition .domQ [] .domQ deltaSeqRecipGuards Φ ∧
    ModelsExcised Φ (0, 0) ∧
    ModelsExcised Φ (-2, 0) ∧
    InEffDom .domQ deltaSeqRecipGuards (2, 0) ∧
    ¬ ModelsExcised Φ (2, 0) := by
  have hPart : SemExactScopeLossPartition .domQ [] .domQ deltaSeqRecipGuards
      (buildCanonicalRetreatExcised (.sameBaseDom .domQ) [] deltaSeqRecipGuards) :=
    L_B2B_TelescopicPartition_from_G7
      (fuel := 3) (Γ_env := []) (C := containerSeqRecipPrefixDef)
      (prefixDefNodeId := "n_seq_prefix_def") (specId := "spec_a0")
      (step := .sameBaseDom .domQ) (D_old := .domQ) (D_new := .domQ)
      (Γ_old := []) (ΔΓ := deltaSeqRecipGuards) (Γ_new := deltaSeqRecipGuards)
      (goalDummy := .eqZero (.const 0))
      (by decide) (by decide) (by decide) (by decide)
      (fun _ h => nomatch h)
      (semSameEffDom_refl .domQ deltaSeqRecipGuards)
  have hOldZero : InEffDom .domQ [] (0, 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
  have hNotNewZero : ¬ InEffDom .domQ deltaSeqRecipGuards (0, 0) := by
    intro hNew
    have hxNe : ModelsStrictForm (.neqZero .varX) (0, 0) :=
      hNew.2.2 (.neqZero .varX) (List.mem_cons_self ..)
    rcases hxNe.2 with ⟨v, hv, hne⟩
    cases hv
    exact hne rfl
  have hExcZero : ModelsExcised
      (buildCanonicalRetreatExcised (.sameBaseDom .domQ) [] deltaSeqRecipGuards) (0, 0) :=
    ((hPart.exact_set_difference (0, 0)).mp ⟨hOldZero, hNotNewZero⟩).2
  have hNeg2Ne : ((-2 : Int) : Rat) ≠ 0 := by
    intro hz
    have hz0 : ((0 : Int) : Rat) = 0 := rfl
    rw [← hz0] at hz
    exact absurd (Rat.intCast_inj.mp hz) (by decide)
  have hOldNeg2 : InEffDom .domQ [] (((-2 : Int) : Rat), 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
  have hNotNewNeg2 : ¬ InEffDom .domQ deltaSeqRecipGuards (((-2 : Int) : Rat), 0) := by
    intro hNew
    have hRecPos : ModelsStrictForm (.pos (.div (.const 1) .varX)) (((-2 : Int) : Rat), 0) :=
      hNew.2.2 _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))
    rcases hRecPos.2 with ⟨v, hv, hpos⟩
    have hEvalNeg2 : PartExprEvalRel (.div (.const 1) .varX) (((-2 : Int) : Rat), 0)
        (((1 : Int) : Rat) / ((-2 : Int) : Rat)) :=
      .div (.const 1 _) (.varX _) hNeg2Ne
    have heq := partExprEvalRel_unique hEvalNeg2 hv
    rw [← heq] at hpos
    have h1Eq : ((1 : Int) : Rat) = 1 := rfl
    rw [h1Eq, Rat.div_def, Rat.one_mul, Rat.inv_pos] at hpos
    exact absurd (Rat.intCast_pos.mp hpos) (by decide)
  have hExcNeg2 : ModelsExcised
      (buildCanonicalRetreatExcised (.sameBaseDom .domQ) [] deltaSeqRecipGuards) (((-2 : Int) : Rat), 0) :=
    ((hPart.exact_set_difference (((-2 : Int) : Rat), 0)).mp ⟨hOldNeg2, hNotNewNeg2⟩).2
  have hNewPos2 : InEffDom .domQ deltaSeqRecipGuards (((2 : Int) : Rat), 0) := by
    have h2Pos : (0 : Rat) < ((2 : Int) : Rat) := Rat.intCast_pos.mpr (by decide)
    have h2Ne : ((2 : Int) : Rat) ≠ 0 := Rat.ne_of_gt h2Pos
    have hDiv2 : PartExprEvalRel (.div (.const 1) .varX) (((2 : Int) : Rat), 0)
        (((1 : Int) : Rat) / ((2 : Int) : Rat)) :=
      .div (.const 1 _) (.varX _) h2Ne
    have hHalfPos : (0 : Rat) < ((1 : Int) : Rat) / ((2 : Int) : Rat) := by
      have h1Eq : ((1 : Int) : Rat) = 1 := rfl
      rw [h1Eq, Rat.div_def, Rat.one_mul]
      exact Rat.inv_pos.mpr h2Pos
    have hM1 : ModelsStrictForm (.neqZero .varX) (((2 : Int) : Rat), 0) :=
      ⟨⟨((2 : Int) : Rat), .varX _⟩, ⟨((2 : Int) : Rat), .varX _, h2Ne⟩⟩
    have hM2 : ModelsStrictForm (.pos (.div (.const 1) .varX)) (((2 : Int) : Rat), 0) :=
      ⟨⟨((1 : Int) : Rat) / ((2 : Int) : Rat), hDiv2⟩,
       ⟨((1 : Int) : Rat) / ((2 : Int) : Rat), hDiv2, hHalfPos⟩⟩
    refine ⟨rfl, ⟨hM1.1, fun _ => ⟨hM2.1, fun _ => trivial⟩⟩, ?_⟩
    intro γ hγ
    rcases List.mem_cons.mp hγ with rfl | hRest
    · exact hM1
    · rcases List.mem_cons.mp hRest with rfl | hNil
      · exact hM2
      · nomatch hNil
  refine ⟨by decide, hPart, hExcZero, hExcNeg2, hNewPos2, ?_⟩
  intro hExc2
  exact hPart.disjoint_new_excised (((2 : Int) : Rat), 0) ⟨hNewPos2, hExc2⟩

/-- **`A0-03b` — Counterexample Suite (`F-B2B-T2-01` Unguarded Reciprocal & `F-B2B-T1-02` Partial-Loss Hiding)**:
    (1) Raw unguarded `γ = (1/x > 0)` and its raw dual `γ̄ = (-1/x ≥ 0)` BOTH fail at `(0, 0)`,
        violating `SemExactScopeLossPartition`, AND `containerInvalidRawRecip` is deterministically
        rejected (`guardWfFailed`) by frozen `verifyReachableDerivation`!
    (2) Retreating `ℚ → {x > 10}` while claiming excised locus `[[ -x > 0 ]]` (`x < 0`) fails
        `SemExactScopeLossPartition` at `ρ = (5, 0)`! -/
theorem A0_03b_partition_counterexamples_rejected :
    let rawGamma : StrictForm := .pos (.div (.const 1) .varX)
    -- (1) F-B2B-T2-01: Unguarded 1/x > 0 misses x = 0 and is rejected by frozen G7:
    (¬ ModelsStrictForm rawGamma (0, 0) ∧
     ¬ ModelsStrictForm (atomicComplement rawGamma) (0, 0) ∧
     ¬ SemExactScopeLossPartition .domQ [] .domQ [rawGamma] [[atomicComplement rawGamma]] ∧
     verifyReachableDerivation 3 [] containerInvalidRawRecip "n_bad_raw_recip" =
       .rejectInvalid .guardWfFailed) ∧
    -- (2) F-B2B-T1-02: Partial-loss hiding (x > 10 claiming only x < 0 excised) fails at (5, 0):
    (¬ SemExactScopeLossPartition .domQ [] .domQ [.pos (.sub .varX (.const 10))]
         [[.pos (.neg .varX)]]) := by
  refine ⟨⟨?_, ?_, ?_, by decide⟩, ?_⟩
  · rintro ⟨⟨_, hRel⟩, _⟩
    cases hRel with
    | div _ hDen hNe => cases hDen; exact hNe rfl
  · rintro ⟨⟨_, hNegRel⟩, _⟩
    cases hNegRel with
    | neg hRel =>
        cases hRel with
        | div _ hDen hNe => cases hDen; exact hNe rfl
  · intro hBadPart
    have hOld0 : InEffDom .domQ [] (0, 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
    rcases hBadPart.old_covered_by_new_or_excised (0, 0) hOld0 with hNew0 | ⟨E, hEMem, hE⟩
    · have hM : ModelsStrictForm (.pos (.div (.const 1) .varX)) (0, 0) :=
        hNew0.2.2 _ (List.mem_cons_self ..)
      rcases hM.1 with ⟨_, hRel⟩
      cases hRel with
      | div _ hDen hNe => cases hDen; exact hNe rfl
    · rcases List.mem_cons.mp hEMem with rfl | hNil
      · have hM : ModelsStrictForm (atomicComplement (.pos (.div (.const 1) .varX))) (0, 0) :=
          hE.2 _ (List.mem_cons_self ..)
        rcases hM.1 with ⟨_, hNegRel⟩
        cases hNegRel with
        | neg hRel =>
            cases hRel with
            | div _ hDen hNe => cases hDen; exact hNe rfl
      · nomatch hNil
  · intro hHidePart
    have hOld5 : InEffDom .domQ [] (((5 : Int) : Rat), 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
    rcases hHidePart.old_covered_by_new_or_excised (((5 : Int) : Rat), 0) hOld5 with hNew5 | ⟨E, hEMem, hE⟩
    · have hGt10 : ModelsStrictForm (.pos (.sub .varX (.const 10))) (((5 : Int) : Rat), 0) :=
        hNew5.2.2 _ (List.mem_cons_self ..)
      rcases hGt10.2 with ⟨v, hv, hpos⟩
      have hEval : PartExprEvalRel (.sub .varX (.const 10)) (((5 : Int) : Rat), 0)
          (((5 : Int) : Rat) - ((10 : Int) : Rat)) :=
        .sub (.varX _) (.const 10 _)
      have heq := partExprEvalRel_unique hEval hv
      rw [← heq, ← Rat.intCast_sub] at hpos
      exact absurd (Rat.intCast_pos.mp hpos) (by decide)
    · rcases List.mem_cons.mp hEMem with rfl | hNil
      · have hLt0 : ModelsStrictForm (.pos (.neg .varX)) (((5 : Int) : Rat), 0) :=
          hE.2 _ (List.mem_cons_self ..)
        rcases hLt0.2 with ⟨v, hv, hpos⟩
        have hEval : PartExprEvalRel (.neg .varX) (((5 : Int) : Rat), 0) (-(((5 : Int) : Rat))) :=
          .neg (.varX _)
        have heq := partExprEvalRel_unique hEval hv
        rw [← heq, ← Rat.intCast_neg] at hpos
        exact absurd (Rat.intCast_pos.mp hpos) (by decide)
      · nomatch hNil

end OmegaCellC1P1B2BA0
