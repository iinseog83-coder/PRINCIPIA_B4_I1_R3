/-
  PRINCIPIA Ω-CELL-C1-P1A0 — Isolated Minimal Whitebox Type Kernel
  Module: OmegaCellC1P1A0.P1A0A_BaseChartGuard (Stage P1A0-A)

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1A0_R1` Conditionally Authorized — Stage P1A0-A):
    1. Strict 3-State Evaluation (`StrictPred`):
       Separates `defined : D → Prop` from `rawSat : D → Prop`, defining official truth
       `ModelsStrictPred P x := P.defined x ∧ P.rawSat x` and `ValidCounterexamplePoint`
       (`T-A0-05`: undefined partial terms cannot form counterexamples; `x^2 > 0` at `0 : Rat`
       is strictly defined and semantically false).
    2. Four-Tier Guard Evidence Hierarchy (`F-C1-R1-03`, `T-A0-10`):
       `GuardViolationWitness`, `GuardNecessary`, `GuardSufficient`, and
       `GuardExactCharacterization`, with constructive pairwise non-implication counterexamples
       for all four directions, maximal defined-and-true locus theorem, and exact rational
       characterization `(a + b)^2 ≥ a^2 + b^2 ↔ a * b ≥ 0` (`CE-C1-03`).
    3. Registry-Pinned Semantic Base & `CertifiedChartAnchor` (`F-A0-01`, `T-A0-03`, `T-A0-04`):
       Separates immutable `ChartRegistry` lookup (`LookupBaseSpec`, `DomainObsPinned`,
       `ChartProvenanceValid`) from untrusted transport proposals, constructs the explicit
       Hilbert-Hotel bijection `ℚ ≃ ℚ \ {0}`, refutes base-commuting full-domain maps (`CE-C1-01a`),
       refutes the fake chart `β⁻¹` against pinned intrinsic observables (`T-A0-04a` / `CE-C1-01b`),
       and proves co-mutated pullback observables are rejected by `DomainObsPinned` (`T-A0-04b`).

  Explicitly Excluded (`NOT AUTHORIZED` / `FROZEN` / `HELD`):
    - Zero imports from `GPED-MINCORE-0` (`36` GPED assets remain strictly `FROZEN`).
    - Wire/CID/Merkle serialization, `C1-P1B/C` full `G1..G8` operational loop, `MT-22b`,
      `L3-P2C`, and `checkTraceDec` remain `NOT AUTHORIZED`.
    - External registry storage tamper-resistance, empirical sensor calibration, cryptographic
      collision resistance, and institutional authority remain `HELD`.
-/

namespace OmegaCellC1P1A0

/-! ### 1. Core Rational Arithmetic Foundations (`Rat` in Core `Init`, Zero External Deps) -/

/-- Strictly positive `1 : Rat` (`0 < 1`). -/
theorem rat_zero_lt_one : (0 : Rat) < 1 := by
  show ((0 : Int) : Rat) < ((1 : Int) : Rat)
  exact Rat.intCast_lt_intCast.mpr (by decide)

/-- Nonzero witness `1 ≠ 0` in `Rat`. -/
theorem rat_one_ne_zero : (1 : Rat) ≠ 0 :=
  Rat.ne_of_gt rat_zero_lt_one

/-- Negative witness `-1 < 0` in `Rat`. -/
theorem rat_neg_one_lt_zero : (-1 : Rat) < 0 := by
  show ((-1 : Int) : Rat) < ((0 : Int) : Rat)
  exact Rat.intCast_lt_intCast.mpr (by decide)

/-- Every square `x * x` in `Rat` is non-negative (`0 ≤ x * x`). -/
theorem rat_sq_nonneg (x : Rat) : 0 ≤ x * x := by
  rcases Rat.nonneg_total x with hpos | hneg
  · exact Rat.mul_nonneg hpos hpos
  · have hmul : (-x) * (-x) = x * x := by
      rw [Rat.neg_mul, Rat.mul_neg, Rat.neg_neg]
    rw [← hmul]
    exact Rat.mul_nonneg hneg hneg

/-- Strict square positivity in `Rat` holds iff `x ≠ 0` (`0 < x * x ↔ x ≠ 0`). -/
theorem rat_sq_pos_iff_ne_zero (x : Rat) : 0 < x * x ↔ x ≠ 0 := by
  constructor
  · intro hpos hzero
    subst hzero
    rw [Rat.mul_zero] at hpos
    exact Rat.lt_irrefl hpos
  · intro hne
    have hmul_ne : x * x ≠ 0 := fun hz =>
      match Rat.mul_eq_zero.mp hz with
      | Or.inl h => hne h
      | Or.inr h => hne h
    exact Rat.lt_of_le_of_ne (rat_sq_nonneg x) (Ne.symm hmul_ne)

/-- Algebraic binomial identity `(a + b)^2 = (a^2 + b^2) + 2ab` in `Rat`. -/
theorem rat_add_sq_expand (a b : Rat) :
    (a + b) * (a + b) = (a * a + b * b) + (a * b + a * b) := by
  calc
    (a + b) * (a + b)
      = a * (a + b) + b * (a + b) := Rat.add_mul a b (a + b)
    _ = (a * a + a * b) + (b * a + b * b) := by rw [Rat.mul_add, Rat.mul_add]
    _ = (a * a + a * b) + (a * b + b * b) := by rw [Rat.mul_comm b a]
    _ = a * a + (a * b + (a * b + b * b)) := by rw [Rat.add_assoc]
    _ = a * a + ((a * b + a * b) + b * b) := by rw [← Rat.add_assoc (a * b) (a * b) (b * b)]
    _ = a * a + (b * b + (a * b + a * b)) := by rw [Rat.add_comm (a * b + a * b) (b * b)]
    _ = (a * a + b * b) + (a * b + a * b) := by rw [← Rat.add_assoc]

/-- Exact rational characterization `a^2 + b^2 ≤ (a + b)^2 ↔ 0 ≤ a * b` (`CE-C1-03`). -/
theorem rat_sum_sq_le_add_sq_iff (a b : Rat) :
    a * a + b * b ≤ (a + b) * (a + b) ↔ 0 ≤ a * b := by
  rw [rat_add_sq_expand]
  have hshift : a * a + b * b ≤ (a * a + b * b) + (a * b + a * b) ↔ 0 ≤ a * b + a * b := by
    have h := @Rat.add_le_add_left 0 (a * b + a * b) (a * a + b * b)
    rwa [Rat.add_zero] at h
  rw [hshift]
  constructor
  · intro hsum
    by_cases hab : 0 ≤ a * b
    · exact hab
    · exfalso
      have hlt : a * b < 0 := Rat.not_le.mp hab
      have hle1 : a * b + a * b ≤ 0 + a * b :=
        Rat.le_of_lt (Rat.add_lt_add_right.mpr hlt)
      rw [Rat.zero_add] at hle1
      exact hab (Rat.le_trans hsum hle1)
  · intro hab
    exact Rat.add_nonneg hab hab

/-! ### 2. Strict 3-State Evaluation (`StrictPred`) & `T-A0-05` (`CE-C1-01` Defined-False Law) -/

/-- Strict predicate separating domain-of-definition (`defined`) from raw truth (`rawSat`). -/
structure StrictPred (D : Type u) where
  defined : D → Prop
  rawSat  : D → Prop

/-- Strict satisfaction requires both `defined` and `rawSat`. -/
def ModelsStrictPred {D : Type u} (P : StrictPred D) (x : D) : Prop :=
  P.defined x ∧ P.rawSat x

/-- Undefined term / domain-of-definition failure at `x0` (neither true nor semantic counterexample). -/
def UndefinedPoint {D : Type u} (dom : D → Prop) (P : StrictPred D) (x0 : D) : Prop :=
  dom x0 ∧ ¬ P.defined x0

/-- Admissible semantic counterexample requires `x0 ∈ dom`, `P.defined x0`, and `¬ P.rawSat x0`. -/
def ValidCounterexamplePoint {D : Type u} (dom : D → Prop) (P : StrictPred D) (x0 : D) : Prop :=
  dom x0 ∧ P.defined x0 ∧ ¬ P.rawSat x0

/-- Partial reciprocal predicate `x * x⁻¹ = 1` with strict partial definedness `x ≠ 0`. -/
def ratPartialRecipEqOnePred : StrictPred Rat where
  defined := fun x => x ≠ 0
  rawSat  := fun x => x * x⁻¹ = 1

/-- Total rational square-positivity predicate `x^2 > 0` (`CE-C1-01` corrected target). -/
def ratSqPosPred : StrictPred Rat where
  defined := fun _ => True
  rawSat  := fun x => 0 < x * x

/-- Total rational square-nonnegativity predicate `x^2 ≥ 0`. -/
def ratSqNonnegPred : StrictPred Rat where
  defined := fun _ => True
  rawSat  := fun x => 0 ≤ x * x

/-- **`T-A0-05` — Strict Separation of Undefined Partial Terms vs Defined Semantic Falsehood**:
    (1) Any `UndefinedPoint` can neither satisfy `ModelsStrictPred` nor instantiate `ValidCounterexamplePoint`;
    (2) `ratPartialRecipEqOnePred` at `0 : Rat` is an `UndefinedPoint`, NOT a `ValidCounterexamplePoint`;
    (3) `ratSqPosPred` (`x^2 > 0`) at `0 : Rat` is strictly defined and semantically false (`ValidCounterexamplePoint`),
        while holding strictly at every nonzero rational `x ≠ 0`. -/
theorem T_A0_05_undefined_vs_defined_false_separation :
    (∀ {D : Type} (dom : D → Prop) (P : StrictPred D) (x0 : D),
      UndefinedPoint dom P x0 →
        ¬ ValidCounterexamplePoint dom P x0 ∧ ¬ ModelsStrictPred P x0) ∧
    (UndefinedPoint (fun _ : Rat => True) ratPartialRecipEqOnePred 0 ∧
      ¬ ValidCounterexamplePoint (fun _ : Rat => True) ratPartialRecipEqOnePred 0) ∧
    ValidCounterexamplePoint (fun _ : Rat => True) ratSqPosPred 0 ∧
    (∀ x : Rat, x ≠ 0 → ModelsStrictPred ratSqPosPred x) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro D dom P x0 hund
    exact ⟨fun hce => hund.2 hce.2.1, fun hm => hund.2 hm.1⟩
  · refine ⟨⟨trivial, fun hne => hne rfl⟩, ?_⟩
    intro hce
    exact hce.2.1 rfl
  · refine ⟨trivial, trivial, ?_⟩
    intro hpos
    exact (rat_sq_pos_iff_ne_zero 0).mp hpos rfl
  · intro x hne
    exact ⟨trivial, (rat_sq_pos_iff_ne_zero x).mpr hne⟩

/-! ### 3. Four-Tier `GuardEvidence` Hierarchy & `T-A0-10` (`F-C1-R1-03` & `CE-C1-03`) -/

/-- Tier 1: Single-point joint violation witness (`¬ψ(x_viol) ∧ ¬P(x_viol)` under strict definedness). -/
structure GuardViolationWitness {D : Type u} (dom : D → Prop) (P ψ : StrictPred D) where
  xViol  : D
  inDom  : dom xViol
  defP   : P.defined xViol
  defPsi : ψ.defined xViol
  notPsi : ¬ ψ.rawSat xViol
  notP   : ¬ P.rawSat xViol

/-- Tier 2: Universal guard necessity on `dom` (`ModelsStrict P x → ModelsStrict ψ x`) with non-triviality. -/
def GuardNecessary {D : Type u} (dom : D → Prop) (P ψ : StrictPred D) : Prop :=
  (∀ x : D, dom x → ModelsStrictPred P x → ModelsStrictPred ψ x) ∧
  (∃ xViol : D, dom xViol ∧ ψ.defined xViol ∧ ¬ ψ.rawSat xViol)

/-- Tier 3: Universal guard sufficiency on `dom` (`ModelsStrict ψ x → ModelsStrict P x`). -/
def GuardSufficient {D : Type u} (dom : D → Prop) (P ψ : StrictPred D) : Prop :=
  ∀ x : D, dom x → ModelsStrictPred ψ x → ModelsStrictPred P x

/-- Tier 4: Exact biconditional domain characterization (`GuardNecessary ∧ GuardSufficient`). -/
def GuardExactCharacterization {D : Type u} (dom : D → Prop) (P ψ : StrictPred D) : Prop :=
  GuardNecessary dom P ψ ∧ GuardSufficient dom P ψ

/-- Strict positive rational guard `x > 0`. -/
def ratPosPred : StrictPred Rat where
  defined := fun _ => True
  rawSat  := fun x => 0 < x

/-- Non-negative rational guard `x ≥ 0`. -/
def ratNonnegPred : StrictPred Rat where
  defined := fun _ => True
  rawSat  := fun x => 0 ≤ x

/-- `CE-C1-03` target predicate `(a + b)^2 ≥ a^2 + b^2` on `Rat × Rat`. -/
def ratPairSumSqTarget : StrictPred (Rat × Rat) where
  defined := fun _ => True
  rawSat  := fun p => p.1 * p.1 + p.2 * p.2 ≤ (p.1 + p.2) * (p.1 + p.2)

/-- `CE-C1-03` guard predicate `a * b ≥ 0` on `Rat × Rat`. -/
def ratPairProdNonnegGuard : StrictPred (Rat × Rat) where
  defined := fun _ => True
  rawSat  := fun p => 0 ≤ p.1 * p.2

/-- **`T-A0-10` — Four-Tier Guard Non-Implication Matrix, Maximal Defined-True Locus, & `CE-C1-03`**:
    (1) `GuardViolationWitness ⇏ GuardNecessary` (`P: x^2 > 0`, `ψ: x > 0`, violated at `0`, refuted at `-1`);
    (2) `GuardViolationWitness ⇏ GuardSufficient` (`P: x > 0`, `ψ: x ≥ 0`, violated at `-1`, refuted at `0`);
    (3) `GuardNecessary ⇏ GuardSufficient` (`P: x > 0`, `ψ: x ≥ 0`);
    (4) `GuardSufficient ⇏ GuardNecessary` (`P: x^2 > 0`, `ψ: x > 0`);
    (5) Under `GuardExactCharacterization`, `{x ∈ dom | ModelsStrict ψ x}` equals the exact maximal
        defined-and-true locus `{x ∈ dom | Defined(P, x) ∧ RawSat(P, x)}` as a strict subset of `dom`;
    (6) `CE-C1-03` `(a + b)^2 ≥ a^2 + b^2` vs `a * b ≥ 0` satisfies `GuardExactCharacterization` on `ℚ²`. -/
theorem T_A0_10_guard_four_tier_separation_and_exact_char :
    (Nonempty (GuardViolationWitness (fun _ : Rat => True) ratSqPosPred ratPosPred) ∧
      ¬ GuardNecessary (fun _ : Rat => True) ratSqPosPred ratPosPred) ∧
    (Nonempty (GuardViolationWitness (fun _ : Rat => True) ratPosPred ratNonnegPred) ∧
      ¬ GuardSufficient (fun _ : Rat => True) ratPosPred ratNonnegPred) ∧
    (GuardNecessary (fun _ : Rat => True) ratPosPred ratNonnegPred ∧
      ¬ GuardSufficient (fun _ : Rat => True) ratPosPred ratNonnegPred) ∧
    (GuardSufficient (fun _ : Rat => True) ratSqPosPred ratPosPred ∧
      ¬ GuardNecessary (fun _ : Rat => True) ratSqPosPred ratPosPred) ∧
    (∀ {D : Type} (dom : D → Prop) (P ψ : StrictPred D),
      GuardExactCharacterization dom P ψ →
        (∀ x : D, dom x → (ModelsStrictPred ψ x ↔ (P.defined x ∧ P.rawSat x))) ∧
        (∃ xViol : D, dom xViol ∧ ¬ ModelsStrictPred P xViol)) ∧
    GuardExactCharacterization (fun _ : Rat × Rat => True) ratPairSumSqTarget ratPairProdNonnegGuard := by
  have hnot_zero_pos : ¬ (0 : Rat) < 0 := Rat.lt_irrefl
  have hnot_zero_sq : ¬ (0 : Rat) < 0 * 0 := by
    rw [Rat.mul_zero]; exact Rat.lt_irrefl
  have hnot_neg1_pos : ¬ (0 : Rat) < -1 :=
    Rat.not_lt.mpr (Rat.le_of_lt rat_neg_one_lt_zero)
  have hnot_neg1_nonneg : ¬ (0 : Rat) ≤ -1 :=
    Rat.not_le.mpr rat_neg_one_lt_zero
  have hneg1_ne_zero : (-1 : Rat) ≠ 0 :=
    Rat.ne_of_lt rat_neg_one_lt_zero
  have hnot_nec_sq_pos : ¬ GuardNecessary (fun _ : Rat => True) ratSqPosPred ratPosPred := by
    intro hnec
    have hm : ModelsStrictPred ratSqPosPred (-1) :=
      ⟨trivial, (rat_sq_pos_iff_ne_zero (-1)).mpr hneg1_ne_zero⟩
    have hpsi := hnec.1 (-1) trivial hm
    exact hnot_neg1_pos hpsi.2
  have hnot_suff_pos_nonneg : ¬ GuardSufficient (fun _ : Rat => True) ratPosPred ratNonnegPred := by
    intro hsuff
    have hpsi : ModelsStrictPred ratNonnegPred 0 := ⟨trivial, Rat.le_refl⟩
    have hp := hsuff 0 trivial hpsi
    exact hnot_zero_pos hp.2
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · refine ⟨⟨⟨0, trivial, trivial, trivial, hnot_zero_pos, hnot_zero_sq⟩⟩, hnot_nec_sq_pos⟩
  · refine ⟨⟨⟨-1, trivial, trivial, trivial, hnot_neg1_nonneg, hnot_neg1_pos⟩⟩, hnot_suff_pos_nonneg⟩
  · refine ⟨⟨?_, ⟨-1, trivial, trivial, hnot_neg1_nonneg⟩⟩, hnot_suff_pos_nonneg⟩
    intro x _ hx
    exact ⟨trivial, Rat.le_of_lt hx.2⟩
  · refine ⟨?_, hnot_nec_sq_pos⟩
    intro x _ hx
    exact ⟨trivial, Rat.mul_pos hx.2 hx.2⟩
  · intro D dom P ψ hexact
    refine ⟨?_, ?_⟩
    · intro x hdom
      exact ⟨fun hpsi => hexact.2 x hdom hpsi, fun hp => hexact.1.1 x hdom hp⟩
    · rcases hexact.1.2 with ⟨xv, hdomv, _, hnotpsi⟩
      refine ⟨xv, hdomv, ?_⟩
      intro hp
      exact hnotpsi (hexact.1.1 xv hdomv hp).2
  · refine ⟨⟨?_, ⟨(1, -1), trivial, trivial, ?_⟩⟩, ?_⟩
    · intro p _ hp
      exact ⟨trivial, (rat_sum_sq_le_add_sq_iff p.1 p.2).mp hp.2⟩
    · show ¬ (0 : Rat) ≤ (1 : Rat) * (-1 : Rat)
      rw [Rat.one_mul]
      exact hnot_neg1_nonneg
    · intro p _ hpsi
      exact ⟨trivial, (rat_sum_sq_le_add_sq_iff p.1 p.2).mpr hpsi.2⟩

/-! ### 4. Hilbert-Hotel Constructive Bijection `ℚ ≃ ℚ \ {0}` (`CE-C1-01a` Setup) -/

/-- Nonzero rational domain `ℚ \ {0}`. -/
abbrev RatNonzero : Type := { q : Rat // q ≠ 0 }

/-- Computable test whether `q : Rat` is a non-negative integer `(n : Nat)` (`den = 1 ∧ 0 ≤ num`). -/
def isNatRat (q : Rat) : Bool :=
  (q.den == 1) && decide (0 ≤ q.num)

/-- Computable test whether `q : Rat` is a strictly positive integer (`den = 1 ∧ 1 ≤ num`). -/
def isPosIntRat (q : Rat) : Bool :=
  (q.den == 1) && decide (1 ≤ q.num)

private theorem rat_eq_intCast_of_den_one {q : Rat} (h : q.den = 1) : q = (q.num : Rat) :=
  Rat.ext rfl h

private theorem isNatRat_iff (q : Rat) : isNatRat q = true ↔ q.den = 1 ∧ 0 ≤ q.num := by
  unfold isNatRat
  simp [Bool.and_eq_true]

private theorem isPosIntRat_iff (q : Rat) : isPosIntRat q = true ↔ q.den = 1 ∧ 1 ≤ q.num := by
  unfold isPosIntRat
  simp [Bool.and_eq_true]

private theorem hilbert_fwd_ne_zero (q : Rat) :
    (if isNatRat q then q + 1 else q) ≠ 0 := by
  by_cases h : isNatRat q = true
  · rw [if_pos h]
    rcases (isNatRat_iff q).mp h with ⟨hden, hnum⟩
    have hq : q = (q.num : Rat) := rat_eq_intCast_of_den_one hden
    have hq1 : q + 1 = ((q.num + 1 : Int) : Rat) := by
      rw [hq]; exact (Rat.intCast_add q.num 1).symm
    intro hz
    rw [hq1, Rat.intCast_eq_zero_iff] at hz
    omega
  · rw [if_neg h]
    intro hz
    subst hz
    apply h
    rw [isNatRat_iff]
    exact ⟨rfl, Int.le_refl 0⟩

/-- Constructive Hilbert-Hotel map `β : ℚ → ℚ \ {0}` (`n ↦ n + 1` on `ℕ ⊆ ℚ`, identity elsewhere). -/
def hilbertRatToNonzero (q : Rat) : RatNonzero :=
  ⟨if isNatRat q then q + 1 else q, hilbert_fwd_ne_zero q⟩

/-- Constructive inverse map `β⁻¹ : ℚ \ {0} → ℚ` (`m ↦ m - 1` on `ℕ⁺ ⊆ ℚ \ {0}`, identity elsewhere). -/
def hilbertNonzeroToRat (y : RatNonzero) : Rat :=
  if isPosIntRat y.1 then y.1 - 1 else y.1

/-- Left inverse law `β⁻¹(β(q)) = q` for all `q : Rat`. -/
theorem hilbert_left_inv (q : Rat) :
    hilbertNonzeroToRat (hilbertRatToNonzero q) = q := by
  let f := if isNatRat q then q + 1 else q
  change (if isPosIntRat f then f - 1 else f) = q
  by_cases h : isNatRat q = true
  · have hf : f = q + 1 := if_pos h
    rw [hf]
    rcases (isNatRat_iff q).mp h with ⟨hden, hnum⟩
    have hq : q = (q.num : Rat) := rat_eq_intCast_of_den_one hden
    have hq1 : q + 1 = ((q.num + 1 : Int) : Rat) := by
      rw [hq]; exact (Rat.intCast_add q.num 1).symm
    have hpos : isPosIntRat (q + 1) = true := by
      rw [isPosIntRat_iff, hq1, Rat.den_intCast, Rat.num_intCast]
      exact ⟨rfl, by omega⟩
    rw [if_pos hpos]
    exact Rat.add_sub_cancel
  · have hf : f = q := if_neg h
    rw [hf]
    have hnotpos : ¬ (isPosIntRat q = true) := by
      intro hp
      rcases (isPosIntRat_iff q).mp hp with ⟨hden, hnum⟩
      apply h
      rw [isNatRat_iff]
      exact ⟨hden, by omega⟩
    rw [if_neg hnotpos]

/-- Right inverse law `β(β⁻¹(y)) = y` for all `y : RatNonzero`. -/
theorem hilbert_right_inv (y : RatNonzero) :
    hilbertRatToNonzero (hilbertNonzeroToRat y) = y := by
  apply Subtype.ext
  unfold hilbertRatToNonzero hilbertNonzeroToRat
  dsimp only
  by_cases hp : isPosIntRat y.1 = true
  · rw [if_pos hp]
    rcases (isPosIntRat_iff y.1).mp hp with ⟨hden, hnum⟩
    have hy : y.1 = (y.1.num : Rat) := rat_eq_intCast_of_den_one hden
    have hy1 : y.1 - 1 = ((y.1.num - 1 : Int) : Rat) := by
      rw [hy]; exact (Rat.intCast_sub y.1.num 1).symm
    have hnat : isNatRat (y.1 - 1) = true := by
      rw [isNatRat_iff, hy1, Rat.den_intCast, Rat.num_intCast]
      exact ⟨rfl, by omega⟩
    rw [if_pos hnat]
    exact Rat.sub_add_cancel
  · rw [if_neg hp]
    have hnotnat : ¬ (isNatRat y.1 = true) := by
      intro hnat
      rcases (isNatRat_iff y.1).mp hnat with ⟨hden, hnum⟩
      by_cases hge1 : 1 ≤ y.1.num
      · exact hp ((isPosIntRat_iff y.1).mpr ⟨hden, hge1⟩)
      · have hznum : y.1.num = 0 := by omega
        exact y.2 (Rat.num_eq_zero.mp hznum)
    rw [if_neg hnotnat]

/-- Exact evaluation `β⁻¹(1) = 0` witnessing that `1 ∈ ℚ \ {0}` is mapped to `0 ∈ ℚ`. -/
theorem hilbertNonzeroToRat_one :
    hilbertNonzeroToRat ⟨1, rat_one_ne_zero⟩ = 0 := by
  unfold hilbertNonzeroToRat
  have hp : isPosIntRat 1 = true := by
    rw [isPosIntRat_iff]
    exact ⟨rfl, by decide⟩
  rw [if_pos hp]
  exact Rat.sub_self

/-! ### 5. Registry-Pinned `SemanticBase`, `CertifiedChartAnchor`, & `T-A0-03` / `T-A0-04` (`F-A0-01`) -/

/-- Semantic base space `(B, obsB)` fixing observable/algebraic predicates over `B`. -/
structure SemanticBase (B : Type u) (ObsIdx : Type v) where
  obsB : ObsIdx → B → Prop

/-- Domain observable specification `(D, obsD)` prior to and independent of any transport proposal. -/
structure DomainSpec (D : Type u) (ObsIdx : Type v) where
  obsD : ObsIdx → D → Prop

/-- Extensional equality of two domain observable specifications on `D`. -/
def DomainObsExtEq {D : Type u} {ObsIdx : Type v}
    (S1 S2 : DomainSpec D ObsIdx) : Prop :=
  ∀ (i : ObsIdx) (x : D), S1.obsD i x ↔ S2.obsD i x

/-- Observation preservation condition `O_D(i, x) ↔ O_B(i, j(x))`. -/
def PreservesObs {B : Type u} {D : Type v} {ObsIdx : Type w}
    (base : SemanticBase B ObsIdx) (domSpec : DomainSpec D ObsIdx) (j : D → B) : Prop :=
  ∀ (i : ObsIdx) (x : D), domSpec.obsD i x ↔ base.obsB i (j x)

/-- Provenance classification separating formal mathematical chart constructors from `HELD`
    external/empirical calibrations (`CRYPTO_EMPIRICAL_OPERATIONAL_INSTITUTIONAL_AUTHORITY_HELD`). -/
inductive ChartProvenance where
  | canonicalIdentity       : ChartProvenance
  | canonicalSubspace       : ChartProvenance
  | verifiedAlgebraicIso    : ChartProvenance
  | externalCalibrationHeld : ChartProvenance
  deriving DecidableEq, Repr

/-- Pure mathematical kernel only certifies formal provenances; external calibrations remain `HELD`. -/
def isKernelCertifiedProvenance : ChartProvenance → Bool
  | .canonicalIdentity       => true
  | .canonicalSubspace       => true
  | .verifiedAlgebraicIso    => true
  | .externalCalibrationHeld => false

/-- Immutable specification & chart registry context (`F-A0-01` Trust Boundary Explicit). -/
structure ChartRegistry (B : Type u) (ObsIdx : Type v) where
  lookupBase?      : String → Option (SemanticBase B ObsIdx)
  DomainSpecPinned : {D : Type u} → String → DomainSpec D ObsIdx → Prop
  ChartOriginValid : {D : Type u} → String → String → (D → B) → ChartProvenance → Prop

/-- **`F-A0-01` — `CertifiedChartAnchor`**:
    Binds `j : D → B` simultaneously to:
    (1) `lookupBase? baseId = some base` (`BaseSpecPinned`),
    (2) `DomainSpecPinned domId domSpec` (`DomainObsPinned` — independent of `j`),
    (3) `PreservesObs base domSpec j`, and
    (4) kernel-admissible provenance (`isKernelCertifiedProvenance prov = true` ∧ `ChartOriginValid`). -/
structure CertifiedChartAnchor {B : Type u} {ObsIdx : Type v}
    (reg : ChartRegistry B ObsIdx) (baseId domId : String) (D : Type u) where
  base        : SemanticBase B ObsIdx
  domSpec     : DomainSpec D ObsIdx
  j           : D → B
  prov        : ChartProvenance
  base_pinned : reg.lookupBase? baseId = some base
  dom_pinned  : reg.DomainSpecPinned domId domSpec
  preserves   : PreservesObs base domSpec j
  prov_kernel : isKernelCertifiedProvenance prov = true
  prov_valid  : reg.ChartOriginValid baseId domId j prov

/-- External calibration charts (`externalCalibrationHeld`) can never pass `CertifiedChartAnchor`
    inside the pure mathematical kernel (`HELD` boundary theorem). -/
theorem externalCalibrationHeld_not_kernel_certified
    {B ObsIdx : Type} (reg : ChartRegistry B ObsIdx) (baseId domId : String) (D : Type)
    (anch : CertifiedChartAnchor reg baseId domId D) :
    anch.prov ≠ .externalCalibrationHeld := by
  intro heq
  have hk := anch.prov_kernel
  rw [heq] at hk
  contradiction

/-- Rational observable index family (`sqPos`: `b^2 > 0`; `isZero`: `b = 0`). -/
inductive RatObsIdx where
  | sqPos  : RatObsIdx
  | isZero : RatObsIdx
  deriving DecidableEq, Repr

/-- Standard semantic base `(ℚ, {sqPos, isZero})`. -/
def ratSemanticBase : SemanticBase Rat RatObsIdx where
  obsB
    | .sqPos,  b => 0 < b * b
    | .isZero, b => b = 0

/-- Intrinsic observable specification on full `ℚ`. -/
def ratFullIntrSpec : DomainSpec Rat RatObsIdx where
  obsD
    | .sqPos,  x => 0 < x * x
    | .isZero, x => x = 0

/-- Intrinsic subspace observable specification on `ℚ \ {0}` (independent of any fake chart). -/
def ratNonzeroIntrSpec : DomainSpec RatNonzero RatObsIdx where
  obsD
    | .sqPos,  y => 0 < y.1 * y.1
    | .isZero, y => y.1 = 0

/-- Honest identity chart `j_old = id : ℚ → ℚ`. -/
def ratIdChart (x : Rat) : Rat := x

/-- Honest subspace inclusion chart `j_new = Subtype.val : ℚ \ {0} → ℚ`. -/
def ratSubspaceChart (y : RatNonzero) : Rat := y.1

/-- Adversarial fake chart `j_fake = β⁻¹ : ℚ \ {0} → ℚ` (`CE-C1-01b`). -/
def ratFakeHilbertChart (y : RatNonzero) : Rat :=
  hilbertNonzeroToRat y

/-- Colluding pullback observable specification `O_pull(y) := O_B(β⁻¹(y))` (`CE-C1-01c`). -/
def ratNonzeroPullbackFakeSpec : DomainSpec RatNonzero RatObsIdx where
  obsD i y := ratSemanticBase.obsB i (ratFakeHilbertChart y)

/-- Official pinned rational chart registry fixing `"base_Q"`, `"dom_Q"`, and `"dom_Q_nonzero"`. -/
def ratPinnedRegistry : ChartRegistry Rat RatObsIdx where
  lookupBase? s := if s == "base_Q" then some ratSemanticBase else none
  DomainSpecPinned {D} domId S :=
    (domId = "dom_Q" ∧ ∃ h : D = Rat,
      ∀ i x, S.obsD i x ↔ ratFullIntrSpec.obsD i (cast h x)) ∨
    (domId = "dom_Q_nonzero" ∧ ∃ h : D = RatNonzero,
      ∀ i y, S.obsD i y ↔ ratNonzeroIntrSpec.obsD i (cast h y))
  ChartOriginValid {D} baseId domId j prov :=
    baseId = "base_Q" ∧
    ((domId = "dom_Q" ∧ prov = .canonicalIdentity ∧ ∀ x : D, ∃ h : D = Rat, j x = cast h x) ∨
     (domId = "dom_Q_nonzero" ∧ prov = .canonicalSubspace ∧
       ∀ y : D, ∃ h : D = RatNonzero, j y = (cast h y).1))

/-- Certified honest anchor for full `ℚ` (`g_0` and re-expanded `g_2`). -/
def ratFullCertifiedAnchor : CertifiedChartAnchor ratPinnedRegistry "base_Q" "dom_Q" Rat where
  base        := ratSemanticBase
  domSpec     := ratFullIntrSpec
  j           := ratIdChart
  prov        := .canonicalIdentity
  base_pinned := rfl
  dom_pinned  := Or.inl ⟨rfl, rfl, fun _ _ => Iff.rfl⟩
  preserves   := fun i x => by cases i <;> exact Iff.rfl
  prov_kernel := rfl
  prov_valid  := ⟨rfl, Or.inl ⟨rfl, rfl, fun _ => ⟨rfl, rfl⟩⟩⟩

/-- Certified honest subspace anchor for `ℚ \ {0}` (`g_1`). -/
def ratNonzeroCertifiedAnchor :
    CertifiedChartAnchor ratPinnedRegistry "base_Q" "dom_Q_nonzero" RatNonzero where
  base        := ratSemanticBase
  domSpec     := ratNonzeroIntrSpec
  j           := ratSubspaceChart
  prov        := .canonicalSubspace
  base_pinned := rfl
  dom_pinned  := Or.inr ⟨rfl, rfl, fun _ _ => Iff.rfl⟩
  preserves   := fun i y => by cases i <;> exact Iff.rfl
  prov_kernel := rfl
  prov_valid  := ⟨rfl, Or.inr ⟨rfl, rfl, fun _ => ⟨rfl, rfl⟩⟩⟩

/-- **`T-A0-03` (`CE-C1-01a`) — Hilbert-Hotel Bijection Exists Yet Base-Commuting Map Fails**:
    (1) `hilbertRatToNonzero` and `hilbertNonzeroToRat` form an explicit two-sided bijection `ℚ ≃ ℚ \ {0}`;
    (2) Under the certified honest charts `ratIdChart` (`id_ℚ`) and `ratSubspaceChart` (`ℚ \ {0} ↪ ℚ`),
        NO total map `f : Rat → RatNonzero` commutes with the semantic base (`¬∃ f, ∀ x, j_new(f x) = j_old x`). -/
theorem T_A0_03_hilbert_bijection_exists_yet_no_base_commuting_map :
    ((∀ q : Rat, hilbertNonzeroToRat (hilbertRatToNonzero q) = q) ∧
     (∀ y : RatNonzero, hilbertRatToNonzero (hilbertNonzeroToRat y) = y)) ∧
    ¬ (∃ f : Rat → RatNonzero, ∀ x : Rat, ratSubspaceChart (f x) = ratIdChart x) := by
  refine ⟨⟨hilbert_left_inv, hilbert_right_inv⟩, ?_⟩
  rintro ⟨f, hcomm⟩
  have h0 : (f 0).1 = 0 := hcomm 0
  exact (f 0).2 h0

/-- **`T-A0-04a` (`CE-C1-01b`) — Pinned Intrinsic Observable Refutes Fake Chart `j_fake = β⁻¹`**:
    Against `ratSemanticBase` and `ratNonzeroIntrSpec`, `ratFakeHilbertChart` fails `PreservesObs`
    at `y = 1` (`1^2 > 0` is `True`, whereas `(β⁻¹(1))^2 = 0^2 > 0` is `False`), so NO
    `CertifiedChartAnchor` on `"dom_Q_nonzero"` can use `ratFakeHilbertChart`. -/
theorem T_A0_04a_fake_chart_violates_pinned_PreservesObs :
    ¬ PreservesObs ratSemanticBase ratNonzeroIntrSpec ratFakeHilbertChart ∧
    ¬ (∃ anch : CertifiedChartAnchor ratPinnedRegistry "base_Q" "dom_Q_nonzero" RatNonzero,
        anch.j = ratFakeHilbertChart) := by
  have hnot_pres : ¬ PreservesObs ratSemanticBase ratNonzeroIntrSpec ratFakeHilbertChart := by
    intro hpres
    let y1 : RatNonzero := ⟨1, rat_one_ne_zero⟩
    have hiff := hpres .sqPos y1
    have hlhs : ratNonzeroIntrSpec.obsD .sqPos y1 :=
      (rat_sq_pos_iff_ne_zero 1).mpr rat_one_ne_zero
    have hrhs : ratSemanticBase.obsB .sqPos (ratFakeHilbertChart y1) := hiff.mp hlhs
    change 0 < (hilbertNonzeroToRat y1) * (hilbertNonzeroToRat y1) at hrhs
    rw [hilbertNonzeroToRat_one, Rat.mul_zero] at hrhs
    exact Rat.lt_irrefl hrhs
  refine ⟨hnot_pres, ?_⟩
  rintro ⟨anch, hj⟩
  have hb : anch.base = ratSemanticBase := by
    have hbp := anch.base_pinned
    simp [ratPinnedRegistry] at hbp
    exact hbp.symm
  have hdom : ∀ i y, anch.domSpec.obsD i y ↔ ratNonzeroIntrSpec.obsD i y := by
    rcases anch.dom_pinned with ⟨hbad, _⟩ | ⟨_, heq, hiff⟩
    · exact False.elim ((by decide : "dom_Q_nonzero" ≠ "dom_Q") hbad)
    · cases heq
      exact hiff
  apply hnot_pres
  intro i y
  rw [← hdom i y, ← hj, ← hb]
  exact anch.preserves i y

/-- **`T-A0-04b` (`CE-C1-01c`) — Co-Mutated Pullback Observable Blocked by `DomainObsPinned`**:
    Although `ratNonzeroPullbackFakeSpec` trivially satisfies unpinned `PreservesObs` with
    `ratFakeHilbertChart`, it is extensionally unequal to `ratNonzeroIntrSpec` at `y = 1` and is
    rejected by `ratPinnedRegistry.DomainSpecPinned "dom_Q_nonzero"`, blocking self-certification. -/
theorem T_A0_04b_comutated_pullback_obs_rejected_by_DomainObsPinned :
    PreservesObs ratSemanticBase ratNonzeroPullbackFakeSpec ratFakeHilbertChart ∧
    ¬ DomainObsExtEq ratNonzeroPullbackFakeSpec ratNonzeroIntrSpec ∧
    ¬ ratPinnedRegistry.DomainSpecPinned "dom_Q_nonzero" ratNonzeroPullbackFakeSpec ∧
    ¬ (∃ anch : CertifiedChartAnchor ratPinnedRegistry "base_Q" "dom_Q_nonzero" RatNonzero,
        anch.domSpec = ratNonzeroPullbackFakeSpec) := by
  have htriv : PreservesObs ratSemanticBase ratNonzeroPullbackFakeSpec ratFakeHilbertChart :=
    fun _ _ => Iff.rfl
  have hneq : ¬ DomainObsExtEq ratNonzeroPullbackFakeSpec ratNonzeroIntrSpec := by
    intro hext
    let y1 : RatNonzero := ⟨1, rat_one_ne_zero⟩
    have h1 := (hext .sqPos y1).mpr ((rat_sq_pos_iff_ne_zero 1).mpr rat_one_ne_zero)
    change 0 < (hilbertNonzeroToRat y1) * (hilbertNonzeroToRat y1) at h1
    rw [hilbertNonzeroToRat_one, Rat.mul_zero] at h1
    exact Rat.lt_irrefl h1
  have hnot_pin : ¬ ratPinnedRegistry.DomainSpecPinned "dom_Q_nonzero" ratNonzeroPullbackFakeSpec := by
    intro hpin
    rcases hpin with ⟨hbad, _⟩ | ⟨_, heq, hiff⟩
    · exact (by decide : "dom_Q_nonzero" ≠ "dom_Q") hbad
    · cases heq
      exact hneq hiff
  refine ⟨htriv, hneq, hnot_pin, ?_⟩
  rintro ⟨anch, hds⟩
  have hpin := anch.dom_pinned
  rw [hds] at hpin
  exact hnot_pin hpin

end OmegaCellC1P1A0
