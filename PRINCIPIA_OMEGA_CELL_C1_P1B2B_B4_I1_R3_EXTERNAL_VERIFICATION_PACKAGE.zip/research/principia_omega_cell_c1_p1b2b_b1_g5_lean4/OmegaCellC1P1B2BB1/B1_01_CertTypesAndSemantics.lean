/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B1 — Isolated G5 Certified Obstruction Discharge Kernel
  Module: OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics

  Authorization: `PRINCIPIA_P1B2B_B1_ISOLATED_G5_IMPLEMENTATION_AUTHORIZED`
  Scope (`B1-A1` & `B1-A2`):
    1. Typed syntactic G5 certificate structures (`1:1` aligned with `R1 + Corrigendum 01` & `B1-A2`):
       - `RatCoord2`, `G5NonEmptyWitness`
       - `VerifiedObstructionSpec` (`ObstructionEvidenceData`)
       - `RepairDomEqCert` (`abbrev RepairDomEqWitness`)
       - `G5RetreatPartitionCert` (`abbrev G5ExactScopeLossCert`)
       - `G5RefinementCert`
       - `G5DerivedPrimDeps`
       - `G5DischargeCert`
    2. Pure non-circular declarative G5 semantics (`S_sem_B1` — ZERO executable checker calls!):
       - Read-only reuse of frozen `OmegaCellC1P1B2BA0`: `InEffDom`, `SemSameEffDom`,
         `ExcisedLocus`, `ModelsExcisedBranch`, `ModelsExcised`, `SemExactScopeLossPartition`.
       - `G5ObstReflexAllowed` (semantic refinement of `P1B1`'s `ObstReflexMatrixAllowed`,
         accompanied by mechanized impossibility theorem `T_B1_04b_conservative_refinement_excludes_counterexample`).
       - `SemValidObstructionOnOld`, `SemValidRepairDischarge`, `SemValidRetreatDischarge`,
         `SemValidRefinementDischarge`, `SemValidG5Discharge`.
       - External provenance of retention anchors (`AuthoritativeAnchorProvenanceHeld`) and
         ledger mutation of `historicalRetreat` remain explicitly separated as external `B4` boundaries.
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1
import OmegaCellC1P1B2A
import OmegaCellC1P1B2BA0

namespace OmegaCellC1P1B2BB1

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0

/-! ### 1. Exact Rational Witness Coordinates & Typed G5 Certificate Structures (`B1-A2`) -/

/-- Exact syntactic rational coordinate `(xNum / xDenPos, yNum / yDenPos) ∈ ℚ × ℚ`.
    Well-formedness (`0 < xDenPos ∧ 0 < yDenPos`) is checked deterministically in `B1_02`
    and required in `S_sem_B1`. -/
structure RatCoord2 where
  xNum    : Int
  xDenPos : Nat
  yNum    : Int
  yDenPos : Nat
  deriving DecidableEq, Repr

/-- Pure mathematical embedding of `RatCoord2` into `Env2 = Rat × Rat` (`0` checker calls). -/
def ratCoordToEnv2 (pt : RatCoord2) : Env2 :=
  ((pt.xNum : Rat) / ((pt.xDenPos : Int) : Rat),
   (pt.yNum : Rat) / ((pt.yDenPos : Int) : Rat))

/-- Convenience constructor lifting an integer pair `(ix, iy)` into `RatCoord2` with unit denominators. -/
def ratCoordOfInt2 (ix iy : Int) : RatCoord2 :=
  ⟨ix, 1, iy, 1⟩

theorem ratCoordOfInt2_toEnv2 (ix iy : Int) :
    ratCoordToEnv2 (ratCoordOfInt2 ix iy) = ((ix : Rat), (iy : Rat)) := by
  have hOne : (((1 : Nat) : Int) : Rat) = 1 := rfl
  have hNe : (1 : Rat) ≠ 0 := by decide
  have hDiv1 : ∀ q : Rat, q / (1 : Rat) = q := by
    intro q
    rw [Rat.div_def]
    have hInv : (1 : Rat)⁻¹ = 1 := by
      have hm := Rat.mul_inv_cancel (1 : Rat) hNe
      rwa [Rat.one_mul] at hm
    rw [hInv, Rat.mul_one]
  unfold ratCoordToEnv2 ratCoordOfInt2
  dsimp only
  rw [hOne, hDiv1, hDiv1]

/-- **`G5NonEmptyWitness` (`B1-A2`)**:
    Concrete rational witness certifying post-reflex effective-domain non-emptiness (`D_new,eff ≠ ∅`). -/
structure G5NonEmptyWitness where
  witnessCoord : RatCoord2
  deriving DecidableEq, Repr

/-- Concrete obstruction evidence payload (`B1-02`: no bare boolean `PASS` flags). -/
inductive ObstructionEvidenceData where
  | counterexamplePt : (obsPt : RatCoord2) → ObstructionEvidenceData
  | invalidSosCert   : (badSos : PolyPositivstellensatzCert) → (probePt : RatCoord2) →
                       ObstructionEvidenceData
  | missingGuard     : (candGuard : StrictForm) → (failOrWitPt? : Option RatCoord2) →
                       (obstProofNodeId? : Option String) → ObstructionEvidenceData
  | scopedNoGoLocus  : (locusGuards : List StrictForm) → (noGoPt : RatCoord2) →
                       (noGoNodeId : String) → ObstructionEvidenceData
  deriving DecidableEq, Repr

/-- **`VerifiedObstructionSpec` (`B1-A2`)**:
    Binds obstruction CID, target old cell/spec identifiers, `KernelObstKindV1`, and concrete evidence. -/
structure VerifiedObstructionSpec where
  obstCid          : String
  targetCellOldCid : String
  targetSpecOldId  : String
  obstKind         : KernelObstKindV1
  evidence         : ObstructionEvidenceData
  deriving DecidableEq, Repr

/-- Closed base-domain equivalence modes allowed in `Repair` (`D_old,eff = D_new,eff`). -/
inductive BaseDomEquivStep where
  | sameBaseDom       : (D : G7DomTag) → BaseDomEquivStep
  | qGuardNzToNonzero : (nzProofNodeId : String) → BaseDomEquivStep
  | nonzeroToQGuardNz : (nzProofNodeId : String) → BaseDomEquivStep
  deriving DecidableEq, Repr

/-- **`RepairDomEqCert` (`B1-A2`; `R1` alias `RepairDomEqWitness`)**:
    Proof references establishing bidirectional effective-domain equality
    `SemSameEffDom D_old Γ_old D_new Γ_new` plus optional redundant-guard proof for `.missingAssumption true`. -/
structure RepairDomEqCert where
  baseEquivStep            : BaseDomEquivStep
  oldGuardsDefNodeId?      : Option String
  oldEntailsNewGuardNodes  : List (StrictForm × String)
  newEntailsOldGuardNodes  : List (StrictForm × String)
  redundantGuardNodeId?    : Option String
  deriving DecidableEq, Repr

/-- `1:1` alias preserving `P1B2B-R1` identifier `RepairDomEqWitness`. -/
abbrev RepairDomEqWitness : Type := RepairDomEqCert

/-- Guard-connection certificate linking `Γ_new` to `Γ_old ++ ΔΓ` on `D_new` in `Retreat`. -/
inductive GuardConnCert where
  | syntacticConcat : GuardConnCert
  | mutualImplication :
      (deltaEntailsNewNodes : List (StrictForm × String)) →
      (newEntailsDeltaNodes : List (StrictForm × String)) →
      GuardConnCert
  deriving DecidableEq, Repr

/-- Optional `G7`-verified equivalent re-expression certificate when `excisedBranches != B_canon`
    (`Corrigendum 01` §1.2 Step 3). -/
structure ExcisedReexprCert where
  /-- Each reported branch `E_i ∈ excisedBranches` paired with `(defNodeId, disjointNodeId)`:
      - `defNodeId` proves `⟨D_old, specNewId, Γ_old ++ E_i, .eqZero (.const 0)⟩`
      - `disjointNodeId` proves `⟨D_new, specNewId, Γ_new ++ E_i, .pos (.const 0)⟩`. -/
  branchDefAndDisjNodes : List (List StrictForm × String × String)
  /-- Each canonical branch `B_j ∈ B_canon` paired with `(targetBranch E_i, [(ψ, nodeId) for ψ ∈ E_i])`
      where each `nodeId` proves `⟨D_old, specNewId, B_j, ψ⟩`. -/
  canonCoverWitnesses   : List (List StrictForm × List StrictForm × List (StrictForm × String))
  deriving DecidableEq, Repr

/-- **`G5RetreatPartitionCert` (`B1-A2`; `R1` alias `G5ExactScopeLossCert`)**:
    2-stage telescopic partition certificate (`BaseDomRetreatStep` + prefix-defined `deltaGuards`),
    reported `excisedBranches`, strict loss witness in `D_old,eff ∩ ModelsExcised`, optional
    adopted-guard proof node, and conditionally checked retention anchors. -/
structure G5RetreatPartitionCert where
  baseStep                : BaseDomRetreatStep
  deltaGuards             : List StrictForm
  prefixDefNodeId         : String
  guardConn               : GuardConnCert
  excisedBranches         : ExcisedLocus
  reexprCert?             : Option ExcisedReexprCert
  strictLossWitness       : RatCoord2
  claimedRetentionAnchors : List RatCoord2
  adoptedGuardNodeId?     : Option String
  deriving DecidableEq, Repr

/-- `1:1` alias preserving `P1B2B-R1` identifier `G5ExactScopeLossCert`. -/
abbrev G5ExactScopeLossCert : Type := G5RetreatPartitionCert

/-- Closed base-domain conservative expansion modes (`inG7Dom D_old ρ → inG7Dom D_new ρ`). -/
inductive BaseDomExpandStep where
  | sameBaseDom    : (D : G7DomTag) → BaseDomExpandStep
  | qNonzeroToQ    : BaseDomExpandStep
  | qToQ2          : BaseDomExpandStep
  | qNonzeroToQ2   : BaseDomExpandStep
  | finiteGridSup  : (L_old L_new : List (Int × Int)) → BaseDomExpandStep
  deriving DecidableEq, Repr

/-- **`G5RefinementCert` (`B1-A2` & `B1-05`)**:
    Conservative refinement certificate establishing `D_old,eff ⊆ D_new,eff`, conservative
    goal entailment `∀ ρ ∈ D_new,eff, P_new(ρ) → P_old(ρ)`, and explicit scope-expansion
    accounting (`scopeExpanded = false` requires bidirectional `SemSameEffDom`;
    `scopeExpanded = true` requires concrete `expansionWitness? = some pt_exp ∈ D_new,eff \ D_old,eff`). -/
structure G5RefinementCert where
  baseExpandStep           : BaseDomExpandStep
  oldGuardsDefNodeId?      : Option String
  oldEntailsNewGuardNodes  : List (StrictForm × String)
  newEntailsOldGuardNodes  : List (StrictForm × String)
  goalImpNodeId?           : Option String
  adoptedGuardNodeId?      : Option String
  scopeExpanded            : Bool
  expansionWitness?        : Option RatCoord2
  deriving DecidableEq, Repr

/-- **`G5DerivedPrimDeps` (`B1-A2`)**:
    Canonical deduplicated list of transitive primitive premise IDs across ALL proof roots of `cert`. -/
structure G5DerivedPrimDeps where
  primDepIds : List String
  deriving DecidableEq, Repr

/-- **`G5DischargeCert` (`B1-02` & `B1-A2`)**:
    Complete typed G5 certified obstruction discharge submission.
    Branch-specific sub-certificates (`repairCert?`, `retreatCert?`, `refinementCert?`) are enforced
    mutually exclusive in both `SemValidG5Discharge` and `checkG5DischargeBool`. -/
structure G5DischargeCert where
  certVersion            : String
  rflxCid                : String
  cellOldCid             : String
  obstCid                : String
  cellNewCid             : String
  baseId                 : String
  specOldId              : String
  specNewId              : String
  domOld                 : G7DomTag
  guardsOld              : List StrictForm
  goalOld                : StrictForm
  domNew                 : G7DomTag
  guardsNew              : List StrictForm
  goalNew                : StrictForm
  reflexKind             : ReflexKind
  obstructionSpec        : VerifiedObstructionSpec
  nonEmptyWitness        : G5NonEmptyWitness
  goalNewNodeId          : String
  repairCert?            : Option RepairDomEqCert
  retreatCert?           : Option G5RetreatPartitionCert
  refinementCert?        : Option G5RefinementCert
  claimedPrimDeps        : G5DerivedPrimDeps
  requiresRetreatHistory : Bool
  deriving DecidableEq, Repr

/-! ### 2. Pure Non-Circular Declarative Semantics (`S_sem_B1` — `0` Executable Checker Calls!) -/

/-- Pure declarative evaluation of a sum of weighted squares `∑ w_k * p_k(ρ)^2` (`0` checker calls). -/
def evalPureSosSqSum : List (Int × PolyExpr) → Env2 → Rat
  | [],               _ => 0
  | (w, p) :: rest,   ρ =>
      let vp := evalPolyExpr p ρ
      (w : Rat) * (vp * vp) + evalPureSosSqSum rest ρ

/-- Pure mathematical necessary conditions for `sc : PolyPositivstellensatzCert` to be a valid
    SOS certificate for `goalOld` on `(D_old, Γ_old)` (`0` executable checker calls).
    Violating this predicate (`¬ SemNecessarySosConditions ...`) proves mathematically that `sc`
    is genuinely defective on `(D_old, Γ_old, goalOld)`. -/
def SemNecessarySosConditions (D_old : G7DomTag) (Γ_old : List StrictForm)
    (goalOld : StrictForm) (sc : PolyPositivstellensatzCert) : Prop :=
  0 < sc.lhsScale ∧
  0 ≤ sc.constTerm ∧
  (∀ wp ∈ sc.sqTerms, 0 ≤ wp.1) ∧
  (∀ ρ : Env2, InEffDom D_old Γ_old ρ →
    match goalOld with
    | .nonneg e =>
        ∃ v : Rat, PartExprEvalRel e ρ v ∧
          (sc.nonnegMult = [] ∧ sc.posMult = [] ∧ sc.eqMult = [] →
            (sc.lhsScale : Rat) * v = (sc.constTerm : Rat) + evalPureSosSqSum sc.sqTerms ρ)
    | .pos e =>
        (sc.posMult = [] → 0 < sc.constTerm) ∧
        ∃ v : Rat, PartExprEvalRel e ρ v ∧
          (sc.nonnegMult = [] ∧ sc.posMult = [] ∧ sc.eqMult = [] →
            (sc.lhsScale : Rat) * v = (sc.constTerm : Rat) + evalPureSosSqSum sc.sqTerms ρ)
    | .eqZero e =>
        sc.constTerm = 0 ∧ sc.sqTerms = [] ∧
        ∃ v : Rat, PartExprEvalRel e ρ v ∧
          (sc.nonnegMult = [] ∧ sc.posMult = [] ∧ sc.eqMult = [] →
            (sc.lhsScale : Rat) * v = 0)
    | _ => False)

/-- Pure semantic `(KernelObstKindV1 × ReflexKind)` admissibility relation for `G5` (`0` checker calls).
    Refines `P1B1`'s syntactic `ObstReflexMatrixAllowed`:
    - Excludes `.environmentalFailure` (non-epistemic) and `.unsupportedHorizon` (held in `B1`);
    - Excludes `(.scopedNoGo, .repair)`, `(.invalidCertificate, .retreat)`, `(.missingAssumption false, .repair)`;
    - Excludes `(.counterexamplePoint, .refinement)`, `(.scopedNoGo, .refinement)`, and
      `(.missingAssumption false, .refinement)` because conservative `Refinement` (`D_old,eff ⊆ D_new,eff`
      and `P_new ⇒ P_old`) mathematically forces `P_old` (and any adopted guard) to hold across ALL of `D_old,eff`! -/
def G5ObstReflexAllowed : KernelObstKindV1 → ReflexKind → Prop
  | .counterexamplePoint,      .repair     => True
  | .counterexamplePoint,      .retreat    => True
  | .counterexamplePoint,      .refinement => False
  | .invalidCertificate,       .repair     => True
  | .invalidCertificate,       .retreat    => False
  | .invalidCertificate,       .refinement => True
  | .missingAssumption true,   .repair     => True
  | .missingAssumption false,  .repair     => False
  | .missingAssumption _,      .retreat    => True
  | .missingAssumption true,   .refinement => True
  | .missingAssumption false,  .refinement => False
  | .scopedNoGo,               .repair     => False
  | .scopedNoGo,               .retreat    => True
  | .scopedNoGo,               .refinement => False
  | .unsupportedHorizon,       _           => False
  | .environmentalFailure,     _           => False

/-- Every `(okind, rk)` allowed by `G5ObstReflexAllowed` strictly obeys frozen `P1B1`'s
    `ObstReflexMatrixAllowed` and excludes `.environmentalFailure`. -/
theorem g5ObstReflexAllowed_implies_p1b1_matrix {okind : KernelObstKindV1} {rk : ReflexKind}
    (h : G5ObstReflexAllowed okind rk) :
    okind ≠ .environmentalFailure ∧ ObstReflexMatrixAllowed okind rk := by
  cases okind with
  | counterexamplePoint =>
      cases rk <;> first | contradiction | exact ⟨by decide, trivial⟩
  | invalidCertificate =>
      cases rk <;> first | contradiction | exact ⟨by decide, trivial⟩
  | missingAssumption b =>
      cases b <;> cases rk <;> first | contradiction | exact ⟨by decide, trivial⟩
  | scopedNoGo =>
      cases rk <;> first | contradiction | exact ⟨by decide, trivial⟩
  | unsupportedHorizon =>
      cases rk <;> contradiction
  | environmentalFailure =>
      cases rk <;> contradiction

/-- **`T_B1_04b` — Semantic Impossibility of Conservative `Refinement` Under Any Old-Domain Point Failure**:
    If `D_old,eff ⊆ D_new,eff`, `P_new` holds across `D_new,eff`, AND `P_new ⇒ P_old` holds across
    `D_new,eff`, then NO point `ρ_obs ∈ D_old,eff` can satisfy `¬ ModelsStrictForm goalOld ρ_obs`.
    This proves mechanically why genuine `.counterexamplePoint` and `.scopedNoGo` obstructions
    can ONLY be discharged by `Repair` (modifying `goalOld`) or `Retreat` (excising `ρ_obs`), NEVER
    by conservative `Refinement`! -/
theorem T_B1_04b_conservative_refinement_excludes_counterexample
    {D_old D_new : G7DomTag} {Γ_old Γ_new : List StrictForm} {goalOld goalNew : StrictForm}
    (hDomIncl : ∀ ρ : Env2, InEffDom D_old Γ_old ρ → InEffDom D_new Γ_new ρ)
    (hGoalNew : ∀ ρ : Env2, InEffDom D_new Γ_new ρ → ModelsStrictForm goalNew ρ)
    (hConsImp : ∀ ρ : Env2, InEffDom D_new Γ_new ρ →
                  ModelsStrictForm goalNew ρ → ModelsStrictForm goalOld ρ) :
    ¬ ∃ ρ_obs : Env2, InEffDom D_old Γ_old ρ_obs ∧ ¬ ModelsStrictForm goalOld ρ_obs := by
  rintro ⟨ρ_obs, hOldObs, hNotGoalOld⟩
  have hNewObs : InEffDom D_new Γ_new ρ_obs := hDomIncl ρ_obs hOldObs
  have hSatNew : ModelsStrictForm goalNew ρ_obs := hGoalNew ρ_obs hNewObs
  exact hNotGoalOld (hConsImp ρ_obs hNewObs hSatNew)

/-- Pure declarative semantic validity of `VerifiedObstructionSpec` on `(D_old, Γ_old, goalOld)`
    (`0` executable checker calls). -/
def SemValidObstructionOnOld (D_old : G7DomTag) (Γ_old : List StrictForm) (goalOld : StrictForm)
    (spec : VerifiedObstructionSpec) : Prop :=
  match spec.obstKind, spec.evidence with
  | .counterexamplePoint, .counterexamplePt obsPt =>
      0 < obsPt.xDenPos ∧ 0 < obsPt.yDenPos ∧
      InEffDom D_old Γ_old (ratCoordToEnv2 obsPt) ∧
      ¬ ModelsStrictForm goalOld (ratCoordToEnv2 obsPt)
  | .invalidCertificate, .invalidSosCert badSos probePt =>
      0 < probePt.xDenPos ∧ 0 < probePt.yDenPos ∧
      ¬ SemNecessarySosConditions D_old Γ_old goalOld badSos
  | .missingAssumption true, .missingGuard candGuard none _ =>
      ∀ ρ : Env2, InEffDom D_old Γ_old ρ → ModelsStrictForm candGuard ρ
  | .missingAssumption false, .missingGuard candGuard (some failPt) _ =>
      0 < failPt.xDenPos ∧ 0 < failPt.yDenPos ∧
      InEffDom D_old Γ_old (ratCoordToEnv2 failPt) ∧
      ¬ ModelsStrictForm candGuard (ratCoordToEnv2 failPt)
  | .scopedNoGo, .scopedNoGoLocus locusGuards noGoPt _ =>
      0 < noGoPt.xDenPos ∧ 0 < noGoPt.yDenPos ∧
      InEffDom D_old (Γ_old ++ locusGuards) (ratCoordToEnv2 noGoPt) ∧
      (∀ ρ : Env2, InEffDom D_old (Γ_old ++ locusGuards) ρ → ¬ ModelsStrictForm goalOld ρ)
  | _, _ => False

/-- Pure declarative `Repair` discharge obligation (`B1-03`, `0` checker calls):
    - Exact bidirectional effective-domain equality `SemSameEffDom D_old Γ_old D_new Γ_new`
      (rejecting BOTH domain shrinkage AND domain expansion!),
    - `requiresRetreatHistory = false`,
    - Obstruction-kind-specific resolution (in particular, any `.counterexamplePt obsPt` lies in
      `D_new,eff` and satisfies `ModelsStrictForm goalNew (ratCoordToEnv2 obsPt)`!). -/
def SemValidRepairDischarge (cert : G5DischargeCert) : Prop :=
  cert.repairCert?.isSome = true ∧
  cert.retreatCert? = none ∧
  cert.refinementCert? = none ∧
  cert.requiresRetreatHistory = false ∧
  SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew ∧
  match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
  | .counterexamplePoint, .counterexamplePt obsPt =>
      InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 obsPt) ∧
      ModelsStrictForm cert.goalNew (ratCoordToEnv2 obsPt)
  | .invalidCertificate, .invalidSosCert _ _ =>
      ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm cert.goalNew ρ
  | .missingAssumption true, .missingGuard candGuard none _ =>
      (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm candGuard ρ) ∧
      (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm cert.goalNew ρ)
  | _, _ => False

/-- Pure declarative `Retreat` discharge obligation (`B1-04`, `0` checker calls):
    - Exact disjoint scope-loss partition `SemExactScopeLossPartition D_old Γ_old D_new Γ_new Φ_excised`,
    - Genuine non-empty loss (`strictLossWitness ∈ D_old,eff ∩ ModelsExcised Φ_excised`),
    - `requiresRetreatHistory = true` (explicit output obligation; ledger mutation held for `B4`),
    - Conditional retention of supplied `claimedRetentionAnchors` (external baseline provenance held for `B4`),
    - Obstruction-kind-specific excision / guard-adoption resolution! -/
def SemValidRetreatDischarge (cert : G5DischargeCert) : Prop :=
  cert.repairCert? = none ∧
  cert.refinementCert? = none ∧
  cert.requiresRetreatHistory = true ∧
  match cert.retreatCert? with
  | none => False
  | some rCert =>
      let ρ_loss := ratCoordToEnv2 rCert.strictLossWitness
      0 < rCert.strictLossWitness.xDenPos ∧ 0 < rCert.strictLossWitness.yDenPos ∧
      SemExactScopeLossPartition cert.domOld cert.guardsOld cert.domNew cert.guardsNew
        rCert.excisedBranches ∧
      InEffDom cert.domOld cert.guardsOld ρ_loss ∧
      ModelsExcised rCert.excisedBranches ρ_loss ∧
      ¬ InEffDom cert.domNew cert.guardsNew ρ_loss ∧
      (∀ pt_a ∈ rCert.claimedRetentionAnchors,
        0 < pt_a.xDenPos ∧ 0 < pt_a.yDenPos ∧
        InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 pt_a)) ∧
      match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
      | .counterexamplePoint, .counterexamplePt obsPt =>
          InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 obsPt) ∧
          ModelsExcised rCert.excisedBranches (ratCoordToEnv2 obsPt) ∧
          ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 obsPt)
      | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
          InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 noGoPt) ∧
          ModelsExcised rCert.excisedBranches (ratCoordToEnv2 noGoPt) ∧
          ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 noGoPt)
      | .missingAssumption true, .missingGuard candGuard none _ =>
          ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ
      | .missingAssumption false, .missingGuard candGuard (some failPt) _ =>
          InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 failPt) ∧
          ModelsExcised rCert.excisedBranches (ratCoordToEnv2 failPt) ∧
          ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 failPt) ∧
          (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ)
      | _, _ => False

/-- Pure declarative `Refinement` discharge obligation (`B1-05`, `0` checker calls):
    - Conservative domain inclusion `D_old,eff ⊆ D_new,eff`,
    - Conservative goal preservation `∀ ρ ∈ D_new,eff, P_new(ρ) → P_old(ρ)`
      (hence `∀ ρ ∈ D_old,eff, P_old(ρ)`!),
    - Explicit scope-expansion accounting (`scopeExpanded = false → D_old,eff = D_new,eff`;
      `scopeExpanded = true → ∃ ρ_exp ∈ D_new,eff \ D_old,eff`),
    - Obstruction-kind-specific resolution (`.invalidCertificate` or `.missingAssumption true`). -/
def SemValidRefinementDischarge (cert : G5DischargeCert) : Prop :=
  cert.repairCert? = none ∧
  cert.retreatCert? = none ∧
  cert.requiresRetreatHistory = false ∧
  match cert.refinementCert? with
  | none => False
  | some refCert =>
      (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
        InEffDom cert.domNew cert.guardsNew ρ) ∧
      (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ →
        ModelsStrictForm cert.goalNew ρ → ModelsStrictForm cert.goalOld ρ) ∧
      (if refCert.scopeExpanded then
        ∃ pt_exp : RatCoord2,
          refCert.expansionWitness? = some pt_exp ∧
          0 < pt_exp.xDenPos ∧ 0 < pt_exp.yDenPos ∧
          InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 pt_exp) ∧
          ¬ InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 pt_exp)
       else
        refCert.expansionWitness? = none ∧
        SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew) ∧
      match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
      | .invalidCertificate, .invalidSosCert _ _ =>
          ∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm cert.goalOld ρ
      | .missingAssumption true, .missingGuard candGuard none _ =>
          (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ) ∧
          (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm cert.goalOld ρ)
      | _, _ => False

/-- **`SemValidG5Discharge` (`B1-A1` & `B1-06` — Top-Level Non-Circular Declarative G5 Semantics)**:
    Conjoins canonical subject binding, `(ObstKind × ReflexKind)` admissibility, genuine old-state
    obstruction validity, post-reflex effective-domain non-emptiness (`nonEmptyWitness ∈ D_new,eff`),
    post-reflex universal target validity (`∀ ρ ∈ D_new,eff, ModelsStrictForm goalNew ρ`), and
    exact branch-specific domain & obstruction discharge laws.
    Contains **ZERO** calls to any executable checker (`Cone*(SemValidG5Discharge) ∩ K_exec = ∅`). -/
structure SemValidG5Discharge (cert : G5DischargeCert) : Prop where
  canonicalBinding :
    cert.certVersion = "g5_b1_v1" ∧
    cert.rflxCid ≠ "" ∧
    cert.cellOldCid ≠ "" ∧
    cert.obstCid ≠ "" ∧
    cert.cellNewCid ≠ "" ∧
    cert.baseId = "base_Q" ∧
    cert.specOldId ≠ "" ∧
    cert.specNewId ≠ "" ∧
    cert.obstructionSpec.obstCid = cert.obstCid ∧
    cert.obstructionSpec.targetCellOldCid = cert.cellOldCid ∧
    cert.obstructionSpec.targetSpecOldId = cert.specOldId
  allowedObstReflex :
    G5ObstReflexAllowed cert.obstructionSpec.obstKind cert.reflexKind
  validObstructionOnOld :
    SemValidObstructionOnOld cert.domOld cert.guardsOld cert.goalOld cert.obstructionSpec
  nonEmptyNewEffDom :
    0 < cert.nonEmptyWitness.witnessCoord.xDenPos ∧
    0 < cert.nonEmptyWitness.witnessCoord.yDenPos ∧
    InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 cert.nonEmptyWitness.witnessCoord)
  validPostReflexTarget :
    ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm cert.goalNew ρ
  branchExactDischarge :
    match cert.reflexKind with
    | .repair     => SemValidRepairDischarge cert
    | .retreat    => SemValidRetreatDischarge cert
    | .refinement => SemValidRefinementDischarge cert

end OmegaCellC1P1B2BB1
