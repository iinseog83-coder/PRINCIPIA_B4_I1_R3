/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B1 — Isolated G5 Certified Obstruction Discharge Kernel
  Module: OmegaCellC1P1B2BB1.B1_04_WitnessesAndCounterexamples

  Authorization: `PRINCIPIA_P1B2B_B1_ISOLATED_G5_IMPLEMENTATION_AUTHORIZED`
  Scope (`B1-A5`):
    1. Concrete Positive Inhabitation Witnesses (`checkG5DischargeBool = true` + `SemValidG5Discharge`):
       - `posG5Repair_F05_SOS`: `Repair` on `ℚ` resolving `(1, 0)` counterexample via SOS `x^2 + 4 > 0`
         with non-integer rational witness `(1/2, 0)` (`B1-01` reuse of `A0_06_F_B2B_05_SOS_Witness_Proven`).
       - `posG5Retreat_BaseDomNz`: `Retreat` `ℚ → ℚ \ {0}` resolving `x = 0` division-by-zero singularity
         of `(x/x) - 1 = 0`, preserving anchor `(1, 0)`, `requiresRetreatHistory = true`.
       - `posG5Retreat_PartialDivSeq`: `Retreat` `ℚ → [x ≠ 0, 1/x > 0]` with partial-definedness guard,
         exact telescopic partition `[[x = 0], [x ≠ 0, -1/x ≥ 0]]`, resolving `(-2, 0)`, preserving `(2, 0)`.
       - `posG5Refinement_SameDomStrengthen`: Conservative `Refinement` (`scopeExpanded = false`)
         strengthening `x - 1 > 0` to `x - 2 > 0` under `[x - 3 > 0]` and resolving `.invalidCertificate`.
       - `posG5Refinement_DomExpand`: Conservative `Refinement` (`scopeExpanded = true`) expanding
         `.domQNonzero ↪ .domQ` for `x^2 ≥ 0` with expansion witness `(0, 0)`.
    2. Complete 10-Vector Orthogonal & Cross-Term Adversarial Suite (`B1-CE01` .. `B1-CE10`):
       All 10 mandatory attack classes mechanically proved REJECTED / ESCALATION-BLOCKED in Lean 4.33.1.
-/
import OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure

namespace OmegaCellC1P1B2BB1

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0

/-! ### 1. Positive Inhabitation Witnesses (`Repair`, `Retreat`, Partial-Div `Retreat`, `Refinement`) -/

/-- **Positive Witness 1 (`posG5Repair_F05_SOS`)**:
    Legitimate `Repair` on `.domQ` resolving `(1, 0)` counterexample of `(x - 1)^2 > 0` via SOS
    `x^2 + 4 > 0` (`f05_sosCertGoalNew`), using non-integer rational witness `(1/2, 0)`. -/
def posG5Repair_F05_SOS : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_repair_f05"
  cellOldCid             := "cell_f05_old"
  obstCid                := "obst_f05_x1"
  cellNewCid             := "cell_f05_new"
  baseId                 := "base_Q"
  specOldId              := "spec_f05_old"
  specNewId              := "spec_f05_new"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := f05_goalOld
  domNew                 := .domQ
  guardsNew              := []
  goalNew                := f05_goalNew
  reflexKind             := .repair
  obstructionSpec        := {
    obstCid          := "obst_f05_x1"
    targetCellOldCid := "cell_f05_old"
    targetSpecOldId  := "spec_f05_old"
    obstKind         := .counterexamplePoint
    evidence         := .counterexamplePt ⟨1, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨1, 2, 0, 1⟩⟩
  goalNewNodeId          := "n_f05_goal_new"
  repairCert?            := some {
    baseEquivStep           := .sameBaseDom .domQ
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    redundantGuardNodeId?   := none
  }
  retreatCert?           := none
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := false

/-- `G7DagContainer` for `posG5Retreat_BaseDomNz` (`ℚ → ℚ \ {0}` for `(x/x) - 1 = 0`). -/
def containerPosRetreatBaseNz : G7DagContainer where
  nodes := [
    { nodeId     := "n_nz_prefix_def"
      topoRank   := 0
      domTag     := .domQNonzero
      specId     := "spec_ret_nz_new"
      guards     := []
      conclusion := .eqZero (.const 0)
      step       := .directDerivStep
                      (.certStep (.eqZero (.const 0))
                        (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)) },
    { nodeId     := "n_nz_goal_divself"
      topoRank   := 1
      domTag     := .domQNonzero
      specId     := "spec_ret_nz_new"
      guards     := []
      conclusion := .eqZero exprDivSelfMinusOne
      step       := .directDerivStep
                      (.certStep (.eqZero exprDivSelfMinusOne)
                        (.guardedReciprocal (.selfDivCancel .varX))) }
  ]

/-- **Positive Witness 2 (`posG5Retreat_BaseDomNz`)**:
    Legitimate base-domain `Retreat` `ℚ → ℚ \ {0}` discharging the division-by-zero singularity
    `x = 0` of `(x / x) - 1 = 0`, preserving retention anchor `(1, 0)`, and flagging
    `requiresRetreatHistory = true`. -/
def posG5Retreat_BaseDomNz : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_retreat_nz"
  cellOldCid             := "cell_divself_old"
  obstCid                := "obst_divself_zero"
  cellNewCid             := "cell_divself_new"
  baseId                 := "base_Q"
  specOldId              := "spec_ret_nz_old"
  specNewId              := "spec_ret_nz_new"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := .eqZero exprDivSelfMinusOne
  domNew                 := .domQNonzero
  guardsNew              := []
  goalNew                := .eqZero exprDivSelfMinusOne
  reflexKind             := .retreat
  obstructionSpec        := {
    obstCid          := "obst_divself_zero"
    targetCellOldCid := "cell_divself_old"
    targetSpecOldId  := "spec_ret_nz_old"
    obstKind         := .counterexamplePoint
    evidence         := .counterexamplePt ⟨0, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨3, 4, 0, 1⟩⟩
  goalNewNodeId          := "n_nz_goal_divself"
  repairCert?            := none
  retreatCert?           := some {
    baseStep                := .qToQNonzero
    deltaGuards             := []
    prefixDefNodeId         := "n_nz_prefix_def"
    guardConn               := .syntacticConcat
    excisedBranches         := [[.eqZero .varX]]
    reexprCert?             := none
    strictLossWitness       := ⟨0, 1, 0, 1⟩
    claimedRetentionAnchors := [⟨1, 1, 0, 1⟩]
    adoptedGuardNodeId?     := none
  }
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := true

/-- `G7DagContainer` for `posG5Retreat_PartialDivSeq` (`ℚ → [x ≠ 0, 1/x > 0]`). -/
def containerPosRetreatPartialDiv : G7DagContainer where
  nodes := [
    { nodeId     := "n_seq_prefix_def"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_a0"
      guards     := deltaSeqRecipGuards
      conclusion := .eqZero (.const 0)
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := deltaSeqRecipGuards
        goalForm             := .eqZero (.const 0)
        guardWfCerts         := [.totalPolyWf, .prefixGuardDenomWf .varX]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.eqZero (.const 0))
                                  (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)
      } },
    { nodeId     := "n_seq_goal_recip_pos"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_a0"
      guards     := deltaSeqRecipGuards
      conclusion := .pos (.div (.const 1) .varX)
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := deltaSeqRecipGuards
        goalForm             := .pos (.div (.const 1) .varX)
        guardWfCerts         := [.totalPolyWf, .prefixGuardDenomWf .varX]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .hypGuard 1 (.pos (.div (.const 1) .varX))
      } }
  ]

/-- **Positive Witness 3 (`posG5Retreat_PartialDivSeq`)**:
    Legitimate partial-definedness guard `Retreat` `ℚ → [x ≠ 0, 1/x > 0]` with exact telescopic
    partition `[[x = 0], [x ≠ 0, -1/x ≥ 0]]`, resolving counterexample `(-2, 0)` while capturing
    undefined singularity `(0, 0)` and preserving anchor `(2, 0)`. -/
def posG5Retreat_PartialDivSeq : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_retreat_seq_recip"
  cellOldCid             := "cell_recip_old"
  obstCid                := "obst_recip_neg2"
  cellNewCid             := "cell_recip_new"
  baseId                 := "base_Q"
  specOldId              := "spec_recip_old"
  specNewId              := "spec_a0"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := .pos (.div (.const 1) .varX)
  domNew                 := .domQ
  guardsNew              := deltaSeqRecipGuards
  goalNew                := .pos (.div (.const 1) .varX)
  reflexKind             := .retreat
  obstructionSpec        := {
    obstCid          := "obst_recip_neg2"
    targetCellOldCid := "cell_recip_old"
    targetSpecOldId  := "spec_recip_old"
    obstKind         := .counterexamplePoint
    evidence         := .counterexamplePt ⟨-2, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨5, 2, 0, 1⟩⟩
  goalNewNodeId          := "n_seq_goal_recip_pos"
  repairCert?            := none
  retreatCert?           := some {
    baseStep                := .sameBaseDom .domQ
    deltaGuards             := deltaSeqRecipGuards
    prefixDefNodeId         := "n_seq_prefix_def"
    guardConn               := .syntacticConcat
    excisedBranches         := [[.eqZero .varX],
                                [.neqZero .varX, .nonneg (.neg (.div (.const 1) .varX))]]
    reexprCert?             := none
    strictLossWitness       := ⟨0, 1, 0, 1⟩
    claimedRetentionAnchors := [⟨2, 1, 0, 1⟩]
    adoptedGuardNodeId?     := none
  }
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := true

/-- `G7DagContainer` for `posG5Refinement_SameDomStrengthen` (`x - 2 > 0 ⇒ x - 1 > 0` on `[x - 3 > 0]`). -/
def containerPosRefineStrengthen : G7DagContainer where
  nodes := [
    { nodeId     := "n_ref_goal_new"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_ref_str_new"
      guards     := [.pos (.sub .varX (.const 3))]
      conclusion := .pos (.sub .varX (.const 2))
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.pos (.sub .varX (.const 3))]
        goalForm             := .pos (.sub .varX (.const 2))
        guardWfCerts         := [.totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.pos (.sub .varX (.const 2)))
                                  (.polyPositivstellensatz ⟨1, 1, [], [], [(0, 1)], []⟩)
      } },
    { nodeId     := "n_ref_goal_imp"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_ref_str_new"
      guards     := [.pos (.sub .varX (.const 3)), .pos (.sub .varX (.const 2))]
      conclusion := .pos (.sub .varX (.const 1))
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.pos (.sub .varX (.const 3)), .pos (.sub .varX (.const 2))]
        goalForm             := .pos (.sub .varX (.const 1))
        guardWfCerts         := [.totalPolyWf, .totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.pos (.sub .varX (.const 1)))
                                  (.polyPositivstellensatz ⟨1, 1, [], [], [(1, 1)], []⟩)
      } }
  ]

/-- **Positive Witness 4 (`posG5Refinement_SameDomStrengthen`)**:
    Legitimate conservative `Refinement` (`scopeExpanded = false`) strengthening `x - 1 > 0`
    to `x - 2 > 0` on `[x - 3 > 0]` and resolving `.invalidCertificate` (`⟨0, 0, [], [], [], []⟩`). -/
def posG5Refinement_SameDomStrengthen : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_refine_strengthen"
  cellOldCid             := "cell_ref_str_old"
  obstCid                := "obst_ref_bad_cert"
  cellNewCid             := "cell_ref_str_new"
  baseId                 := "base_Q"
  specOldId              := "spec_ref_str_old"
  specNewId              := "spec_ref_str_new"
  domOld                 := .domQ
  guardsOld              := [.pos (.sub .varX (.const 3))]
  goalOld                := .pos (.sub .varX (.const 1))
  domNew                 := .domQ
  guardsNew              := [.pos (.sub .varX (.const 3))]
  goalNew                := .pos (.sub .varX (.const 2))
  reflexKind             := .refinement
  obstructionSpec        := {
    obstCid          := "obst_ref_bad_cert"
    targetCellOldCid := "cell_ref_str_old"
    targetSpecOldId  := "spec_ref_str_old"
    obstKind         := .invalidCertificate
    evidence         := .invalidSosCert ⟨0, 0, [], [], [], []⟩ ⟨4, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨7, 2, 0, 1⟩⟩
  goalNewNodeId          := "n_ref_goal_new"
  repairCert?            := none
  retreatCert?           := none
  refinementCert?        := some {
    baseExpandStep          := .sameBaseDom .domQ
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    goalImpNodeId?          := some "n_ref_goal_imp"
    adoptedGuardNodeId?     := none
    scopeExpanded           := false
    expansionWitness?       := none
  }
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := false

/-- `G7DagContainer` for `posG5Refinement_DomExpand` (`.domQNonzero ↪ .domQ` for `x^2 ≥ 0`). -/
def containerPosRefineExpand : G7DagContainer where
  nodes := [
    { nodeId     := "n_ref_exp_sq_nonneg"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_ref_exp_new"
      guards     := []
      conclusion := .nonneg (.mul .varX .varX)
      step       := .directDerivStep
                      (.certStep (.nonneg (.mul .varX .varX))
                        (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)) }
  ]

/-- **Positive Witness 5 (`posG5Refinement_DomExpand`)**:
    Legitimate conservative `Refinement` (`scopeExpanded = true`) expanding `.domQNonzero ↪ .domQ`
    with verified expansion witness `(0, 0) ∈ D_new,eff \ D_old,eff` and resolving `.invalidCertificate`. -/
def posG5Refinement_DomExpand : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_refine_expand"
  cellOldCid             := "cell_ref_exp_old"
  obstCid                := "obst_ref_exp_bad_cert"
  cellNewCid             := "cell_ref_exp_new"
  baseId                 := "base_Q"
  specOldId              := "spec_ref_exp_old"
  specNewId              := "spec_ref_exp_new"
  domOld                 := .domQNonzero
  guardsOld              := []
  goalOld                := .nonneg (.mul .varX .varX)
  domNew                 := .domQ
  guardsNew              := []
  goalNew                := .nonneg (.mul .varX .varX)
  reflexKind             := .refinement
  obstructionSpec        := {
    obstCid          := "obst_ref_exp_bad_cert"
    targetCellOldCid := "cell_ref_exp_old"
    targetSpecOldId  := "spec_ref_exp_old"
    obstKind         := .invalidCertificate
    evidence         := .invalidSosCert ⟨0, 0, [], [], [], []⟩ ⟨1, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨0, 1, 0, 1⟩⟩
  goalNewNodeId          := "n_ref_exp_sq_nonneg"
  repairCert?            := none
  retreatCert?           := none
  refinementCert?        := some {
    baseExpandStep          := .qNonzeroToQ
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    goalImpNodeId?          := none
    adoptedGuardNodeId?     := none
    scopeExpanded           := true
    expansionWitness?       := some ⟨0, 1, 0, 1⟩
  }
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := false

/-- **All 5 Positive Witnesses Accepted & Semantically Sound (`B1_PosWitnessSuite_Proven`)**:
    Mechanically verifies `checkG5DischargeBool = true` AND `SemValidG5Discharge` across
    `Repair` (SOS), `Retreat` (`ℚ \ {0}`), Partial-Div `Retreat` (`[x ≠ 0, 1/x > 0]`), and both
    same-domain and domain-expanding `Refinement`s! -/
theorem B1_PosWitnessSuite_Proven :
    (checkG5DischargeBool 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS = true ∧
     SemValidG5Discharge posG5Repair_F05_SOS) ∧
    (checkG5DischargeBool 6 [] containerPosRetreatBaseNz posG5Retreat_BaseDomNz = true ∧
     SemValidG5Discharge posG5Retreat_BaseDomNz) ∧
    (checkG5DischargeBool 6 [] containerPosRetreatPartialDiv posG5Retreat_PartialDivSeq = true ∧
     SemValidG5Discharge posG5Retreat_PartialDivSeq) ∧
    (checkG5DischargeBool 6 [] containerPosRefineStrengthen posG5Refinement_SameDomStrengthen = true ∧
     SemValidG5Discharge posG5Refinement_SameDomStrengthen) ∧
    (checkG5DischargeBool 6 [] containerPosRefineExpand posG5Refinement_DomExpand = true ∧
     SemValidG5Discharge posG5Refinement_DomExpand) := by
  have h1Acc : checkG5DischargeBool 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS = true :=
    by decide
  have h2Acc : checkG5DischargeBool 6 [] containerPosRetreatBaseNz posG5Retreat_BaseDomNz = true :=
    by decide
  have h3Acc : checkG5DischargeBool 6 [] containerPosRetreatPartialDiv
      posG5Retreat_PartialDivSeq = true := by decide
  have h4Acc : checkG5DischargeBool 6 [] containerPosRefineStrengthen
      posG5Refinement_SameDomStrengthen = true := by decide
  have h5Acc : checkG5DischargeBool 6 [] containerPosRefineExpand posG5Refinement_DomExpand = true :=
    by decide
  exact ⟨⟨h1Acc, T_B1_07_CheckG5Discharge_MasterSoundness (by decide) (by decide) h1Acc
                   (fun _ h => nomatch h)⟩,
         ⟨h2Acc, T_B1_07_CheckG5Discharge_MasterSoundness (by decide) (by decide) h2Acc
                   (fun _ h => nomatch h)⟩,
         ⟨h3Acc, T_B1_07_CheckG5Discharge_MasterSoundness (by decide) (by decide) h3Acc
                   (fun _ h => nomatch h)⟩,
         ⟨h4Acc, T_B1_07_CheckG5Discharge_MasterSoundness (by decide) (by decide) h4Acc
                   (fun _ h => nomatch h)⟩,
         ⟨h5Acc, T_B1_07_CheckG5Discharge_MasterSoundness (by decide) (by decide) h5Acc
                   (fun _ h => nomatch h)⟩⟩

/-! ### 2. Orthogonal & Cross-Term Adversarial Counterexample Suite (`B1-CE01` .. `B1-CE10`) -/

/-- **`B1-CE01`** — Contradictory post-reflex guards `[x - 1 > 0, -x - 1 > 0]` collapsing `D_new,eff` to `∅`. -/
def ce01_contradictoryGuards : List StrictForm :=
  [.pos (.sub .varX (.const 1)), .pos (.sub (.neg .varX) (.const 1))]

def ce01_emptyDomainCert (candWit : G5NonEmptyWitness) : G5DischargeCert :=
  { posG5Retreat_PartialDivSeq with
    rflxCid         := "ce01_vacuous_collapse"
    guardsNew       := ce01_contradictoryGuards
    nonEmptyWitness := candWit }

/-- **`B1_CE01_VacuousEmptyDomain_Rejected`**:
    (1) `InEffDom .domQ ce01_contradictoryGuards` is provably empty (`∀ ρ, ¬ InEffDom ... ρ`);
    (2) For **EVERY** possible candidate witness `wit : G5NonEmptyWitness`, container `C`, premise
        env `Γ`, and fuel `fuel`, `checkG5DischargeBool fuel Γ C (ce01_emptyDomainCert wit) = false`! -/
theorem B1_CE01_VacuousEmptyDomain_Rejected :
    (∀ ρ : Env2, ¬ InEffDom .domQ ce01_contradictoryGuards ρ) ∧
    (∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (wit : G5NonEmptyWitness),
      checkG5DischargeBool fuel Γ C (ce01_emptyDomainCert wit) = false) := by
  have hEmpty : ∀ ρ : Env2, ¬ InEffDom .domQ ce01_contradictoryGuards ρ := by
    intro ρ hIn
    have hGt1 : ModelsStrictForm (.pos (.sub .varX (.const 1))) ρ :=
      hIn.2.2 _ (List.mem_cons_self ..)
    have hLtNeg1 : ModelsStrictForm (.pos (.sub (.neg .varX) (.const 1))) ρ :=
      hIn.2.2 _ (List.mem_cons_of_mem _ (List.mem_cons_self ..))
    rcases hGt1.2 with ⟨v1, hv1, hp1⟩
    rcases hLtNeg1.2 with ⟨v2, hv2, hp2⟩
    have he1 : PartExprEvalRel (.sub .varX (.const 1)) ρ (ρ.1 - ((1 : Int) : Rat)) :=
      .sub (.varX ρ) (.const 1 ρ)
    have he2 : PartExprEvalRel (.sub (.neg .varX) (.const 1)) ρ ((-ρ.1) - ((1 : Int) : Rat)) :=
      .sub (.neg (.varX ρ)) (.const 1 ρ)
    rw [← partExprEvalRel_unique he1 hv1] at hp1
    rw [← partExprEvalRel_unique he2 hv2] at hp2
    have hSumPos : (0 : Rat) < (ρ.1 - ((1 : Int) : Rat)) + ((-ρ.1) - ((1 : Int) : Rat)) := by
      have ha : (0 : Rat) + 0 < (ρ.1 - ((1 : Int) : Rat)) + 0 := Rat.add_lt_add_right.mpr hp1
      have hb : (ρ.1 - ((1 : Int) : Rat)) + 0 <
          (ρ.1 - ((1 : Int) : Rat)) + ((-ρ.1) - ((1 : Int) : Rat)) := Rat.add_lt_add_left.mpr hp2
      rw [Rat.add_zero, Rat.add_zero] at ha
      rw [Rat.add_zero] at hb
      exact Rat.not_le.mp (fun hle => Rat.not_lt.mpr (Rat.le_trans hle (Rat.le_of_lt ha)) hb)
    have hSimp : (ρ.1 - ((1 : Int) : Rat)) + ((-ρ.1) - ((1 : Int) : Rat)) = ((-2 : Int) : Rat) := by
      have hNeg1 : -((1 : Int) : Rat) = ((-1 : Int) : Rat) := (Rat.intCast_neg 1).symm
      calc
        (ρ.1 - ((1 : Int) : Rat)) + ((-ρ.1) - ((1 : Int) : Rat))
          = (ρ.1 + -((1 : Int) : Rat)) + (-ρ.1 + -((1 : Int) : Rat)) := by
              rw [Rat.sub_eq_add_neg, Rat.sub_eq_add_neg]
        _ = (ρ.1 + ((-1 : Int) : Rat)) + (-ρ.1 + ((-1 : Int) : Rat)) := by rw [hNeg1]
        _ = ρ.1 + (((-1 : Int) : Rat) + (-ρ.1 + ((-1 : Int) : Rat))) := by rw [Rat.add_assoc]
        _ = ρ.1 + ((-ρ.1 + ((-1 : Int) : Rat)) + ((-1 : Int) : Rat)) := by
              rw [Rat.add_comm ((-1 : Int) : Rat)]
        _ = ρ.1 + (-ρ.1 + (((-1 : Int) : Rat) + ((-1 : Int) : Rat))) := by
              rw [Rat.add_assoc (-ρ.1)]
        _ = (ρ.1 + -ρ.1) + (((-1 : Int) : Rat) + ((-1 : Int) : Rat)) := by
              rw [← Rat.add_assoc ρ.1 (-ρ.1)]
        _ = 0 + (((-1 : Int) : Rat) + ((-1 : Int) : Rat)) := by rw [Rat.add_neg_cancel]
        _ = ((-1 : Int) : Rat) + ((-1 : Int) : Rat) := by rw [Rat.zero_add]
        _ = ((-2 : Int) : Rat) := (Rat.intCast_add (-1) (-1)).symm
    rw [hSimp] at hSumPos
    exact absurd (Rat.intCast_pos.mp hSumPos) (by decide)
  refine ⟨hEmpty, ?_⟩
  intro fuel Γ C wit
  cases hChk : checkG5DischargeBool fuel Γ C (ce01_emptyDomainCert wit) with
  | false => rfl
  | true  =>
      rcases (T_B1_01_G5_NonEmptiness_Sound hChk).2.2.2 with ⟨ρ, hIn⟩
      exact False.elim (hEmpty ρ hIn)

/-- **`B1-CE02`** — `Repair` silently shrinking the effective domain (`ℚ → ℚ \ {0}` or adding `[x > 0]`). -/
def ce02a_repairSilentBaseShrink : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid := "ce02a_repair_base_shrink"
    domNew  := .domQNonzero }

def ce02b_repairSilentGuardShrink : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid   := "ce02b_repair_guard_shrink"
    guardsNew := [.pos .varX] }

theorem B1_CE02_RepairSilentShrink_Rejected :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce02a_repairSilentBaseShrink = false ∧
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce02b_repairSilentGuardShrink = false ∧
    ¬ SemValidG5Discharge ce02a_repairSilentBaseShrink ∧
    ¬ SemValidG5Discharge ce02b_repairSilentGuardShrink := by
  refine ⟨by decide, by decide, ?_, ?_⟩
  · intro hSem
    have hOld0 : InEffDom .domQ [] (0, 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
    have hNew0 : InEffDom .domQNonzero [] (0, 0) :=
      (hSem.branchExactDischarge.2.2.2.2.1 (0, 0)).mp hOld0
    exact hNew0.1.1 rfl
  · intro hSem
    have hOld0 : InEffDom .domQ [] (0, 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
    have hNew0 : InEffDom .domQ [.pos .varX] (0, 0) :=
      (hSem.branchExactDischarge.2.2.2.2.1 (0, 0)).mp hOld0
    have hPos0 : ModelsStrictForm (.pos .varX) (0, 0) := hNew0.2.2 _ (List.mem_cons_self ..)
    rcases hPos0.2 with ⟨v, hv, hp⟩
    cases hv
    exact Rat.lt_irrefl hp

/-- **`B1-CE03`** — `Repair` silently expanding the effective domain (`{x > 0} → ℚ`). -/
def ce03_repairSilentExpand : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid   := "ce03_repair_silent_expand"
    guardsOld := [.pos .varX] }

theorem B1_CE03_RepairSilentExpand_Rejected :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce03_repairSilentExpand = false ∧
    ¬ SemValidG5Discharge ce03_repairSilentExpand := by
  refine ⟨by decide, ?_⟩
  intro hSem
  have hNew0 : InEffDom .domQ [] (0, 0) := ⟨rfl, trivial, fun _ h => nomatch h⟩
  have hOld0 : InEffDom .domQ [.pos .varX] (0, 0) :=
    (hSem.branchExactDischarge.2.2.2.2.1 (0, 0)).mpr hNew0
  have hPos0 : ModelsStrictForm (.pos .varX) (0, 0) := hOld0.2.2 _ (List.mem_cons_self ..)
  rcases hPos0.2 with ⟨v, hv, hp⟩
  cases hv
  exact Rat.lt_irrefl hp

/-- **`B1-CE04`** — `Retreat` omitting part of the lost region (`ℚ → {x > 10}` reporting only `[[-x > 0]]`). -/
def containerCE04HideLoss : G7DagContainer where
  nodes := [
    { nodeId     := "n_ce04_prefix"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_ce04"
      guards     := [.pos (.sub .varX (.const 10))]
      conclusion := .eqZero (.const 0)
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.pos (.sub .varX (.const 10))]
        goalForm             := .eqZero (.const 0)
        guardWfCerts         := [.totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.eqZero (.const 0))
                                  (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)
      } },
    { nodeId     := "n_ce04_goal"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_ce04"
      guards     := [.pos (.sub .varX (.const 10))]
      conclusion := .pos (.sub .varX (.const 10))
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.pos (.sub .varX (.const 10))]
        goalForm             := .pos (.sub .varX (.const 10))
        guardWfCerts         := [.totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .hypGuard 0 (.pos (.sub .varX (.const 10)))
      } }
  ]

def ce04_retreatPartialLossOmission : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "ce04_hide_0_to_10"
  cellOldCid             := "cell_ce04_old"
  obstCid                := "obst_ce04_neg2"
  cellNewCid             := "cell_ce04_new"
  baseId                 := "base_Q"
  specOldId              := "spec_ce04_old"
  specNewId              := "spec_ce04"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := .pos (.sub .varX (.const 10))
  domNew                 := .domQ
  guardsNew              := [.pos (.sub .varX (.const 10))]
  goalNew                := .pos (.sub .varX (.const 10))
  reflexKind             := .retreat
  obstructionSpec        := {
    obstCid          := "obst_ce04_neg2"
    targetCellOldCid := "cell_ce04_old"
    targetSpecOldId  := "spec_ce04_old"
    obstKind         := .counterexamplePoint
    evidence         := .counterexamplePt ⟨-2, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨12, 1, 0, 1⟩⟩
  goalNewNodeId          := "n_ce04_goal"
  repairCert?            := none
  retreatCert?           := some {
    baseStep                := .sameBaseDom .domQ
    deltaGuards             := [.pos (.sub .varX (.const 10))]
    prefixDefNodeId         := "n_ce04_prefix"
    guardConn               := .syntacticConcat
    excisedBranches         := [[.pos (.neg .varX)]]
    reexprCert?             := none
    strictLossWitness       := ⟨-2, 1, 0, 1⟩
    claimedRetentionAnchors := []
    adoptedGuardNodeId?     := none
  }
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := true

theorem B1_CE04_RetreatPartialLossOmission_Rejected :
    checkG5DischargeBool 6 [] containerCE04HideLoss ce04_retreatPartialLossOmission = false ∧
    ¬ SemValidG5Discharge ce04_retreatPartialLossOmission := by
  refine ⟨by decide, ?_⟩
  intro hSem
  have hPart : SemExactScopeLossPartition .domQ [] .domQ [.pos (.sub .varX (.const 10))]
      [[.pos (.neg .varX)]] := hSem.branchExactDischarge.2.2.2.2.2.1
  exact A0_03b_partition_counterexamples_rejected.2 hPart

/-- **`B1-CE05`** — Hiding undefined point `x = 0` of `1/x` via unguarded `ΔΓ = [1/x > 0]`. -/
def ce05_unguardedRecipRetreat : G5DischargeCert :=
  { posG5Retreat_PartialDivSeq with
    rflxCid       := "ce05_hide_div_zero"
    guardsNew     := [.pos (.div (.const 1) .varX)]
    goalNewNodeId := "n_bad_raw_recip"
    retreatCert?  := some {
      baseStep                := .sameBaseDom .domQ
      deltaGuards             := [.pos (.div (.const 1) .varX)]
      prefixDefNodeId         := "n_bad_raw_recip"
      guardConn               := .syntacticConcat
      excisedBranches         := [[.nonneg (.neg (.div (.const 1) .varX))]]
      reexprCert?             := none
      strictLossWitness       := ⟨-2, 1, 0, 1⟩
      claimedRetentionAnchors := []
      adoptedGuardNodeId?     := none
    } }

theorem B1_CE05_UndefinedZeroPointHidden_Rejected :
    verifyReachableDerivation 4 [] containerInvalidRawRecip "n_bad_raw_recip" =
      .rejectInvalid .guardWfFailed ∧
    checkG5DischargeBool 6 [] containerInvalidRawRecip ce05_unguardedRecipRetreat = false ∧
    ¬ SemValidG5Discharge ce05_unguardedRecipRetreat := by
  refine ⟨by decide, by decide, ?_⟩
  intro hSem
  have hPart : SemExactScopeLossPartition .domQ [] .domQ [.pos (.div (.const 1) .varX)]
      [[atomicComplement (.pos (.div (.const 1) .varX))]] :=
    hSem.branchExactDischarge.2.2.2.2.2.1
  exact A0_03b_partition_counterexamples_rejected.1.2.2.1 hPart

/-- **`B1-CE06`** — Splicing a proof node from a foreign `specId`, wrong `goalNew`, or wrong `domNew`. -/
def ce06a_foreignSpecCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid   := "ce06a_foreign_spec"
    specNewId := "spec_FOREIGN_OTHER_TARGET" }

def ce06b_wrongGoalCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid := "ce06b_wrong_goal"
    goalNew := .pos (.add (.mul .varX .varX) (.const 99)) }

def ce06c_wrongDomainNodeCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid       := "ce06c_wrong_dom_node"
    goalNew       := .eqZero exprDivSelfMinusOne
    goalNewNodeId := "n_nz_goal_divself" }

theorem B1_CE06_ForeignOrMismatchedNode_Rejected :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce06a_foreignSpecCert = false ∧
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce06b_wrongGoalCert = false ∧
    checkG5DischargeBool 6 [] containerPosRetreatBaseNz ce06c_wrongDomainNodeCert = false := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`B1-CE07`** — Invalid obstruction point (`(2, 0)` where `(x-1)^2 > 0` holds!) OR forged SOS (`constTerm = -2`). -/
def ce07a_fakeObstructionPtCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid         := "ce07a_fake_obst_pt"
    obstructionSpec := {
      posG5Repair_F05_SOS.obstructionSpec with
      evidence := .counterexamplePt ⟨2, 1, 0, 1⟩
    } }

def containerCE07ForgedSos : G7DagContainer where
  nodes := [
    { nodeId     := "n_ce07_forged_sos"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_f05_new"
      guards     := []
      conclusion := .nonneg (.add (.mul .varX .varX) (.const (-2)))
      step       := .directDerivStep
                      (.certStep (.nonneg (.add (.mul .varX .varX) (.const (-2))))
                        (.polyPositivstellensatz ⟨1, -2, [(1, .pVarX)], [], [], []⟩)) }
  ]

def ce07b_forgedSosGoalCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid       := "ce07b_forged_sos"
    goalNew       := .nonneg (.add (.mul .varX .varX) (.const (-2)))
    goalNewNodeId := "n_ce07_forged_sos" }

theorem B1_CE07_FakeObstructionOrForgedProof_Rejected :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce07a_fakeObstructionPtCert = false ∧
    checkG5DischargeBool 6 [] containerCE07ForgedSos ce07b_forgedSosGoalCert = false ∧
    ¬ SemValidObstructionOnOld .domQ [] f05_goalOld ce07a_fakeObstructionPtCert.obstructionSpec := by
  refine ⟨by decide, by decide, ?_⟩
  intro hBadObst
  have hWf2 : checkRatCoordWfBool ⟨2, 1, 0, 1⟩ = true := by decide
  have hSat2 : evalStrictFormRatCoord 5 f05_goalOld ⟨2, 1, 0, 1⟩ = .satTrue := by decide
  have hTrueAt2 : ModelsStrictForm f05_goalOld (ratCoordToEnv2 ⟨2, 1, 0, 1⟩) :=
    (evalStrictFormRatCoord_sound ⟨2, 1, 0, 1⟩ hWf2 5 f05_goalOld).1 hSat2
  exact hBadObst.2.2.2 hTrueAt2

/-- **`B1-CE08`** — Omitting a transitive primitive premise ancestor (`"p_root_ax"`) from `claimedPrimDeps`. -/
def ce08_primEnv : PrimPremiseEnv :=
  [ ⟨"p_root_ax", .domQ, "spec_ce08", .pos (.add (.mul .varX .varX) (.const 1)), []⟩
  , ⟨"p_mid",     .domQ, "spec_ce08", f05_goalNew, ["p_root_ax"]⟩ ]

def containerCE08TransPrem : G7DagContainer where
  nodes := [
    { nodeId     := "n_ce08_goal"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_ce08"
      guards     := []
      conclusion := f05_goalNew
      step       := .directDerivStep (.primPrem "p_mid" f05_goalNew) }
  ]

def ce08_omittedAncestorCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid         := "ce08_omit_ancestor"
    specNewId       := "spec_ce08"
    goalNewNodeId   := "n_ce08_goal"
    claimedPrimDeps := ⟨["p_mid"]⟩ }

def ce08_completeDepsCert : G5DischargeCert :=
  { ce08_omittedAncestorCert with
    rflxCid         := "ce08_complete_deps"
    claimedPrimDeps := ⟨["p_mid", "p_root_ax"]⟩ }

theorem B1_CE08_OmittedTransitivePrimDep_Rejected :
    deriveG5PrimDeps ce08_primEnv containerCE08TransPrem ce08_omittedAncestorCert =
      ["p_mid", "p_root_ax"] ∧
    checkG5DischargeBool 6 ce08_primEnv containerCE08TransPrem ce08_omittedAncestorCert = false ∧
    checkG5DischargeBool 6 ce08_primEnv containerCE08TransPrem ce08_completeDepsCert = true := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`B1-CE09`** — Unauthorized `(ObstKind × ReflexKind)` combinations and mixed branch certificates. -/
def ce09a_nonRedundantMissingGuardRepair : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid         := "ce09a_missing_false_repair"
    obstructionSpec := {
      obstCid          := "obst_f05_x1"
      targetCellOldCid := "cell_f05_old"
      targetSpecOldId  := "spec_f05_old"
      obstKind         := .missingAssumption false
      evidence         := .missingGuard (.pos .varX) (some ⟨0, 1, 0, 1⟩) none
    } }

def ce09b_scopedNoGoRepair : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid         := "ce09b_scoped_nogo_repair"
    obstructionSpec := {
      obstCid          := "obst_f05_x1"
      targetCellOldCid := "cell_f05_old"
      targetSpecOldId  := "spec_f05_old"
      obstKind         := .scopedNoGo
      evidence         := .scopedNoGoLocus [.eqZero (.sub .varX (.const 1))] ⟨1, 1, 0, 1⟩ "n_f05_goal_new"
    } }

def ce09c_invalidCertRetreat : G5DischargeCert :=
  { posG5Retreat_BaseDomNz with
    rflxCid         := "ce09c_invalid_cert_retreat"
    obstructionSpec := {
      obstCid          := "obst_divself_zero"
      targetCellOldCid := "cell_divself_old"
      targetSpecOldId  := "spec_ret_nz_old"
      obstKind         := .invalidCertificate
      evidence         := .invalidSosCert ⟨0, 0, [], [], [], []⟩ ⟨1, 1, 0, 1⟩
    } }

def ce09d_envFailureRetreat : G5DischargeCert :=
  { posG5Retreat_BaseDomNz with
    rflxCid         := "ce09d_env_failure"
    obstructionSpec := {
      posG5Retreat_BaseDomNz.obstructionSpec with
      obstKind := .environmentalFailure
    } }

def ce09e_counterexampleRefinement : G5DischargeCert :=
  { posG5Refinement_SameDomStrengthen with
    rflxCid         := "ce09e_counterexample_refinement"
    obstructionSpec := {
      obstCid          := "obst_ref_bad_cert"
      targetCellOldCid := "cell_ref_str_old"
      targetSpecOldId  := "spec_ref_str_old"
      obstKind         := .counterexamplePoint
      evidence         := .counterexamplePt ⟨4, 1, 0, 1⟩
    } }

def ce09f_mixedRepairWithRetreatPayload : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid      := "ce09f_mixed_branch_payload"
    retreatCert? := posG5Retreat_BaseDomNz.retreatCert? }

theorem B1_CE09_ForbiddenPairsAndMixedBranches_Rejected :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce09a_nonRedundantMissingGuardRepair = false ∧
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce09b_scopedNoGoRepair = false ∧
    checkG5DischargeBool 6 [] containerPosRetreatBaseNz ce09c_invalidCertRetreat = false ∧
    checkG5DischargeBool 6 [] containerPosRetreatBaseNz ce09d_envFailureRetreat = false ∧
    checkG5DischargeBool 6 [] containerPosRefineStrengthen ce09e_counterexampleRefinement = false ∧
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce09f_mixedRepairWithRetreatPayload = false := by
  exact ⟨by decide, by decide, by decide, by decide, by decide, by decide⟩

/-- **`B1-CE10`** — Cross-Term Proof (`G5Pass ⇏ G6Pass` & `G5Pass ⇏ FullReflexAdmitted`):
    Using `posG5Repair_F05_SOS` (`θ_old = 2 → θ_new = -2` on `I(x; θ) : x^2 + θ ≥ 0`), proves:
    (1) `posG5Repair_F05_SOS` genuinely passes BOTH `checkG5DischargeBool = true` AND
        `SemValidG5Discharge` (`G5` `Repair` PASS!);
    (2) Old `G6` protected invariant `I(x; 2) : x^2 + 2 ≥ 0` holds across ALL `ρ ∈ InEffDom .domQ []`;
    (3) Post-repair `G6` protected invariant `I(x; -2) : x^2 - 2 ≥ 0` is **STRICTLY VIOLATED** at
        `(0, 0) ∈ InEffDom .domQ []` (`G5Pass ⇏ G6Pass`!);
    (4) `qualifyG5Isolated?` produces a `G5QualifiedRecord` whose `g6ProtectedSlot = .mkUnchecked`,
        `g1IntegritySlot = .mkUnchecked`, and `grantFlag = .noGrantFromMathCheck`, while
        `FullReflexAdmitted checkUnauthStageCertBool _ _` remains provably uninhabited! -/
theorem B1_CE10_G5Pass_DoesNotImply_G6Pass_Or_FullReflex :
    let invOld := instantiateInvariantAtParam 2 1 f05_invTemplate
    let invNew := instantiateInvariantAtParam (-2) 1 f05_invTemplate
    -- (1) Genuine G5 Repair PASS:
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS = true ∧
    SemValidG5Discharge posG5Repair_F05_SOS ∧
    -- (2) Old G6 invariant preserved on old effective domain:
    (∀ ρ : Env2, InEffDom .domQ [] ρ → ModelsStrictForm invOld ρ) ∧
    -- (3) Post-repair G6 invariant violated on post-repair effective domain:
    InEffDom .domQ [] (0, 0) ∧
    FormDefined invNew (0, 0) ∧
    ¬ ModelsStrictForm invNew (0, 0) ∧
    -- (4) Scoped output seals G6 = .unchecked, G1 = .unchecked, noGrantFromMathCheck, and blocks FullReflexAdmitted:
    (∃ rec : G5QualifiedRecord 6 [] f05_dagContainerGoalNew,
      qualifyG5Isolated? 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS = some rec ∧
      rec.g6ProtectedSlot = .mkUnchecked ∧
      rec.g1IntegritySlot = .mkUnchecked ∧
      rec.grantFlag = .noGrantFromMathCheck) ∧
    ¬ Nonempty (FullReflexAdmitted checkUnauthStageCertBool
        checkUnauthStageCertBool checkCertifiedG7BundleBool) := by
  have hF05 := A0_06_F_B2B_05_SOS_Witness_Proven
  have hG5Acc : checkG5DischargeBool 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS = true :=
    by decide
  have hG5Sem : SemValidG5Discharge posG5Repair_F05_SOS :=
    B1_PosWitnessSuite_Proven.1.2
  refine ⟨hG5Acc, hG5Sem,
          fun ρ hIn => hF05.2.2.2.2.1 ρ hIn.1,
          ⟨rfl, trivial, fun _ h => nomatch h⟩,
          hF05.2.2.2.2.2.2.2.2.2.2.1.1,
          hF05.2.2.2.2.2.2.2.2.2.2.1.2,
          ?_,
          T_B1_08_Zero_G6_G1_Authority_Escalation.2.2 _ _⟩
  unfold qualifyG5Isolated?
  rw [dif_pos hG5Acc]
  exact ⟨_, rfl, rfl, rfl, rfl⟩

/-! ### 3. Exhaustive Non-Vacuity Across All Admissible `(ObstKind × ReflexKind)` Matrix Cells -/

/-- `Repair` resolving `.invalidCertificate` on `.domQ`. -/
def posG5Repair_InvalidCert : G5DischargeCert :=
  { posG5Repair_F05_SOS with
    rflxCid         := "rflx_b1_pos_repair_invcert"
    obstructionSpec := {
      obstCid          := "obst_f05_x1"
      targetCellOldCid := "cell_f05_old"
      targetSpecOldId  := "spec_f05_old"
      obstKind         := .invalidCertificate
      evidence         := .invalidSosCert ⟨0, 0, [], [], [], []⟩ ⟨1, 1, 0, 1⟩
    } }

/-- Container proving redundant guard `x^2 > 0` on `.domQNonzero`. -/
def containerRedundantSqPos : G7DagContainer where
  nodes := [
    { nodeId     := "n_nz_sq_pos"
      topoRank   := 0
      domTag     := .domQNonzero
      specId     := "spec_red_nz"
      guards     := []
      conclusion := .pos (.mul .varX .varX)
      step       := .directDerivStep
                      (.certStep (.pos (.mul .varX .varX))
                        (.guardedReciprocal (.nonzeroSqStrictPos .varX))) }
  ]

/-- `Repair` resolving `.missingAssumption true` on `.domQNonzero`. -/
def posG5Repair_MissingTrue : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_repair_missing_true"
  cellOldCid             := "cell_red_old"
  obstCid                := "obst_red_sqpos"
  cellNewCid             := "cell_red_new"
  baseId                 := "base_Q"
  specOldId              := "spec_red_old"
  specNewId              := "spec_red_nz"
  domOld                 := .domQNonzero
  guardsOld              := []
  goalOld                := .pos (.mul .varX .varX)
  domNew                 := .domQNonzero
  guardsNew              := []
  goalNew                := .pos (.mul .varX .varX)
  reflexKind             := .repair
  obstructionSpec        := {
    obstCid          := "obst_red_sqpos"
    targetCellOldCid := "cell_red_old"
    targetSpecOldId  := "spec_red_old"
    obstKind         := .missingAssumption true
    evidence         := .missingGuard (.pos (.mul .varX .varX)) none (some "n_nz_sq_pos")
  }
  nonEmptyWitness        := ⟨⟨1, 1, 0, 1⟩⟩
  goalNewNodeId          := "n_nz_sq_pos"
  repairCert?            := some {
    baseEquivStep           := .sameBaseDom .domQNonzero
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    redundantGuardNodeId?   := some "n_nz_sq_pos"
  }
  retreatCert?           := none
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := false

/-- `Refinement` resolving `.missingAssumption true` on `.domQNonzero`. -/
def posG5Refine_MissingTrue : G5DischargeCert :=
  { posG5Repair_MissingTrue with
    rflxCid         := "rflx_b1_pos_refine_missing_true"
    reflexKind      := .refinement
    repairCert?     := none
    refinementCert? := some {
      baseExpandStep          := .sameBaseDom .domQNonzero
      oldGuardsDefNodeId?     := none
      oldEntailsNewGuardNodes := []
      newEntailsOldGuardNodes := []
      goalImpNodeId?          := none
      adoptedGuardNodeId?     := some "n_nz_sq_pos"
      scopeExpanded           := false
      expansionWitness?       := none
    } }

/-- `Retreat` resolving `.missingAssumption false` (`x - 10 > 0` adopted on `.domQ`). -/
def posG5Retreat_MissingFalse : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_retreat_missing_false"
  cellOldCid             := "cell_mf_old"
  obstCid                := "obst_mf_x10"
  cellNewCid             := "cell_mf_new"
  baseId                 := "base_Q"
  specOldId              := "spec_mf_old"
  specNewId              := "spec_ce04"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := .pos (.sub .varX (.const 10))
  domNew                 := .domQ
  guardsNew              := [.pos (.sub .varX (.const 10))]
  goalNew                := .pos (.sub .varX (.const 10))
  reflexKind             := .retreat
  obstructionSpec        := {
    obstCid          := "obst_mf_x10"
    targetCellOldCid := "cell_mf_old"
    targetSpecOldId  := "spec_mf_old"
    obstKind         := .missingAssumption false
    evidence         := .missingGuard (.pos (.sub .varX (.const 10))) (some ⟨0, 1, 0, 1⟩) none
  }
  nonEmptyWitness        := ⟨⟨12, 1, 0, 1⟩⟩
  goalNewNodeId          := "n_ce04_goal"
  repairCert?            := none
  retreatCert?           := some {
    baseStep                := .sameBaseDom .domQ
    deltaGuards             := [.pos (.sub .varX (.const 10))]
    prefixDefNodeId         := "n_ce04_prefix"
    guardConn               := .syntacticConcat
    excisedBranches         := [[.nonneg (.neg (.sub .varX (.const 10)))]]
    reexprCert?             := none
    strictLossWitness       := ⟨0, 1, 0, 1⟩
    claimedRetentionAnchors := [⟨15, 1, 0, 1⟩]
    adoptedGuardNodeId?     := some "n_ce04_goal"
  }
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := true

/-- Container for `.scopedNoGo` `Retreat` (`x = 0 ⊢ -x^2 ≥ 0` on `.domQ`, retreated to `.domQNonzero`). -/
def containerScopedNoGoSqPos : G7DagContainer where
  nodes := [
    { nodeId     := "n_nogo_zero_locus"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_nogo_new"
      guards     := [.eqZero .varX]
      conclusion := .nonneg (.neg (.mul .varX .varX))
      step       := .guardedDomStep {
        domTag               := .domQ
        guards               := [.eqZero .varX]
        goalForm             := .nonneg (.neg (.mul .varX .varX))
        guardWfCerts         := [.totalPolyWf]
        guardContextEvidence := .selfContainedCtx
        goalDeriv            := .certStep (.nonneg (.neg (.mul .varX .varX)))
                                  (.polyPositivstellensatz ⟨1, 0, [], [], [], [(0, .pNeg .pVarX)]⟩)
      } },
    { nodeId     := "n_nogo_prefix_def"
      topoRank   := 1
      domTag     := .domQNonzero
      specId     := "spec_nogo_new"
      guards     := []
      conclusion := .eqZero (.const 0)
      step       := .directDerivStep
                      (.certStep (.eqZero (.const 0))
                        (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)) },
    { nodeId     := "n_nogo_nz_sq_pos"
      topoRank   := 2
      domTag     := .domQNonzero
      specId     := "spec_nogo_new"
      guards     := []
      conclusion := .pos (.mul .varX .varX)
      step       := .directDerivStep
                      (.certStep (.pos (.mul .varX .varX))
                        (.guardedReciprocal (.nonzeroSqStrictPos .varX))) }
  ]

/-- `Retreat` resolving `.scopedNoGo` (`x = 0` no-go locus for `x^2 > 0`, retreated to `.domQNonzero`). -/
def posG5Retreat_ScopedNoGo : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_b1_pos_retreat_scoped_nogo"
  cellOldCid             := "cell_nogo_old"
  obstCid                := "obst_nogo_x0"
  cellNewCid             := "cell_nogo_new"
  baseId                 := "base_Q"
  specOldId              := "spec_nogo_old"
  specNewId              := "spec_nogo_new"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := .pos (.mul .varX .varX)
  domNew                 := .domQNonzero
  guardsNew              := []
  goalNew                := .pos (.mul .varX .varX)
  reflexKind             := .retreat
  obstructionSpec        := {
    obstCid          := "obst_nogo_x0"
    targetCellOldCid := "cell_nogo_old"
    targetSpecOldId  := "spec_nogo_old"
    obstKind         := .scopedNoGo
    evidence         := .scopedNoGoLocus [.eqZero .varX] ⟨0, 1, 0, 1⟩ "n_nogo_zero_locus"
  }
  nonEmptyWitness        := ⟨⟨2, 3, 0, 1⟩⟩
  goalNewNodeId          := "n_nogo_nz_sq_pos"
  repairCert?            := none
  retreatCert?           := some {
    baseStep                := .qToQNonzero
    deltaGuards             := []
    prefixDefNodeId         := "n_nogo_prefix_def"
    guardConn               := .syntacticConcat
    excisedBranches         := [[.eqZero .varX]]
    reexprCert?             := none
    strictLossWitness       := ⟨0, 1, 0, 1⟩
    claimedRetentionAnchors := [⟨1, 1, 0, 1⟩]
    adoptedGuardNodeId?     := none
  }
  refinementCert?        := none
  claimedPrimDeps        := ⟨[]⟩
  requiresRetreatHistory := true

/-- **Exhaustive Matrix Non-Vacuity Theorem (`B1_AllAdmissibleMatrixCellsInhabited_Proven`)**:
    Together with `B1_PosWitnessSuite_Proven`, constructively inhabits **100%** of admissible
    `(KernelObstKindV1 × ReflexKind)` cells in `G5ObstReflexAllowed` (`0` dead/vacuous paths!). -/
theorem B1_AllAdmissibleMatrixCellsInhabited_Proven :
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew posG5Repair_InvalidCert = true ∧
    checkG5DischargeBool 6 [] containerRedundantSqPos posG5Repair_MissingTrue = true ∧
    checkG5DischargeBool 6 [] containerRedundantSqPos posG5Refine_MissingTrue = true ∧
    checkG5DischargeBool 6 [] containerCE04HideLoss posG5Retreat_MissingFalse = true ∧
    checkG5DischargeBool 6 [] containerScopedNoGoSqPos posG5Retreat_ScopedNoGo = true := by
  exact ⟨by decide, by decide, by decide, by decide, by decide⟩

end OmegaCellC1P1B2BB1
