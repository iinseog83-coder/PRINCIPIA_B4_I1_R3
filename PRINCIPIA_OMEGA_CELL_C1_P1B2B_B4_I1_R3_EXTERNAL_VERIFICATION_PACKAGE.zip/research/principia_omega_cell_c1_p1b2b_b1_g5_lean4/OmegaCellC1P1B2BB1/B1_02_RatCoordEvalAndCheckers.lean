/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B1 — Isolated G5 Certified Obstruction Discharge Kernel
  Module: OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers

  Authorization: `PRINCIPIA_P1B2B_B1_ISOLATED_G5_IMPLEMENTATION_AUTHORIZED`
  Scope (`B1-A3`):
    1. Pure-`Int` exact rational coordinate evaluator (`evalPartExprRatCoord`, `evalStrictFormRatCoord`)
       over `RatCoord2` (`0` `Nat.gcd` calls — kernel `decide` friendly!) with full 3-branch soundness
       (`.satTrue`, `.satDefinedFalse`, `.undefinedTerm`) and exact `G7DomTag` membership biconditional.
    2. Complete proof-root collector `collectG5ProofRootIds` and transitive primitive dependency
       closure `deriveG5PrimDeps` (`B1-A3`).
    3. Deterministic checkers (`B1-A3`):
       - `checkVerifiedObstructionBool`
       - `checkRepairDomEqBool`
       - `checkRetreatExactPartitionBool`
       - `checkRefinementBool`
       - `checkG5CoreProofsBool` & `checkG5DischargeBool`
    4. Proof-bearing scoped qualification record `G5QualifiedRecord` keeping `G6 = .unchecked`,
       `G1 = .unchecked`, and `grantFlag = .noGrantFromMathCheck` (`B1-02`, `B1-04`, `B1-A4.8`).
-/
import OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics

namespace OmegaCellC1P1B2BB1

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0

/-! ### 1. Pure-`Int` Exact Rational Coordinate Evaluator (`0` `Nat.gcd`) & Soundness -/

/-- Computable positive-denominator check for `RatCoord2`. -/
def checkRatCoordWfBool (pt : RatCoord2) : Bool :=
  decide (0 < pt.xDenPos) && decide (0 < pt.yDenPos)

theorem checkRatCoordWfBool_iff (pt : RatCoord2) :
    checkRatCoordWfBool pt = true ↔ (0 < pt.xDenPos ∧ 0 < pt.yDenPos) := by
  unfold checkRatCoordWfBool
  simp only [Bool.and_eq_true, decide_eq_true_eq]

private theorem rat_add_pos_of_nonneg_pos_b1 {a b : Rat} (ha : 0 ≤ a) (hb : 0 < b) :
    0 < a + b := by
  have h1 : (0 : Rat) + 0 ≤ a + 0 := Rat.add_le_add_right.mpr ha
  have h2 : a + 0 < a + b := Rat.add_lt_add_left.mpr hb
  rw [Rat.add_zero, Rat.add_zero] at h1
  rw [Rat.add_zero] at h2
  exact Rat.not_le.mp (fun hba => Rat.not_lt.mpr (Rat.le_trans hba h1) h2)

private theorem rat_scale_eq_zero_iff_b1 {k : Int} (hk : 0 < k) {v : Rat} :
    (k : Rat) * v = 0 ↔ v = 0 := by
  have hk_ne : (k : Rat) ≠ 0 := Rat.ne_of_gt (Rat.intCast_pos.mpr hk)
  constructor
  · intro hz
    rcases Rat.mul_eq_zero.mp hz with hbad | hv
    · exact False.elim (hk_ne hbad)
    · exact hv
  · intro hv
    rw [hv, Rat.mul_zero]

private theorem rat_nonneg_of_pos_mul_nonneg_b1 {k : Int} (hk : 0 < k) {v : Rat}
    (hmul : 0 ≤ (k : Rat) * v) : 0 ≤ v := by
  have hk_pos : (0 : Rat) < (k : Rat) := Rat.intCast_pos.mpr hk
  if hv : 0 ≤ v then
    exact hv
  else
    have hv_lt : v < 0 := Rat.not_le.mp hv
    have hneg_pos : 0 < -v := by
      have h1 : v + (-v) < 0 + (-v) := Rat.add_lt_add_right.mpr hv_lt
      rwa [Rat.add_neg_cancel, Rat.zero_add] at h1
    have hprod_pos : 0 < (k : Rat) * (-v) := Rat.mul_pos hk_pos hneg_pos
    rw [Rat.mul_neg] at hprod_pos
    have hsum : 0 < (k : Rat) * v + -((k : Rat) * v) :=
      rat_add_pos_of_nonneg_pos_b1 hmul hprod_pos
    rw [Rat.add_neg_cancel] at hsum
    exact False.elim (Rat.lt_irrefl hsum)

private theorem rat_pos_of_pos_mul_pos_b1 {k : Int} (hk : 0 < k) {v : Rat}
    (hmul : 0 < (k : Rat) * v) : 0 < v := by
  have hle : 0 ≤ v := rat_nonneg_of_pos_mul_nonneg_b1 hk (Rat.le_of_lt hmul)
  have hne : v ≠ 0 := by
    intro hz
    rw [hz, Rat.mul_zero] at hmul
    exact Rat.lt_irrefl hmul
  exact Rat.lt_of_le_of_ne hle (Ne.symm hne)

private theorem synFracRep_rat_div {num : Int} {denPos : Nat} (hd : 0 < denPos) :
    SynFracRep ⟨num, (denPos : Int)⟩ ((num : Rat) / ((denPos : Int) : Rat)) := by
  have hdInt : (0 : Int) < (denPos : Int) := by omega
  refine ⟨hdInt, ?_⟩
  have hdNe : ((denPos : Int) : Rat) ≠ 0 := Rat.ne_of_gt (Rat.intCast_pos.mpr hdInt)
  dsimp only
  rw [Rat.div_def, ← Rat.mul_assoc, Rat.mul_comm ((denPos : Int) : Rat) (num : Rat),
      Rat.mul_assoc, Rat.mul_inv_cancel ((denPos : Int) : Rat) hdNe, Rat.mul_one]

/-- Pure-`Int` 3-state evaluator for `PartExpr` at `pt : RatCoord2` (`0` `Nat.gcd` calls). -/
def evalPartExprRatCoord : Nat → PartExpr → RatCoord2 → SynEvalRes
  | 0,     _,          _  => .resourceHeld 0
  | _ + 1, .const c,   _  => .val ⟨c, 1⟩
  | _ + 1, .varX,      pt => .val ⟨pt.xNum, (pt.xDenPos : Int)⟩
  | _ + 1, .varY,      pt => .val ⟨pt.yNum, (pt.yDenPos : Int)⟩
  | f + 1, .neg e,     pt =>
      match evalPartExprRatCoord f e pt with
      | .val r            => .val ⟨-r.num, r.den⟩
      | .undefinedDivZero => .undefinedDivZero
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .add e1 e2, pt =>
      match evalPartExprRatCoord f e1 pt, evalPartExprRatCoord f e2 pt with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.den + b.num * a.den, a.den * b.den⟩
  | f + 1, .sub e1 e2, pt =>
      match evalPartExprRatCoord f e1 pt, evalPartExprRatCoord f e2 pt with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.den - b.num * a.den, a.den * b.den⟩
  | f + 1, .mul e1 e2, pt =>
      match evalPartExprRatCoord f e1 pt, evalPartExprRatCoord f e2 pt with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b => .val ⟨a.num * b.num, a.den * b.den⟩
  | f + 1, .div e1 e2, pt =>
      match evalPartExprRatCoord f e1 pt, evalPartExprRatCoord f e2 pt with
      | .undefinedDivZero, _ => .undefinedDivZero
      | .resourceHeld k,   _ => .resourceHeld k
      | .val _, .undefinedDivZero => .undefinedDivZero
      | .val _, .resourceHeld k   => .resourceHeld k
      | .val a, .val b =>
          if b.num == 0 then .undefinedDivZero
          else if decide (0 < b.num) then .val ⟨a.num * b.den, a.den * b.num⟩
          else .val ⟨-(a.num * b.den), a.den * (-b.num)⟩

/-- Pure-`Int` 4-state evaluator for `StrictForm` at `pt : RatCoord2` (`0` `Nat.gcd` calls). -/
def evalStrictFormRatCoord : Nat → StrictForm → RatCoord2 → FormEvalRes
  | 0,     _,              _  => .resourceHeld 0
  | f + 1, .eqZero e,      pt =>
      match evalPartExprRatCoord f e pt with
      | .val r            => if r.num == 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .nonneg e,      pt =>
      match evalPartExprRatCoord f e pt with
      | .val r            => if decide (0 ≤ r.num) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .pos e,         pt =>
      match evalPartExprRatCoord f e pt with
      | .val r            => if decide (0 < r.num) then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .neqZero e,     pt =>
      match evalPartExprRatCoord f e pt with
      | .val r            => if r.num != 0 then .satTrue else .satDefinedFalse
      | .undefinedDivZero => .undefinedTerm
      | .resourceHeld k   => .resourceHeld k
  | f + 1, .conj φ ψ,      pt =>
      match evalStrictFormRatCoord f φ pt, evalStrictFormRatCoord f ψ pt with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satTrue         => .satTrue
      | _,                _                => .satDefinedFalse
  | f + 1, .impStrict φ ψ, pt =>
      match evalStrictFormRatCoord f φ pt, evalStrictFormRatCoord f ψ pt with
      | .resourceHeld k,  _                => .resourceHeld k
      | _,                .resourceHeld k  => .resourceHeld k
      | .undefinedTerm,   _                => .undefinedTerm
      | _,                .undefinedTerm   => .undefinedTerm
      | .satTrue,         .satDefinedFalse => .satDefinedFalse
      | _,                _                => .satTrue

/-- Value and undefinedness soundness of `evalPartExprRatCoord` over `ratCoordToEnv2 pt`. -/
theorem evalPartExprRatCoord_sound (pt : RatCoord2) (hWf : checkRatCoordWfBool pt = true) :
    ∀ (fuel : Nat) (e : PartExpr),
      (∀ r : SynFrac, evalPartExprRatCoord fuel e pt = .val r →
        ∃ v : Rat, PartExprEvalRel e (ratCoordToEnv2 pt) v ∧ SynFracRep r v) ∧
      (evalPartExprRatCoord fuel e pt = .undefinedDivZero →
        ¬ PartExprDefined e (ratCoordToEnv2 pt))
  | 0, _ => And.intro (fun _ h => nomatch h) (fun h => nomatch h)
  | _ + 1, .const c =>
      ⟨fun r h => by
        injection h with hr; subst hr
        exact ⟨(c : Rat), .const c (ratCoordToEnv2 pt),
          ⟨show (0 : Int) < 1 by decide, Rat.one_mul (c : Rat)⟩⟩,
       fun h => nomatch h⟩
  | _ + 1, .varX =>
      ⟨fun r h => by
        injection h with hr; subst hr
        have hxPos : 0 < pt.xDenPos := ((checkRatCoordWfBool_iff pt).mp hWf).1
        exact ⟨(ratCoordToEnv2 pt).1, .varX (ratCoordToEnv2 pt), synFracRep_rat_div hxPos⟩,
       fun h => nomatch h⟩
  | _ + 1, .varY =>
      ⟨fun r h => by
        injection h with hr; subst hr
        have hyPos : 0 < pt.yDenPos := ((checkRatCoordWfBool_iff pt).mp hWf).2
        exact ⟨(ratCoordToEnv2 pt).2, .varY (ratCoordToEnv2 pt), synFracRep_rat_div hyPos⟩,
       fun h => nomatch h⟩
  | f + 1, .neg e => by
      have ih := evalPartExprRatCoord_sound pt hWf f e
      refine ⟨?_, ?_⟩
      · intro r h; unfold evalPartExprRatCoord at h
        cases he : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [he] at h; nomatch h
        | resourceHeld _   => rw [he] at h; nomatch h
        | val a =>
            rw [he] at h; injection h with hr; subst hr
            rcases ih.1 a he with ⟨v, hrel, hd, heq⟩
            refine ⟨-v, .neg hrel, hd, ?_⟩
            dsimp only
            rw [Rat.mul_neg, heq, Rat.intCast_neg]
      · intro h ⟨_, hrel⟩
        cases hrel with
        | neg ha =>
            unfold evalPartExprRatCoord at h
            cases he : evalPartExprRatCoord f e pt with
            | val _            => rw [he] at h; nomatch h
            | resourceHeld _   => rw [he] at h; nomatch h
            | undefinedDivZero => exact ih.2 he ⟨_, ha⟩
  | f + 1, .add e1 e2 => by
      have ih1 := evalPartExprRatCoord_sound pt hWf f e1
      have ih2 := evalPartExprRatCoord_sound pt hWf f e2
      refine ⟨?_, ?_⟩
      · intro r h; unfold evalPartExprRatCoord at h
        cases h1 : evalPartExprRatCoord f e1 pt with
        | undefinedDivZero => rw [h1] at h; nomatch h
        | resourceHeld _   => rw [h1] at h; nomatch h
        | val a =>
            rw [h1] at h
            cases h2 : evalPartExprRatCoord f e2 pt with
            | undefinedDivZero => rw [h2] at h; nomatch h
            | resourceHeld _   => rw [h2] at h; nomatch h
            | val b =>
                rw [h2] at h; injection h with hr; subst hr
                rcases ih1.1 a h1 with ⟨v1, hr1, hda, hea⟩
                rcases ih2.1 b h2 with ⟨v2, hr2, hdb, heb⟩
                refine ⟨v1 + v2, .add hr1 hr2, Int.mul_pos hda hdb, ?_⟩
                dsimp only
                rw [Rat.intCast_mul, Rat.intCast_add, Rat.intCast_mul, Rat.intCast_mul, Rat.mul_add]
                have t1 : (a.den : Rat) * (b.den : Rat) * v1 = (a.num : Rat) * (b.den : Rat) := by
                  rw [Rat.mul_comm (a.den : Rat) (b.den : Rat), Rat.mul_assoc, hea, Rat.mul_comm]
                have t2 : (a.den : Rat) * (b.den : Rat) * v2 = (b.num : Rat) * (a.den : Rat) := by
                  rw [Rat.mul_assoc, heb, Rat.mul_comm]
                rw [t1, t2]
      · intro h ⟨_, hrel⟩
        cases hrel with
        | add ha hb =>
            unfold evalPartExprRatCoord at h
            cases h1 : evalPartExprRatCoord f e1 pt with
            | undefinedDivZero => exact ih1.2 h1 ⟨_, ha⟩
            | resourceHeld _   => rw [h1] at h; nomatch h
            | val _ =>
                rw [h1] at h
                cases h2 : evalPartExprRatCoord f e2 pt with
                | val _            => rw [h2] at h; nomatch h
                | resourceHeld _   => rw [h2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 h2 ⟨_, hb⟩
  | f + 1, .sub e1 e2 => by
      have ih1 := evalPartExprRatCoord_sound pt hWf f e1
      have ih2 := evalPartExprRatCoord_sound pt hWf f e2
      refine ⟨?_, ?_⟩
      · intro r h; unfold evalPartExprRatCoord at h
        cases h1 : evalPartExprRatCoord f e1 pt with
        | undefinedDivZero => rw [h1] at h; nomatch h
        | resourceHeld _   => rw [h1] at h; nomatch h
        | val a =>
            rw [h1] at h
            cases h2 : evalPartExprRatCoord f e2 pt with
            | undefinedDivZero => rw [h2] at h; nomatch h
            | resourceHeld _   => rw [h2] at h; nomatch h
            | val b =>
                rw [h2] at h; injection h with hr; subst hr
                rcases ih1.1 a h1 with ⟨v1, hr1, hda, hea⟩
                rcases ih2.1 b h2 with ⟨v2, hr2, hdb, heb⟩
                refine ⟨v1 - v2, .sub hr1 hr2, Int.mul_pos hda hdb, ?_⟩
                dsimp only
                rw [Rat.intCast_mul, Rat.intCast_sub, Rat.intCast_mul, Rat.intCast_mul,
                    Rat.sub_eq_add_neg, Rat.mul_add, Rat.mul_neg]
                have t1 : (a.den : Rat) * (b.den : Rat) * v1 = (a.num : Rat) * (b.den : Rat) := by
                  rw [Rat.mul_comm (a.den : Rat) (b.den : Rat), Rat.mul_assoc, hea, Rat.mul_comm]
                have t2 : (a.den : Rat) * (b.den : Rat) * v2 = (b.num : Rat) * (a.den : Rat) := by
                  rw [Rat.mul_assoc, heb, Rat.mul_comm]
                rw [t1, t2, ← Rat.sub_eq_add_neg]
      · intro h ⟨_, hrel⟩
        cases hrel with
        | sub ha hb =>
            unfold evalPartExprRatCoord at h
            cases h1 : evalPartExprRatCoord f e1 pt with
            | undefinedDivZero => exact ih1.2 h1 ⟨_, ha⟩
            | resourceHeld _   => rw [h1] at h; nomatch h
            | val _ =>
                rw [h1] at h
                cases h2 : evalPartExprRatCoord f e2 pt with
                | val _            => rw [h2] at h; nomatch h
                | resourceHeld _   => rw [h2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 h2 ⟨_, hb⟩
  | f + 1, .mul e1 e2 => by
      have ih1 := evalPartExprRatCoord_sound pt hWf f e1
      have ih2 := evalPartExprRatCoord_sound pt hWf f e2
      refine ⟨?_, ?_⟩
      · intro r h; unfold evalPartExprRatCoord at h
        cases h1 : evalPartExprRatCoord f e1 pt with
        | undefinedDivZero => rw [h1] at h; nomatch h
        | resourceHeld _   => rw [h1] at h; nomatch h
        | val a =>
            rw [h1] at h
            cases h2 : evalPartExprRatCoord f e2 pt with
            | undefinedDivZero => rw [h2] at h; nomatch h
            | resourceHeld _   => rw [h2] at h; nomatch h
            | val b =>
                rw [h2] at h; injection h with hr; subst hr
                rcases ih1.1 a h1 with ⟨v1, hr1, hda, hea⟩
                rcases ih2.1 b h2 with ⟨v2, hr2, hdb, heb⟩
                refine ⟨v1 * v2, .mul hr1 hr2, Int.mul_pos hda hdb, ?_⟩
                dsimp only
                rw [Rat.intCast_mul, Rat.intCast_mul, Rat.mul_assoc (a.den : Rat),
                    ← Rat.mul_assoc (b.den : Rat) v1 v2, Rat.mul_comm (b.den : Rat) v1,
                    Rat.mul_assoc v1 (b.den : Rat) v2, heb, ← Rat.mul_assoc, hea]
      · intro h ⟨_, hrel⟩
        cases hrel with
        | mul ha hb =>
            unfold evalPartExprRatCoord at h
            cases h1 : evalPartExprRatCoord f e1 pt with
            | undefinedDivZero => exact ih1.2 h1 ⟨_, ha⟩
            | resourceHeld _   => rw [h1] at h; nomatch h
            | val _ =>
                rw [h1] at h
                cases h2 : evalPartExprRatCoord f e2 pt with
                | val _            => rw [h2] at h; nomatch h
                | resourceHeld _   => rw [h2] at h; nomatch h
                | undefinedDivZero => exact ih2.2 h2 ⟨_, hb⟩
  | f + 1, .div e1 e2 => by
      have ih1 := evalPartExprRatCoord_sound pt hWf f e1
      have ih2 := evalPartExprRatCoord_sound pt hWf f e2
      refine ⟨?_, ?_⟩
      · intro r h; unfold evalPartExprRatCoord at h
        cases h1 : evalPartExprRatCoord f e1 pt with
        | undefinedDivZero => rw [h1] at h; nomatch h
        | resourceHeld _   => rw [h1] at h; nomatch h
        | val a =>
            rw [h1] at h
            cases h2 : evalPartExprRatCoord f e2 pt with
            | undefinedDivZero => rw [h2] at h; nomatch h
            | resourceHeld _   => rw [h2] at h; nomatch h
            | val b =>
                rw [h2] at h; dsimp only at h
                rcases ih1.1 a h1 with ⟨v1, hr1, hda, hea⟩
                rcases ih2.1 b h2 with ⟨v2, hr2, hdb, heb⟩
                if hbz : (b.num == 0) = true then
                  rw [if_pos hbz] at h; nomatch h
                else
                  rw [if_neg hbz] at h
                  have hbnum_ne : b.num ≠ 0 := fun hz => hbz (beq_iff_eq.mpr hz)
                  have hv2_ne : v2 ≠ 0 := by
                    intro hz
                    rw [hz, Rat.mul_zero] at heb
                    exact hbnum_ne (Rat.intCast_eq_zero_iff.mp heb.symm)
                  have hCore : ((a.den : Rat) * (b.num : Rat)) * (v1 / v2) =
                      (a.num : Rat) * (b.den : Rat) := by
                    rw [← heb, Rat.div_def]
                    have hSwap : ((a.den : Rat) * ((b.den : Rat) * v2)) * (v1 * v2⁻¹) =
                        (b.den : Rat) * ((a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                      calc
                        ((a.den : Rat) * ((b.den : Rat) * v2)) * (v1 * v2⁻¹)
                          = ((a.den : Rat) * (b.den : Rat) * v2) * (v1 * v2⁻¹) := by
                              rw [Rat.mul_assoc (a.den : Rat) (b.den : Rat) v2]
                        _ = ((b.den : Rat) * (a.den : Rat) * v2) * (v1 * v2⁻¹) := by
                              rw [Rat.mul_comm (a.den : Rat) (b.den : Rat)]
                        _ = ((b.den : Rat) * (a.den : Rat)) * (v2 * (v1 * v2⁻¹)) := by
                              rw [Rat.mul_assoc ((b.den : Rat) * (a.den : Rat)) v2 (v1 * v2⁻¹)]
                        _ = ((b.den : Rat) * (a.den : Rat)) * ((v2 * v1) * v2⁻¹) := by
                              rw [Rat.mul_assoc v2 v1 v2⁻¹]
                        _ = ((b.den : Rat) * (a.den : Rat)) * ((v1 * v2) * v2⁻¹) := by
                              rw [Rat.mul_comm v2 v1]
                        _ = ((b.den : Rat) * (a.den : Rat)) * (v1 * (v2 * v2⁻¹)) := by
                              rw [Rat.mul_assoc v1 v2 v2⁻¹]
                        _ = ((b.den : Rat) * (a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                              rw [← Rat.mul_assoc ((b.den : Rat) * (a.den : Rat)) v1 (v2 * v2⁻¹)]
                        _ = (b.den : Rat) * ((a.den : Rat) * v1) * (v2 * v2⁻¹) := by
                              rw [Rat.mul_assoc (b.den : Rat) (a.den : Rat) v1]
                    rw [hSwap, hea, Rat.mul_inv_cancel v2 hv2_ne, Rat.mul_one, Rat.mul_comm]
                  if hbpos : decide (0 < b.num) = true then
                    rw [if_pos hbpos] at h; injection h with hr; subst hr
                    refine ⟨v1 / v2, .div hr1 hr2 hv2_ne,
                            Int.mul_pos hda (of_decide_eq_true hbpos), ?_⟩
                    dsimp only
                    rw [Rat.intCast_mul, Rat.intCast_mul]
                    exact hCore
                  else
                    rw [if_neg hbpos] at h; injection h with hr; subst hr
                    have hnotpos : ¬ (0 < b.num) := fun hp => hbpos (decide_eq_true hp)
                    have hbneg : 0 < -b.num := by omega
                    refine ⟨v1 / v2, .div hr1 hr2 hv2_ne, Int.mul_pos hda hbneg, ?_⟩
                    dsimp only
                    rw [Rat.intCast_mul, Rat.intCast_neg, Rat.intCast_neg, Rat.intCast_mul,
                        Rat.mul_neg, Rat.neg_mul ((a.den : Rat) * (b.num : Rat)) (v1 / v2), hCore]
      · intro h ⟨_, hrel⟩
        cases hrel with
        | div ha hb hne =>
            unfold evalPartExprRatCoord at h
            cases h1 : evalPartExprRatCoord f e1 pt with
            | undefinedDivZero => exact ih1.2 h1 ⟨_, ha⟩
            | resourceHeld _   => rw [h1] at h; nomatch h
            | val a =>
                rw [h1] at h
                cases h2 : evalPartExprRatCoord f e2 pt with
                | undefinedDivZero => exact ih2.2 h2 ⟨_, hb⟩
                | resourceHeld _   => rw [h2] at h; nomatch h
                | val b =>
                    rw [h2] at h; dsimp only at h
                    rcases ih2.1 b h2 with ⟨v2, hr2, hdb, heb⟩
                    have hvEq := partExprEvalRel_unique hr2 hb
                    subst hvEq
                    if hbz : (b.num == 0) = true then
                      rw [eq_of_beq hbz] at heb
                      have hz0 : ((0 : Int) : Rat) = 0 := rfl
                      rw [hz0] at heb
                      exact hne ((rat_scale_eq_zero_iff_b1 hdb).mp heb)
                    else
                      rw [if_neg hbz] at h
                      if hbpos : decide (0 < b.num) = true then
                        rw [if_pos hbpos] at h; nomatch h
                      else
                        rw [if_neg hbpos] at h; nomatch h

/-- Full 3-branch soundness of `evalStrictFormRatCoord` (`satTrue`, `satDefinedFalse`, `undefinedTerm`). -/
theorem evalStrictFormRatCoord_sound (pt : RatCoord2) (hWf : checkRatCoordWfBool pt = true) :
    ∀ (fuel : Nat) (φ : StrictForm),
      (evalStrictFormRatCoord fuel φ pt = .satTrue →
        ModelsStrictForm φ (ratCoordToEnv2 pt)) ∧
      (evalStrictFormRatCoord fuel φ pt = .satDefinedFalse →
        FormDefined φ (ratCoordToEnv2 pt) ∧ ¬ FormRawSat φ (ratCoordToEnv2 pt)) ∧
      (evalStrictFormRatCoord fuel φ pt = .undefinedTerm →
        ¬ FormDefined φ (ratCoordToEnv2 pt))
  | 0, _ => And.intro (fun h => nomatch h) (And.intro (fun h => nomatch h) (fun h => nomatch h))
  | f + 1, .eqZero e => by
      have he := evalPartExprRatCoord_sound pt hWf f e
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hz : (r.num == 0) = true then
              rw [eq_of_beq hz] at heq
              have hz0 : ((0 : Int) : Rat) = 0 := rfl
              rw [hz0] at heq
              exact ⟨⟨v, hrel⟩, ⟨v, hrel, (rat_scale_eq_zero_iff_b1 hd).mp heq⟩⟩
            else
              rw [if_neg hz] at h; nomatch h
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, _, heq⟩
            if hz : (r.num == 0) = true then
              rw [if_pos hz] at h; nomatch h
            else
              refine ⟨⟨v, hrel⟩, ?_⟩
              rintro ⟨v', hrel', hv0⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv; rw [hv0, Rat.mul_zero] at heq
              exact hz (beq_iff_eq.mpr (Rat.intCast_eq_zero_iff.mp heq.symm))
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => exact he.2 hr hDef
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            if hz : (r.num == 0) = true then rw [if_pos hz] at h; nomatch h
            else rw [if_neg hz] at h; nomatch h
  | f + 1, .nonneg e => by
      have he := evalPartExprRatCoord_sound pt hWf f e
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hnn : decide (0 ≤ r.num) = true then
              have hr_nn : (0 : Rat) ≤ (r.num : Rat) := Rat.intCast_nonneg.mpr (of_decide_eq_true hnn)
              rw [← heq] at hr_nn
              exact ⟨⟨v, hrel⟩, ⟨v, hrel, rat_nonneg_of_pos_mul_nonneg_b1 hd hr_nn⟩⟩
            else
              rw [if_neg hnn] at h; nomatch h
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hnn : decide (0 ≤ r.num) = true then
              rw [if_pos hnn] at h; nomatch h
            else
              refine ⟨⟨v, hrel⟩, ?_⟩
              rintro ⟨v', hrel', hv_nn⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv
              have hd_nn : (0 : Rat) ≤ (r.den : Rat) := Rat.le_of_lt (Rat.intCast_pos.mpr hd)
              have hprod : (0 : Rat) ≤ (r.den : Rat) * v := Rat.mul_nonneg hd_nn hv_nn
              rw [heq] at hprod
              exact hnn (decide_eq_true (Rat.intCast_nonneg.mp hprod))
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => exact he.2 hr hDef
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            if hnn : decide (0 ≤ r.num) = true then rw [if_pos hnn] at h; nomatch h
            else rw [if_neg hnn] at h; nomatch h
  | f + 1, .pos e => by
      have he := evalPartExprRatCoord_sound pt hWf f e
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hp : decide (0 < r.num) = true then
              have hr_pos : (0 : Rat) < (r.num : Rat) := Rat.intCast_pos.mpr (of_decide_eq_true hp)
              rw [← heq] at hr_pos
              exact ⟨⟨v, hrel⟩, ⟨v, hrel, rat_pos_of_pos_mul_pos_b1 hd hr_pos⟩⟩
            else
              rw [if_neg hp] at h; nomatch h
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hp : decide (0 < r.num) = true then
              rw [if_pos hp] at h; nomatch h
            else
              refine ⟨⟨v, hrel⟩, ?_⟩
              rintro ⟨v', hrel', hv_pos⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv
              have hprod : (0 : Rat) < (r.den : Rat) * v :=
                Rat.mul_pos (Rat.intCast_pos.mpr hd) hv_pos
              rw [heq] at hprod
              exact hp (decide_eq_true (Rat.intCast_pos.mp hprod))
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => exact he.2 hr hDef
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            if hp : decide (0 < r.num) = true then rw [if_pos hp] at h; nomatch h
            else rw [if_neg hp] at h; nomatch h
  | f + 1, .neqZero e => by
      have he := evalPartExprRatCoord_sound pt hWf f e
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, _, heq⟩
            if hne : (r.num != 0) = true then
              have hv_ne : v ≠ 0 := by
                intro hz; rw [hz, Rat.mul_zero] at heq
                have hr0 : r.num = 0 := Rat.intCast_eq_zero_iff.mp heq.symm
                rw [hr0] at hne; contradiction
              exact ⟨⟨v, hrel⟩, ⟨v, hrel, hv_ne⟩⟩
            else
              rw [if_neg hne] at h; nomatch h
      · intro h; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => rw [hr] at h; nomatch h
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            rcases he.1 r hr with ⟨v, hrel, hd, heq⟩
            if hne : (r.num != 0) = true then
              rw [if_pos hne] at h; nomatch h
            else
              have hr0 : r.num = 0 := by
                cases hb : (r.num == 0) with
                | true  => exact eq_of_beq hb
                | false => simp [bne, hb] at hne
              rw [hr0] at heq
              have hz0 : ((0 : Int) : Rat) = 0 := rfl
              rw [hz0] at heq
              have hv0 : v = 0 := (rat_scale_eq_zero_iff_b1 hd).mp heq
              refine ⟨⟨v, hrel⟩, ?_⟩
              rintro ⟨v', hrel', hv_ne⟩
              have hv := partExprEvalRel_unique hrel hrel'
              subst hv; exact hv_ne hv0
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases hr : evalPartExprRatCoord f e pt with
        | undefinedDivZero => exact he.2 hr hDef
        | resourceHeld _   => rw [hr] at h; nomatch h
        | val r =>
            rw [hr] at h; dsimp only at h
            if hne : (r.num != 0) = true then rw [if_pos hne] at h; nomatch h
            else rw [if_neg hne] at h; nomatch h
  | f + 1, .conj φ ψ => by
      have ih1 := evalStrictFormRatCoord_sound pt hWf f φ
      have ih2 := evalStrictFormRatCoord_sound pt hWf f ψ
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | resourceHeld _  => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | satDefinedFalse => rw [h2] at h; nomatch h
            | satTrue         =>
                exact ⟨⟨(ih1.1 h1).1, (ih2.1 h2).1⟩, ⟨(ih1.1 h1).2, (ih2.1 h2).2⟩⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse =>
                exact ⟨⟨(ih1.1 h1).1, (ih2.2.1 h2).1⟩, fun hc => (ih2.2.1 h2).2 hc.2⟩
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         =>
                exact ⟨⟨(ih1.2.1 h1).1, (ih2.1 h2).1⟩, fun hc => (ih1.2.1 h1).2 hc.1⟩
            | satDefinedFalse =>
                exact ⟨⟨(ih1.2.1 h1).1, (ih2.2.1 h2).1⟩, fun hc => (ih1.2.1 h1).2 hc.1⟩
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | resourceHeld _ => rw [h2] at h; nomatch h
            | _              => exact ih1.2.2 h1 hDef.1
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => exact ih2.2.2 h2 hDef.2
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => rw [h2] at h; nomatch h
            | satDefinedFalse => rw [h2] at h; nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => exact ih2.2.2 h2 hDef.2
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => rw [h2] at h; nomatch h
            | satDefinedFalse => rw [h2] at h; nomatch h
  | f + 1, .impStrict φ ψ => by
      have ih1 := evalStrictFormRatCoord_sound pt hWf f φ
      have ih2 := evalStrictFormRatCoord_sound pt hWf f ψ
      refine ⟨?_, ?_, ?_⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _ => rw [h1] at h; nomatch h
        | undefinedTerm  =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | satDefinedFalse => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         =>
                exact ⟨⟨(ih1.1 h1).1, (ih2.1 h2).1⟩, fun _ => (ih2.1 h2).2⟩
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         =>
                exact ⟨⟨(ih1.2.1 h1).1, (ih2.1 h2).1⟩, fun _ => (ih2.1 h2).2⟩
            | satDefinedFalse =>
                exact ⟨⟨(ih1.2.1 h1).1, (ih2.2.1 h2).1⟩,
                  fun hf => False.elim ((ih1.2.1 h1).2 hf)⟩
      · intro h; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt <;> rw [h2] at h <;> nomatch h
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | satTrue         => rw [h2] at h; nomatch h
            | undefinedTerm   => rw [h2] at h; nomatch h
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satDefinedFalse =>
                exact ⟨⟨(ih1.1 h1).1, (ih2.2.1 h2).1⟩,
                  fun himp => (ih2.2.1 h2).2 (himp (ih1.1 h1).2)⟩
      · intro h hDef; unfold evalStrictFormRatCoord at h
        cases h1 : evalStrictFormRatCoord f φ pt with
        | resourceHeld _  => rw [h1] at h; nomatch h
        | undefinedTerm   =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | resourceHeld _ => rw [h2] at h; nomatch h
            | _              => exact ih1.2.2 h1 hDef.1
        | satTrue =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => exact ih2.2.2 h2 hDef.2
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => rw [h2] at h; nomatch h
            | satDefinedFalse => rw [h2] at h; nomatch h
        | satDefinedFalse =>
            rw [h1] at h
            cases h2 : evalStrictFormRatCoord f ψ pt with
            | undefinedTerm   => exact ih2.2.2 h2 hDef.2
            | resourceHeld _  => rw [h2] at h; nomatch h
            | satTrue         => rw [h2] at h; nomatch h
            | satDefinedFalse => rw [h2] at h; nomatch h

/-! ### 2. Exact `G7DomTag` & `InEffDom` Membership Checkers over `RatCoord2` -/

private theorem rat_div_eq_intCast_iff {num g : Int} {denPos : Nat} (hd : 0 < denPos) :
    (num : Rat) / ((denPos : Int) : Rat) = (g : Rat) ↔ num = g * (denPos : Int) := by
  have hRep := synFracRep_rat_div (num := num) hd
  have hdInt : (0 : Int) < (denPos : Int) := by omega
  have hdNe : ((denPos : Int) : Rat) ≠ 0 := Rat.ne_of_gt (Rat.intCast_pos.mpr hdInt)
  constructor
  · intro hEq
    have hMul : ((denPos : Int) : Rat) * ((num : Rat) / ((denPos : Int) : Rat)) =
        ((denPos : Int) : Rat) * (g : Rat) := congrArg (((denPos : Int) : Rat) * ·) hEq
    rw [hRep.2, Rat.mul_comm ((denPos : Int) : Rat) (g : Rat), ← Rat.intCast_mul] at hMul
    exact Rat.intCast_inj.mp hMul
  · intro hIntEq
    rw [hIntEq, Rat.intCast_mul, Rat.div_def, Rat.mul_assoc,
        Rat.mul_inv_cancel ((denPos : Int) : Rat) hdNe, Rat.mul_one]

private theorem rat_div_eq_zero_iff {num : Int} {denPos : Nat} (hd : 0 < denPos) :
    (num : Rat) / ((denPos : Int) : Rat) = 0 ↔ num = 0 := by
  have hz0 : ((0 : Int) : Rat) = 0 := rfl
  rw [← hz0, rat_div_eq_intCast_iff hd, Int.zero_mul]

/-- Computable exact `inG7Dom` membership test across all 4 `G7DomTag` constructors. -/
def checkInG7DomRatCoordBool (D : G7DomTag) (pt : RatCoord2) : Bool :=
  match D with
  | .domQ            => pt.yNum == 0
  | .domQNonzero     => (pt.xNum != 0) && (pt.yNum == 0)
  | .domQ2           => true
  | .domFiniteGrid L =>
      L.any (fun g =>
        (pt.xNum == g.1 * (pt.xDenPos : Int)) &&
        (pt.yNum == g.2 * (pt.yDenPos : Int)))

/-- Exact biconditional between `checkInG7DomRatCoordBool` and declarative `inG7Dom`. -/
theorem checkInG7DomRatCoordBool_iff (D : G7DomTag) (pt : RatCoord2)
    (hWf : checkRatCoordWfBool pt = true) :
    checkInG7DomRatCoordBool D pt = true ↔ inG7Dom D (ratCoordToEnv2 pt) := by
  rcases (checkRatCoordWfBool_iff pt).mp hWf with ⟨hxPos, hyPos⟩
  cases D with
  | domQ =>
      dsimp [checkInG7DomRatCoordBool, inG7Dom, ratCoordToEnv2]
      rw [beq_iff_eq, rat_div_eq_zero_iff hyPos]
  | domQNonzero =>
      dsimp [checkInG7DomRatCoordBool, inG7Dom, ratCoordToEnv2]
      simp only [Bool.and_eq_true, bne_iff_ne, beq_iff_eq]
      rw [ne_eq, rat_div_eq_zero_iff hxPos, rat_div_eq_zero_iff hyPos]
  | domQ2 =>
      dsimp [checkInG7DomRatCoordBool, inG7Dom]
      exact ⟨fun _ => trivial, fun _ => rfl⟩
  | domFiniteGrid L =>
      dsimp [checkInG7DomRatCoordBool, inG7Dom, ratCoordToEnv2]
      rw [List.any_eq_true]
      constructor
      · rintro ⟨g, hgMem, hgEq⟩
        simp only [Bool.and_eq_true, beq_iff_eq] at hgEq
        refine ⟨g, hgMem, ?_⟩
        unfold gridPtToEnv2
        rw [(rat_div_eq_intCast_iff hxPos).mpr hgEq.1,
            (rat_div_eq_intCast_iff hyPos).mpr hgEq.2]
      · rintro ⟨g, hgMem, hgEq⟩
        unfold gridPtToEnv2 at hgEq
        injection hgEq with hxEq hyEq
        refine ⟨g, hgMem, ?_⟩
        simp only [Bool.and_eq_true, beq_iff_eq]
        exact ⟨(rat_div_eq_intCast_iff hxPos).mp hxEq.symm,
               (rat_div_eq_intCast_iff hyPos).mp hyEq.symm⟩

/-- Sequential guard satisfaction check on `RatCoord2`. -/
def checkGuardsSatRatCoordBool (fuel : Nat) : List StrictForm → RatCoord2 → Bool
  | [],      _  => true
  | γ :: γs, pt =>
      (evalStrictFormRatCoord fuel γ pt == .satTrue) &&
      checkGuardsSatRatCoordBool fuel γs pt

theorem checkGuardsSatRatCoordBool_sound (fuel : Nat) (Γ : List StrictForm) (pt : RatCoord2)
    (hWf : checkRatCoordWfBool pt = true)
    (hSat : checkGuardsSatRatCoordBool fuel Γ pt = true) :
    TelescopicGuardsDefined Γ (ratCoordToEnv2 pt) ∧
    ∀ γ ∈ Γ, ModelsStrictForm γ (ratCoordToEnv2 pt) := by
  induction Γ with
  | nil => exact ⟨trivial, fun _ h => nomatch h⟩
  | cons γ γs ih =>
      unfold checkGuardsSatRatCoordBool at hSat
      simp only [Bool.and_eq_true] at hSat
      have hHead : ModelsStrictForm γ (ratCoordToEnv2 pt) :=
        (evalStrictFormRatCoord_sound pt hWf fuel γ).1 (eq_of_beq hSat.1)
      rcases ih hSat.2 with ⟨hTelTail, hSatTail⟩
      refine ⟨⟨hHead.1, fun _ => hTelTail⟩, ?_⟩
      intro g hg
      rcases List.mem_cons.mp hg with rfl | hMem
      · exact hHead
      · exact hSatTail g hMem

/-- Computable `InEffDom` witness check at `pt : RatCoord2`. -/
def checkInEffDomRatCoordBool (fuel : Nat) (D : G7DomTag) (Γ : List StrictForm)
    (pt : RatCoord2) : Bool :=
  checkRatCoordWfBool pt &&
  checkInG7DomRatCoordBool D pt &&
  checkGuardsSatRatCoordBool fuel Γ pt

theorem checkInEffDomRatCoordBool_sound (fuel : Nat) (D : G7DomTag) (Γ : List StrictForm)
    (pt : RatCoord2) (h : checkInEffDomRatCoordBool fuel D Γ pt = true) :
    0 < pt.xDenPos ∧ 0 < pt.yDenPos ∧ InEffDom D Γ (ratCoordToEnv2 pt) := by
  unfold checkInEffDomRatCoordBool at h
  simp only [Bool.and_eq_true] at h
  rcases h with ⟨⟨hWf, hDom⟩, hGuards⟩
  rcases (checkRatCoordWfBool_iff pt).mp hWf with ⟨hx, hy⟩
  rcases checkGuardsSatRatCoordBool_sound fuel Γ pt hWf hGuards with ⟨hTel, hSat⟩
  exact ⟨hx, hy, (checkInG7DomRatCoordBool_iff D pt hWf).mp hDom, hTel, hSat⟩

/-- Sequential guard failure/undefinedness check at `pt : RatCoord2`. -/
def checkGuardsFailRatCoordBool (fuel : Nat) : List StrictForm → RatCoord2 → Bool
  | [],      _  => false
  | γ :: γs, pt =>
      match evalStrictFormRatCoord fuel γ pt with
      | .satDefinedFalse => true
      | .undefinedTerm   => true
      | .satTrue         => checkGuardsFailRatCoordBool fuel γs pt
      | .resourceHeld _  => false

theorem checkGuardsFailRatCoordBool_sound (fuel : Nat) (Γ : List StrictForm) (pt : RatCoord2)
    (hWf : checkRatCoordWfBool pt = true)
    (hFail : checkGuardsFailRatCoordBool fuel Γ pt = true) :
    ¬ (TelescopicGuardsDefined Γ (ratCoordToEnv2 pt) ∧
       ∀ γ ∈ Γ, ModelsStrictForm γ (ratCoordToEnv2 pt)) := by
  induction Γ with
  | nil => nomatch hFail
  | cons γ γs ih =>
      unfold checkGuardsFailRatCoordBool at hFail
      have hSnd := evalStrictFormRatCoord_sound pt hWf fuel γ
      cases hEv : evalStrictFormRatCoord fuel γ pt with
      | resourceHeld _ => rw [hEv] at hFail; nomatch hFail
      | satDefinedFalse =>
          rintro ⟨_, hAll⟩
          exact (hSnd.2.1 hEv).2 (hAll γ (List.mem_cons_self ..)).2
      | undefinedTerm =>
          rintro ⟨hTel, _⟩
          exact hSnd.2.2 hEv hTel.1
      | satTrue =>
          rw [hEv] at hFail
          rintro ⟨hTel, hAll⟩
          have hHead : ModelsStrictForm γ (ratCoordToEnv2 pt) :=
            hAll γ (List.mem_cons_self ..)
          exact ih hFail ⟨hTel.2 hHead, fun g hg => hAll g (List.mem_cons_of_mem γ hg)⟩

/-- Computable `¬ InEffDom D Γ (ratCoordToEnv2 pt)` check (used for `Refinement` `scopeExpanded = true`). -/
def checkNotInEffDomRatCoordBool (fuel : Nat) (D : G7DomTag) (Γ : List StrictForm)
    (pt : RatCoord2) : Bool :=
  checkRatCoordWfBool pt &&
  (!checkInG7DomRatCoordBool D pt || checkGuardsFailRatCoordBool fuel Γ pt)

theorem checkNotInEffDomRatCoordBool_sound (fuel : Nat) (D : G7DomTag) (Γ : List StrictForm)
    (pt : RatCoord2) (h : checkNotInEffDomRatCoordBool fuel D Γ pt = true) :
    0 < pt.xDenPos ∧ 0 < pt.yDenPos ∧ ¬ InEffDom D Γ (ratCoordToEnv2 pt) := by
  unfold checkNotInEffDomRatCoordBool at h
  simp only [Bool.and_eq_true] at h
  rcases h with ⟨hWf, hDisj⟩
  rcases (checkRatCoordWfBool_iff pt).mp hWf with ⟨hx, hy⟩
  refine ⟨hx, hy, ?_⟩
  rcases Bool.or_eq_true_iff.mp hDisj with hNotDom | hGuardFail
  · rintro ⟨hDom, _, _⟩
    have hDomTrue : checkInG7DomRatCoordBool D pt = true :=
      (checkInG7DomRatCoordBool_iff D pt hWf).mpr hDom
    rw [hDomTrue] at hNotDom
    nomatch hNotDom
  · rintro ⟨_, hTel, hSat⟩
    exact checkGuardsFailRatCoordBool_sound fuel Γ pt hWf hGuardFail ⟨hTel, hSat⟩

/-- Computable `ModelsExcised` witness check at `pt : RatCoord2`. -/
def checkModelsExcisedRatCoordBool (fuel : Nat) (Φ : ExcisedLocus) (pt : RatCoord2) : Bool :=
  checkRatCoordWfBool pt &&
  Φ.any (fun E => checkGuardsSatRatCoordBool fuel E pt)

theorem checkModelsExcisedRatCoordBool_sound (fuel : Nat) (Φ : ExcisedLocus) (pt : RatCoord2)
    (h : checkModelsExcisedRatCoordBool fuel Φ pt = true) :
    ModelsExcised Φ (ratCoordToEnv2 pt) := by
  unfold checkModelsExcisedRatCoordBool at h
  simp only [Bool.and_eq_true, List.any_eq_true] at h
  rcases h with ⟨hWf, ⟨E, hEMem, hESat⟩⟩
  exact ⟨E, hEMem, checkGuardsSatRatCoordBool_sound fuel E pt hWf hESat⟩

/-! ### 3. Complete Proof-Root Collection & `deriveG5PrimDeps` (`B1-A3`) -/

/-- Collect EVERY `G7` node identifier referenced across `cert` and its branch sub-certificates. -/
def collectG5ProofRootIds (cert : G5DischargeCert) : List String :=
  let obstNodes : List String :=
    match cert.obstructionSpec.evidence with
    | .missingGuard _ _ (some nid) => [nid]
    | .scopedNoGoLocus _ _ nid     => [nid]
    | _                            => []
  let repairNodes : List String :=
    match cert.repairCert? with
    | none => []
    | some r =>
        let baseN : List String :=
          match r.baseEquivStep with
          | .sameBaseDom _           => []
          | .qGuardNzToNonzero nzNid => [nzNid]
          | .nonzeroToQGuardNz nzNid => [nzNid]
        baseN ++ r.oldGuardsDefNodeId?.toList ++
        r.oldEntailsNewGuardNodes.map Prod.snd ++
        r.newEntailsOldGuardNodes.map Prod.snd ++
        r.redundantGuardNodeId?.toList
  let retreatNodes : List String :=
    match cert.retreatCert? with
    | none => []
    | some rt =>
        let connN : List String :=
          match rt.guardConn with
          | .syntacticConcat => []
          | .mutualImplication d2n n2d => d2n.map Prod.snd ++ n2d.map Prod.snd
        let rxN : List String :=
          match rt.reexprCert? with
          | none => []
          | some rx =>
              rx.branchDefAndDisjNodes.foldr (fun (_, dId, jId) acc => dId :: jId :: acc) [] ++
              rx.canonCoverWitnesses.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) []
        [rt.prefixDefNodeId] ++ connN ++ rxN ++ rt.adoptedGuardNodeId?.toList
  let refineNodes : List String :=
    match cert.refinementCert? with
    | none => []
    | some rf =>
        rf.oldGuardsDefNodeId?.toList ++
        rf.oldEntailsNewGuardNodes.map Prod.snd ++
        rf.newEntailsOldGuardNodes.map Prod.snd ++
        rf.goalImpNodeId?.toList ++
        rf.adoptedGuardNodeId?.toList
  canonSortStrs ([cert.goalNewNodeId] ++ obstNodes ++ repairNodes ++ retreatNodes ++ refineNodes)

/-- **`deriveG5PrimDeps` (`B1-A3`)**:
    Extracts the canonical deduplicated transitive primitive premise closure across ALL proof roots
    of `cert` using frozen `OmegaCellC1P1B2BA0.multiRootTransitivePrimDeps`. -/
def deriveG5PrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer) (cert : G5DischargeCert) :
    List String :=
  multiRootTransitivePrimDeps Γ C (collectG5ProofRootIds cert)

/-! ### 4. Deterministic G5 Sub-Checkers (`B1-A3`) -/

/-- Exact helper checking that `nid` is accepted by frozen `verifyReachableDerivation` with exact
    header `⟨domTag, specId, guards, conclusion⟩`. -/
def checkExactG7SequentBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (nid : String) (domTag : G7DomTag) (specId : String)
    (guards : List StrictForm) (conclusion : StrictForm) : Bool :=
  verifyReachableDerivation fuel Γ C nid == .accept ⟨domTag, specId, guards, conclusion⟩

/-- Check that `pairs : List (StrictForm × String)` matches `targetGuards` 1:1 in order and that
    every `(γ, nid)` is proved under `(domSrc, specId, guardsSrc)`. -/
def checkGuardEntailmentListBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (domSrc : G7DomTag) (specId : String) (guardsSrc targetGuards : List StrictForm)
    (pairs : List (StrictForm × String)) : Bool :=
  (pairs.map Prod.fst == targetGuards) &&
  pairs.all (fun gn => checkExactG7SequentBool fuel Γ C gn.2 domSrc specId guardsSrc gn.1)

/-- Computable `(KernelObstKindV1 × ReflexKind)` admissibility check matching `G5ObstReflexAllowed`. -/
def checkG5ObstReflexAllowedBool (okind : KernelObstKindV1) (rk : ReflexKind) : Bool :=
  match okind, rk with
  | .counterexamplePoint,      .repair     => true
  | .counterexamplePoint,      .retreat    => true
  | .invalidCertificate,       .repair     => true
  | .invalidCertificate,       .refinement => true
  | .missingAssumption true,   .repair     => true
  | .missingAssumption _,      .retreat    => true
  | .missingAssumption true,   .refinement => true
  | .scopedNoGo,               .retreat    => true
  | _,                         _           => false

/-- Computable certificate-defect witness check for `.invalidCertificate` (`¬ SemNecessarySosConditions`). -/
def checkSosCertDefectiveBool (fuel : Nat) (D_old : G7DomTag) (Γ_old : List StrictForm)
    (goalOld : StrictForm) (badSos : PolyPositivstellensatzCert) (probePt : RatCoord2) : Bool :=
  checkRatCoordWfBool probePt &&
  (checkAlgDomCertBool D_old Γ_old goalOld (.polyPositivstellensatz badSos) == false) &&
  ((badSos.lhsScale == 0) ||
   decide (badSos.constTerm < 0) ||
   badSos.sqTerms.any (fun wp => decide (wp.1 < 0)) ||
   (checkInEffDomRatCoordBool fuel D_old Γ_old probePt &&
    match goalOld with
    | .pos _       => badSos.posMult.isEmpty && !decide (0 < badSos.constTerm)
    | .eqZero _    => (badSos.constTerm != 0) || !badSos.sqTerms.isEmpty
    | .conj _ _    => true
    | .impStrict _ _ => true
    | .nonneg _    => false
    | .neqZero _   => true))

/-- Computable obstruction verification against `(D_old, Γ_old, goalOld)` (`B1-02`, `B1-A5`). -/
def checkVerifiedObstructionBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (goalOld : StrictForm) (specNewId : String)
    (spec : VerifiedObstructionSpec) : Bool :=
  match spec.obstKind, spec.evidence with
  | .counterexamplePoint, .counterexamplePt obsPt =>
      checkInEffDomRatCoordBool fuel D_old Γ_old obsPt &&
      (let res := evalStrictFormRatCoord fuel goalOld obsPt
       (res == .satDefinedFalse) || (res == .undefinedTerm))
  | .invalidCertificate, .invalidSosCert badSos probePt =>
      checkSosCertDefectiveBool fuel D_old Γ_old goalOld badSos probePt
  | .missingAssumption true, .missingGuard candGuard none (some obstNid) =>
      checkExactG7SequentBool fuel Γ C obstNid D_old specNewId Γ_old candGuard
  | .missingAssumption false, .missingGuard candGuard (some failPt) none =>
      checkInEffDomRatCoordBool fuel D_old Γ_old failPt &&
      (let res := evalStrictFormRatCoord fuel candGuard failPt
       (res == .satDefinedFalse) || (res == .undefinedTerm))
  | .scopedNoGo, .scopedNoGoLocus locusGuards noGoPt noGoNid =>
      isAtomicStrictFormBool goalOld &&
      checkInEffDomRatCoordBool fuel D_old (Γ_old ++ locusGuards) noGoPt &&
      checkExactG7SequentBool fuel Γ C noGoNid D_old specNewId
        (Γ_old ++ locusGuards) (atomicComplement goalOld)
  | _, _ => false

/-- Check bidirectional effective-domain equality (`SemSameEffDom D_old Γ_old D_new Γ_new`) assuming
    `TelescopicGuardsDefined Γ_new` on `inG7Dom D_new` is already established by `goalNewNodeId`. -/
def checkSameEffDomCoreBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (D_new : G7DomTag) (Γ_new : List StrictForm)
    (specNewId : String) (step : BaseDomEquivStep) (oldDefNid? : Option String)
    (oldToNew : List (StrictForm × String)) (newToOld : List (StrictForm × String)) : Bool :=
  let baseOk : Bool :=
    match step with
    | .sameBaseDom D =>
        (D_old == D) && (D_new == D)
    | .qGuardNzToNonzero nzNid =>
        (D_old == .domQ) && (D_new == .domQNonzero) &&
        checkExactG7SequentBool fuel Γ C nzNid .domQ specNewId Γ_old (.neqZero .varX)
    | .nonzeroToQGuardNz nzNid =>
        (D_old == .domQNonzero) && (D_new == .domQ) &&
        checkExactG7SequentBool fuel Γ C nzNid .domQ specNewId Γ_new (.neqZero .varX)
  if (D_old == D_new) && (Γ_old == Γ_new) then
    baseOk && oldDefNid?.isNone && oldToNew.isEmpty && newToOld.isEmpty
  else
    let oldDefOk : Bool :=
      if Γ_old.isEmpty then oldDefNid?.isNone
      else
        match oldDefNid? with
        | none     => false
        | some did => checkExactG7SequentBool fuel Γ C did D_old specNewId Γ_old (.eqZero (.const 0))
    baseOk && oldDefOk &&
    checkGuardEntailmentListBool fuel Γ C D_old specNewId Γ_old Γ_new oldToNew &&
    checkGuardEntailmentListBool fuel Γ C D_new specNewId Γ_new Γ_old newToOld

/-- **`checkRepairDomEqBool` (`B1-A3` & `B1-03`)**:
    Verifies exact bidirectional effective-domain equality `D_old,eff = D_new,eff` and
    obstruction-specific `Repair` obligations. -/
def checkRepairDomEqBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) (rCert : RepairDomEqCert) : Bool :=
  checkSameEffDomCoreBool fuel Γ C cert.domOld cert.guardsOld cert.domNew cert.guardsNew
    cert.specNewId rCert.baseEquivStep rCert.oldGuardsDefNodeId?
    rCert.oldEntailsNewGuardNodes rCert.newEntailsOldGuardNodes &&
  match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
  | .counterexamplePoint, .counterexamplePt obsPt =>
      rCert.redundantGuardNodeId?.isNone &&
      checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew obsPt &&
      (evalStrictFormRatCoord fuel cert.goalNew obsPt == .satTrue)
  | .invalidCertificate, .invalidSosCert _ _ =>
      rCert.redundantGuardNodeId?.isNone
  | .missingAssumption true, .missingGuard candGuard none (some _) =>
      match rCert.redundantGuardNodeId? with
      | none      => false
      | some rnid => checkExactG7SequentBool fuel Γ C rnid cert.domOld cert.specNewId
                       cert.guardsOld candGuard
  | _, _ => false

/-- Check `ExcisedReexprCert` (`Corrigendum 01` §1.2 Step 3 equivalent excised locus verification). -/
def checkExcisedReexprBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (D_new : G7DomTag) (Γ_new : List StrictForm)
    (specNewId : String) (B_canon excisedBranches : ExcisedLocus)
    (rx : ExcisedReexprCert) : Bool :=
  (rx.branchDefAndDisjNodes.map Prod.fst == excisedBranches) &&
  rx.branchDefAndDisjNodes.all (fun (E_i, defNid, disjNid) =>
    checkExactG7SequentBool fuel Γ C defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0)) &&
    checkExactG7SequentBool fuel Γ C disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))) &&
  (rx.canonCoverWitnesses.map Prod.fst == B_canon) &&
  rx.canonCoverWitnesses.all (fun (B_j, E_target, psiNodes) =>
    excisedBranches.contains E_target &&
    checkGuardEntailmentListBool fuel Γ C D_old specNewId B_j E_target psiNodes)

/-- **`checkRetreatExactPartitionBool` (`B1-A3` & `B1-04`)**:
    Verifies 2-stage telescopic partition (`L_B2B_TelescopicPartition_from_G7`), exact excised-locus
    coverage & disjointness, strict loss witness, conditional retention anchors, and obstruction
    excision / guard adoption. -/
def checkRetreatExactPartitionBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) (rt : G5RetreatPartitionCert) : Bool :=
  let B_canon := buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards
  let guardConnOk : Bool :=
    match rt.guardConn with
    | .syntacticConcat =>
        cert.guardsNew == cert.guardsOld ++ rt.deltaGuards
    | .mutualImplication d2n n2d =>
        checkGuardEntailmentListBool fuel Γ C cert.domNew cert.specNewId
          (cert.guardsOld ++ rt.deltaGuards) cert.guardsNew d2n &&
        checkGuardEntailmentListBool fuel Γ C cert.domNew cert.specNewId
          cert.guardsNew (cert.guardsOld ++ rt.deltaGuards) n2d
  let excisedOk : Bool :=
    match rt.reexprCert? with
    | none => rt.excisedBranches == B_canon
    | some rx =>
        checkExcisedReexprBool fuel Γ C cert.domOld cert.guardsOld cert.domNew cert.guardsNew
          cert.specNewId B_canon rt.excisedBranches rx
  let obstResolvedOk : Bool :=
    match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
    | .counterexamplePoint, .counterexamplePt obsPt =>
        rt.adoptedGuardNodeId?.isNone &&
        checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld obsPt &&
        checkModelsExcisedRatCoordBool fuel rt.excisedBranches obsPt
    | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
        rt.adoptedGuardNodeId?.isNone &&
        checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld noGoPt &&
        checkModelsExcisedRatCoordBool fuel rt.excisedBranches noGoPt
    | .missingAssumption true, .missingGuard candGuard none (some _) =>
        match rt.adoptedGuardNodeId? with
        | none      => false
        | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                         cert.guardsNew candGuard
    | .missingAssumption false, .missingGuard candGuard (some failPt) none =>
        checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld failPt &&
        checkModelsExcisedRatCoordBool fuel rt.excisedBranches failPt &&
        match rt.adoptedGuardNodeId? with
        | none      => false
        | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                         cert.guardsNew candGuard
    | _, _ => false
  checkBaseDomRetreatStepBool rt.baseStep cert.domOld cert.domNew &&
  rt.deltaGuards.all isAtomicStrictFormBool &&
  checkExactG7SequentBool fuel Γ C rt.prefixDefNodeId cert.domNew cert.specNewId
    (cert.guardsOld ++ rt.deltaGuards) (.eqZero (.const 0)) &&
  guardConnOk &&
  excisedOk &&
  checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld rt.strictLossWitness &&
  checkModelsExcisedRatCoordBool fuel rt.excisedBranches rt.strictLossWitness &&
  rt.claimedRetentionAnchors.all (checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew) &&
  obstResolvedOk

/-- Computable check for conservative base-domain expansion (`inG7Dom D_old ρ → inG7Dom D_new ρ`). -/
def checkBaseDomExpandStepBool (step : BaseDomExpandStep) (D_old D_new : G7DomTag) : Bool :=
  match step with
  | .sameBaseDom D => (D_old == D) && (D_new == D)
  | .qNonzeroToQ   => (D_old == .domQNonzero) && (D_new == .domQ)
  | .qToQ2         => (D_old == .domQ) && (D_new == .domQ2)
  | .qNonzeroToQ2  => (D_old == .domQNonzero) && (D_new == .domQ2)
  | .finiteGridSup L_old L_new =>
      (D_old == .domFiniteGrid L_old) &&
      (D_new == .domFiniteGrid L_new) &&
      L_old.all (fun p => L_new.contains p)

/-- **`checkRefinementBool` (`B1-A3` & `B1-05`)**:
    Verifies conservative effective-domain inclusion `D_old,eff ⊆ D_new,eff`, conservative goal
    entailment `∀ ρ ∈ D_new,eff, P_new(ρ) → P_old(ρ)`, explicit `scopeExpanded` accounting, and
    obstruction-specific resolution. -/
def checkRefinementBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) (rf : G5RefinementCert) : Bool :=
  let inclGuardsOk : Bool :=
    if cert.guardsNew == cert.guardsOld then rf.oldEntailsNewGuardNodes.isEmpty
    else
      checkGuardEntailmentListBool fuel Γ C cert.domOld cert.specNewId
        cert.guardsOld cert.guardsNew rf.oldEntailsNewGuardNodes
  let goalImpOk : Bool :=
    match rf.goalImpNodeId? with
    | none        => cert.goalNew == cert.goalOld
    | some impNid =>
        checkExactG7SequentBool fuel Γ C impNid cert.domNew cert.specNewId
          (cert.guardsNew ++ [cert.goalNew]) cert.goalOld
  let scopeAccountingOk : Bool :=
    if rf.scopeExpanded then
      rf.oldGuardsDefNodeId?.isNone &&
      rf.newEntailsOldGuardNodes.isEmpty &&
      match rf.expansionWitness? with
      | none        => false
      | some pt_exp =>
          checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew pt_exp &&
          checkNotInEffDomRatCoordBool fuel cert.domOld cert.guardsOld pt_exp
    else
      rf.expansionWitness?.isNone &&
      match rf.baseExpandStep with
      | .sameBaseDom D =>
          checkSameEffDomCoreBool fuel Γ C cert.domOld cert.guardsOld cert.domNew cert.guardsNew
            cert.specNewId (.sameBaseDom D) rf.oldGuardsDefNodeId?
            (if cert.guardsNew == cert.guardsOld then [] else rf.oldEntailsNewGuardNodes)
            rf.newEntailsOldGuardNodes
      | _ => false
  let obstResolvedOk : Bool :=
    match cert.obstructionSpec.obstKind, cert.obstructionSpec.evidence with
    | .invalidCertificate, .invalidSosCert _ _ =>
        rf.adoptedGuardNodeId?.isNone
    | .missingAssumption true, .missingGuard candGuard none (some _) =>
        match rf.adoptedGuardNodeId? with
        | none      => false
        | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                         cert.guardsNew candGuard
    | _, _ => false
  checkBaseDomExpandStepBool rf.baseExpandStep cert.domOld cert.domNew &&
  inclGuardsOk &&
  goalImpOk &&
  scopeAccountingOk &&
  obstResolvedOk

/-! ### 5. Top-Level `checkG5DischargeBool` & Proof-Bearing `G5QualifiedRecord` (`B1-A3`, `B1-A4.8`) -/

/-- Canonical subject-binding and non-empty identifier check for `G5DischargeCert`. -/
def checkG5CanonicalBindingBool (cert : G5DischargeCert) : Bool :=
  (cert.certVersion == "g5_b1_v1") &&
  (cert.rflxCid != "") &&
  (cert.cellOldCid != "") &&
  (cert.obstCid != "") &&
  (cert.cellNewCid != "") &&
  (cert.baseId == "base_Q") &&
  (cert.specOldId != "") &&
  (cert.specNewId != "") &&
  (cert.obstructionSpec.obstCid == cert.obstCid) &&
  (cert.obstructionSpec.targetCellOldCid == cert.cellOldCid) &&
  (cert.obstructionSpec.targetSpecOldId == cert.specOldId)

/-- Core `G5` mathematical proof & branch-exclusivity verifier (factored cleanly from
    `claimedPrimDeps == deriveG5PrimDeps` so `OutputCongruence` and `RestrictionInvariance`
    compose 1:1 with `A0_05_1` and `A0_05_3`!). -/
def checkG5CoreProofsBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) : Bool :=
  checkG5CanonicalBindingBool cert &&
  checkG5ObstReflexAllowedBool cert.obstructionSpec.obstKind cert.reflexKind &&
  checkVerifiedObstructionBool fuel Γ C cert.domOld cert.guardsOld cert.goalOld
    cert.specNewId cert.obstructionSpec &&
  checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew cert.nonEmptyWitness.witnessCoord &&
  checkExactG7SequentBool fuel Γ C cert.goalNewNodeId cert.domNew cert.specNewId
    cert.guardsNew cert.goalNew &&
  match cert.reflexKind with
  | .repair =>
      (!cert.requiresRetreatHistory) &&
      cert.retreatCert?.isNone &&
      cert.refinementCert?.isNone &&
      match cert.repairCert? with
      | none       => false
      | some rCert => checkRepairDomEqBool fuel Γ C cert rCert
  | .retreat =>
      cert.requiresRetreatHistory &&
      cert.repairCert?.isNone &&
      cert.refinementCert?.isNone &&
      match cert.retreatCert? with
      | none        => false
      | some rtCert => checkRetreatExactPartitionBool fuel Γ C cert rtCert
  | .refinement =>
      (!cert.requiresRetreatHistory) &&
      cert.repairCert?.isNone &&
      cert.retreatCert?.isNone &&
      match cert.refinementCert? with
      | none        => false
      | some rfCert => checkRefinementBool fuel Γ C cert rfCert

/-- **`checkG5DischargeBool` (`B1-A3` & `B1-06` — Official Deterministic `G5` Kernel Checker)**:
    Verifies exact transitive primitive premise dependency binding (`claimedPrimDeps == deriveG5PrimDeps`)
    together with `checkG5CoreProofsBool`. -/
def checkG5DischargeBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) : Bool :=
  (cert.claimedPrimDeps.primDepIds == deriveG5PrimDeps Γ C cert) &&
  checkG5CoreProofsBool fuel Γ C cert

/-- Proof-bearing scoped `G5` qualification record (`B1-02`, `B1-04`, `B1-A4.8`):
    - Carries a kernel-verified `{ c : G5DischargeCert // checkG5DischargeBool fuel Γ C c = true }`,
    - Explicitly surfaces `requiresRetreatHistory : Bool` WITHOUT mutating any `P1B1` ledger,
    - Seals `g6ProtectedSlot = .unchecked` (`G5Pass ⇏ G6Pass`),
    - Seals `g1IntegritySlot = .unchecked`, and
    - Seals `grantFlag = .noGrantFromMathCheck` (`Zero-Authority-Escalation`). -/
structure G5QualifiedRecord (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) where
  verifiedG5Slot         : SlotWitness G5DischargeCert (checkG5DischargeBool fuel Γ C) .verified
  requiresRetreatHistory : Bool
  g6ProtectedSlot        : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  g1IntegritySlot        : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  grantFlag              : CheckDerivesNoGrant

/-- Deterministic constructor producing `Option (G5QualifiedRecord fuel Γ C)` from `cert`. -/
def qualifyG5Isolated? (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (cert : G5DischargeCert) : Option (G5QualifiedRecord fuel Γ C) :=
  if h : checkG5DischargeBool fuel Γ C cert = true then
    some {
      verifiedG5Slot         := .mkVerified ⟨cert, h⟩
      requiresRetreatHistory := cert.requiresRetreatHistory
      g6ProtectedSlot        := .mkUnchecked
      g1IntegritySlot        := .mkUnchecked
      grantFlag              := .noGrantFromMathCheck
    }
  else
    none

end OmegaCellC1P1B2BB1
