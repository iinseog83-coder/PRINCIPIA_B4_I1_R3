/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B1 — Isolated G5 Certified Obstruction Discharge Kernel
  Module: OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure

  Authorization: `PRINCIPIA_P1B2B_B1_ISOLATED_G5_IMPLEMENTATION_AUTHORIZED`
  Scope (`B1-A4` — 8 Conditional Soundness, Dependency Closure, & Non-Escalation Theorems):
    1. `T_B1_01_G5_NonEmptiness_Sound` (+ `T_B1_01b_G5_DomNz_ImpNorm_Target_Sound` reusing
       frozen `A0`'s `L_B2B_DomNz` & `L_B2B_ImpNorm`)
    2. `T_B1_02_Repair_ExactEffDomEq_Sound`
    3. `T_B1_03_Retreat_ExactScopeLossPartition_Sound` (reusing `L_B2B_TelescopicPartition_from_G7`)
    4. `T_B1_04_Refinement_ConservativePreservation_Sound`
    5. `T_B1_05_Obstruction_GenuineDischarge_Sound`
    6. `T_B1_06_ProofRoots_And_PrimDeps_Completeness` (reusing `A0_05_1`, `A0_05_2`, `A0_05_3`, `A0_05_4`,
       while preserving A0's uninstrumented frozen runtime trace status as `HELD`)
    7. `T_B1_07_CheckG5Discharge_MasterSoundness`
    8. `T_B1_08_Zero_G6_G1_Authority_Escalation`
-/
import OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers

namespace OmegaCellC1P1B2BB1

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0

/-! ### 1. List & Root-Membership Lemmas for `collectG5ProofRootIds` -/

private theorem map_eq_imp_forall_mem_eq {α β : Type} {f g : α → β} :
    ∀ {L : List α}, L.map f = L.map g → ∀ x ∈ L, f x = g x
  | [],      _,    _, hx => nomatch hx
  | _ :: _,  hMap, _, hx => by
      simp only [List.map_cons] at hMap
      injection hMap with hHead hTail
      rcases List.mem_cons.mp hx with rfl | hRest
      · exact hHead
      · exact map_eq_imp_forall_mem_eq hTail _ hRest

private theorem mem_foldr_pair_ids {α : Type} :
    ∀ (L : List (α × String × String)) {e : α} {dId jId : String},
      (e, dId, jId) ∈ L →
      dId ∈ L.foldr (fun (_, d, j) acc => d :: j :: acc) [] ∧
      jId ∈ L.foldr (fun (_, d, j) acc => d :: j :: acc) []
  | [], _, _, _, h => nomatch h
  | (_, _, _) :: tail, _, _, _, hMem => by
      rcases List.mem_cons.mp hMem with hEq | hRest
      · injection hEq with _ hPair
        injection hPair with hd hj
        subst hd; subst hj
        exact ⟨List.mem_cons_self .., List.mem_cons_of_mem _ (List.mem_cons_self ..)⟩
      · rcases mem_foldr_pair_ids tail hRest with ⟨hd, hj⟩
        exact ⟨List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hd),
               List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hj)⟩

private theorem mem_foldr_cover_ids {α β : Type} :
    ∀ (L : List (α × β × List (StrictForm × String)))
      {b : α} {e : β} {ps : List (StrictForm × String)} {nid : String},
      (b, e, ps) ∈ L → nid ∈ ps.map Prod.snd →
      nid ∈ L.foldr (fun (_, _, q) acc => q.map Prod.snd ++ acc) []
  | [], _, _, _, _, h, _ => nomatch h
  | (_, _, _) :: tail, _, _, _, _, hMem, hNid => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hMem with hEq | hRest
      · injection hEq with _ hPair
        injection hPair with _ hPs
        subst hPs
        exact List.mem_append_left _ hNid
      · exact List.mem_append_right _ (mem_foldr_cover_ids tail hRest hNid)

private theorem mem_map_fst_exists_pair {α β : Type} :
    ∀ {L : List (α × β)} {x : α}, x ∈ L.map Prod.fst → ∃ y : β, (x, y) ∈ L
  | [],            _, h => nomatch h
  | (_, b) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, List.mem_cons_self ..⟩
      · rcases mem_map_fst_exists_pair hTail with ⟨y, hy⟩
        exact ⟨y, List.mem_cons_of_mem _ hy⟩

private theorem mem_map_fst_triple {α β γ : Type} :
    ∀ {L : List (α × β × γ)} {x : α},
      x ∈ L.map Prod.fst → ∃ (y : β) (z : γ), (x, y, z) ∈ L
  | [],               _, h => nomatch h
  | (_, b, c) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, c, List.mem_cons_self ..⟩
      · rcases mem_map_fst_triple hTail with ⟨y, z, hyz⟩
        exact ⟨y, z, List.mem_cons_of_mem _ hyz⟩

theorem goalNewNodeId_mem_collectG5ProofRootIds (cert : G5DischargeCert) :
    cert.goalNewNodeId ∈ collectG5ProofRootIds cert := by
  unfold collectG5ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_left _ (List.mem_cons_self ..))))

private theorem obstList_sub_roots (cert : G5DischargeCert) {nid : String}
    (h : nid ∈ match cert.obstructionSpec.evidence with
               | .missingGuard _ _ (some id) => [id]
               | .scopedNoGoLocus _ _ id     => [id]
               | _                           => []) :
    nid ∈ collectG5ProofRootIds cert := by
  unfold collectG5ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_right _ h)))

private theorem repairList_sub_roots (cert : G5DischargeCert) (r : RepairDomEqCert)
    (hEq : cert.repairCert? = some r) {nid : String}
    (h : nid ∈ (match r.baseEquivStep with
                | .sameBaseDom _           => []
                | .qGuardNzToNonzero nzNid => [nzNid]
                | .nonzeroToQGuardNz nzNid => [nzNid]) ++
               r.oldGuardsDefNodeId?.toList ++
               r.oldEntailsNewGuardNodes.map Prod.snd ++
               r.newEntailsOldGuardNodes.map Prod.snd ++
               r.redundantGuardNodeId?.toList) :
    nid ∈ collectG5ProofRootIds cert := by
  unfold collectG5ProofRootIds
  rw [mem_canonSortStrs, hEq]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ h))

private theorem retreatList_sub_roots (cert : G5DischargeCert) (rt : G5RetreatPartitionCert)
    (hEq : cert.retreatCert? = some rt) {nid : String}
    (h : nid ∈ [rt.prefixDefNodeId] ++
               (match rt.guardConn with
                | .syntacticConcat => []
                | .mutualImplication d2n n2d => d2n.map Prod.snd ++ n2d.map Prod.snd) ++
               (match rt.reexprCert? with
                | none => []
                | some rx =>
                    rx.branchDefAndDisjNodes.foldr (fun (_, dId, jId) acc => dId :: jId :: acc) [] ++
                    rx.canonCoverWitnesses.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) []) ++
               rt.adoptedGuardNodeId?.toList) :
    nid ∈ collectG5ProofRootIds cert := by
  unfold collectG5ProofRootIds
  rw [mem_canonSortStrs, hEq]
  exact List.mem_append_left _ (List.mem_append_right _ h)

private theorem refineList_sub_roots (cert : G5DischargeCert) (rf : G5RefinementCert)
    (hEq : cert.refinementCert? = some rf) {nid : String}
    (h : nid ∈ rf.oldGuardsDefNodeId?.toList ++
               rf.oldEntailsNewGuardNodes.map Prod.snd ++
               rf.newEntailsOldGuardNodes.map Prod.snd ++
               rf.goalImpNodeId?.toList ++
               rf.adoptedGuardNodeId?.toList) :
    nid ∈ collectG5ProofRootIds cert := by
  unfold collectG5ProofRootIds
  rw [mem_canonSortStrs, hEq]
  exact List.mem_append_right _ h

/-! ### 2. Sub-Checker Soundness Lemmas (`G7` Sequent Bridge, Guard Entailment, `SemSameEffDom`) -/

/-- Whenever `nid ∈ collectG5ProofRootIds cert` passes `checkExactG7SequentBool`,
    `A0_05_4_SemanticDependencyClosure` yields `SemValidSequent` under `deriveG5PrimDeps`. -/
theorem exactG7Sequent_sound_of_root {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {cert : G5DischargeCert} {nid : String} {domTag : G7DomTag} {specId : String}
    {guards : List StrictForm} {conclusion : StrictForm}
    (hVal  : ValidContainer C)
    (hPrem : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hRoot : nid ∈ collectG5ProofRootIds cert)
    (hChk  : checkExactG7SequentBool fuel Γ C nid domTag specId guards conclusion = true) :
    SemValidSequent ⟨domTag, specId, guards, conclusion⟩ := by
  unfold checkExactG7SequentBool at hChk
  exact A0_05_4_SemanticDependencyClosure fuel Γ C (collectG5ProofRootIds cert) hVal hPrem
    nid hRoot ⟨domTag, specId, guards, conclusion⟩ (eq_of_beq hChk)

private theorem checkGuardEntailmentListBool_sound {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {cert : G5DischargeCert}
    {domSrc : G7DomTag} {specId : String} {guardsSrc targetGuards : List StrictForm}
    {pairs : List (StrictForm × String)}
    (hVal   : ValidContainer C)
    (hPrem  : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hRoots : ∀ nid ∈ pairs.map Prod.snd, nid ∈ collectG5ProofRootIds cert)
    (hChk   : checkGuardEntailmentListBool fuel Γ C domSrc specId guardsSrc targetGuards pairs = true) :
    ∀ ρ : Env2, inG7Dom domSrc ρ → (∀ g ∈ guardsSrc, ModelsStrictForm g ρ) →
      ∀ γ ∈ targetGuards, ModelsStrictForm γ ρ := by
  unfold checkGuardEntailmentListBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨hMapEq, hAllOk⟩
  intro ρ hDom hSatSrc γ hMemTarget
  rw [← eq_of_beq hMapEq] at hMemTarget
  rcases mem_map_fst_exists_pair hMemTarget with ⟨nid, hPairMem⟩
  have hNidInMap : nid ∈ pairs.map Prod.snd := List.mem_map_of_mem hPairMem
  have hSeqOk : checkExactG7SequentBool fuel Γ C nid domSrc specId guardsSrc γ = true :=
    List.all_eq_true.mp hAllOk (γ, nid) hPairMem
  have hSem := exactG7Sequent_sound_of_root hVal hPrem (hRoots nid hNidInMap) hSeqOk
  exact hSem.2 ρ hDom hSatSrc

private theorem checkSameEffDomCoreBool_sound {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {cert : G5DischargeCert}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {step : BaseDomEquivStep} {oldDefNid? : Option String}
    {oldToNew newToOld : List (StrictForm × String)}
    (hVal        : ValidContainer C)
    (hPrem       : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hNewTel     : ∀ ρ : Env2, inG7Dom D_new ρ → TelescopicGuardsDefined Γ_new ρ)
    (hStepRoots  : ∀ nid ∈ (match step with
                            | .sameBaseDom _        => []
                            | .qGuardNzToNonzero id => [id]
                            | .nonzeroToQGuardNz id => [id]),
                     nid ∈ collectG5ProofRootIds cert)
    (hDefRoots   : ∀ nid ∈ oldDefNid?.toList, nid ∈ collectG5ProofRootIds cert)
    (hO2NRoots   : ∀ nid ∈ oldToNew.map Prod.snd, nid ∈ collectG5ProofRootIds cert)
    (hN2ORoots   : ∀ nid ∈ newToOld.map Prod.snd, nid ∈ collectG5ProofRootIds cert)
    (hChk        : checkSameEffDomCoreBool fuel Γ C D_old Γ_old D_new Γ_new specNewId
                     step oldDefNid? oldToNew newToOld = true) :
    SemSameEffDom D_old Γ_old D_new Γ_new := by
  unfold checkSameEffDomCoreBool at hChk
  by_cases hSameSyntax : ((D_old == D_new) && (Γ_old == Γ_new)) = true
  · simp only [Bool.and_eq_true] at hSameSyntax
    rw [eq_of_beq hSameSyntax.1, eq_of_beq hSameSyntax.2]
    exact semSameEffDom_refl D_new Γ_new
  · rw [if_neg hSameSyntax] at hChk
    simp only [Bool.and_eq_true] at hChk
    rcases hChk with ⟨⟨⟨hBaseOk, hOldDefOk⟩, hO2N⟩, hN2O⟩
    have hOldTel : ∀ ρ : Env2, inG7Dom D_old ρ → TelescopicGuardsDefined Γ_old ρ := by
      cases Γ_old with
      | nil => intro _ _; trivial
      | cons g gs =>
          dsimp [List.isEmpty] at hOldDefOk
          cases hOpt : oldDefNid? with
          | none     => rw [hOpt] at hOldDefOk; nomatch hOldDefOk
          | some did =>
              rw [hOpt] at hOldDefOk
              have hRoot : did ∈ collectG5ProofRootIds cert := by
                apply hDefRoots did
                rw [hOpt]; exact List.mem_cons_self ..
              exact (exactG7Sequent_sound_of_root hVal hPrem hRoot hOldDefOk).1
    have hFwdGuards := checkGuardEntailmentListBool_sound hVal hPrem hO2NRoots hO2N
    have hBwdGuards := checkGuardEntailmentListBool_sound hVal hPrem hN2ORoots hN2O
    have hBaseIff :
        (∀ ρ : Env2, inG7Dom D_old ρ → (∀ g ∈ Γ_old, ModelsStrictForm g ρ) → inG7Dom D_new ρ) ∧
        (∀ ρ : Env2, inG7Dom D_new ρ → (∀ g ∈ Γ_new, ModelsStrictForm g ρ) → inG7Dom D_old ρ) := by
      cases step with
      | sameBaseDom D =>
          simp only [Bool.and_eq_true] at hBaseOk
          rw [eq_of_beq hBaseOk.1, eq_of_beq hBaseOk.2]
          exact ⟨fun _ h _ => h, fun _ h _ => h⟩
      | qGuardNzToNonzero nzNid =>
          simp only [Bool.and_eq_true] at hBaseOk
          rcases hBaseOk with ⟨⟨hdOld, hdNew⟩, hNzOk⟩
          rw [eq_of_beq hdOld, eq_of_beq hdNew]
          have hSemNz := exactG7Sequent_sound_of_root hVal hPrem
            (hStepRoots nzNid (List.mem_cons_self ..)) hNzOk
          refine ⟨?_, fun _ hDomNew _ => hDomNew.2⟩
          intro ρ hDomQ hSatOld
          have hNeq : ModelsStrictForm (.neqZero .varX) ρ := hSemNz.2 ρ hDomQ hSatOld
          rcases hNeq.2 with ⟨v, hv, hne⟩
          cases hv
          exact ⟨hne, hDomQ⟩
      | nonzeroToQGuardNz nzNid =>
          simp only [Bool.and_eq_true] at hBaseOk
          rcases hBaseOk with ⟨⟨hdOld, hdNew⟩, hNzOk⟩
          rw [eq_of_beq hdOld, eq_of_beq hdNew]
          have hSemNz := exactG7Sequent_sound_of_root hVal hPrem
            (hStepRoots nzNid (List.mem_cons_self ..)) hNzOk
          refine ⟨fun _ hDomOld _ => hDomOld.2, ?_⟩
          intro ρ hDomQ hSatNew
          have hNeq : ModelsStrictForm (.neqZero .varX) ρ := hSemNz.2 ρ hDomQ hSatNew
          rcases hNeq.2 with ⟨v, hv, hne⟩
          cases hv
          exact ⟨hne, hDomQ⟩
    intro ρ
    constructor
    · rintro ⟨hDomOld, _, hSatOld⟩
      have hDomNew : inG7Dom D_new ρ := hBaseIff.1 ρ hDomOld hSatOld
      exact ⟨hDomNew, hNewTel ρ hDomNew, hFwdGuards ρ hDomOld hSatOld⟩
    · rintro ⟨hDomNew, _, hSatNew⟩
      have hDomOld : inG7Dom D_old ρ := hBaseIff.2 ρ hDomNew hSatNew
      exact ⟨hDomOld, hOldTel ρ hDomOld, hBwdGuards ρ hDomNew hSatNew⟩

/-! ### 3. Obstruction-Resolution Soundness Helpers (Plain Variable Arguments) -/

private theorem repairObstMatch_sound {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {cert : G5DischargeCert} {rCert : RepairDomEqCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hVal      : ValidContainer C)
    (hPrem     : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hGoalAll  : ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ →
                   ModelsStrictForm cert.goalNew ρ)
    (hRedRoots : ∀ rnid ∈ rCert.redundantGuardNodeId?.toList,
                   rnid ∈ collectG5ProofRootIds cert) :
    ((match okind, ev with
      | .counterexamplePoint, .counterexamplePt obsPt =>
          rCert.redundantGuardNodeId?.isNone &&
          checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew obsPt &&
          (evalStrictFormRatCoord fuel cert.goalNew obsPt == FormEvalRes.satTrue)
      | .invalidCertificate, .invalidSosCert _ _ =>
          rCert.redundantGuardNodeId?.isNone
      | .missingAssumption true, .missingGuard candGuard none (some _) =>
          match rCert.redundantGuardNodeId? with
          | none      => false
          | some rnid => checkExactG7SequentBool fuel Γ C rnid cert.domOld
                           cert.specNewId cert.guardsOld candGuard
      | _, _ => false) = true) →
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 obsPt) ∧
         ModelsStrictForm cert.goalNew (ratCoordToEnv2 obsPt)
     | .invalidCertificate, .invalidSosCert _ _ =>
         ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm cert.goalNew ρ
     | .missingAssumption true, .missingGuard candGuard none _ =>
         (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm candGuard ρ) ∧
         (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm cert.goalNew ρ)
     | _, _ => False) := by
  intro hOk
  cases okind with
  | counterexamplePoint =>
      cases ev with
      | counterexamplePt obsPt =>
          dsimp only at hOk ⊢
          simp only [Bool.and_eq_true] at hOk
          rcases hOk with ⟨⟨_, hInNewPt⟩, hGoalPt⟩
          have hInNew := (checkInEffDomRatCoordBool_sound fuel cert.domNew cert.guardsNew
            obsPt hInNewPt).2.2
          have hWfPt : checkRatCoordWfBool obsPt = true := by
            unfold checkInEffDomRatCoordBool at hInNewPt
            simp only [Bool.and_eq_true] at hInNewPt
            exact hInNewPt.1.1
          exact ⟨hInNew, (evalStrictFormRatCoord_sound obsPt hWfPt fuel cert.goalNew).1
            (eq_of_beq hGoalPt)⟩
      | invalidSosCert _ _ => nomatch hOk
      | missingGuard _ _ _ => nomatch hOk
      | scopedNoGoLocus _ _ _ => nomatch hOk
  | invalidCertificate =>
      cases ev with
      | invalidSosCert _ _ => exact hGoalAll
      | counterexamplePt _ => nomatch hOk
      | missingGuard _ _ _ => nomatch hOk
      | scopedNoGoLocus _ _ _ => nomatch hOk
  | missingAssumption b =>
      cases b with
      | false =>
          cases ev <;> nomatch hOk
      | true =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | some _ => nomatch hOk
              | none =>
                  cases obstNid? with
                  | none => nomatch hOk
                  | some _ =>
                      dsimp only at hOk ⊢
                      cases hRedEq : rCert.redundantGuardNodeId? with
                      | none => rw [hRedEq] at hOk; nomatch hOk
                      | some rnid =>
                          rw [hRedEq] at hOk
                          have hRoot : rnid ∈ collectG5ProofRootIds cert := by
                            apply hRedRoots rnid
                            rw [hRedEq]; exact List.mem_cons_self ..
                          have hRedSem := exactG7Sequent_sound_of_root hVal hPrem hRoot hOk
                          exact ⟨fun ρ hOld => hRedSem.2 ρ hOld.1 hOld.2.2, hGoalAll⟩
          | counterexamplePt _ => nomatch hOk
          | invalidSosCert _ _ => nomatch hOk
          | scopedNoGoLocus _ _ _ => nomatch hOk
  | scopedNoGo => cases ev <;> nomatch hOk
  | unsupportedHorizon => cases ev <;> nomatch hOk
  | environmentalFailure => cases ev <;> nomatch hOk

private theorem retreatObstMatch_sound {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {cert : G5DischargeCert} {rt : G5RetreatPartitionCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hVal     : ValidContainer C)
    (hPrem    : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hPart    : SemExactScopeLossPartition cert.domOld cert.guardsOld cert.domNew cert.guardsNew
                  rt.excisedBranches)
    (hAdRoots : ∀ anid ∈ rt.adoptedGuardNodeId?.toList, anid ∈ collectG5ProofRootIds cert) :
    ((match okind, ev with
      | .counterexamplePoint, .counterexamplePt obsPt =>
          rt.adoptedGuardNodeId?.isNone &&
          checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld obsPt &&
          checkModelsExcisedRatCoordBool fuel rt.excisedBranches obsPt
      | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
          rt.adoptedGuardNodeId?.isNone &&
          checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld noGoPt &&
          checkModelsExcisedRatCoordBool fuel rt.excisedBranches noGoPt
      | .missingAssumption true, .missingGuard candGuard none (some _) =>
          match rt.adoptedGuardNodeId? with
          | none      => false
          | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                           cert.guardsNew candGuard
      | .missingAssumption false, .missingGuard candGuard (some failPt) none =>
          checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld failPt &&
          checkModelsExcisedRatCoordBool fuel rt.excisedBranches failPt &&
          match rt.adoptedGuardNodeId? with
          | none      => false
          | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                           cert.guardsNew candGuard
      | _, _ => false) = true) →
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 obsPt) ∧
         ModelsExcised rt.excisedBranches (ratCoordToEnv2 obsPt) ∧
         ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 obsPt)
     | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
         InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 noGoPt) ∧
         ModelsExcised rt.excisedBranches (ratCoordToEnv2 noGoPt) ∧
         ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 noGoPt)
     | .missingAssumption true, .missingGuard candGuard none _ =>
         ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ
     | .missingAssumption false, .missingGuard candGuard (some failPt) _ =>
         InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 failPt) ∧
         ModelsExcised rt.excisedBranches (ratCoordToEnv2 failPt) ∧
         ¬ InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 failPt) ∧
         (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ)
     | _, _ => False) := by
  intro hOk
  cases okind with
  | counterexamplePoint =>
      cases ev with
      | counterexamplePt obsPt =>
          dsimp only at hOk ⊢
          simp only [Bool.and_eq_true] at hOk
          rcases hOk with ⟨⟨_, hInOld⟩, hInExc⟩
          have hOldS := (checkInEffDomRatCoordBool_sound fuel cert.domOld cert.guardsOld obsPt hInOld).2.2
          have hExcS := checkModelsExcisedRatCoordBool_sound fuel rt.excisedBranches obsPt hInExc
          exact ⟨hOldS, hExcS, fun hN => hPart.disjoint_new_excised _ ⟨hN, hExcS⟩⟩
      | invalidSosCert _ _ => nomatch hOk
      | missingGuard _ _ _ => nomatch hOk
      | scopedNoGoLocus _ _ _ => nomatch hOk
  | scopedNoGo =>
      cases ev with
      | scopedNoGoLocus _ noGoPt _ =>
          dsimp only at hOk ⊢
          simp only [Bool.and_eq_true] at hOk
          rcases hOk with ⟨⟨_, hInOld⟩, hInExc⟩
          have hOldS := (checkInEffDomRatCoordBool_sound fuel cert.domOld cert.guardsOld noGoPt hInOld).2.2
          have hExcS := checkModelsExcisedRatCoordBool_sound fuel rt.excisedBranches noGoPt hInExc
          exact ⟨hOldS, hExcS, fun hN => hPart.disjoint_new_excised _ ⟨hN, hExcS⟩⟩
      | counterexamplePt _ => nomatch hOk
      | invalidSosCert _ _ => nomatch hOk
      | missingGuard _ _ _ => nomatch hOk
  | missingAssumption b =>
      cases b with
      | true =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | some _ => nomatch hOk
              | none =>
                  cases obstNid? with
                  | none => nomatch hOk
                  | some _ =>
                      dsimp only at hOk ⊢
                      cases hAdEq : rt.adoptedGuardNodeId? with
                      | none => rw [hAdEq] at hOk; nomatch hOk
                      | some anid =>
                          rw [hAdEq] at hOk
                          have hRoot : anid ∈ collectG5ProofRootIds cert := by
                            apply hAdRoots anid
                            rw [hAdEq]; exact List.mem_cons_self ..
                          have hAdSem := exactG7Sequent_sound_of_root hVal hPrem hRoot hOk
                          exact fun ρ hIn => hAdSem.2 ρ hIn.1 hIn.2.2
          | counterexamplePt _ => nomatch hOk
          | invalidSosCert _ _ => nomatch hOk
          | scopedNoGoLocus _ _ _ => nomatch hOk
      | false =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | none => nomatch hOk
              | some failPt =>
                  cases obstNid? with
                  | some _ => nomatch hOk
                  | none =>
                      dsimp only at hOk ⊢
                      simp only [Bool.and_eq_true] at hOk
                      rcases hOk with ⟨⟨hFailOld, hFailExc⟩, hAdOk⟩
                      cases hAdEq : rt.adoptedGuardNodeId? with
                      | none => rw [hAdEq] at hAdOk; nomatch hAdOk
                      | some anid =>
                          rw [hAdEq] at hAdOk
                          have hRoot : anid ∈ collectG5ProofRootIds cert := by
                            apply hAdRoots anid
                            rw [hAdEq]; exact List.mem_cons_self ..
                          have hAdSem := exactG7Sequent_sound_of_root hVal hPrem hRoot hAdOk
                          have hOldS := (checkInEffDomRatCoordBool_sound fuel cert.domOld
                            cert.guardsOld failPt hFailOld).2.2
                          have hExcS := checkModelsExcisedRatCoordBool_sound fuel rt.excisedBranches
                            failPt hFailExc
                          exact ⟨hOldS, hExcS,
                            fun hN => hPart.disjoint_new_excised _ ⟨hN, hExcS⟩,
                            fun ρ hIn => hAdSem.2 ρ hIn.1 hIn.2.2⟩
          | counterexamplePt _ => nomatch hOk
          | invalidSosCert _ _ => nomatch hOk
          | scopedNoGoLocus _ _ _ => nomatch hOk
  | invalidCertificate => cases ev <;> nomatch hOk
  | unsupportedHorizon => cases ev <;> nomatch hOk
  | environmentalFailure => cases ev <;> nomatch hOk

private theorem refineObstMatch_sound {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {cert : G5DischargeCert} {rf : G5RefinementCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hVal        : ValidContainer C)
    (hPrem       : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hOldGoalAll : ∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
                     ModelsStrictForm cert.goalOld ρ)
    (hAdRoots    : ∀ anid ∈ rf.adoptedGuardNodeId?.toList, anid ∈ collectG5ProofRootIds cert) :
    ((match okind, ev with
      | .invalidCertificate, .invalidSosCert _ _ =>
          rf.adoptedGuardNodeId?.isNone
      | .missingAssumption true, .missingGuard candGuard none (some _) =>
          match rf.adoptedGuardNodeId? with
          | none      => false
          | some anid => checkExactG7SequentBool fuel Γ C anid cert.domNew cert.specNewId
                           cert.guardsNew candGuard
      | _, _ => false) = true) →
    (match okind, ev with
     | .invalidCertificate, .invalidSosCert _ _ =>
         ∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm cert.goalOld ρ
     | .missingAssumption true, .missingGuard candGuard none _ =>
         (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ → ModelsStrictForm candGuard ρ) ∧
         (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ → ModelsStrictForm cert.goalOld ρ)
     | _, _ => False) := by
  intro hOk
  cases okind with
  | invalidCertificate =>
      cases ev with
      | invalidSosCert _ _ => exact hOldGoalAll
      | counterexamplePt _ => nomatch hOk
      | missingGuard _ _ _ => nomatch hOk
      | scopedNoGoLocus _ _ _ => nomatch hOk
  | missingAssumption b =>
      cases b with
      | false => cases ev <;> nomatch hOk
      | true =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | some _ => nomatch hOk
              | none =>
                  cases obstNid? with
                  | none => nomatch hOk
                  | some _ =>
                      dsimp only at hOk ⊢
                      cases hAdEq : rf.adoptedGuardNodeId? with
                      | none => rw [hAdEq] at hOk; nomatch hOk
                      | some anid =>
                          rw [hAdEq] at hOk
                          have hRoot : anid ∈ collectG5ProofRootIds cert := by
                            apply hAdRoots anid
                            rw [hAdEq]; exact List.mem_cons_self ..
                          have hAdSem := exactG7Sequent_sound_of_root hVal hPrem hRoot hOk
                          exact ⟨fun ρ hIn => hAdSem.2 ρ hIn.1 hIn.2.2, hOldGoalAll⟩
          | counterexamplePt _ => nomatch hOk
          | invalidSosCert _ _ => nomatch hOk
          | scopedNoGoLocus _ _ _ => nomatch hOk
  | counterexamplePoint => cases ev <;> nomatch hOk
  | scopedNoGo => cases ev <;> nomatch hOk
  | unsupportedHorizon => cases ev <;> nomatch hOk
  | environmentalFailure => cases ev <;> nomatch hOk

private theorem checkG5ObstReflexAllowedBool_sound (okind : KernelObstKindV1) (rk : ReflexKind)
    (h : checkG5ObstReflexAllowedBool okind rk = true) :
    G5ObstReflexAllowed okind rk := by
  cases okind with
  | counterexamplePoint => cases rk <;> first | trivial | nomatch h
  | invalidCertificate => cases rk <;> first | trivial | nomatch h
  | missingAssumption b => cases b <;> cases rk <;> first | trivial | nomatch h
  | scopedNoGo => cases rk <;> first | trivial | nomatch h
  | unsupportedHorizon => cases rk <;> nomatch h
  | environmentalFailure => cases rk <;> nomatch h

private theorem checkSosCertDefectiveBool_sound {fuel : Nat}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {goalOld : StrictForm}
    {badSos : PolyPositivstellensatzCert} {probePt : RatCoord2}
    (h : checkSosCertDefectiveBool fuel D_old Γ_old goalOld badSos probePt = true) :
    0 < probePt.xDenPos ∧ 0 < probePt.yDenPos ∧
    ¬ SemNecessarySosConditions D_old Γ_old goalOld badSos := by
  unfold checkSosCertDefectiveBool at h
  simp only [Bool.and_eq_true] at h
  rcases h with ⟨⟨hWf, _⟩, hDefect⟩
  rcases (checkRatCoordWfBool_iff probePt).mp hWf with ⟨hx, hy⟩
  refine ⟨hx, hy, ?_⟩
  rintro ⟨hScalePos, hConstNn, hSqNn, hPointwise⟩
  rcases Bool.or_eq_true_iff.mp hDefect with hLeft3 | hProbeBranch
  · rcases Bool.or_eq_true_iff.mp hLeft3 with hLeft2 | hNegSq
    · rcases Bool.or_eq_true_iff.mp hLeft2 with hZeroScale | hNegConst
      · have hz : badSos.lhsScale = 0 := eq_of_beq hZeroScale
        omega
      · have hc : badSos.constTerm < 0 := of_decide_eq_true hNegConst
        omega
    · rcases List.any_eq_true.mp hNegSq with ⟨wp, hMemWp, hLtWp⟩
      have hwLt : wp.1 < 0 := of_decide_eq_true hLtWp
      have hwNn : 0 ≤ wp.1 := hSqNn wp hMemWp
      omega
  · simp only [Bool.and_eq_true] at hProbeBranch
    rcases hProbeBranch with ⟨hInOldProbe, hGoalCase⟩
    have hInOld := (checkInEffDomRatCoordBool_sound fuel D_old Γ_old probePt hInOldProbe).2.2
    have hAtProbe := hPointwise (ratCoordToEnv2 probePt) hInOld
    cases goalOld with
    | nonneg _ => nomatch hGoalCase
    | neqZero _ => exact hAtProbe
    | conj _ _ => exact hAtProbe
    | impStrict _ _ => exact hAtProbe
    | pos _ =>
        simp only [Bool.and_eq_true] at hGoalCase
        have hPosEmpty : badSos.posMult = [] := List.isEmpty_iff.mp hGoalCase.1
        have hConstPos : 0 < badSos.constTerm := hAtProbe.1 hPosEmpty
        have hDecTrue : decide (0 < badSos.constTerm) = true := decide_eq_true hConstPos
        rw [hDecTrue] at hGoalCase
        nomatch hGoalCase.2
    | eqZero _ =>
        rcases Bool.or_eq_true_iff.mp hGoalCase with hConstNe | hSqNe
        · rw [hAtProbe.1] at hConstNe
          nomatch hConstNe
        · rw [hAtProbe.2.1] at hSqNe
          nomatch hSqNe

private theorem verifiedObstructionAux_sound {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {cert : G5DischargeCert}
    (obstCid cellOldCid specOldId : String)
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hVal      : ValidContainer C)
    (hPrem     : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hObstRoot : ∀ nid ∈ (match ev with
                          | .missingGuard _ _ (some id) => [id]
                          | .scopedNoGoLocus _ _ id     => [id]
                          | _                           => []),
                   nid ∈ collectG5ProofRootIds cert)
    (hChk : checkVerifiedObstructionBool fuel Γ C cert.domOld cert.guardsOld cert.goalOld
              cert.specNewId ⟨obstCid, cellOldCid, specOldId, okind, ev⟩ = true) :
    SemValidObstructionOnOld cert.domOld cert.guardsOld cert.goalOld
      ⟨obstCid, cellOldCid, specOldId, okind, ev⟩ := by
  unfold checkVerifiedObstructionBool at hChk
  unfold SemValidObstructionOnOld
  dsimp only at hChk ⊢
  cases okind with
  | counterexamplePoint =>
      cases ev with
      | counterexamplePt obsPt =>
          dsimp only at hChk ⊢
          simp only [Bool.and_eq_true] at hChk
          rcases hChk with ⟨hInOld, hFailOrUndef⟩
          rcases checkInEffDomRatCoordBool_sound fuel cert.domOld cert.guardsOld obsPt hInOld with
            ⟨hx, hy, hOldSem⟩
          have hWf : checkRatCoordWfBool obsPt = true :=
            (checkRatCoordWfBool_iff obsPt).mpr ⟨hx, hy⟩
          have hSnd := evalStrictFormRatCoord_sound obsPt hWf fuel cert.goalOld
          refine ⟨hx, hy, hOldSem, ?_⟩
          rcases Bool.or_eq_true_iff.mp hFailOrUndef with hDefFalse | hUndef
          · exact fun hM => (hSnd.2.1 (eq_of_beq hDefFalse)).2 hM.2
          · exact fun hM => hSnd.2.2 (eq_of_beq hUndef) hM.1
      | invalidSosCert _ _ => nomatch hChk
      | missingGuard _ _ _ => nomatch hChk
      | scopedNoGoLocus _ _ _ => nomatch hChk
  | invalidCertificate =>
      cases ev with
      | invalidSosCert _ _ => exact checkSosCertDefectiveBool_sound hChk
      | counterexamplePt _ => nomatch hChk
      | missingGuard _ _ _ => nomatch hChk
      | scopedNoGoLocus _ _ _ => nomatch hChk
  | missingAssumption b =>
      cases b with
      | true =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | some _ => nomatch hChk
              | none =>
                  cases obstNid? with
                  | none => nomatch hChk
                  | some obstNid =>
                      dsimp only at hChk ⊢
                      have hSem := exactG7Sequent_sound_of_root hVal hPrem
                        (hObstRoot obstNid (List.mem_cons_self ..)) hChk
                      exact fun ρ hOld => hSem.2 ρ hOld.1 hOld.2.2
          | counterexamplePt _ => nomatch hChk
          | invalidSosCert _ _ => nomatch hChk
          | scopedNoGoLocus _ _ _ => nomatch hChk
      | false =>
          cases ev with
          | missingGuard candGuard failPt? obstNid? =>
              cases failPt? with
              | none => nomatch hChk
              | some failPt =>
                  cases obstNid? with
                  | some _ => nomatch hChk
                  | none =>
                      dsimp only at hChk ⊢
                      simp only [Bool.and_eq_true] at hChk
                      rcases hChk with ⟨hInOld, hFailOrUndef⟩
                      rcases checkInEffDomRatCoordBool_sound fuel cert.domOld cert.guardsOld
                        failPt hInOld with ⟨hx, hy, hOldSem⟩
                      have hWf : checkRatCoordWfBool failPt = true :=
                        (checkRatCoordWfBool_iff failPt).mpr ⟨hx, hy⟩
                      have hSnd := evalStrictFormRatCoord_sound failPt hWf fuel candGuard
                      refine ⟨hx, hy, hOldSem, ?_⟩
                      rcases Bool.or_eq_true_iff.mp hFailOrUndef with hDefFalse | hUndef
                      · exact fun hM => (hSnd.2.1 (eq_of_beq hDefFalse)).2 hM.2
                      · exact fun hM => hSnd.2.2 (eq_of_beq hUndef) hM.1
          | counterexamplePt _ => nomatch hChk
          | invalidSosCert _ _ => nomatch hChk
          | scopedNoGoLocus _ _ _ => nomatch hChk
  | scopedNoGo =>
      cases ev with
      | scopedNoGoLocus locusGuards noGoPt noGoNid =>
          dsimp only at hChk ⊢
          simp only [Bool.and_eq_true] at hChk
          rcases hChk with ⟨⟨hAtomGoal, hInNoGo⟩, hNoGoSeq⟩
          rcases checkInEffDomRatCoordBool_sound fuel cert.domOld
            (cert.guardsOld ++ locusGuards) noGoPt hInNoGo with ⟨hx, hy, hNoGoSem⟩
          have hCompSem := exactG7Sequent_sound_of_root hVal hPrem
            (hObstRoot noGoNid (List.mem_cons_self ..)) hNoGoSeq
          refine ⟨hx, hy, hNoGoSem, ?_⟩
          intro ρ hInLocus hGoalTrue
          have hCompTrue : ModelsStrictForm (atomicComplement cert.goalOld) ρ :=
            hCompSem.2 ρ hInLocus.1 hInLocus.2.2
          rcases (atomicComplement_defined_xor hAtomGoal hGoalTrue.1).2 with
            ⟨_, hNotComp⟩ | ⟨hNotGoal, _⟩
          · exact hNotComp hCompTrue
          · exact hNotGoal hGoalTrue
      | counterexamplePt _ => nomatch hChk
      | invalidSosCert _ _ => nomatch hChk
      | missingGuard _ _ _ => nomatch hChk
  | unsupportedHorizon => cases ev <;> nomatch hChk
  | environmentalFailure => cases ev <;> nomatch hChk

/-! ### 4. Headline Theorems `T_B1_01` .. `T_B1_05` (`B1-A4`) -/

/-- **`T_B1_01_G5_NonEmptiness_Sound` (`B1-A4.1`)**:
    Whenever `checkG5DischargeBool fuel Γ C cert = true`, `cert.nonEmptyWitness.witnessCoord`
    is a well-formed rational coordinate strictly inhabiting `InEffDom cert.domNew cert.guardsNew`,
    certifying `∃ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ` (vacuous-truth domain collapse blocked). -/
theorem T_B1_01_G5_NonEmptiness_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (hAcc : checkG5DischargeBool fuel Γ C cert = true) :
    0 < cert.nonEmptyWitness.witnessCoord.xDenPos ∧
    0 < cert.nonEmptyWitness.witnessCoord.yDenPos ∧
    InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 cert.nonEmptyWitness.witnessCoord) ∧
    (∃ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ) := by
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  have hWitChk : checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew
      cert.nonEmptyWitness.witnessCoord = true := hAcc.2.1.1.2
  rcases checkInEffDomRatCoordBool_sound fuel cert.domNew cert.guardsNew
    cert.nonEmptyWitness.witnessCoord hWitChk with ⟨hx, hy, hIn⟩
  exact ⟨hx, hy, hIn, ⟨ratCoordToEnv2 cert.nonEmptyWitness.witnessCoord, hIn⟩⟩

/-- **`T_B1_01b_G5_DomNz_ImpNorm_Target_Sound` (`B1-01` Explicit Reuse of `L_B2B_DomNz` & `L_B2B_ImpNorm`)**:
    Whenever `SemValidG5Discharge cert` holds AND `checkGuardsAndGoalDomDefBool cert.domNew cert.guardsNew cert.goalNew = true`,
    the normalized strict implication `foldStrictImp cert.guardsNew cert.goalNew` is everywhere
    defined and universally satisfied across `inG7Dom cert.domNew`. -/
theorem T_B1_01b_G5_DomNz_ImpNorm_Target_Sound {cert : G5DischargeCert}
    (hSem : SemValidG5Discharge cert)
    (hDef : checkGuardsAndGoalDomDefBool cert.domNew cert.guardsNew cert.goalNew = true) :
    ∀ ρ : Env2, inG7Dom cert.domNew ρ →
      (∀ d ∈ intrinsicNzOfDom cert.domNew, ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0) ∧
      FormDefined (foldStrictImp cert.guardsNew cert.goalNew) ρ ∧
      ModelsStrictForm (foldStrictImp cert.guardsNew cert.goalNew) ρ := by
  intro ρ hDom
  have hNz := L_B2B_DomNz cert.domNew ρ hDom
  have hNorm := L_B2B_ImpNorm hDef ρ hDom
  exact ⟨hNz, hNorm.1.1, hNorm.2.mpr (hSem.validPostReflexTarget ρ)⟩

/-- **`T_B1_02_Repair_ExactEffDomEq_Sound` (`B1-A4.2` & `B1-03`)**:
    Under `ValidContainer C` and `SemValidPrimId` on `deriveG5PrimDeps Γ C cert`, any `Repair`
    certificate accepted by `checkG5DischargeBool` establishes exact bidirectional effective-domain
    equality `SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew`
    (`D_old,eff = D_new,eff`, blocking both silent domain shrinkage and silent domain expansion),
    `requiresRetreatHistory = false`, and `SemValidRepairDischarge cert`. -/
theorem T_B1_02_Repair_ExactEffDomEq_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (hVal  : ValidContainer C)
    (hAcc  : checkG5DischargeBool fuel Γ C cert = true)
    (hPrem : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hRk   : cert.reflexKind = .repair) :
    SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew ∧
    cert.requiresRetreatHistory = false ∧
    SemValidRepairDischarge cert := by
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  rcases hAcc with ⟨_, ⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hGoalNewOk⟩, hBranchOk⟩
  rw [hRk] at hBranchOk
  simp only [Bool.and_eq_true] at hBranchOk
  rcases hBranchOk with ⟨⟨⟨hNoRetHist, hRetNone⟩, hRefNone⟩, hRepOpt⟩
  cases hRepEq : cert.repairCert? with
  | none => rw [hRepEq] at hRepOpt; nomatch hRepOpt
  | some rCert =>
      rw [hRepEq] at hRepOpt
      have hGoalNewSem := exactG7Sequent_sound_of_root hVal hPrem
        (goalNewNodeId_mem_collectG5ProofRootIds cert) hGoalNewOk
      unfold checkRepairDomEqBool at hRepOpt
      simp only [Bool.and_eq_true] at hRepOpt
      rcases hRepOpt with ⟨hDomEqOk, hObstRepOk⟩
      have hSameDom : SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew := by
        apply checkSameEffDomCoreBool_sound hVal hPrem hGoalNewSem.1 _ _ _ _ hDomEqOk
        · intro nid hn
          exact repairList_sub_roots cert rCert hRepEq
            (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
              (List.mem_append_left _ hn))))
        · intro nid hn
          exact repairList_sub_roots cert rCert hRepEq
            (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
              (List.mem_append_right _ hn))))
        · intro nid hn
          exact repairList_sub_roots cert rCert hRepEq
            (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ hn)))
        · intro nid hn
          exact repairList_sub_roots cert rCert hRepEq
            (List.mem_append_left _ (List.mem_append_right _ hn))
      have hHistFalse : cert.requiresRetreatHistory = false := by
        cases hH : cert.requiresRetreatHistory with
        | false => rfl
        | true  => rw [hH] at hNoRetHist; nomatch hNoRetHist
      have hRetEqNone : cert.retreatCert? = none := Option.isNone_iff_eq_none.mp hRetNone
      have hRefEqNone : cert.refinementCert? = none := Option.isNone_iff_eq_none.mp hRefNone
      have hRepSome : cert.repairCert?.isSome = true := by rw [hRepEq]; rfl
      refine ⟨hSameDom, hHistFalse, ?_⟩
      unfold SemValidRepairDischarge
      refine ⟨hRepSome, hRetEqNone, hRefEqNone, hHistFalse, hSameDom, ?_⟩
      exact repairObstMatch_sound cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
        hVal hPrem (fun ρ hIn => hGoalNewSem.2 ρ hIn.1 hIn.2.2)
        (fun rnid hr => repairList_sub_roots cert rCert hRepEq (List.mem_append_right _ hr))
        hObstRepOk

private theorem checkExcisedReexprBool_sound {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {cert : G5DischargeCert}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {B_canon excisedBranches : ExcisedLocus} {rx : ExcisedReexprCert}
    (hVal      : ValidContainer C)
    (hPrem     : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hCanon    : SemExactScopeLossPartition D_old Γ_old D_new Γ_new B_canon)
    (hDJRoots  : ∀ nid ∈ rx.branchDefAndDisjNodes.foldr
                   (fun (_, dId, jId) acc => dId :: jId :: acc) [],
                   nid ∈ collectG5ProofRootIds cert)
    (hCovRoots : ∀ nid ∈ rx.canonCoverWitnesses.foldr
                   (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) [],
                   nid ∈ collectG5ProofRootIds cert)
    (hChk      : checkExcisedReexprBool fuel Γ C D_old Γ_old D_new Γ_new specNewId
                   B_canon excisedBranches rx = true) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_new excisedBranches := by
  unfold checkExcisedReexprBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨⟨⟨hExcMap, hAllDJ⟩, hCanonMap⟩, hAllCov⟩
  have hBranchProps : ∀ E_i ∈ excisedBranches,
      (∀ ρ : Env2, inG7Dom D_old ρ → TelescopicGuardsDefined (Γ_old ++ E_i) ρ) ∧
      (∀ ρ : Env2, InEffDom D_new Γ_new ρ → ¬ ModelsExcisedBranch E_i ρ) := by
    intro E_i hEMem
    rw [← eq_of_beq hExcMap] at hEMem
    rcases mem_map_fst_triple hEMem with ⟨defNid, disjNid, hTripMem⟩
    have hPairOk := List.all_eq_true.mp hAllDJ (E_i, defNid, disjNid) hTripMem
    simp only [Bool.and_eq_true] at hPairOk
    rcases mem_foldr_pair_ids rx.branchDefAndDisjNodes hTripMem with ⟨hDefIn, hDisjIn⟩
    have hDefSem := exactG7Sequent_sound_of_root hVal hPrem (hDJRoots defNid hDefIn) hPairOk.1
    have hDisjSem := exactG7Sequent_sound_of_root hVal hPrem (hDJRoots disjNid hDisjIn) hPairOk.2
    refine ⟨hDefSem.1, ?_⟩
    intro ρ hInNew hExcBr
    have hZeroPos : ModelsStrictForm (.pos (.const 0)) ρ := by
      apply hDisjSem.2 ρ hInNew.1
      intro φ hPhi
      rcases List.mem_append.mp hPhi with hInG | hInE
      · exact hInNew.2.2 φ hInG
      · exact hExcBr.2 φ hInE
    rcases hZeroPos.2 with ⟨v, hv, hpos⟩
    cases hv
    exact Rat.lt_irrefl hpos
  apply mkSemExactScopeLossPartition
  · rintro ρ ⟨hInNew, ⟨E_i, hEMem, hEBr⟩⟩
    exact (hBranchProps E_i hEMem).2 ρ hInNew hEBr
  · intro ρ hInOld
    rcases hCanon.old_covered_by_new_or_excised ρ hInOld with hInNew | ⟨B_j, hBMem, hBBr⟩
    · exact Or.inl hInNew
    · rw [← eq_of_beq hCanonMap] at hBMem
      rcases mem_map_fst_triple hBMem with ⟨E_target, psiNodes, hCovMem⟩
      have hCovOk := List.all_eq_true.mp hAllCov (B_j, E_target, psiNodes) hCovMem
      simp only [Bool.and_eq_true] at hCovOk
      have hETargetMem : E_target ∈ excisedBranches := List.contains_iff_mem.mp hCovOk.1
      have hEntails := checkGuardEntailmentListBool_sound hVal hPrem
        (fun nid hn => hCovRoots nid (mem_foldr_cover_ids rx.canonCoverWitnesses hCovMem hn))
        hCovOk.2
      have hTelAll : TelescopicGuardsDefined (Γ_old ++ E_target) ρ :=
        (hBranchProps E_target hETargetMem).1 ρ hInOld.1
      have hTelE : TelescopicGuardsDefined E_target ρ :=
        ((telescopicGuardsDefined_append_iff Γ_old E_target ρ).mp hTelAll).2 hInOld.2.2
      exact Or.inr ⟨E_target, hETargetMem, hTelE, hEntails ρ hInOld.1 hBBr.2⟩
  · exact hCanon.new_subset_old

/-- **`T_B1_03_Retreat_ExactScopeLossPartition_Sound` (`B1-A4.3` & `B1-04`)**:
    Under `ValidContainer C` and `SemValidPrimId` on `deriveG5PrimDeps Γ C cert`, any `Retreat`
    certificate `rt` accepted by `checkG5DischargeBool` establishes:
    (1) Exact scope-loss partition `SemExactScopeLossPartition` via `L_B2B_TelescopicPartition_from_G7`,
    (2) Genuine strict scope loss (`strictLossWitness ∈ D_old,eff \ D_new,eff`),
    (3) Conditional preservation of all supplied `claimedRetentionAnchors` in `D_new,eff`,
    (4) Explicit output obligation `cert.requiresRetreatHistory = true`, and
    (5) `SemValidRetreatDischarge cert`. -/
theorem T_B1_03_Retreat_ExactScopeLossPartition_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (hVal  : ValidContainer C)
    (hAcc  : checkG5DischargeBool fuel Γ C cert = true)
    (hPrem : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hRk   : cert.reflexKind = .retreat) :
    ∃ rt : G5RetreatPartitionCert,
      cert.retreatCert? = some rt ∧
      SemExactScopeLossPartition cert.domOld cert.guardsOld cert.domNew cert.guardsNew
        rt.excisedBranches ∧
      (∃ ρ_lost : Env2, InEffDom cert.domOld cert.guardsOld ρ_lost ∧
        ModelsExcised rt.excisedBranches ρ_lost ∧
        ¬ InEffDom cert.domNew cert.guardsNew ρ_lost) ∧
      (∀ pt_a ∈ rt.claimedRetentionAnchors,
        InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 pt_a)) ∧
      cert.requiresRetreatHistory = true ∧
      SemValidRetreatDischarge cert := by
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  rcases hAcc with ⟨_, ⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hGoalNewOk⟩, hBranchOk⟩
  rw [hRk] at hBranchOk
  simp only [Bool.and_eq_true] at hBranchOk
  rcases hBranchOk with ⟨⟨⟨hRetHist, hRepNone⟩, hRefNone⟩, hRetOpt⟩
  cases hRtEq : cert.retreatCert? with
  | none => rw [hRtEq] at hRetOpt; nomatch hRetOpt
  | some rt =>
      rw [hRtEq] at hRetOpt
      have hGoalNewSem := exactG7Sequent_sound_of_root hVal hPrem
        (goalNewNodeId_mem_collectG5ProofRootIds cert) hGoalNewOk
      unfold checkRetreatExactPartitionBool at hRetOpt
      simp only [Bool.and_eq_true] at hRetOpt
      rcases hRetOpt with
        ⟨⟨⟨⟨⟨⟨⟨⟨hBaseStep, hAtoms⟩, hPrefixOk⟩, hConnOk⟩, hExcOk⟩,
            hLossInOld⟩, hLossInExc⟩, hAnchorsOk⟩, hObstRetOk⟩
      have hPrefixRoot : rt.prefixDefNodeId ∈ collectG5ProofRootIds cert :=
        retreatList_sub_roots cert rt hRtEq
          (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
            (List.mem_cons_self ..))))
      have hPrefixAcc : verifyReachableDerivation fuel Γ C rt.prefixDefNodeId =
          .accept ⟨cert.domNew, cert.specNewId, cert.guardsOld ++ rt.deltaGuards,
                   .eqZero (.const 0)⟩ := eq_of_beq hPrefixOk
      have hPrefixPrem : ∀ p ∈ extractTransitivePrimDeps Γ C rt.prefixDefNodeId,
          SemValidPrimId Γ p :=
        fun p hp => hPrem p (mem_multiRootTransitivePrimDeps Γ C hPrefixRoot hp)
      have hPrefixSem := exactG7Sequent_sound_of_root hVal hPrem hPrefixRoot hPrefixOk
      have hGuardConn : SemSameEffDom cert.domNew cert.guardsNew cert.domNew
          (cert.guardsOld ++ rt.deltaGuards) := by
        cases hConnMode : rt.guardConn with
        | syntacticConcat =>
            rw [hConnMode] at hConnOk
            rw [eq_of_beq hConnOk]
            exact semSameEffDom_refl cert.domNew (cert.guardsOld ++ rt.deltaGuards)
        | mutualImplication d2n n2d =>
            rw [hConnMode] at hConnOk
            simp only [Bool.and_eq_true] at hConnOk
            have hD2N := checkGuardEntailmentListBool_sound hVal hPrem
              (fun nid hn => retreatList_sub_roots cert rt hRtEq
                (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _
                  (by rw [hConnMode]; exact List.mem_append_left _ hn)))))
              hConnOk.1
            have hN2D := checkGuardEntailmentListBool_sound hVal hPrem
              (fun nid hn => retreatList_sub_roots cert rt hRtEq
                (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _
                  (by rw [hConnMode]; exact List.mem_append_right _ hn)))))
              hConnOk.2
            intro ρ
            constructor
            · rintro ⟨hDom, _, hSatNew⟩
              exact ⟨hDom, hPrefixSem.1 ρ hDom, hN2D ρ hDom hSatNew⟩
            · rintro ⟨hDom, _, hSatDelta⟩
              exact ⟨hDom, hGoalNewSem.1 ρ hDom, hD2N ρ hDom hSatDelta⟩
      have hCanonPart : SemExactScopeLossPartition cert.domOld cert.guardsOld
          cert.domNew cert.guardsNew
          (buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards) :=
        L_B2B_TelescopicPartition_from_G7 hVal hBaseStep hAtoms hPrefixAcc hPrefixPrem hGuardConn
      have hExactPart : SemExactScopeLossPartition cert.domOld cert.guardsOld
          cert.domNew cert.guardsNew rt.excisedBranches := by
        cases hRxEq : rt.reexprCert? with
        | none =>
            rw [hRxEq] at hExcOk
            rw [eq_of_beq hExcOk]
            exact hCanonPart
        | some rx =>
            rw [hRxEq] at hExcOk
            exact checkExcisedReexprBool_sound hVal hPrem hCanonPart
              (fun nid hn => retreatList_sub_roots cert rt hRtEq
                (List.mem_append_left _ (List.mem_append_right _
                  (by rw [hRxEq]; exact List.mem_append_left _ hn))))
              (fun nid hn => retreatList_sub_roots cert rt hRtEq
                (List.mem_append_left _ (List.mem_append_right _
                  (by rw [hRxEq]; exact List.mem_append_right _ hn))))
              hExcOk
      rcases checkInEffDomRatCoordBool_sound fuel cert.domOld cert.guardsOld
        rt.strictLossWitness hLossInOld with ⟨hxLoss, hyLoss, hLossOldSem⟩
      have hLossExcSem := checkModelsExcisedRatCoordBool_sound fuel rt.excisedBranches
        rt.strictLossWitness hLossInExc
      have hLossNotNew : ¬ InEffDom cert.domNew cert.guardsNew
          (ratCoordToEnv2 rt.strictLossWitness) :=
        fun hNew => hExactPart.disjoint_new_excised _ ⟨hNew, hLossExcSem⟩
      have hAnchorsSem : ∀ pt_a ∈ rt.claimedRetentionAnchors,
          0 < pt_a.xDenPos ∧ 0 < pt_a.yDenPos ∧
          InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 pt_a) := by
        intro pt_a hMemA
        exact checkInEffDomRatCoordBool_sound fuel cert.domNew cert.guardsNew pt_a
          (List.all_eq_true.mp hAnchorsOk pt_a hMemA)
      have hRepEqNone : cert.repairCert? = none := Option.isNone_iff_eq_none.mp hRepNone
      have hRefEqNone : cert.refinementCert? = none := Option.isNone_iff_eq_none.mp hRefNone
      have hSemRet : SemValidRetreatDischarge cert := by
        unfold SemValidRetreatDischarge
        rw [hRtEq]
        exact ⟨hRepEqNone, hRefEqNone, hRetHist, hxLoss, hyLoss, hExactPart,
          hLossOldSem, hLossExcSem, hLossNotNew, hAnchorsSem,
          retreatObstMatch_sound cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
            hVal hPrem hExactPart
            (fun anid ha => retreatList_sub_roots cert rt hRtEq (List.mem_append_right _ ha))
            hObstRetOk⟩
      exact ⟨rt, rfl, hExactPart,
        ⟨ratCoordToEnv2 rt.strictLossWitness, hLossOldSem, hLossExcSem, hLossNotNew⟩,
        fun pt_a hM => (hAnchorsSem pt_a hM).2.2, hRetHist, hSemRet⟩

private theorem checkBaseDomExpandStepBool_sound {step : BaseDomExpandStep}
    {D_old D_new : G7DomTag} (h : checkBaseDomExpandStepBool step D_old D_new = true) :
    ∀ ρ : Env2, inG7Dom D_old ρ → inG7Dom D_new ρ := by
  cases step with
  | sameBaseDom D =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ hDom => hDom
  | qNonzeroToQ =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ hDom => hDom.2
  | qToQ2 =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ _ => trivial
  | qNonzeroToQ2 =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ _ => trivial
  | finiteGridSup L_old L_new =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rcases h with ⟨⟨hOld, hNew⟩, hSub⟩
      rw [eq_of_beq hOld, eq_of_beq hNew]
      rintro ρ ⟨p, hpMem, hpEq⟩
      exact ⟨p, List.contains_iff_mem.mp (List.all_eq_true.mp hSub p hpMem), hpEq⟩

/-- **`T_B1_04_Refinement_ConservativePreservation_Sound` (`B1-A4.4` & `B1-05`)**:
    Under `ValidContainer C` and `SemValidPrimId` on `deriveG5PrimDeps Γ C cert`, any `Refinement`
    certificate `rf` accepted by `checkG5DischargeBool` establishes:
    (1) Conservative effective-domain inclusion `D_old,eff ⊆ D_new,eff`,
    (2) Conservative goal entailment `∀ ρ ∈ D_new,eff, P_new(ρ) → P_old(ρ)`
        (and hence `∀ ρ ∈ D_old,eff, P_old(ρ)`),
    (3) Exact scope-expansion accounting, and
    (4) `SemValidRefinementDischarge cert`. -/
theorem T_B1_04_Refinement_ConservativePreservation_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (hVal  : ValidContainer C)
    (hAcc  : checkG5DischargeBool fuel Γ C cert = true)
    (hPrem : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid)
    (hRk   : cert.reflexKind = .refinement) :
    (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
      InEffDom cert.domNew cert.guardsNew ρ) ∧
    (∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ →
      ModelsStrictForm cert.goalNew ρ → ModelsStrictForm cert.goalOld ρ) ∧
    (∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
      ModelsStrictForm cert.goalOld ρ) ∧
    SemValidRefinementDischarge cert := by
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  rcases hAcc with ⟨_, ⟨⟨⟨⟨_, _⟩, _⟩, _⟩, hGoalNewOk⟩, hBranchOk⟩
  rw [hRk] at hBranchOk
  simp only [Bool.and_eq_true] at hBranchOk
  rcases hBranchOk with ⟨⟨⟨hNoRetHist, hRepNone⟩, hRetNone⟩, hRefOpt⟩
  cases hRfEq : cert.refinementCert? with
  | none => rw [hRfEq] at hRefOpt; nomatch hRefOpt
  | some rf =>
      rw [hRfEq] at hRefOpt
      have hGoalNewSem := exactG7Sequent_sound_of_root hVal hPrem
        (goalNewNodeId_mem_collectG5ProofRootIds cert) hGoalNewOk
      unfold checkRefinementBool at hRefOpt
      simp only [Bool.and_eq_true] at hRefOpt
      rcases hRefOpt with ⟨⟨⟨⟨hBaseExp, hInclGuards⟩, hGoalImp⟩, hScopeAcc⟩, hObstRefOk⟩
      have hBaseIncl := checkBaseDomExpandStepBool_sound hBaseExp
      have hDomIncl : ∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
          InEffDom cert.domNew cert.guardsNew ρ := by
        intro ρ ⟨hDomOld, _, hSatOld⟩
        have hDomNew : inG7Dom cert.domNew ρ := hBaseIncl ρ hDomOld
        refine ⟨hDomNew, hGoalNewSem.1 ρ hDomNew, ?_⟩
        by_cases hSameG : (cert.guardsNew == cert.guardsOld) = true
        · rw [eq_of_beq hSameG]
          exact hSatOld
        · rw [if_neg hSameG] at hInclGuards
          have hEntails := checkGuardEntailmentListBool_sound hVal hPrem
            (fun nid hn => refineList_sub_roots cert rf hRfEq
              (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                (List.mem_append_right _ hn)))))
            hInclGuards
          exact hEntails ρ hDomOld hSatOld
      have hGoalCons : ∀ ρ : Env2, InEffDom cert.domNew cert.guardsNew ρ →
          ModelsStrictForm cert.goalNew ρ → ModelsStrictForm cert.goalOld ρ := by
        cases hImpEq : rf.goalImpNodeId? with
        | none =>
            rw [hImpEq] at hGoalImp
            rw [← eq_of_beq hGoalImp]
            exact fun _ _ hM => hM
        | some impNid =>
            rw [hImpEq] at hGoalImp
            have hRootImp : impNid ∈ collectG5ProofRootIds cert := by
              apply refineList_sub_roots cert rf hRfEq
              apply List.mem_append_left
              apply List.mem_append_right
              rw [hImpEq]; exact List.mem_cons_self ..
            have hImpSem := exactG7Sequent_sound_of_root hVal hPrem hRootImp hGoalImp
            intro ρ hInNew hSatGoalNew
            apply hImpSem.2 ρ hInNew.1
            intro φ hPhi
            rcases List.mem_append.mp hPhi with hInG | hInGoal
            · exact hInNew.2.2 φ hInG
            · rcases List.mem_cons.mp hInGoal with rfl | hNil
              · exact hSatGoalNew
              · nomatch hNil
      have hOldGoalAll : ∀ ρ : Env2, InEffDom cert.domOld cert.guardsOld ρ →
          ModelsStrictForm cert.goalOld ρ := by
        intro ρ hOld
        have hNew := hDomIncl ρ hOld
        exact hGoalCons ρ hNew (hGoalNewSem.2 ρ hNew.1 hNew.2.2)
      have hScopeSem :
          if rf.scopeExpanded then
            ∃ pt_exp : RatCoord2,
              rf.expansionWitness? = some pt_exp ∧
              0 < pt_exp.xDenPos ∧ 0 < pt_exp.yDenPos ∧
              InEffDom cert.domNew cert.guardsNew (ratCoordToEnv2 pt_exp) ∧
              ¬ InEffDom cert.domOld cert.guardsOld (ratCoordToEnv2 pt_exp)
          else
            rf.expansionWitness? = none ∧
            SemSameEffDom cert.domOld cert.guardsOld cert.domNew cert.guardsNew := by
        cases hExp : rf.scopeExpanded with
        | true =>
            rw [hExp] at hScopeAcc
            simp only [ite_true, Bool.and_eq_true] at hScopeAcc ⊢
            rcases hScopeAcc with ⟨⟨_, _⟩, hWitOpt⟩
            cases hW : rf.expansionWitness? with
            | none => rw [hW] at hWitOpt; nomatch hWitOpt
            | some pt_exp =>
                rw [hW] at hWitOpt
                simp only [Bool.and_eq_true] at hWitOpt
                rcases checkInEffDomRatCoordBool_sound fuel cert.domNew cert.guardsNew
                  pt_exp hWitOpt.1 with ⟨hx, hy, hInNewExp⟩
                have hNotOldExp := (checkNotInEffDomRatCoordBool_sound fuel cert.domOld
                  cert.guardsOld pt_exp hWitOpt.2).2.2
                exact ⟨pt_exp, rfl, hx, hy, hInNewExp, hNotOldExp⟩
        | false =>
            rw [hExp] at hScopeAcc
            simp only [Bool.false_eq_true, ite_false, Bool.and_eq_true] at hScopeAcc ⊢
            rcases hScopeAcc with ⟨hWitNone, hSameOk⟩
            refine ⟨Option.isNone_iff_eq_none.mp hWitNone, ?_⟩
            cases hStepEq : rf.baseExpandStep with
            | sameBaseDom D =>
                rw [hStepEq] at hSameOk
                apply checkSameEffDomCoreBool_sound hVal hPrem hGoalNewSem.1 _ _ _ _ hSameOk
                · intro _ hn; nomatch hn
                · intro nid hn
                  exact refineList_sub_roots cert rf hRfEq
                    (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                      (List.mem_append_left _ hn))))
                · intro nid hn
                  by_cases hG : (cert.guardsNew == cert.guardsOld) = true
                  · rw [if_pos hG] at hn; nomatch hn
                  · rw [if_neg hG] at hn
                    exact refineList_sub_roots cert rf hRfEq
                      (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                        (List.mem_append_right _ hn))))
                · intro nid hn
                  exact refineList_sub_roots cert rf hRfEq
                    (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ hn)))
            | qNonzeroToQ => rw [hStepEq] at hSameOk; nomatch hSameOk
            | qToQ2 => rw [hStepEq] at hSameOk; nomatch hSameOk
            | qNonzeroToQ2 => rw [hStepEq] at hSameOk; nomatch hSameOk
            | finiteGridSup _ _ => rw [hStepEq] at hSameOk; nomatch hSameOk
      have hHistFalse : cert.requiresRetreatHistory = false := by
        cases hH : cert.requiresRetreatHistory with
        | false => rfl
        | true  => rw [hH] at hNoRetHist; nomatch hNoRetHist
      have hRepEqNone : cert.repairCert? = none := Option.isNone_iff_eq_none.mp hRepNone
      have hRetEqNone : cert.retreatCert? = none := Option.isNone_iff_eq_none.mp hRetNone
      have hSemRef : SemValidRefinementDischarge cert := by
        unfold SemValidRefinementDischarge
        rw [hRfEq]
        exact ⟨hRepEqNone, hRetEqNone, hHistFalse, hDomIncl, hGoalCons, hScopeSem,
          refineObstMatch_sound cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
            hVal hPrem hOldGoalAll
            (fun anid ha => refineList_sub_roots cert rf hRfEq (List.mem_append_right _ ha))
            hObstRefOk⟩
      exact ⟨hDomIncl, hGoalCons, hOldGoalAll, hSemRef⟩

/-- **`T_B1_05_Obstruction_GenuineDischarge_Sound` (`B1-A4.5`)**:
    Whenever `checkG5DischargeBool fuel Γ C cert = true` holds under `ValidContainer C` and
    `SemValidPrimId` on `deriveG5PrimDeps Γ C cert`, BOTH:
    (1) `(cert.obstructionSpec.obstKind, cert.reflexKind)` satisfies `G5ObstReflexAllowed`
        (and hence `P1B1`'s `ObstReflexMatrixAllowed` with `obstKind ≠ .environmentalFailure`), AND
    (2) `cert.obstructionSpec` is a genuinely verified semantic obstruction on the old state
        (`SemValidObstructionOnOld cert.domOld cert.guardsOld cert.goalOld cert.obstructionSpec`). -/
theorem T_B1_05_Obstruction_GenuineDischarge_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (hVal  : ValidContainer C)
    (hAcc  : checkG5DischargeBool fuel Γ C cert = true)
    (hPrem : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid) :
    G5ObstReflexAllowed cert.obstructionSpec.obstKind cert.reflexKind ∧
    cert.obstructionSpec.obstKind ≠ .environmentalFailure ∧
    ObstReflexMatrixAllowed cert.obstructionSpec.obstKind cert.reflexKind ∧
    SemValidObstructionOnOld cert.domOld cert.guardsOld cert.goalOld cert.obstructionSpec := by
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  rcases hAcc with ⟨_, ⟨⟨⟨⟨_, hAllowBool⟩, hObstBool⟩, _⟩, _⟩, _⟩
  have hAllow := checkG5ObstReflexAllowedBool_sound cert.obstructionSpec.obstKind
    cert.reflexKind hAllowBool
  rcases g5ObstReflexAllowed_implies_p1b1_matrix hAllow with ⟨hNotEnv, hMat⟩
  refine ⟨hAllow, hNotEnv, hMat, ?_⟩
  rcases hSpecEq : cert.obstructionSpec with ⟨obstCid, cellOldCid, specOldId, okind, ev⟩
  exact verifiedObstructionAux_sound obstCid cellOldCid specOldId okind ev hVal hPrem
    (fun nid hn => obstList_sub_roots cert (by rw [hSpecEq]; exact hn))
    (by rw [hSpecEq] at hObstBool; exact hObstBool)

/-! ### 5. Proof-Root & Transitive Dependency Closure Completeness (`T_B1_06`) -/

private theorem bool_and_congr {a1 a2 b1 b2 : Bool} (ha : a1 = a2) (hb : b1 = b2) :
    (a1 && b1) = (a2 && b2) := by
  rw [ha, hb]

private theorem list_all_congr {α : Type} :
    ∀ (L : List α) {p q : α → Bool}, (∀ x ∈ L, p x = q x) → L.all p = L.all q
  | [],      _, _, _ => rfl
  | a :: as, _, _, h => by
      simp only [List.all_cons]
      rw [h a (List.mem_cons_self ..),
          list_all_congr as (fun x hx => h x (List.mem_cons_of_mem a hx))]

private theorem checkGuardEntailmentListBool_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {domSrc : G7DomTag} {specId : String} {guardsSrc targetGuards : List StrictForm}
    {pairs : List (StrictForm × String)}
    (hEq : ∀ nid ∈ pairs.map Prod.snd,
      verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) :
    checkGuardEntailmentListBool fuel Γ1 C1 domSrc specId guardsSrc targetGuards pairs =
    checkGuardEntailmentListBool fuel Γ2 C2 domSrc specId guardsSrc targetGuards pairs := by
  unfold checkGuardEntailmentListBool
  congr 1
  induction pairs with
  | nil => rfl
  | cons gn rest ih =>
      dsimp only [List.all]
      have hHead : checkExactG7SequentBool fuel Γ1 C1 gn.2 domSrc specId guardsSrc gn.1 =
          checkExactG7SequentBool fuel Γ2 C2 gn.2 domSrc specId guardsSrc gn.1 := by
        unfold checkExactG7SequentBool
        rw [hEq gn.2 (List.mem_cons_self ..)]
      rw [hHead, ih (fun nid hn => hEq nid (List.mem_cons_of_mem _ hn))]

private theorem checkSameEffDomCoreBool_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {step : BaseDomEquivStep} {oldDefNid? : Option String}
    {oldToNew newToOld : List (StrictForm × String)} :
    (∀ nid ∈ (match step with
              | .sameBaseDom _        => []
              | .qGuardNzToNonzero id => [id]
              | .nonzeroToQGuardNz id => [id]),
       verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
    (∀ nid ∈ oldDefNid?.toList,
       verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
    (∀ nid ∈ oldToNew.map Prod.snd,
       verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
    (∀ nid ∈ newToOld.map Prod.snd,
       verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
    checkSameEffDomCoreBool fuel Γ1 C1 D_old Γ_old D_new Γ_new specNewId
      step oldDefNid? oldToNew newToOld =
    checkSameEffDomCoreBool fuel Γ2 C2 D_old Γ_old D_new Γ_new specNewId
      step oldDefNid? oldToNew newToOld := by
  have hBaseCongrAux :
      (∀ nid ∈ (match step with
                | .sameBaseDom _        => []
                | .qGuardNzToNonzero id => [id]
                | .nonzeroToQGuardNz id => [id]),
         verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
      (match step with
       | .sameBaseDom D => (D_old == D) && (D_new == D)
       | .qGuardNzToNonzero nzNid =>
           (D_old == G7DomTag.domQ) && (D_new == G7DomTag.domQNonzero) &&
           checkExactG7SequentBool fuel Γ1 C1 nzNid G7DomTag.domQ specNewId Γ_old (.neqZero .varX)
       | .nonzeroToQGuardNz nzNid =>
           (D_old == G7DomTag.domQNonzero) && (D_new == G7DomTag.domQ) &&
           checkExactG7SequentBool fuel Γ1 C1 nzNid G7DomTag.domQ specNewId Γ_new (.neqZero .varX)) =
      (match step with
       | .sameBaseDom D => (D_old == D) && (D_new == D)
       | .qGuardNzToNonzero nzNid =>
           (D_old == G7DomTag.domQ) && (D_new == G7DomTag.domQNonzero) &&
           checkExactG7SequentBool fuel Γ2 C2 nzNid G7DomTag.domQ specNewId Γ_old (.neqZero .varX)
       | .nonzeroToQGuardNz nzNid =>
           (D_old == G7DomTag.domQNonzero) && (D_new == G7DomTag.domQ) &&
           checkExactG7SequentBool fuel Γ2 C2 nzNid G7DomTag.domQ specNewId Γ_new (.neqZero .varX)) := by
    cases step with
    | sameBaseDom _ => intro _; rfl
    | qGuardNzToNonzero nzNid =>
        intro hS; dsimp only; unfold checkExactG7SequentBool
        rw [hS nzNid (List.mem_cons_self ..)]
    | nonzeroToQGuardNz nzNid =>
        intro hS; dsimp only; unfold checkExactG7SequentBool
        rw [hS nzNid (List.mem_cons_self ..)]
  have hDefCongrAux :
      (∀ nid ∈ oldDefNid?.toList,
         verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) →
      (if Γ_old.isEmpty then oldDefNid?.isNone
       else match oldDefNid? with
            | none => false
            | some did => checkExactG7SequentBool fuel Γ1 C1 did D_old specNewId Γ_old (.eqZero (.const 0))) =
      (if Γ_old.isEmpty then oldDefNid?.isNone
       else match oldDefNid? with
            | none => false
            | some did => checkExactG7SequentBool fuel Γ2 C2 did D_old specNewId Γ_old (.eqZero (.const 0))) := by
    by_cases hE : Γ_old.isEmpty = true
    · intro _; rw [if_pos hE, if_pos hE]
    · rw [if_neg hE, if_neg hE]
      cases oldDefNid? with
      | none => intro _; rfl
      | some did =>
          intro hD
          dsimp [Option.toList] at hD ⊢
          unfold checkExactG7SequentBool
          rw [hD did (List.mem_cons_self ..)]
  intro hStepEq hDefEq hO2NEq hN2OEq
  unfold checkSameEffDomCoreBool
  have hBaseCongr := hBaseCongrAux hStepEq
  have hDefCongr := hDefCongrAux hDefEq
  dsimp only
  by_cases hSame : ((D_old == D_new) && (Γ_old == Γ_new)) = true
  · rw [if_pos hSame, if_pos hSame]
    exact bool_and_congr (bool_and_congr (bool_and_congr hBaseCongr rfl) rfl) rfl
  · rw [if_neg hSame, if_neg hSame]
    exact bool_and_congr
      (bool_and_congr (bool_and_congr hBaseCongr hDefCongr)
        (checkGuardEntailmentListBool_congr hO2NEq))
      (checkGuardEntailmentListBool_congr hN2OEq)

private theorem checkExcisedReexprBool_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {B_canon excisedBranches : ExcisedLocus} {rx : ExcisedReexprCert}
    (hDJ  : ∀ nid ∈ rx.branchDefAndDisjNodes.foldr
              (fun (_, dId, jId) acc => dId :: jId :: acc) [],
              verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid)
    (hCov : ∀ nid ∈ rx.canonCoverWitnesses.foldr
              (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) [],
              verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) :
    checkExcisedReexprBool fuel Γ1 C1 D_old Γ_old D_new Γ_new specNewId B_canon excisedBranches rx =
    checkExcisedReexprBool fuel Γ2 C2 D_old Γ_old D_new Γ_new specNewId B_canon excisedBranches rx := by
  unfold checkExcisedReexprBool
  have h1 :
      rx.branchDefAndDisjNodes.all (fun (E_i, defNid, disjNid) =>
        checkExactG7SequentBool fuel Γ1 C1 defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0)) &&
        checkExactG7SequentBool fuel Γ1 C1 disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))) =
      rx.branchDefAndDisjNodes.all (fun (E_i, defNid, disjNid) =>
        checkExactG7SequentBool fuel Γ2 C2 defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0)) &&
        checkExactG7SequentBool fuel Γ2 C2 disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))) := by
    apply list_all_congr
    rintro ⟨E_i, defNid, disjNid⟩ hMem
    rcases mem_foldr_pair_ids rx.branchDefAndDisjNodes hMem with ⟨hdIn, hjIn⟩
    dsimp only
    unfold checkExactG7SequentBool
    rw [hDJ defNid hdIn, hDJ disjNid hjIn]
  have h2 :
      rx.canonCoverWitnesses.all (fun (B_j, E_target, psiNodes) =>
        excisedBranches.contains E_target &&
        checkGuardEntailmentListBool fuel Γ1 C1 D_old specNewId B_j E_target psiNodes) =
      rx.canonCoverWitnesses.all (fun (B_j, E_target, psiNodes) =>
        excisedBranches.contains E_target &&
        checkGuardEntailmentListBool fuel Γ2 C2 D_old specNewId B_j E_target psiNodes) := by
    apply list_all_congr
    rintro ⟨B_j, E_target, psiNodes⟩ hMem
    dsimp only
    rw [checkGuardEntailmentListBool_congr
          (fun nid hn => hCov nid (mem_foldr_cover_ids rx.canonCoverWitnesses hMem hn))]
  rw [h1, h2]

private theorem obstVerifyCongr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {goalOld : StrictForm} {specNewId : String}
    (obstCid cellOldCid specOldId : String)
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hEq : ∀ nid ∈ (match ev with
                    | .missingGuard _ _ (some id) => [id]
                    | .scopedNoGoLocus _ _ id     => [id]
                    | _                           => []),
             verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) :
    checkVerifiedObstructionBool fuel Γ1 C1 D_old Γ_old goalOld specNewId
      ⟨obstCid, cellOldCid, specOldId, okind, ev⟩ =
    checkVerifiedObstructionBool fuel Γ2 C2 D_old Γ_old goalOld specNewId
      ⟨obstCid, cellOldCid, specOldId, okind, ev⟩ := by
  unfold checkVerifiedObstructionBool
  dsimp only
  cases okind with
  | counterexamplePoint => cases ev <;> rfl
  | invalidCertificate => cases ev <;> rfl
  | missingAssumption b =>
      cases b with
      | false =>
          cases ev with
          | missingGuard _ fOpt oOpt => cases fOpt <;> cases oOpt <;> rfl
          | _ => rfl
      | true =>
          cases ev with
          | missingGuard _ fOpt oOpt =>
              cases fOpt with
              | some _ => rfl
              | none =>
                  cases oOpt with
                  | none => rfl
                  | some obstNid =>
                      dsimp only at hEq ⊢
                      unfold checkExactG7SequentBool
                      rw [hEq obstNid (List.mem_cons_self ..)]
          | _ => rfl
  | scopedNoGo =>
      cases ev with
      | scopedNoGoLocus _ _ noGoNid =>
          dsimp only at hEq ⊢
          unfold checkExactG7SequentBool
          rw [hEq noGoNid (List.mem_cons_self ..)]
      | _ => rfl
  | unsupportedHorizon => cases ev <;> rfl
  | environmentalFailure => cases ev <;> rfl

private theorem repairObstMatch_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {cert : G5DischargeCert} {rCert : RepairDomEqCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hRedEq : ∀ rnid ∈ rCert.redundantGuardNodeId?.toList,
      verifyReachableDerivation fuel Γ1 C1 rnid = verifyReachableDerivation fuel Γ2 C2 rnid) :
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         rCert.redundantGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew obsPt &&
         (evalStrictFormRatCoord fuel cert.goalNew obsPt == FormEvalRes.satTrue)
     | .invalidCertificate, .invalidSosCert _ _ =>
         rCert.redundantGuardNodeId?.isNone
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rCert.redundantGuardNodeId? with
         | none      => false
         | some rnid => checkExactG7SequentBool fuel Γ1 C1 rnid cert.domOld
                          cert.specNewId cert.guardsOld candGuard
     | _, _ => false) =
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         rCert.redundantGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew obsPt &&
         (evalStrictFormRatCoord fuel cert.goalNew obsPt == FormEvalRes.satTrue)
     | .invalidCertificate, .invalidSosCert _ _ =>
         rCert.redundantGuardNodeId?.isNone
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rCert.redundantGuardNodeId? with
         | none      => false
         | some rnid => checkExactG7SequentBool fuel Γ2 C2 rnid cert.domOld
                          cert.specNewId cert.guardsOld candGuard
     | _, _ => false) := by
  cases okind with
  | missingAssumption b =>
      cases b with
      | false =>
          cases ev with
          | missingGuard _ fOpt oOpt => cases fOpt <;> cases oOpt <;> rfl
          | _ => rfl
      | true =>
          cases ev with
          | missingGuard _ fOpt oOpt =>
              cases fOpt <;> cases oOpt <;> try rfl
              cases hR : rCert.redundantGuardNodeId? with
              | none => rfl
              | some rnid =>
                  rw [hR] at hRedEq
                  dsimp [Option.toList] at hRedEq ⊢
                  unfold checkExactG7SequentBool
                  rw [hRedEq rnid (List.mem_cons_self ..)]
          | _ => rfl
  | _ => cases ev <;> rfl

private theorem retreatObstMatch_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {cert : G5DischargeCert} {rt : G5RetreatPartitionCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hAdEq : ∀ anid ∈ rt.adoptedGuardNodeId?.toList,
      verifyReachableDerivation fuel Γ1 C1 anid = verifyReachableDerivation fuel Γ2 C2 anid) :
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         rt.adoptedGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld obsPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches obsPt
     | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
         rt.adoptedGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld noGoPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches noGoPt
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rt.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ1 C1 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | .missingAssumption false, .missingGuard candGuard (some failPt) none =>
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld failPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches failPt &&
         match rt.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ1 C1 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | _, _ => false) =
    (match okind, ev with
     | .counterexamplePoint, .counterexamplePt obsPt =>
         rt.adoptedGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld obsPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches obsPt
     | .scopedNoGo, .scopedNoGoLocus _ noGoPt _ =>
         rt.adoptedGuardNodeId?.isNone &&
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld noGoPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches noGoPt
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rt.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ2 C2 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | .missingAssumption false, .missingGuard candGuard (some failPt) none =>
         checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld failPt &&
         checkModelsExcisedRatCoordBool fuel rt.excisedBranches failPt &&
         match rt.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ2 C2 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | _, _ => false) := by
  cases okind with
  | missingAssumption b =>
      cases b <;> cases ev <;> try rfl
      all_goals
        rename_i _ fOpt oOpt
        cases fOpt <;> cases oOpt <;> try rfl
        cases hA : rt.adoptedGuardNodeId? with
        | none => rfl
        | some anid =>
            rw [hA] at hAdEq
            dsimp [Option.toList] at hAdEq ⊢
            unfold checkExactG7SequentBool
            rw [hAdEq anid (List.mem_cons_self ..)]
  | _ => cases ev <;> rfl

private theorem refineObstMatch_congr {fuel : Nat}
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    {cert : G5DischargeCert} {rf : G5RefinementCert}
    (okind : KernelObstKindV1) (ev : ObstructionEvidenceData)
    (hAdEq : ∀ anid ∈ rf.adoptedGuardNodeId?.toList,
      verifyReachableDerivation fuel Γ1 C1 anid = verifyReachableDerivation fuel Γ2 C2 anid) :
    (match okind, ev with
     | .invalidCertificate, .invalidSosCert _ _ =>
         rf.adoptedGuardNodeId?.isNone
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rf.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ1 C1 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | _, _ => false) =
    (match okind, ev with
     | .invalidCertificate, .invalidSosCert _ _ =>
         rf.adoptedGuardNodeId?.isNone
     | .missingAssumption true, .missingGuard candGuard none (some _) =>
         match rf.adoptedGuardNodeId? with
         | none      => false
         | some anid => checkExactG7SequentBool fuel Γ2 C2 anid cert.domNew cert.specNewId
                          cert.guardsNew candGuard
     | _, _ => false) := by
  cases okind with
  | missingAssumption b =>
      cases b with
      | false =>
          cases ev with
          | missingGuard _ fOpt oOpt => cases fOpt <;> cases oOpt <;> rfl
          | _ => rfl
      | true =>
          cases ev with
          | missingGuard _ fOpt oOpt =>
              cases fOpt <;> cases oOpt <;> try rfl
              cases hA : rf.adoptedGuardNodeId? with
              | none => rfl
              | some anid =>
                  rw [hA] at hAdEq
                  dsimp [Option.toList] at hAdEq ⊢
                  unfold checkExactG7SequentBool
                  rw [hAdEq anid (List.mem_cons_self ..)]
          | _ => rfl
  | _ => cases ev <;> rfl

/-- Rootwise congruence of `checkG5CoreProofsBool`: every `G7` query performed anywhere inside
    `checkG5CoreProofsBool` is confined to `collectG5ProofRootIds cert`! -/
theorem checkG5CoreProofsBool_congr_on_roots (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (cert : G5DischargeCert)
    (hRootEq : ∀ r ∈ collectG5ProofRootIds cert,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r) :
    checkG5CoreProofsBool fuel Γ1 C1 cert = checkG5CoreProofsBool fuel Γ2 C2 cert := by
  have hObstCongr :
      checkVerifiedObstructionBool fuel Γ1 C1 cert.domOld cert.guardsOld cert.goalOld
        cert.specNewId cert.obstructionSpec =
      checkVerifiedObstructionBool fuel Γ2 C2 cert.domOld cert.guardsOld cert.goalOld
        cert.specNewId cert.obstructionSpec := by
    rcases hSpec : cert.obstructionSpec with ⟨obstCid, cellOldCid, specOldId, okind, ev⟩
    exact obstVerifyCongr obstCid cellOldCid specOldId okind ev
      (fun nid hn => hRootEq nid (obstList_sub_roots cert (by rw [hSpec]; exact hn)))
  have hGoalCongr :
      checkExactG7SequentBool fuel Γ1 C1 cert.goalNewNodeId cert.domNew cert.specNewId
        cert.guardsNew cert.goalNew =
      checkExactG7SequentBool fuel Γ2 C2 cert.goalNewNodeId cert.domNew cert.specNewId
        cert.guardsNew cert.goalNew := by
    unfold checkExactG7SequentBool
    rw [hRootEq cert.goalNewNodeId (goalNewNodeId_mem_collectG5ProofRootIds cert)]
  have hBranchCongr :
      (match cert.reflexKind with
       | .repair =>
           (!cert.requiresRetreatHistory) && cert.retreatCert?.isNone && cert.refinementCert?.isNone &&
           match cert.repairCert? with
           | none => false
           | some rCert => checkRepairDomEqBool fuel Γ1 C1 cert rCert
       | .retreat =>
           cert.requiresRetreatHistory && cert.repairCert?.isNone && cert.refinementCert?.isNone &&
           match cert.retreatCert? with
           | none => false
           | some rtCert => checkRetreatExactPartitionBool fuel Γ1 C1 cert rtCert
       | .refinement =>
           (!cert.requiresRetreatHistory) && cert.repairCert?.isNone && cert.retreatCert?.isNone &&
           match cert.refinementCert? with
           | none => false
           | some rfCert => checkRefinementBool fuel Γ1 C1 cert rfCert) =
      (match cert.reflexKind with
       | .repair =>
           (!cert.requiresRetreatHistory) && cert.retreatCert?.isNone && cert.refinementCert?.isNone &&
           match cert.repairCert? with
           | none => false
           | some rCert => checkRepairDomEqBool fuel Γ2 C2 cert rCert
       | .retreat =>
           cert.requiresRetreatHistory && cert.repairCert?.isNone && cert.refinementCert?.isNone &&
           match cert.retreatCert? with
           | none => false
           | some rtCert => checkRetreatExactPartitionBool fuel Γ2 C2 cert rtCert
       | .refinement =>
           (!cert.requiresRetreatHistory) && cert.repairCert?.isNone && cert.retreatCert?.isNone &&
           match cert.refinementCert? with
           | none => false
           | some rfCert => checkRefinementBool fuel Γ2 C2 cert rfCert) := by
    cases cert.reflexKind with
    | repair =>
        cases hRep : cert.repairCert? with
        | none => rfl
        | some rCert =>
            dsimp only
            congr 1
            unfold checkRepairDomEqBool
            exact bool_and_congr
              (checkSameEffDomCoreBool_congr
                (fun nid hn => hRootEq nid (repairList_sub_roots cert rCert hRep
                  (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                    (List.mem_append_left _ hn))))))
                (fun nid hn => hRootEq nid (repairList_sub_roots cert rCert hRep
                  (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                    (List.mem_append_right _ hn))))))
                (fun nid hn => hRootEq nid (repairList_sub_roots cert rCert hRep
                  (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ hn)))))
                (fun nid hn => hRootEq nid (repairList_sub_roots cert rCert hRep
                  (List.mem_append_left _ (List.mem_append_right _ hn)))))
              (repairObstMatch_congr (cert := cert) (rCert := rCert)
                cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
                (fun rnid hr => hRootEq rnid (repairList_sub_roots cert rCert hRep
                  (List.mem_append_right _ hr))))
    | retreat =>
        cases hRt : cert.retreatCert? with
        | none => rfl
        | some rt =>
            dsimp only
            congr 1
            unfold checkRetreatExactPartitionBool
            have hPrefEq :
                checkExactG7SequentBool fuel Γ1 C1 rt.prefixDefNodeId cert.domNew cert.specNewId
                  (cert.guardsOld ++ rt.deltaGuards) (.eqZero (.const 0)) =
                checkExactG7SequentBool fuel Γ2 C2 rt.prefixDefNodeId cert.domNew cert.specNewId
                  (cert.guardsOld ++ rt.deltaGuards) (.eqZero (.const 0)) := by
              unfold checkExactG7SequentBool
              rw [hRootEq rt.prefixDefNodeId (retreatList_sub_roots cert rt hRt
                (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                  (List.mem_cons_self ..)))))]
            have hConnEq :
                (match rt.guardConn with
                 | .syntacticConcat => cert.guardsNew == cert.guardsOld ++ rt.deltaGuards
                 | .mutualImplication d2n n2d =>
                     checkGuardEntailmentListBool fuel Γ1 C1 cert.domNew cert.specNewId
                       (cert.guardsOld ++ rt.deltaGuards) cert.guardsNew d2n &&
                     checkGuardEntailmentListBool fuel Γ1 C1 cert.domNew cert.specNewId
                       cert.guardsNew (cert.guardsOld ++ rt.deltaGuards) n2d) =
                (match rt.guardConn with
                 | .syntacticConcat => cert.guardsNew == cert.guardsOld ++ rt.deltaGuards
                 | .mutualImplication d2n n2d =>
                     checkGuardEntailmentListBool fuel Γ2 C2 cert.domNew cert.specNewId
                       (cert.guardsOld ++ rt.deltaGuards) cert.guardsNew d2n &&
                     checkGuardEntailmentListBool fuel Γ2 C2 cert.domNew cert.specNewId
                       cert.guardsNew (cert.guardsOld ++ rt.deltaGuards) n2d) := by
              cases hGC : rt.guardConn with
              | syntacticConcat => rfl
              | mutualImplication d2n n2d =>
                  dsimp only
                  rw [checkGuardEntailmentListBool_congr (fun nid hn => hRootEq nid
                        (retreatList_sub_roots cert rt hRt
                          (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _
                            (by rw [hGC]; exact List.mem_append_left _ hn)))))),
                      checkGuardEntailmentListBool_congr (fun nid hn => hRootEq nid
                        (retreatList_sub_roots cert rt hRt
                          (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _
                            (by rw [hGC]; exact List.mem_append_right _ hn))))))]
            have hRxEq :
                (match rt.reexprCert? with
                 | none => rt.excisedBranches ==
                     buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards
                 | some rx =>
                     checkExcisedReexprBool fuel Γ1 C1 cert.domOld cert.guardsOld cert.domNew
                       cert.guardsNew cert.specNewId
                       (buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards)
                       rt.excisedBranches rx) =
                (match rt.reexprCert? with
                 | none => rt.excisedBranches ==
                     buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards
                 | some rx =>
                     checkExcisedReexprBool fuel Γ2 C2 cert.domOld cert.guardsOld cert.domNew
                       cert.guardsNew cert.specNewId
                       (buildCanonicalRetreatExcised rt.baseStep cert.guardsOld rt.deltaGuards)
                       rt.excisedBranches rx) := by
              cases hRx : rt.reexprCert? with
              | none => rfl
              | some rx =>
                  dsimp only
                  exact checkExcisedReexprBool_congr
                    (fun nid hn => hRootEq nid (retreatList_sub_roots cert rt hRt
                      (List.mem_append_left _ (List.mem_append_right _
                        (by rw [hRx]; exact List.mem_append_left _ hn)))))
                    (fun nid hn => hRootEq nid (retreatList_sub_roots cert rt hRt
                      (List.mem_append_left _ (List.mem_append_right _
                        (by rw [hRx]; exact List.mem_append_right _ hn)))))
            have hObstRtEq := retreatObstMatch_congr (cert := cert) (rt := rt)
              cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
              (fun anid ha => hRootEq anid (retreatList_sub_roots cert rt hRt
                (List.mem_append_right _ ha)))
            dsimp only
            exact bool_and_congr
              (congrArg (fun x => ((x &&
                checkInEffDomRatCoordBool fuel cert.domOld cert.guardsOld rt.strictLossWitness) &&
                checkModelsExcisedRatCoordBool fuel rt.excisedBranches rt.strictLossWitness) &&
                rt.claimedRetentionAnchors.all (checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew))
                (bool_and_congr
                  (bool_and_congr
                    (congrArg (Bool.and (checkBaseDomRetreatStepBool rt.baseStep cert.domOld cert.domNew &&
                      rt.deltaGuards.all isAtomicStrictFormBool)) hPrefEq)
                    hConnEq)
                  hRxEq))
              hObstRtEq
    | refinement =>
        cases hRf : cert.refinementCert? with
        | none => rfl
        | some rf =>
            dsimp only
            congr 1
            unfold checkRefinementBool
            have hInclEq :
                (if cert.guardsNew == cert.guardsOld then rf.oldEntailsNewGuardNodes.isEmpty
                 else checkGuardEntailmentListBool fuel Γ1 C1 cert.domOld cert.specNewId
                   cert.guardsOld cert.guardsNew rf.oldEntailsNewGuardNodes) =
                (if cert.guardsNew == cert.guardsOld then rf.oldEntailsNewGuardNodes.isEmpty
                 else checkGuardEntailmentListBool fuel Γ2 C2 cert.domOld cert.specNewId
                   cert.guardsOld cert.guardsNew rf.oldEntailsNewGuardNodes) := by
              by_cases hG : (cert.guardsNew == cert.guardsOld) = true
              · rw [if_pos hG, if_pos hG]
              · rw [if_neg hG, if_neg hG]
                exact checkGuardEntailmentListBool_congr (fun nid hn => hRootEq nid
                  (refineList_sub_roots cert rf hRf
                    (List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
                      (List.mem_append_right _ hn))))))
            have hImpEq :
                (match rf.goalImpNodeId? with
                 | none => cert.goalNew == cert.goalOld
                 | some impNid => checkExactG7SequentBool fuel Γ1 C1 impNid cert.domNew
                     cert.specNewId (cert.guardsNew ++ [cert.goalNew]) cert.goalOld) =
                (match rf.goalImpNodeId? with
                 | none => cert.goalNew == cert.goalOld
                 | some impNid => checkExactG7SequentBool fuel Γ2 C2 impNid cert.domNew
                     cert.specNewId (cert.guardsNew ++ [cert.goalNew]) cert.goalOld) := by
              cases hImp : rf.goalImpNodeId? with
              | none => rfl
              | some impNid =>
                  dsimp only; unfold checkExactG7SequentBool
                  rw [hRootEq impNid (refineList_sub_roots cert rf hRf
                    (List.mem_append_left _ (List.mem_append_right _
                      (by rw [hImp]; exact List.mem_cons_self ..))))]
            have hScopeEq :
                (if rf.scopeExpanded then
                   rf.oldGuardsDefNodeId?.isNone && rf.newEntailsOldGuardNodes.isEmpty &&
                   match rf.expansionWitness? with
                   | none => false
                   | some pt_exp =>
                       checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew pt_exp &&
                       checkNotInEffDomRatCoordBool fuel cert.domOld cert.guardsOld pt_exp
                 else
                   rf.expansionWitness?.isNone &&
                   match rf.baseExpandStep with
                   | .sameBaseDom D =>
                       checkSameEffDomCoreBool fuel Γ1 C1 cert.domOld cert.guardsOld cert.domNew
                         cert.guardsNew cert.specNewId (.sameBaseDom D) rf.oldGuardsDefNodeId?
                         (if cert.guardsNew == cert.guardsOld then [] else rf.oldEntailsNewGuardNodes)
                         rf.newEntailsOldGuardNodes
                   | _ => false) =
                (if rf.scopeExpanded then
                   rf.oldGuardsDefNodeId?.isNone && rf.newEntailsOldGuardNodes.isEmpty &&
                   match rf.expansionWitness? with
                   | none => false
                   | some pt_exp =>
                       checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew pt_exp &&
                       checkNotInEffDomRatCoordBool fuel cert.domOld cert.guardsOld pt_exp
                 else
                   rf.expansionWitness?.isNone &&
                   match rf.baseExpandStep with
                   | .sameBaseDom D =>
                       checkSameEffDomCoreBool fuel Γ2 C2 cert.domOld cert.guardsOld cert.domNew
                         cert.guardsNew cert.specNewId (.sameBaseDom D) rf.oldGuardsDefNodeId?
                         (if cert.guardsNew == cert.guardsOld then [] else rf.oldEntailsNewGuardNodes)
                         rf.newEntailsOldGuardNodes
                   | _ => false) := by
              cases rf.scopeExpanded with
              | true => rfl
              | false =>
                  cases rf.baseExpandStep with
                  | sameBaseDom D =>
                      dsimp only
                      rw [checkSameEffDomCoreBool_congr (step := .sameBaseDom D)
                            (fun _ hn => nomatch hn)
                            (fun nid hn => hRootEq nid (refineList_sub_roots cert rf hRf
                              (List.mem_append_left _ (List.mem_append_left _
                                (List.mem_append_left _ (List.mem_append_left _ hn))))))
                            (fun nid hn => by
                              by_cases hG : (cert.guardsNew == cert.guardsOld) = true
                              · rw [if_pos hG] at hn; nomatch hn
                              · rw [if_neg hG] at hn
                                exact hRootEq nid (refineList_sub_roots cert rf hRf
                                  (List.mem_append_left _ (List.mem_append_left _
                                    (List.mem_append_left _ (List.mem_append_right _ hn))))))
                            (fun nid hn => hRootEq nid (refineList_sub_roots cert rf hRf
                              (List.mem_append_left _ (List.mem_append_left _
                                (List.mem_append_right _ hn)))))]
                  | qNonzeroToQ => rfl
                  | qToQ2 => rfl
                  | qNonzeroToQ2 => rfl
                  | finiteGridSup _ _ => rfl
            have hObstRfEq := refineObstMatch_congr (cert := cert) (rf := rf)
              cert.obstructionSpec.obstKind cert.obstructionSpec.evidence
              (fun anid ha => hRootEq anid (refineList_sub_roots cert rf hRf
                (List.mem_append_right _ ha)))
            dsimp only
            exact bool_and_congr
              (bool_and_congr
                (bool_and_congr
                  (congrArg (Bool.and (checkBaseDomExpandStepBool rf.baseExpandStep cert.domOld cert.domNew))
                    hInclEq)
                  hImpEq)
                hScopeEq)
              hObstRfEq
  unfold checkG5CoreProofsBool
  exact bool_and_congr
    (bool_and_congr
      (congrArg (fun x => x &&
        checkInEffDomRatCoordBool fuel cert.domNew cert.guardsNew cert.nonEmptyWitness.witnessCoord)
        (congrArg (Bool.and (checkG5CanonicalBindingBool cert &&
          checkG5ObstReflexAllowedBool cert.obstructionSpec.obstKind cert.reflexKind)) hObstCongr))
      hGoalCongr)
    hBranchCongr

/-- **`T_B1_06_ProofRoots_And_PrimDeps_Completeness` (`B1-A4.6` & `B1-06`)**:
    Proves complete proof-root capture and transitive primitive dependency closure for `B1`:
    (1) **Exact Claimed-Dependency Binding**: `checkG5DischargeBool fuel Γ C cert = true` forces
        `cert.claimedPrimDeps.primDepIds = deriveG5PrimDeps Γ C cert`;
    (2) **Two-Environment Output Congruence (`A0-05.1`)**: Any `(Γ₁, C₁)` and `(Γ₂, C₂)` agreeing
        on `(deriveG5PrimDeps Γ₁ C₁ cert, multiRootReachableNodes C₁ (collectG5ProofRootIds cert))`
        produce identical `checkG5CoreProofsBool` verdicts;
    (3) **Sub-Container & Sub-Premise Restriction Invariance (`A0-05.3` / `F-B2B-T2-06`)**:
        Restricting `(Γ, C)` to `(restrictPrimEnv Γ P*, restrictContainer C R*)` preserves
        `checkG5CoreProofsBool` identically (`0` omitted proof roots!);
    (4) **Instrumented Traced Lookup Confinement (`A0-05.2`)**: Running `verifyMultiRootTraced`
        over `collectG5ProofRootIds cert` confines 100% of logged DAG & premise lookups to `(R*, P*)`
        *(while uninstrumented frozen `verifyReachableDerivation` runtime trace confinement remains
        explicitly `HELD` per `A0` Sixth Tribunal boundary)*. -/
theorem T_B1_06_ProofRoots_And_PrimDeps_Completeness (fuel : Nat) (cert : G5DischargeCert) :
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer),
      checkG5DischargeBool fuel Γ C cert = true →
      cert.claimedPrimDeps.primDepIds = deriveG5PrimDeps Γ C cert) ∧
    (∀ (Γ1 Γ2 : PrimPremiseEnv) (C1 C2 : G7DagContainer),
      ValidContainer C1 →
      (∀ nid ∈ multiRootReachableNodes C1 (collectG5ProofRootIds cert),
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      (∀ pid ∈ deriveG5PrimDeps Γ1 C1 cert,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      checkG5CoreProofsBool fuel Γ1 C1 cert = checkG5CoreProofsBool fuel Γ2 C2 cert) ∧
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer),
      ValidContainer C →
      let RStar := multiRootReachableNodes C (collectG5ProofRootIds cert)
      let PStar := deriveG5PrimDeps Γ C cert
      checkG5CoreProofsBool fuel (restrictPrimEnv Γ PStar) (restrictContainer C RStar) cert =
      checkG5CoreProofsBool fuel Γ C cert) ∧
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer),
      ValidContainer C →
      LogConfinedTo
        (multiRootReachableNodes C (collectG5ProofRootIds cert))
        (deriveG5PrimDeps Γ C cert)
        (verifyMultiRootTraced fuel Γ C (collectG5ProofRootIds cert)).2) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro Γ C hAcc
    unfold checkG5DischargeBool at hAcc
    simp only [Bool.and_eq_true] at hAcc
    exact eq_of_beq hAcc.1
  · intro Γ1 Γ2 C1 C2 hVal1 hNodeEq hPrimEq
    have hMapEq := A0_05_1_OutputCongruence fuel (collectG5ProofRootIds cert) hVal1 hNodeEq hPrimEq
    exact checkG5CoreProofsBool_congr_on_roots fuel cert (map_eq_imp_forall_mem_eq hMapEq)
  · intro Γ C hVal
    dsimp only
    have hRest := (A0_05_3_RestrictionInvariance fuel Γ C (collectG5ProofRootIds cert) hVal).2
    exact checkG5CoreProofsBool_congr_on_roots fuel cert (map_eq_imp_forall_mem_eq hRest)
  · intro Γ C hVal
    exact A0_05_2_ActualLookupConfinement fuel Γ C (collectG5ProofRootIds cert) hVal

/-! ### 6. Master Conditional Soundness (`T_B1_07`) & Non-Escalation (`T_B1_08`) -/

/-- **`T_B1_07_CheckG5Discharge_MasterSoundness` (`B1-A4.7` & `B1-06` — Core Master Theorem)**:
    Under `checkPrimEnvIntegrityBool Γ = true`, `ValidContainer C`, deterministic acceptance
    `checkG5DischargeBool fuel Γ C cert = true`, and semantic validity of ONLY the derived
    transitive primitive premises `p ∈ deriveG5PrimDeps Γ C cert`, the declarative specification
    `SemValidG5Discharge cert` holds!
    Zero hidden `SemValidG5Discharge` assumption, zero custom axioms, and zero executable checker
    circularity in `SemValidG5Discharge`. -/
theorem T_B1_07_CheckG5Discharge_MasterSoundness
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer} {cert : G5DischargeCert}
    (_hPrimEnv : checkPrimEnvIntegrityBool Γ = true)
    (hVal      : ValidContainer C)
    (hAcc      : checkG5DischargeBool fuel Γ C cert = true)
    (hPrem     : ∀ pid ∈ deriveG5PrimDeps Γ C cert, SemValidPrimId Γ pid) :
    SemValidG5Discharge cert := by
  have hNonEmpty := T_B1_01_G5_NonEmptiness_Sound hAcc
  have hObst     := T_B1_05_Obstruction_GenuineDischarge_Sound hVal hAcc hPrem
  have hAccCopy  := hAcc
  unfold checkG5DischargeBool checkG5CoreProofsBool at hAcc
  simp only [Bool.and_eq_true] at hAcc
  have hBindBool    := hAcc.2.1.1.1.1.1
  have hGoalNewBool := hAcc.2.1.2
  unfold checkG5CanonicalBindingBool at hBindBool
  simp only [Bool.and_eq_true, beq_iff_eq, bne_iff_ne] at hBindBool
  rcases hBindBool with
    ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hv, hr⟩, hco⟩, hob⟩, hcn⟩, hb⟩, hso⟩, hsn⟩, hobEq⟩, hcoEq⟩, hsoEq⟩
  have hGoalNewSem := exactG7Sequent_sound_of_root hVal hPrem
    (goalNewNodeId_mem_collectG5ProofRootIds cert) hGoalNewBool
  refine {
    canonicalBinding      := ⟨hv, hr, hco, hob, hcn, hb, hso, hsn, hobEq, hcoEq, hsoEq⟩
    allowedObstReflex     := hObst.1
    validObstructionOnOld := hObst.2.2.2
    nonEmptyNewEffDom     := ⟨hNonEmpty.1, hNonEmpty.2.1, hNonEmpty.2.2.1⟩
    validPostReflexTarget := fun ρ hIn => hGoalNewSem.2 ρ hIn.1 hIn.2.2
    branchExactDischarge  := ?_
  }
  cases hRk : cert.reflexKind with
  | repair =>
      exact (T_B1_02_Repair_ExactEffDomEq_Sound hVal hAccCopy hPrem hRk).2.2
  | retreat =>
      rcases T_B1_03_Retreat_ExactScopeLossPartition_Sound hVal hAccCopy hPrem hRk with
        ⟨_, _, _, _, _, _, hSemRet⟩
      exact hSemRet
  | refinement =>
      exact (T_B1_04_Refinement_ConservativePreservation_Sound hVal hAccCopy hPrem hRk).2.2.2

/-- **`T_B1_08_Zero_G6_G1_Authority_Escalation` (`B1-A4.8` & `B1-CE10` Structural Seal)**:
    (1) Every `G5QualifiedRecord` produced by `qualifyG5Isolated?` extracts an actual `cert`
        passing `checkG5DischargeBool fuel Γ C cert = true`, preserves `requiresRetreatHistory`,
        and strictly seals `g6ProtectedSlot = .mkUnchecked`, `g1IntegritySlot = .mkUnchecked`,
        and `grantFlag = .noGrantFromMathCheck`;
    (2) Neither `G6` nor `G1` `.verified` slots can be inhabited under `checkUnauthStageCertBool`,
        and `FullReflexAdmitted checkUnauthStageCertBool c56 c7` is provably uninhabited (`Empty`)! -/
theorem T_B1_08_Zero_G6_G1_Authority_Escalation :
    (∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
       (cert : G5DischargeCert) (rec : G5QualifiedRecord fuel Γ C),
      qualifyG5Isolated? fuel Γ C cert = some rec →
        checkG5DischargeBool fuel Γ C cert = true ∧
        rec.requiresRetreatHistory = cert.requiresRetreatHistory ∧
        rec.g6ProtectedSlot = .mkUnchecked ∧
        rec.g1IntegritySlot = .mkUnchecked ∧
        rec.grantFlag = .noGrantFromMathCheck) ∧
    ¬ Nonempty (SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .verified) ∧
    (∀ {G56Raw G7Raw : Type} (c56 : G56Raw → Bool) (c7 : G7Raw → Bool),
      ¬ Nonempty (FullReflexAdmitted checkUnauthStageCertBool c56 c7)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro fuel Γ C cert rec hQual
    unfold qualifyG5Isolated? at hQual
    by_cases hOk : checkG5DischargeBool fuel Γ C cert = true
    · rw [dif_pos hOk] at hQual
      injection hQual with hRec
      subst hRec
      exact ⟨hOk, rfl, rfl, rfl, rfl⟩
    · rw [dif_neg hOk] at hQual
      nomatch hQual
  · rintro ⟨w⟩
    rcases verified_slot_has_checked_cert w with ⟨_, hBad⟩
    nomatch hBad
  · intro _ _ _ _ ⟨full⟩
    rcases verified_slot_has_checked_cert full.slotG1 with ⟨_, hBad⟩
    nomatch hBad

end OmegaCellC1P1B2BB1
