/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B1 — Isolated G5 Certified Obstruction Discharge Kernel
  File: AuditB1G5Axioms.lean (Full Whitebox `Lean.Environment` & Non-Circularity Auditor for B1)

  Audits 100% of `OmegaCellC1P1B2BB1` module-owned constants (including `private` helpers):
    1. Zero `sorryAx` and zero custom `axiom` declarations (`{propext, Classical.choice, Quot.sound}`
       upper bound, reporting exact axioms used by each of the 29 B1 headline theorems).
    2. Zero `unsafe`, zero `opaque`, and zero unjustified `partial` declarations across B1.
    3. Zero `GPED` or unauthorized `G6` / `G56` / `P1C` modules loaded.
    4. Anti-circularity check (`Cone*(S_sem_B1) ∩ K_exec_all = ∅`): verifies that `SemValidG5Discharge`
       and all declarative `S_sem_B1` predicates contain ZERO references to any executable checker.
    5. `B1-01` `L_B2B_ParamSubst` boundary check: verifies that `checkG5DischargeBool` and
       `T_B1_07_CheckG5Discharge_MasterSoundness` do NOT unnecessarily invoke `L_B2B_ParamSubst`.
-/
import Lean
import OmegaCellC1P1B2BB1

open Lean
open OmegaCellC1P1B2BB1

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def b1Modules5 : List Name := [
  `OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers,
  `OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure,
  `OmegaCellC1P1B2BB1.B1_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB1
]

def ancestorModules16 : List Name := [
  `OmegaCellC1P1A0.P1A0A_BaseChartGuard,
  `OmegaCellC1P1A0.P1A0B_TransportScopeLoss,
  `OmegaCellC1P1A0.P1A0C_CheckerQualification,
  `OmegaCellC1P1A0,
  `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
  `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness,
  `OmegaCellC1P1B1,
  `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
  `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
  `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
  `OmegaCellC1P1B2A,
  `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
  `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
  `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
  `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
  `OmegaCellC1P1B2BA0
]

def b1HeadlineTheorems : List Name := [
  -- B1_01
  `OmegaCellC1P1B2BB1.ratCoordOfInt2_toEnv2,
  `OmegaCellC1P1B2BB1.g5ObstReflexAllowed_implies_p1b1_matrix,
  `OmegaCellC1P1B2BB1.T_B1_04b_conservative_refinement_excludes_counterexample,
  -- B1_02
  `OmegaCellC1P1B2BB1.evalPartExprRatCoord_sound,
  `OmegaCellC1P1B2BB1.evalStrictFormRatCoord_sound,
  `OmegaCellC1P1B2BB1.checkInG7DomRatCoordBool_iff,
  `OmegaCellC1P1B2BB1.checkInEffDomRatCoordBool_sound,
  `OmegaCellC1P1B2BB1.checkNotInEffDomRatCoordBool_sound,
  `OmegaCellC1P1B2BB1.checkModelsExcisedRatCoordBool_sound,
  -- B1_03 (8 Mandatory Soundness & Closure Theorems + ImpNorm Bridge)
  `OmegaCellC1P1B2BB1.T_B1_01_G5_NonEmptiness_Sound,
  `OmegaCellC1P1B2BB1.T_B1_01b_G5_DomNz_ImpNorm_Target_Sound,
  `OmegaCellC1P1B2BB1.T_B1_02_Repair_ExactEffDomEq_Sound,
  `OmegaCellC1P1B2BB1.T_B1_03_Retreat_ExactScopeLossPartition_Sound,
  `OmegaCellC1P1B2BB1.T_B1_04_Refinement_ConservativePreservation_Sound,
  `OmegaCellC1P1B2BB1.T_B1_05_Obstruction_GenuineDischarge_Sound,
  `OmegaCellC1P1B2BB1.checkG5CoreProofsBool_congr_on_roots,
  `OmegaCellC1P1B2BB1.T_B1_06_ProofRoots_And_PrimDeps_Completeness,
  `OmegaCellC1P1B2BB1.T_B1_07_CheckG5Discharge_MasterSoundness,
  `OmegaCellC1P1B2BB1.T_B1_08_Zero_G6_G1_Authority_Escalation,
  -- B1_04 (Positive Witness Suites + CE01..CE10)
  `OmegaCellC1P1B2BB1.B1_PosWitnessSuite_Proven,
  `OmegaCellC1P1B2BB1.B1_AllAdmissibleMatrixCellsInhabited_Proven,
  `OmegaCellC1P1B2BB1.B1_CE01_VacuousEmptyDomain_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE02_RepairSilentShrink_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE03_RepairSilentExpand_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE04_RetreatPartialLossOmission_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE05_UndefinedZeroPointHidden_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE06_ForeignOrMismatchedNode_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE07_FakeObstructionOrForgedProof_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE08_OmittedTransitivePrimDep_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE09_ForbiddenPairsAndMixedBranches_Rejected,
  `OmegaCellC1P1B2BB1.B1_CE10_G5Pass_DoesNotImply_G6Pass_Or_FullReflex
]

def b1SemanticAnchors : List Name := [
  `OmegaCellC1P1B2BB1.SemNecessarySosConditions,
  `OmegaCellC1P1B2BB1.G5ObstReflexAllowed,
  `OmegaCellC1P1B2BB1.SemValidObstructionOnOld,
  `OmegaCellC1P1B2BB1.SemValidRepairDischarge,
  `OmegaCellC1P1B2BB1.SemValidRetreatDischarge,
  `OmegaCellC1P1B2BB1.SemValidRefinementDischarge,
  `OmegaCellC1P1B2BB1.SemValidG5Discharge
]

def allExecutableCheckers : List Name := [
  `OmegaCellC1P1B1.checkG3Matrix,
  `OmegaCellC1P1B1.reifyTransportCode,
  `OmegaCellC1P1B2A.evalPartExprFuel,
  `OmegaCellC1P1B2A.evalStrictFormFuel,
  `OmegaCellC1P1B2A.evalPartExprGrid,
  `OmegaCellC1P1B2A.evalStrictFormGrid,
  `OmegaCellC1P1B2A.checkAlgDomCertBool,
  `OmegaCellC1P1B2A.checkExprDefUnderNzBool,
  `OmegaCellC1P1B2A.checkFormDefUnderNzBool,
  `OmegaCellC1P1B2A.checkGuardsPrefixDefinedAux,
  `OmegaCellC1P1B2A.verifyReachableDerivation,
  `OmegaCellC1P1B2A.checkCertifiedG7BundleBool,
  `OmegaCellC1P1B2BA0.intrinsicNzOfDom,
  `OmegaCellC1P1B2BA0.checkGuardsAndGoalDomDefBool,
  `OmegaCellC1P1B2BA0.isAtomicStrictFormBool,
  `OmegaCellC1P1B2BA0.checkBaseDomRetreatStepBool,
  `OmegaCellC1P1B2BA0.checkWellFormedParamSpecBool,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced,
  `OmegaCellC1P1B2BB1.checkRatCoordWfBool,
  `OmegaCellC1P1B2BB1.evalPartExprRatCoord,
  `OmegaCellC1P1B2BB1.evalStrictFormRatCoord,
  `OmegaCellC1P1B2BB1.checkInG7DomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkGuardsSatRatCoordBool,
  `OmegaCellC1P1B2BB1.checkInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkNotInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkModelsExcisedRatCoordBool,
  `OmegaCellC1P1B2BB1.collectG5ProofRootIds,
  `OmegaCellC1P1B2BB1.deriveG5PrimDeps,
  `OmegaCellC1P1B2BB1.checkVerifiedObstructionBool,
  `OmegaCellC1P1B2BB1.checkRepairDomEqBool,
  `OmegaCellC1P1B2BB1.checkRetreatExactPartitionBool,
  `OmegaCellC1P1B2BB1.checkRefinementBool,
  `OmegaCellC1P1B2BB1.checkG5CoreProofsBool,
  `OmegaCellC1P1B2BB1.checkG5DischargeBool
]

def isCoreMod (m : Name) : Bool :=
  let r := m.getRoot
  r == `Init || r == `Std || r == `Lean

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def main : IO UInt32 := do
  initSearchPath (← findSysroot)
  let pubEnv ← importModules #[{ module := `OmegaCellC1P1B2BB1 }] {}
  let rawEnv ← importModules #[{ module := `OmegaCellC1P1B2BB1, importAll := true }] {}
  let env := rawEnv.setExporting false

  let allowedMods := b1Modules5 ++ ancestorModules16
  let mut unexpectedMods : List String := []
  let mut gpedMods : List String := []
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    let ms := m.toString
    if ms.startsWith "Gped" || ms.startsWith "Principia" then
      gpedMods := ms :: gpedMods
    if !(isCoreMod m || allowedMods.contains m) then
      unexpectedMods := ms :: unexpectedMods

  let mut pubB1Decls : List String := []
  for i in [:pubEnv.header.moduleNames.size] do
    if b1Modules5.contains pubEnv.header.moduleNames[i]! then
      for c in pubEnv.header.moduleData[i]!.constNames do
        match c with
        | .str (`OmegaCellC1P1B2BB1) nm =>
            if !(nm.startsWith "instDecidableEq" || nm.startsWith "instRepr" || nm.startsWith "_private") then
              pubB1Decls := c.toString :: pubB1Decls
        | _ => pure ()
  let sortedPubB1 := pubB1Decls.mergeSort (· < ·)

  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut b1OwnedConstCount : Nat := 0
  let mut badAxiomRefs : List String := []
  let mut customAxiomDefs : List String := []
  let mut unsafeConsts : List String := []
  let mut opaqueConsts : List String := []
  let mut unjustifiedPartialConsts : List String := []
  let mut justifiedUnsafeRecCount : Nat := 0

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if b1Modules5.contains m then
      let md := env.header.moduleData[i]!
      b1OwnedConstCount := b1OwnedConstCount + md.constNames.size
      for c in md.constNames do
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) c) env
        for a in axs do
          if !allowedAx.contains a then
            badAxiomRefs := s!"{c} -> {a}" :: badAxiomRefs
        match env.find? c with
        | none => badAxiomRefs := s!"MISSING:{c}" :: badAxiomRefs
        | some ci =>
            if ci.isUnsafe then
              unsafeConsts := c.toString :: unsafeConsts
            match ci with
            | .axiomInfo _  => customAxiomDefs := c.toString :: customAxiomDefs
            | .opaqueInfo _ => opaqueConsts := c.toString :: opaqueConsts
            | .defnInfo v   =>
                if v.safety == .partial then
                  match c with
                  | .str parent "_unsafe_rec" =>
                      match env.find? parent with
                      | some (.defnInfo pv) =>
                          if pv.safety == .safe then
                            justifiedUnsafeRecCount := justifiedUnsafeRecCount + 1
                          else
                            unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                      | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                  | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
            | _ => pure ()

  let mut missingHeadline : List String := []
  let mut headlineAxiomReport : List (String × Json) := []
  for thm in b1HeadlineTheorems do
    match env.find? thm with
    | none => missingHeadline := thm.toString :: missingHeadline
    | some _ =>
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) thm) env
        headlineAxiomReport := headlineAxiomReport ++
          [(thm.toString, toJsonStrArr (axs.toList.map Name.toString))]

  let semCone := transitiveCone env b1SemanticAnchors
  let mut semCircularHits : List String := []
  for k in allExecutableCheckers do
    if semCone.contains k then
      semCircularHits := k.toString :: semCircularHits

  let masterCone := transitiveCone env [
    `OmegaCellC1P1B2BB1.checkG5DischargeBool,
    `OmegaCellC1P1B2BB1.T_B1_07_CheckG5Discharge_MasterSoundness
  ]
  let paramSubstUsedInCoreG5 := masterCone.contains `OmegaCellC1P1B2BA0.L_B2B_ParamSubst

  let allOk :=
    unexpectedMods.isEmpty &&
    gpedMods.isEmpty &&
    badAxiomRefs.isEmpty &&
    customAxiomDefs.isEmpty &&
    unsafeConsts.isEmpty &&
    opaqueConsts.isEmpty &&
    unjustifiedPartialConsts.isEmpty &&
    missingHeadline.isEmpty &&
    semCircularHits.isEmpty &&
    (!paramSubstUsedInCoreG5)

  let report := Json.mkObj [
    ("auditSchema", Json.str "principia.omega.p1b2b.b1.g5_env_audit.v1"),
    ("allChecksPassed", Json.bool allOk),
    ("b1OwnedConstantCount", Json.num b1OwnedConstCount),
    ("b1PublicDeclCount", Json.num sortedPubB1.length),
    ("b1PublicDecls", toJsonStrArr sortedPubB1),
    ("headlineTheoremCount", Json.num b1HeadlineTheorems.length),
    ("missingHeadlineTheorems", toJsonStrArr missingHeadline),
    ("headlineTheoremAxioms", Json.mkObj headlineAxiomReport),
    ("unexpectedModules", toJsonStrArr unexpectedMods),
    ("gpedModulesDetected", toJsonStrArr gpedMods),
    ("badAxiomRefs", toJsonStrArr badAxiomRefs),
    ("customAxiomDefs", toJsonStrArr customAxiomDefs),
    ("unsafeConsts", toJsonStrArr unsafeConsts),
    ("opaqueConsts", toJsonStrArr opaqueConsts),
    ("unjustifiedPartialConsts", toJsonStrArr unjustifiedPartialConsts),
    ("justifiedCompilerUnsafeRecCount", Json.num justifiedUnsafeRecCount),
    ("b1SemanticConeSize", Json.num semCone.size),
    ("semanticCheckerCircularHits", toJsonStrArr semCircularHits),
    ("paramSubstUsedInCoreG5Kernel", Json.bool paramSubstUsedInCoreG5),
    ("frozenRuntimeTraceConfinementStatus", Json.str "HELD_PER_A0_SIXTH_TRIBUNAL")
  ]
  IO.println report.pretty
  return (if allOk then 0 else 1)
