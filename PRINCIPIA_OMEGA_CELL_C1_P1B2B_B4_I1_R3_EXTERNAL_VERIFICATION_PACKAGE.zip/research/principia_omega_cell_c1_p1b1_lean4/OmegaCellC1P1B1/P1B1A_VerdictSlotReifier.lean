/-
  PRINCIPIA Ω-CELL-C1-P1B1 — Isolated Minimal Structural Checker Kernel
  Module: OmegaCellC1P1B1.P1B1A_VerdictSlotReifier

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1B1` Authorized — 7-Theorem Minimal Structural Kernel):
    1. Proof-Bearing Phantom-Indexed `AuditSlot` & `StructuralVerdict6` (`Masterstroke 1`, `T-B1-01`):
       - `AuditSlot` (`unchecked` vs `verified`: `unchecked` is epistemic bottom, NEVER `False`).
       - `SlotWitness RawCert check : AuditSlot → Type`: `.verified` CANNOT be forged by tag alone;
         it must carry `{ c : RawCert // check c = true }` (`Slot = .verified ⟹ ∃ π, check π = true`).
       - `StructuralQualification` (`.unchecked .verified .unchecked .unchecked`) is type-incompatible
         with `FullReflexAdmitted` (`.verified .verified .verified .verified`) and carries
         `CheckDerivesNoGrant` (`noGrantFromMathCheck`).
       - `StructuralVerdict6`: separates `structuralAccept`, `rejectInvalid`, `rejectRefuted`
         (bound to a verified refutation packet), `unsupportedHeld`, `unavailableHeld`, `resourceHeld`.
    2. `G3` Obstruction Matrix & `EnvironmentalFailure` Misuse vs Runtime Hold (`T-B1-03`):
       - Separates `KernelObstKindV1` (6 closed kinds) from `derivationBlocked` and `extObstruction`
         (`UnsupportedHeld`), rejects `(scopedNoGo, repair)`, `(invalidCertificate, retreat)`,
         non-redundant `(missingAssumption, repair)`, and misuse of `environmentalFailure` as an
         epistemic reflex trigger (`RejectInvalid`), while runtime fuel exhaustion yields `ResourceHeld`.
    3. Canonical Context-Bound Tag-Reflection Reifier (`Masterstroke 2`, `T-B1-02`):
       - Finite `TransportCode` DSL compiled in fixed canonical registry/base context `("reg_Q_v1", "base_Q")`
         directly into `P1A0` `CertifiedChartAnchor`s and `SemanticTransport`s with exact `seqCode`
         `(baseId, domTag, specId)` matching and zero `HEq`/`cast`.

  Explicitly Excluded (`NOT AUTHORIZED` / `FROZEN` / `HELD`):
    - Frozen `P1A0` (`8` files) is imported read-only (`0`-byte modification); `GPED` (`36` files)
      has `0` imports and `0` modifications.
    - `G1` hash/Merkle wire layer, `G5/G6` discharge/protected engine, `G7` full derivation footprint
      engine (`T-B1-07`), `P1B2/P1C`, `MT-22b`, `L3-P2C`, and `checkTraceDec` remain `NOT AUTHORIZED`.
-/
import OmegaCellC1P1A0

namespace OmegaCellC1P1B1

open OmegaCellC1P1A0

/-! ### 1. Structural Lineage Path Key, Proof-Bearing `AuditSlot`, & `StructuralVerdict6` (`T-B1-01`) -/

/-- Inductive rose-path key (`Masterstroke 4` — collision-free by constructor injectivity without
    cryptographic hash assumptions inside `P1B1`). -/
inductive StructuralPathKey where
  | root : (cellOld obstCid cellNew rflxCid : String) → StructuralPathKey
  | step : (parent : StructuralPathKey) → (cellOld obstCid cellNew rflxCid : String) → StructuralPathKey
  deriving DecidableEq, Repr

/-- Scott-ordered epistemic audit slot (`unchecked` = not yet verified, distinct from semantic `False`). -/
inductive AuditSlot where
  | unchecked : AuditSlot
  | verified  : AuditSlot
  deriving DecidableEq, Repr

/-- Proof-bearing dependent slot family (`Tribunal §2.A` Mandatory Guardrail):
    `.verified` cannot be inhabited without an actual certificate `c` passing `check c = true`. -/
inductive SlotWitness (RawCert : Type) (check : RawCert → Bool) : AuditSlot → Type where
  | mkUnchecked : SlotWitness RawCert check .unchecked
  | mkVerified  : (cert : { c : RawCert // check c = true }) → SlotWitness RawCert check .verified

/-- Unconditional certificate-extraction law: any `.verified` slot yields `∃ π, check π = true`. -/
theorem verified_slot_has_checked_cert {RawCert : Type} {check : RawCert → Bool}
    (w : SlotWitness RawCert check .verified) :
    ∃ π : RawCert, check π = true := by
  cases w with
  | mkVerified c => exact ⟨c.1, c.2⟩

/-- Explicit marker recording that mathematical qualification itself derives zero institutional grants
    (distinct from whether an external institution previously recorded grants in `GrantLedger`). -/
inductive CheckDerivesNoGrant where
  | noGrantFromMathCheck : CheckDerivesNoGrant
  deriving DecidableEq, Repr

/-- Structural gate identifiers for localized rejection attribution. -/
inductive StructuralGateId where
  | G2 : StructuralGateId
  | G3 : StructuralGateId
  | G4 : StructuralGateId
  | G8 : StructuralGateId
  deriving DecidableEq, Repr

/-- Fine-grained structural rejection reasons (`RejectInvalid` — submission contract failure,
    NOT a refutation of the candidate formula's truth). -/
inductive StructuralRejectErr where
  | registryMismatch            : StructuralRejectErr
  | baseMismatch                : StructuralRejectErr
  | externalCalibrationHeld     : StructuralRejectErr
  | obstCellOrSpecMismatch      : StructuralRejectErr
  | nonEpistemicObstMisuse      : StructuralRejectErr
  | forbiddenObstReflexPair     : StructuralRejectErr
  | unprovedGuardRepairAttempt  : StructuralRejectErr
  | illegalRelabelOrFakeChart   : StructuralRejectErr
  | seqEndpointMismatch         : StructuralRejectErr
  | domainOrSpecEndpointMismatch : StructuralRejectErr
  | kindDomainLawViolation      : StructuralRejectErr
  | parentLineageNotFound       : StructuralRejectErr
  | parentCellOrSpecDiscont     : StructuralRejectErr
  | retreatFlagLaundering       : StructuralRejectErr
  | duplicatePathKey            : StructuralRejectErr
  deriving DecidableEq, Repr

/-- Syntactic refutation record for `RejectRefuted` (requires verified binding to target `(cell, claim, spec)`). -/
structure RawRefutationCert where
  refutCid      : String
  targetCellId  : String
  targetClaimId : RatClaimId
  targetSpecId  : String
  counterPt     : Int
  deriving DecidableEq, Repr

/-- Computable check verifying that a `RawRefutationCert` genuinely refutes `targetClaimId` at `counterPt : Rat`. -/
def checkRawRefutationBool (rc : RawRefutationCert) : Bool :=
  (rc.refutCid != "") &&
  (rc.targetSpecId == "spec_v1" || rc.targetSpecId == "spec_v2") &&
  match rc.targetClaimId with
  | .sqPos    => rc.counterPt == 0
  | .sqNonneg => false

/-- Verified refutation packet: can ONLY be constructed when `checkRawRefutationBool rc = true`. -/
abbrev VerifiedRefutationPacket : Type :=
  { rc : RawRefutationCert // checkRawRefutationBool rc = true }

/-- Every `VerifiedRefutationPacket` witnesses a genuine `ValidCounterexamplePoint` on `ℚ`. -/
theorem verifiedRefutationPacket_sound (vp : VerifiedRefutationPacket) :
    ValidCounterexamplePoint (fun _ : Rat => True)
      (evalRatClaimPred vp.1.targetSpecId vp.1.targetClaimId) (vp.1.counterPt : Rat) := by
  have hb := vp.2
  unfold checkRawRefutationBool at hb
  simp only [Bool.and_eq_true] at hb
  rcases hb with ⟨_, hmatch⟩
  cases hc : vp.1.targetClaimId <;> rw [hc] at hmatch
  · contradiction
  · have hpt : vp.1.counterPt = 0 := eq_of_beq hmatch
    rw [hpt]
    exact T_A0_05_undefined_vs_defined_false_separation.2.2.1

/-- Non-acceptance branches shared by `reifyTransportCode` and `checkStructuralReflex`. -/
inductive NonAcceptOutcome where
  | rejectInvalid   : StructuralGateId → StructuralRejectErr → NonAcceptOutcome
  | rejectRefuted   : VerifiedRefutationPacket → NonAcceptOutcome
  | unsupportedHeld : String → NonAcceptOutcome
  | unavailableHeld : String → NonAcceptOutcome
  | resourceHeld    : Nat → NonAcceptOutcome
  deriving DecidableEq

/-- Summary certificate verified by `P1B1` (`G2 · G3 · G4 · G8` structural checks). -/
structure CheckedG2348Summary where
  rflxCid              : String
  pathKey              : StructuralPathKey
  cellOldCid           : String
  obstCid              : String
  cellNewCid           : String
  baseId               : String
  domOldId             : String
  domNewId             : String
  specOldId            : String
  specNewId            : String
  historicalRetreat    : Bool
  checkedHistoryIds    : List String
  nonEmptyRflxCidCheck : Bool
  deriving DecidableEq, Repr

/-- Structural summary sanity check (`nonEmptyRflxCidCheck && rflxCid != ""`). -/
def checkG2348SummaryBool (s : CheckedG2348Summary) : Bool :=
  s.nonEmptyRflxCidCheck && (s.rflxCid != "")

/-- Parametric 4-slot qualification spine (`G1`, `G2348`, `G56`, `G7`) parameterized by future
    certificate types and their boolean checkers (`Masterstroke 1`). -/
structure ReflexQualification
    {G1Raw G56Raw G7Raw : Type}
    (checkG1  : G1Raw → Bool)
    (checkG56 : G56Raw → Bool)
    (checkG7  : G7Raw → Bool)
    (sG1 s2348 sG56 sG7 : AuditSlot) where
  slotG1    : SlotWitness G1Raw checkG1 sG1
  slot2348  : SlotWitness CheckedG2348Summary checkG2348SummaryBool s2348
  slotG56   : SlotWitness G56Raw checkG56 sG56
  slotG7    : SlotWitness G7Raw checkG7 sG7
  grantFlag : CheckDerivesNoGrant

/-- Placeholder unimplemented certificate type for `G1`, `G56`, `G7` in `P1B1` (`NOT AUTHORIZED`). -/
inductive UnauthorizedStageCert where
  | mkPlaceholder : String → UnauthorizedStageCert
  deriving DecidableEq, Repr

/-- Disabled checker (`false`) ensuring `.verified` cannot be forged for unauthorized stages in `P1B1`. -/
def checkUnauthStageCertBool (_ : UnauthorizedStageCert) : Bool :=
  false

/-- **`StructuralQualification`** (`P1B1` output): ONLY `s2348 = .verified`; `G1`, `G56`, `G7` are `.unchecked`. -/
abbrev StructuralQualification : Type :=
  ReflexQualification
    checkUnauthStageCertBool checkUnauthStageCertBool checkUnauthStageCertBool
    .unchecked .verified .unchecked .unchecked

/-- **`FullReflexAdmitted`** (`Future Full Pipeline` output): ALL four slots `.verified`. -/
abbrev FullReflexAdmitted
    {G1Raw G56Raw G7Raw : Type}
    (c1 : G1Raw → Bool) (c56 : G56Raw → Bool) (c7 : G7Raw → Bool) : Type :=
  ReflexQualification c1 c56 c7 .verified .verified .verified .verified

/-- Extract the underlying `CheckedG2348Summary` from a `StructuralQualification`. -/
def extractSummary (sq : StructuralQualification) : CheckedG2348Summary :=
  match sq.slot2348 with
  | .mkVerified c => c.1

/-- Monotone upgrade combinator showing `.unchecked` can later be upgraded to `.verified` without
    contradiction or re-proving `slot2348` once `G1`, `G56`, `G7` certificates are supplied. -/
def upgradeStructuralToFull
    {G1Raw G56Raw G7Raw : Type}
    {c1 : G1Raw → Bool} {c56 : G56Raw → Bool} {c7 : G7Raw → Bool}
    (sq  : ReflexQualification c1 c56 c7 .unchecked .verified .unchecked .unchecked)
    (w1  : { x : G1Raw // c1 x = true })
    (w56 : { x : G56Raw // c56 x = true })
    (w7  : { x : G7Raw // c7 x = true }) :
    FullReflexAdmitted c1 c56 c7 where
  slotG1    := .mkVerified w1
  slot2348  := sq.slot2348
  slotG56   := .mkVerified w56
  slotG7    := .mkVerified w7
  grantFlag := sq.grantFlag

/-- Six-branch epistemic-polarity verdict returned by `P1B1` (`F-P1B-P0-01`). -/
inductive StructuralVerdict6 where
  | structuralAccept : StructuralQualification → StructuralVerdict6
  | rejectInvalid    : StructuralGateId → StructuralRejectErr → StructuralVerdict6
  | rejectRefuted    : VerifiedRefutationPacket → StructuralVerdict6
  | unsupportedHeld  : String → StructuralVerdict6
  | unavailableHeld  : String → StructuralVerdict6
  | resourceHeld     : Nat → StructuralVerdict6

/-- Lift a `NonAcceptOutcome` into `StructuralVerdict6`. -/
def nonAcceptToVerdict6 : NonAcceptOutcome → StructuralVerdict6
  | .rejectInvalid g e => .rejectInvalid g e
  | .rejectRefuted vp  => .rejectRefuted vp
  | .unsupportedHeld t => .unsupportedHeld t
  | .unavailableHeld c => .unavailableHeld c
  | .resourceHeld f    => .resourceHeld f

/-- Boolean projection testing whether a verdict is `.structuralAccept`. -/
def isStructuralAcceptBool : StructuralVerdict6 → Bool
  | .structuralAccept _ => true
  | _                   => false

/-- Boolean projection testing whether a verdict carries a verified semantic refutation. -/
def hasVerifiedRefutationBool : StructuralVerdict6 → Bool
  | .rejectRefuted _ => true
  | _                => false

/-- **`T-B1-01` — Proof-Bearing Slot Invariant, Unforgeable Unauthorized Stages, & Verdict Polarity**:
    (1) Every `.verified` slot in `ReflexQualification` yields an actual checked certificate;
    (2) Under `checkUnauthStageCertBool`, `FullReflexAdmitted` is provably uninhabited (`Empty`) in `P1B1`,
        sealing `StructuralQualification ≠ FullReflexAdmitted`;
    (3) Every `StructuralQualification` carries `grantFlag = .noGrantFromMathCheck`;
    (4) Among all `6` verdict branches, ONLY `.rejectRefuted` sets `hasVerifiedRefutationBool = true`
        (and guarantees a genuine `ValidCounterexamplePoint`), while `rejectInvalid`, `unsupportedHeld`,
        `unavailableHeld`, and `resourceHeld` carry neither acceptance nor semantic refutation. -/
theorem T_B1_01_proof_bearing_slots_and_verdict_polarity :
    (∀ sq : StructuralQualification,
      checkG2348SummaryBool (extractSummary sq) = true ∧
      sq.grantFlag = .noGrantFromMathCheck) ∧
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool checkUnauthStageCertBool checkUnauthStageCertBool) ∧
    (∀ (g : StructuralGateId) (e : StructuralRejectErr),
      isStructuralAcceptBool (.rejectInvalid g e) = false ∧
      hasVerifiedRefutationBool (.rejectInvalid g e) = false) ∧
    (∀ t : String,
      isStructuralAcceptBool (.unsupportedHeld t) = false ∧
      hasVerifiedRefutationBool (.unsupportedHeld t) = false) ∧
    (∀ c : String,
      isStructuralAcceptBool (.unavailableHeld c) = false ∧
      hasVerifiedRefutationBool (.unavailableHeld c) = false) ∧
    (∀ f : Nat,
      isStructuralAcceptBool (.resourceHeld f) = false ∧
      hasVerifiedRefutationBool (.resourceHeld f) = false) ∧
    (∀ vp : VerifiedRefutationPacket,
      isStructuralAcceptBool (.rejectRefuted vp) = false ∧
      hasVerifiedRefutationBool (.rejectRefuted vp) = true ∧
      ValidCounterexamplePoint (fun _ : Rat => True)
        (evalRatClaimPred vp.1.targetSpecId vp.1.targetClaimId) (vp.1.counterPt : Rat)) := by
  refine ⟨?_, ?_, fun _ _ => ⟨rfl, rfl⟩, fun _ => ⟨rfl, rfl⟩,
          fun _ => ⟨rfl, rfl⟩, fun _ => ⟨rfl, rfl⟩, ?_⟩
  · intro sq
    rcases sq with ⟨_, s2348, _, _, gflag⟩
    cases s2348 with
    | mkVerified c =>
        cases gflag
        exact ⟨c.2, rfl⟩
  · rintro ⟨full⟩
    rcases verified_slot_has_checked_cert full.slotG1 with ⟨_, hbad⟩
    contradiction
  · intro vp
    exact ⟨rfl, rfl, verifiedRefutationPacket_sound vp⟩

/-! ### 2. `G3` Obstruction Matrix & `EnvironmentalFailure` Misuse Separation (`T-B1-03`) -/

/-- Closed 6-species V1 kernel obstruction kind (`F-C1-01`). -/
inductive KernelObstKindV1 where
  | counterexamplePoint  : KernelObstKindV1
  | invalidCertificate   : KernelObstKindV1
  | missingAssumption    : (guardRedundantCertified : Bool) → KernelObstKindV1
  | unsupportedHorizon   : KernelObstKindV1
  | scopedNoGo           : KernelObstKindV1
  | environmentalFailure : KernelObstKindV1
  deriving DecidableEq, Repr

/-- Explorer-level obstruction input separating V1 kernel kinds from `derivationBlocked` and
    open `extObstruction` (`F-C1-01`, `F-C1-02`). -/
inductive ExplorerObstInput where
  | knownV1           : KernelObstKindV1 → ExplorerObstInput
  | derivationBlocked : (fuelUsed : Nat) → ExplorerObstInput
  | extObstruction    : (schemaTag : String) → ExplorerObstInput
  deriving DecidableEq, Repr

/-- Epistemic reflex morphism classification (`Repair / Retreat / Refinement`). -/
inductive ReflexKind where
  | repair     : ReflexKind
  | retreat    : ReflexKind
  | refinement : ReflexKind
  deriving DecidableEq, Repr

/-- Independent declarative `ObstKind × ReflexKind` admissibility predicate (`Prop`, used by
    `SemStructuralValid` without calling `checkG3Matrix`). -/
def ObstReflexMatrixAllowed : KernelObstKindV1 → ReflexKind → Prop
  | .counterexamplePoint,      _           => True
  | .invalidCertificate,       .repair     => True
  | .invalidCertificate,       .refinement => True
  | .invalidCertificate,       .retreat    => False
  | .missingAssumption true,   .repair     => True
  | .missingAssumption false,  .repair     => False
  | .missingAssumption _,      .retreat    => True
  | .missingAssumption _,      .refinement => True
  | .unsupportedHorizon,       _           => True
  | .scopedNoGo,               .repair     => False
  | .scopedNoGo,               .retreat    => True
  | .scopedNoGo,               .refinement => True
  | .environmentalFailure,     _           => False

/-- Computable `G3` dispatcher separating `UnsupportedHeld` (`derivationBlocked`, `extObstruction`),
    `RejectInvalid` (`environmentalFailure` misuse, `⊥` matrix cells), and admissible pairs. -/
def checkG3Matrix (inp : ExplorerObstInput) (rk : ReflexKind) : Except NonAcceptOutcome KernelObstKindV1 :=
  match inp with
  | .derivationBlocked _ => .error (.unsupportedHeld "derivation_blocked_non_refuting")
  | .extObstruction tag  => .error (.unsupportedHeld ("ext_obst:" ++ tag))
  | .knownV1 okind =>
      match okind, rk with
      | .environmentalFailure,    _        => .error (.rejectInvalid .G3 .nonEpistemicObstMisuse)
      | .scopedNoGo,              .repair  => .error (.rejectInvalid .G3 .forbiddenObstReflexPair)
      | .invalidCertificate,      .retreat => .error (.rejectInvalid .G3 .forbiddenObstReflexPair)
      | .missingAssumption false, .repair  => .error (.rejectInvalid .G3 .unprovedGuardRepairAttempt)
      | _,                        _        => .ok okind

/-- **`T-B1-03` — `G3` Matrix Soundness, `UnsupportedHeld` Routing, & `EnvironmentalFailure` Separation**:
    (1) `checkG3Matrix inp rk = .ok okind` implies `inp = .knownV1 okind`, `okind ≠ .environmentalFailure`,
        and `ObstReflexMatrixAllowed okind rk`;
    (2) Misusing `.environmentalFailure` as an obstruction in a reflex submission yields
        `.rejectInvalid .G3 .nonEpistemicObstMisuse` (`CE-C1-06`), distinct from runtime `resourceHeld`;
    (3) `(scopedNoGo, repair)` (`CE-C1-04`), `(invalidCertificate, retreat)`, and unproved-guard
        `(missingAssumption false, repair)` (`CE-C1-03`) all yield `.rejectInvalid .G3`;
    (4) `derivationBlocked` and `extObstruction` yield `.unsupportedHeld` (neither accept nor refutation). -/
theorem T_B1_03_obstruction_matrix_and_env_misuse_separation :
    (∀ (inp : ExplorerObstInput) (rk : ReflexKind) (okind : KernelObstKindV1),
      checkG3Matrix inp rk = .ok okind →
        inp = .knownV1 okind ∧ okind ≠ .environmentalFailure ∧ ObstReflexMatrixAllowed okind rk) ∧
    (∀ rk : ReflexKind,
      checkG3Matrix (.knownV1 .environmentalFailure) rk =
        .error (.rejectInvalid .G3 .nonEpistemicObstMisuse)) ∧
    (checkG3Matrix (.knownV1 .scopedNoGo) .repair =
      .error (.rejectInvalid .G3 .forbiddenObstReflexPair)) ∧
    (checkG3Matrix (.knownV1 .invalidCertificate) .retreat =
      .error (.rejectInvalid .G3 .forbiddenObstReflexPair)) ∧
    (checkG3Matrix (.knownV1 (.missingAssumption false)) .repair =
      .error (.rejectInvalid .G3 .unprovedGuardRepairAttempt)) ∧
    (∀ (n : Nat) (rk : ReflexKind),
      checkG3Matrix (.derivationBlocked n) rk =
        .error (.unsupportedHeld "derivation_blocked_non_refuting")) ∧
    (∀ (tag : String) (rk : ReflexKind),
      checkG3Matrix (.extObstruction tag) rk =
        .error (.unsupportedHeld ("ext_obst:" ++ tag))) := by
  refine ⟨?_, ?_, rfl, rfl, rfl, fun _ _ => rfl, fun _ _ => rfl⟩
  · intro inp rk okind hok
    cases inp with
    | derivationBlocked _ => nomatch hok
    | extObstruction _    => nomatch hok
    | knownV1 k =>
        cases k with
        | counterexamplePoint =>
            cases rk <;> (injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩)
        | invalidCertificate =>
            cases rk with
            | repair     => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
            | refinement => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
            | retreat    => nomatch hok
        | missingAssumption b =>
            cases b with
            | true =>
                cases rk <;> (injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩)
            | false =>
                cases rk with
                | repair     => nomatch hok
                | retreat    => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
                | refinement => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
        | unsupportedHorizon =>
            cases rk <;> (injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩)
        | scopedNoGo =>
            cases rk with
            | repair     => nomatch hok
            | retreat    => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
            | refinement => injection hok with heq; subst heq; exact ⟨rfl, by decide, trivial⟩
        | environmentalFailure =>
            cases rk <;> nomatch hok
  · intro rk
    cases rk <;> rfl

/-! ### 3. Context-Bound Tag-Reflection `TransportCode` Reifier (`Masterstroke 2`, `T-B1-02`) -/

/-- Canonical V1 domain tags supported in registry `"reg_Q_v1"` over `"base_Q"`. -/
inductive KernelDomTagV1 where
  | domQ        : KernelDomTagV1
  | domQNonzero : KernelDomTagV1
  deriving DecidableEq, Repr

/-- Canonical domain identifier string of a `KernelDomTagV1`. -/
def domTagToId : KernelDomTagV1 → String
  | .domQ        => "dom_Q"
  | .domQNonzero => "dom_Q_nonzero"

/-- Parse a domain string into `KernelDomTagV1` (`none` routes to `UnsupportedHeld`). -/
def parseDomTagV1? (domId : String) : Option KernelDomTagV1 :=
  if domId == "dom_Q" then some .domQ
  else if domId == "dom_Q_nonzero" then some .domQNonzero
  else none

theorem parseDomTagV1?_sound {domId : String} {t : KernelDomTagV1}
    (h : parseDomTagV1? domId = some t) :
    domTagToId t = domId := by
  unfold parseDomTagV1? at h
  by_cases h1 : (domId == "dom_Q") = true
  · rw [if_pos h1] at h
    injection h with ht
    subst ht
    exact (eq_of_beq h1).symm
  · rw [if_neg h1] at h
    by_cases h2 : (domId == "dom_Q_nonzero") = true
    · rw [if_pos h2] at h
      injection h with ht
      subst ht
      exact (eq_of_beq h2).symm
    · rw [if_neg h2] at h
      nomatch h

/-- Reflected carrier type for `KernelDomTagV1`. -/
def DomTagCarrier : KernelDomTagV1 → Type
  | .domQ        => Rat
  | .domQNonzero => RatNonzero

/-- Canonical `P1A0` `CertifiedChartAnchor` reflected in fixed context `("reg_Q_v1", "base_Q")`
    (`Tribunal §2.B`: tag elimination is strictly bound to identical canonical registry/base/spec). -/
def domTagCanonicalAnchor : (t : KernelDomTagV1) →
    CertifiedChartAnchor ratPinnedRegistry "base_Q" (domTagToId t) (DomTagCarrier t)
  | .domQ        => ratFullCertifiedAnchor
  | .domQNonzero => ratNonzeroCertifiedAnchor

/-- Declarative domain law required by each `ReflexKind` on a `SemanticTransport`. -/
def KindDomainLaw {t1 t2 : KernelDomTagV1} (rk : ReflexKind)
    (τ : SemanticTransport (domTagCanonicalAnchor t1) (domTagCanonicalAnchor t2)) : Prop :=
  match rk with
  | .repair     => ValidRepairTransport τ
  | .retreat    => ValidRetreatTransport τ
  | .refinement => ValidRefinementSection τ

/-- Finite syntactic `TransportCode` DSL submitted inside untrusted `StructuralReflexAST`. -/
inductive TransportCode where
  | idCode               : (baseId domId specSrc specDst : String) → TransportCode
  | restrictNonzeroCode  : (baseId specSrc specDst : String) → TransportCode
  | reexpandFullCode     : (baseId specSrc specDst : String) → TransportCode
  | seqCode              : TransportCode → TransportCode → TransportCode
  | hilbertRelabelCode   : (baseId specSrc specDst : String) → TransportCode
  | fakeChartRelabelCode : (baseId specSrc specDst : String) → TransportCode
  | extUnsupportedCode   : (tag : String) → TransportCode
  deriving DecidableEq, Repr

/-- Exact structural mode classification carried by reified transport steps. -/
inductive ReifiedTransportMode where
  | fullIso           : ReifiedTransportMode
  | strictRetreat     : ReifiedTransportMode
  | strictSection     : ReifiedTransportMode
  | mixedUnqualified  : ReifiedTransportMode
  deriving DecidableEq, Repr

/-- Proof-carrying intermediate reification record (`0` `cast`s, `0` `HEq`s). -/
structure ReifiedRawTransport where
  srcTag    : KernelDomTagV1
  dstTag    : KernelDomTagV1
  srcSpecId : String
  dstSpecId : String
  mode      : ReifiedTransportMode
  transport : SemanticTransport (domTagCanonicalAnchor srcTag) (domTagCanonicalAnchor dstTag)
  lawIso    : mode = .fullIso → ValidRepairTransport transport ∧ ValidRefinementSection transport
  lawRet    : mode = .strictRetreat → ValidRetreatTransport transport
  lawSec    : mode = .strictSection → ValidRefinementSection transport

private def composeModes (m1 m2 : ReifiedTransportMode) : ReifiedTransportMode :=
  match m1, m2 with
  | .fullIso,       .fullIso       => .fullIso
  | .fullIso,       .strictRetreat => .strictRetreat
  | .strictRetreat, .fullIso       => .strictRetreat
  | .strictRetreat, .strictRetreat => .strictRetreat
  | .fullIso,       .strictSection => .strictSection
  | .strictSection, .fullIso       => .strictSection
  | .strictSection, .strictSection => .strictSection
  | _,              _              => .mixedUnqualified

/-- Fuel-bounded proof-carrying structural reifier for `TransportCode` in canonical `"reg_Q_v1"`. -/
def reifyRawTransport (fuel : Nat) (regId : String) (code : TransportCode) :
    Except NonAcceptOutcome ReifiedRawTransport :=
  match fuel with
  | 0 => .error (.resourceHeld 0)
  | fuel' + 1 =>
      if regId != "reg_Q_v1" then
        .error (.rejectInvalid .G2 .registryMismatch)
      else
        match code with
        | .extUnsupportedCode tag =>
            .error (.unsupportedHeld ("transport:" ++ tag))
        | .hilbertRelabelCode _ _ _ =>
            .error (.rejectInvalid .G4 .illegalRelabelOrFakeChart)
        | .fakeChartRelabelCode _ _ _ =>
            .error (.rejectInvalid .G4 .illegalRelabelOrFakeChart)
        | .idCode baseId domId specSrc specDst =>
            if baseId != "base_Q" then
              .error (.rejectInvalid .G2 .baseMismatch)
            else
              match parseDomTagV1? domId with
              | none => .error (.unsupportedHeld ("dom:" ++ domId))
              | some t =>
                  .ok {
                    srcTag    := t
                    dstTag    := t
                    srcSpecId := specSrc
                    dstSpecId := specDst
                    mode      := .fullIso
                    transport := idSemanticTransport (domTagCanonicalAnchor t)
                    lawIso    := fun _ => ⟨⟨fun _ => trivial, fun _ => trivial⟩, fun _ => trivial⟩
                    lawRet    := fun h => nomatch h
                    lawSec    := fun h => nomatch h
                  }
        | .restrictNonzeroCode baseId specSrc specDst =>
            if baseId != "base_Q" then
              .error (.rejectInvalid .G2 .baseMismatch)
            else
              .ok {
                srcTag    := .domQ
                dstTag    := .domQNonzero
                srcSpecId := specSrc
                dstSpecId := specDst
                mode      := .strictRetreat
                transport := ratRetreatToNonzero
                lawIso    := fun h => nomatch h
                lawRet    := fun _ => ⟨⟨(0 : Rat), fun hne => hne rfl⟩, fun _ => trivial⟩
                lawSec    := fun h => nomatch h
              }
        | .reexpandFullCode baseId specSrc specDst =>
            if baseId != "base_Q" then
              .error (.rejectInvalid .G2 .baseMismatch)
            else
              .ok {
                srcTag    := .domQNonzero
                dstTag    := .domQ
                srcSpecId := specSrc
                dstSpecId := specDst
                mode      := .strictSection
                transport := ratReexpandToFull
                lawIso    := fun h => nomatch h
                lawRet    := fun h => nomatch h
                lawSec    := fun _ => fun _ => trivial
              }
        | .seqCode c1 c2 =>
            match reifyRawTransport fuel' regId c1 with
            | .error e => .error e
            | .ok ⟨t0, t1, sSrc1, sMid1, m1, τ1, lIso1, lRet1, lSec1⟩ =>
                match reifyRawTransport fuel' regId c2 with
                | .error e => .error e
                | .ok ⟨t1', t2, sMid2, sDst2, m2, τ2, lIso2, lRet2, lSec2⟩ =>
                    if hdom : t1 = t1' then
                      if sMid1 == sMid2 then
                        by
                          cases hdom
                          exact .ok {
                            srcTag    := t0
                            dstTag    := t2
                            srcSpecId := sSrc1
                            dstSpecId := sDst2
                            mode      := composeModes m1 m2
                            transport := composeSemanticTransport τ1 τ2
                            lawIso    := by
                              intro hm
                              cases m1 <;> cases m2 <;> try contradiction
                              have h1 := (lIso1 rfl).1
                              have h2 := (lIso2 rfl).1
                              refine ⟨⟨fun x => ⟨h1.1 x, h2.1 _⟩, fun z => ⟨h2.2 z, h1.2 _⟩⟩,
                                      fun x => ⟨h1.1 x, h2.1 _⟩⟩
                            lawRet    := by
                              intro hm
                              cases m1 <;> cases m2 <;> try contradiction
                              · have h1 := (lIso1 rfl).1
                                have h2 := lRet2 rfl
                                rcases h2.1 with ⟨yLost, hnot2⟩
                                let xLost := (τ1.invFun ⟨yLost, h1.2 yLost⟩).1
                                refine ⟨⟨xLost, ?_⟩, fun z => ⟨h2.2 z, h1.2 _⟩⟩
                                rintro ⟨hx1, hx2⟩
                                have hr := congrArg Subtype.val (τ1.right_inv ⟨yLost, h1.2 yLost⟩)
                                rw [hr] at hx2
                                exact hnot2 hx2
                              · have h1 := lRet1 rfl
                                have h2 := (lIso2 rfl).1
                                rcases h1.1 with ⟨xLost, hnot1⟩
                                exact ⟨⟨xLost, fun ⟨hx1, _⟩ => hnot1 hx1⟩,
                                       fun z => ⟨h2.2 z, h1.2 _⟩⟩
                              · have h1 := lRet1 rfl
                                have h2 := lRet2 rfl
                                rcases h1.1 with ⟨xLost, hnot1⟩
                                exact ⟨⟨xLost, fun ⟨hx1, _⟩ => hnot1 hx1⟩,
                                       fun z => ⟨h2.2 z, h1.2 _⟩⟩
                            lawSec    := by
                              intro hm
                              cases m1 <;> cases m2 <;> try contradiction
                              · exact fun x => ⟨(lIso1 rfl).2 x, lSec2 rfl _⟩
                              · exact fun x => ⟨lSec1 rfl x, (lIso2 rfl).2 _⟩
                              · exact fun x => ⟨lSec1 rfl x, lSec2 rfl _⟩
                          }
                      else
                        .error (.rejectInvalid .G4 .seqEndpointMismatch)
                    else
                      .error (.rejectInvalid .G4 .seqEndpointMismatch)

/-- Final proof-carrying `CertifiedTransportPackage` validated against `(domOld, domNew, specOld, specNew, rk)`. -/
structure CertifiedTransportPackage (domOldId domNewId specOldId specNewId : String) (rk : ReflexKind) where
  srcTag     : KernelDomTagV1
  dstTag     : KernelDomTagV1
  srcDom_eq  : domTagToId srcTag = domOldId
  dstDom_eq  : domTagToId dstTag = domNewId
  transport  : SemanticTransport (domTagCanonicalAnchor srcTag) (domTagCanonicalAnchor dstTag)
  domainLaw  : KindDomainLaw rk transport

/-- Dependent mode-to-`KindDomainLaw` extractor refining `rk` cleanly without `cast` (`PLift` wraps `Prop`). -/
def extractKindDomainLaw : (rk : ReflexKind) → (raw : ReifiedRawTransport) →
    Option (PLift (KindDomainLaw rk raw.transport))
  | .repair, raw =>
      if hm : raw.mode = .fullIso then some (.up ((raw.lawIso hm).1)) else none
  | .retreat, raw =>
      if hm : raw.mode = .strictRetreat then some (.up (raw.lawRet hm)) else none
  | .refinement, raw =>
      if hm1 : raw.mode = .fullIso then some (.up ((raw.lawIso hm1).2))
      else if hm2 : raw.mode = .strictSection then some (.up (raw.lawSec hm2))
      else none

/-- Top-level `G2 + G4` proof-carrying `reifyTransportCode` checking registry, base, provenance,
    endpoint alignment, and `KindDomainLaw` (`Masterstroke 2`). -/
def reifyTransportCode (fuel : Nat) (regId baseId domOldId domNewId specOldId specNewId : String)
    (provOld provNew : ChartProvenance) (rk : ReflexKind) (code : TransportCode) :
    Except NonAcceptOutcome (CertifiedTransportPackage domOldId domNewId specOldId specNewId rk) :=
  if regId != "reg_Q_v1" then
    .error (.rejectInvalid .G2 .registryMismatch)
  else if baseId != "base_Q" then
    .error (.rejectInvalid .G2 .baseMismatch)
  else if !isKernelCertifiedProvenance provOld || !isKernelCertifiedProvenance provNew then
    .error (.rejectInvalid .G2 .externalCalibrationHeld)
  else if (parseDomTagV1? domOldId).isNone then
    .error (.unsupportedHeld ("dom_old:" ++ domOldId))
  else if (parseDomTagV1? domNewId).isNone then
    .error (.unsupportedHeld ("dom_new:" ++ domNewId))
  else
    match reifyRawTransport fuel regId code with
    | .error e => .error e
    | .ok raw =>
        if hOld : domTagToId raw.srcTag = domOldId then
          if hNew : domTagToId raw.dstTag = domNewId then
            if (raw.srcSpecId == specOldId) && (raw.dstSpecId == specNewId) then
              match extractKindDomainLaw rk raw with
              | some (.up hLaw) => .ok ⟨raw.srcTag, raw.dstTag, hOld, hNew, raw.transport, hLaw⟩
              | none            => .error (.rejectInvalid .G4 .kindDomainLawViolation)
            else
              .error (.rejectInvalid .G4 .domainOrSpecEndpointMismatch)
          else
            .error (.rejectInvalid .G4 .domainOrSpecEndpointMismatch)
        else
          .error (.rejectInvalid .G4 .domainOrSpecEndpointMismatch)

/-- **`T-B1-02` — Proof-Carrying `reifyTransportCode` Soundness & `seqCode` Endpoint Enforcement**:
    (1) Whenever `reifyTransportCode ... = .ok pkg`, `regId = "reg_Q_v1"`, `baseId = "base_Q"`,
        `provOld ≠ .externalCalibrationHeld`, `provNew ≠ .externalCalibrationHeld`, and `pkg.transport`
        is a genuine `P1A0` `SemanticTransport` satisfying base commutativity, observable equivalence,
        and `KindDomainLaw rk pkg.transport`;
    (2) Submitting `restrictNonzeroCode` (`ℚ → ℚ \ {0}`) under `rk = .repair` (`CE-C1-01`), submitting
        `hilbertRelabelCode` (`CE-C1-01a`), submitting `fakeChartRelabelCode` (`CE-C1-01b`), or
        submitting a `seqCode` with mismatched intermediate domain or spec all deterministically fail
        with `.rejectInvalid .G4`. -/
theorem T_B1_02_reifyTransportCode_sound_and_seq_checked :
    (∀ (fuel : Nat) (regId baseId domOldId domNewId specOldId specNewId : String)
       (provOld provNew : ChartProvenance) (rk : ReflexKind) (code : TransportCode)
       (pkg : CertifiedTransportPackage domOldId domNewId specOldId specNewId rk),
      reifyTransportCode fuel regId baseId domOldId domNewId specOldId specNewId
        provOld provNew rk code = .ok pkg →
        regId = "reg_Q_v1" ∧
        baseId = "base_Q" ∧
        provOld ≠ .externalCalibrationHeld ∧
        provNew ≠ .externalCalibrationHeld ∧
        KindDomainLaw rk pkg.transport ∧
        (∀ u : { x // pkg.transport.retDom x },
          (domTagCanonicalAnchor pkg.dstTag).j (pkg.transport.toFun u).1 =
            (domTagCanonicalAnchor pkg.srcTag).j u.1) ∧
        (∀ (i : RatObsIdx) (u : { x // pkg.transport.retDom x }),
          (domTagCanonicalAnchor pkg.dstTag).domSpec.obsD i (pkg.transport.toFun u).1 ↔
            (domTagCanonicalAnchor pkg.srcTag).domSpec.obsD i u.1)) ∧
    (reifyTransportCode 4 "reg_Q_v1" "base_Q" "dom_Q" "dom_Q_nonzero" "spec_v1" "spec_v2"
        .canonicalIdentity .canonicalSubspace .repair
        (.restrictNonzeroCode "base_Q" "spec_v1" "spec_v2") =
      .error (.rejectInvalid .G4 .kindDomainLawViolation)) ∧
    (reifyTransportCode 4 "reg_Q_v1" "base_Q" "dom_Q" "dom_Q_nonzero" "spec_v1" "spec_v2"
        .canonicalIdentity .canonicalSubspace .repair
        (.hilbertRelabelCode "base_Q" "spec_v1" "spec_v2") =
      .error (.rejectInvalid .G4 .illegalRelabelOrFakeChart)) ∧
    (reifyTransportCode 4 "reg_Q_v1" "base_Q" "dom_Q" "dom_Q_nonzero" "spec_v1" "spec_v2"
        .canonicalIdentity .canonicalSubspace .repair
        (.fakeChartRelabelCode "base_Q" "spec_v1" "spec_v2") =
      .error (.rejectInvalid .G4 .illegalRelabelOrFakeChart)) ∧
    (reifyTransportCode 4 "reg_Q_v1" "base_Q" "dom_Q" "dom_Q" "spec_v1" "spec_v3"
        .canonicalIdentity .canonicalIdentity .repair
        (.seqCode (.idCode "base_Q" "dom_Q" "spec_v1" "spec_v2")
                  (.idCode "base_Q" "dom_Q_nonzero" "spec_v2" "spec_v3")) =
      .error (.rejectInvalid .G4 .seqEndpointMismatch)) ∧
    (reifyTransportCode 4 "reg_Q_v1" "base_Q" "dom_Q" "dom_Q" "spec_v1" "spec_v3"
        .canonicalIdentity .canonicalIdentity .repair
        (.seqCode (.idCode "base_Q" "dom_Q" "spec_v1" "spec_v2")
                  (.idCode "base_Q" "dom_Q" "spec_WRONG" "spec_v3")) =
      .error (.rejectInvalid .G4 .seqEndpointMismatch)) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro fuel regId baseId domOldId domNewId specOldId specNewId provOld provNew rk code pkg hok
    unfold reifyTransportCode at hok
    by_cases hreg : (regId != "reg_Q_v1") = true
    · rw [if_pos hreg] at hok; nomatch hok
    · rw [if_neg hreg] at hok
      have hreg_eq : regId = "reg_Q_v1" := by
        cases hr : (regId == "reg_Q_v1") with
        | true => exact eq_of_beq hr
        | false => simp [bne, hr] at hreg
      by_cases hbase : (baseId != "base_Q") = true
      · rw [if_pos hbase] at hok; nomatch hok
      · rw [if_neg hbase] at hok
        have hbase_eq : baseId = "base_Q" := by
          cases hb : (baseId == "base_Q") with
          | true => exact eq_of_beq hb
          | false => simp [bne, hb] at hbase
        by_cases hprov : (!isKernelCertifiedProvenance provOld || !isKernelCertifiedProvenance provNew) = true
        · rw [if_pos hprov] at hok; nomatch hok
        · rw [if_neg hprov] at hok
          have hpOld : provOld ≠ .externalCalibrationHeld := by
            intro hp; subst hp; simp [isKernelCertifiedProvenance] at hprov
          have hpNew : provNew ≠ .externalCalibrationHeld := by
            intro hp; subst hp; simp [isKernelCertifiedProvenance] at hprov
          exact ⟨hreg_eq, hbase_eq, hpOld, hpNew, pkg.domainLaw,
                 pkg.transport.base_comm,
                 semanticTransport_preserves_obs pkg.transport⟩
  · simp [reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance,
          domTagToId, extractKindDomainLaw]
  · simp [reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance]
  · simp [reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance]
  · simp [reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance]
  · simp [reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance]

end OmegaCellC1P1B1
