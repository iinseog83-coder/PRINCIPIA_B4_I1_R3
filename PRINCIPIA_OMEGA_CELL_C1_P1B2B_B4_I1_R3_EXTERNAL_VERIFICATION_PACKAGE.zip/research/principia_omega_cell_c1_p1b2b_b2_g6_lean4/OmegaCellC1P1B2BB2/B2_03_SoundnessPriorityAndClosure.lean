/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  Module: OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure

  Authorization: Scoped Human Execution Approval for `P1B2B-B2 G6 Isolated Lean Proof Core R0`
  Normative Specification: `B2 G6 Static Contract R0` + `Static Corrigendum 01` + `F-B2-T12-01..04`

  Mechanically Proves (`0` `sorry`, `0` `Classical.choice`):
    - `Gate A0` (`T_B2_A0_AncestorLineageAndSlotCompatibility`)
    - `Gate A1` (`T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage`)
    - `Gate A2` (`T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound`)
    - `Gate A8.(1)` (`T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound`)
    - `Gate A3` (`T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness` + `T_B2_A3b_EmptySuiteAccepted_NoticeSound`)
    - `Gate A4` + `F-B2-T11-03` + `F-B2-T12-03`:
        * `T_B2_A4a_CounterexampleSound_Unconditional`
        * `T_B2_A4b_FullViolationRecordSound_Conditional`
        * `T_B2_A4c_PremiseFreeViolation_BridgeViaA4b` (explicitly routed through `A4b`)
    - `Gate A5` + `F-B2-T11-01` + `F-B2-T12-02`:
        * `T_B2_A5_Unresolved_ConservativeHold_And_NonPromotion`
        * `T_B2_F12_02A_EmptySuite_FunctionNeverIssues` (execution-function non-issuance)
        * `T_B2_F12_02B_EmptySuite_TypeForbidsRecord` (type-level impossibility on `SlotWitness` & `G6QualifiedRecord`)
    - `Gate A6` (`T_B2_A6_VerdictPriorityLattice_And_ExactClassification`)
    - `Gate A7` + `F-B2-T11-04` + `F-B2-T12-04`:
        * `T_B2_A7_0_PrimDepsEquation_And_PermanentRetraction`
        * `T_B2_A7_1_OutputCongruence`
        * `T_B2_A7_2_RestrictionInvariance`
        * `T_B2_A7_3_ActualLookupConfinement`
        * `T_B2_A7_4_OutsidePremise_FullNonInterference` (all 4 `F-B2-T12-04` conditions!)
    - `Gate A10` + `F-B2-T12-01` (`T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex`)
-/
import OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification

namespace OmegaCellC1P1B2BB2

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1

/-! ### 1. Structural List, `Nodup`, & Root-Inclusion Helpers -/

private theorem nodupStrsBool_sound :
    ∀ (L : List String), nodupStrsBool L = true → L.Nodup
  | [],      _ => List.Pairwise.nil
  | x :: xs, h => by
      unfold nodupStrsBool at h
      simp only [Bool.and_eq_true] at h
      refine List.Pairwise.cons ?_ (nodupStrsBool_sound xs h.2)
      intro y hy hxy
      subst hxy
      have hc : xs.contains x = true := List.contains_iff_mem.mpr hy
      rw [hc] at h
      nomatch h.1

private theorem mem_foldr_pair_ids_b2 {α : Type} :
    ∀ (L : List (α × String × String)) {e : α} {dId jId : String},
      (e, dId, jId) ∈ L →
      dId ∈ L.foldr (fun (_, d, j) acc => d :: j :: acc) [] ∧
      jId ∈ L.foldr (fun (_, d, j) acc => d :: j :: acc) []
  | [], _, _, _, h => nomatch h
  | (_, _, _) :: tail, _, _, _, hMem => by
      rcases List.mem_cons.mp hMem with hEq | hRest
      · injection hEq with _ hPair
        injection hPair with hd hj
        subst hd; subst hj
        exact ⟨List.mem_cons_self .., List.mem_cons_of_mem _ (List.mem_cons_self ..)⟩
      · rcases mem_foldr_pair_ids_b2 tail hRest with ⟨hd, hj⟩
        exact ⟨List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hd),
               List.mem_cons_of_mem _ (List.mem_cons_of_mem _ hj)⟩

private theorem mem_foldr_cover_ids_b2 {α β : Type} :
    ∀ (L : List (α × β × List (StrictForm × String)))
      {b : α} {e : β} {ps : List (StrictForm × String)} {nid : String},
      (b, e, ps) ∈ L → nid ∈ ps.map Prod.snd →
      nid ∈ L.foldr (fun (_, _, q) acc => q.map Prod.snd ++ acc) []
  | [], _, _, _, _, h, _ => nomatch h
  | (_, _, _) :: tail, _, _, _, _, hMem, hNid => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hMem with hEq | hRest
      · injection hEq with _ hPair
        injection hPair with _ hPs
        subst hPs
        exact List.mem_append_left _ hNid
      · exact List.mem_append_right _ (mem_foldr_cover_ids_b2 tail hRest hNid)

private theorem mem_map_fst_exists_pair_b2 {α β : Type} :
    ∀ {L : List (α × β)} {x : α}, x ∈ L.map Prod.fst → ∃ y : β, (x, y) ∈ L
  | [],            _, h => nomatch h
  | (_, b) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, List.mem_cons_self ..⟩
      · rcases mem_map_fst_exists_pair_b2 hTail with ⟨y, hy⟩
        exact ⟨y, List.mem_cons_of_mem _ hy⟩

private theorem mem_map_fst_triple_b2 {α β γ : Type} :
    ∀ {L : List (α × β × γ)} {x : α},
      x ∈ L.map Prod.fst → ∃ (y : β) (z : γ), (x, y, z) ∈ L
  | [],               _, h => nomatch h
  | (_, b, c) :: rest, _, h => by
      rcases List.mem_cons.mp h with rfl | hTail
      · exact ⟨b, c, List.mem_cons_self ..⟩
      · rcases mem_map_fst_triple_b2 hTail with ⟨y, z, hyz⟩
        exact ⟨y, z, List.mem_cons_of_mem _ hyz⟩

private theorem mem_foldr_items_roots :
    ∀ (items : List G6ProtectedInvariantSpec) {item : G6ProtectedInvariantSpec} {nid : String},
      item ∈ items → nid ∈ collectItemG6ProofRootIds item →
      nid ∈ items.foldr (fun it acc => collectItemG6ProofRootIds it ++ acc) []
  | [],        _, _, hIn, _ => nomatch hIn
  | a :: rest, _, _, hIn, hNid => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hIn with rfl | hTail
      · exact List.mem_append_left _ hNid
      · exact List.mem_append_right _ (mem_foldr_items_roots rest hTail hNid)

theorem itemRoot_mem_suiteRoots {suite : G6ProtectedSuite} {item : G6ProtectedInvariantSpec}
    {nid : String} (hItem : item ∈ suite.items) (hNid : nid ∈ collectItemG6ProofRootIds item) :
    nid ∈ collectG6ProofRootIds suite := by
  unfold collectG6ProofRootIds
  rw [mem_canonSortStrs]
  exact mem_foldr_items_roots suite.items hItem hNid

theorem oldBase_mem_itemRoots (item : G6ProtectedInvariantSpec) {nid : String}
    (h : nid ∈ item.oldNewState.oldBaselineProofNodeId?.toList) :
    nid ∈ collectItemG6ProofRootIds item := by
  unfold collectItemG6ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_left _ h)))

theorem newGuardsDef_mem_itemRoots (item : G6ProtectedInvariantSpec) {nid : String}
    (h : nid ∈ item.oldNewState.newGuardsDefNodeId?.toList) :
    nid ∈ collectItemG6ProofRootIds item := by
  unfold collectItemG6ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
    (List.mem_append_right _ h)))

theorem scopePol_mem_itemRoots (item : G6ProtectedInvariantSpec) {nid : String}
    (h : nid ∈ rawScopePolicyRootIds item.oldNewState.scopePolicy) :
    nid ∈ collectItemG6ProofRootIds item := by
  unfold collectItemG6ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ h))

theorem scopeLoss_mem_itemRoots (item : G6ProtectedInvariantSpec) {nid : String}
    (h : nid ∈ rawScopeLossRootIds item.scopeLossRecord?) :
    nid ∈ collectItemG6ProofRootIds item := by
  unfold collectItemG6ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_left _ (List.mem_append_right _ h)

private theorem lossPrefix_mem_raw (lr : G6ScopeLossRecord) :
    lr.prefixDefNodeId ∈ rawScopeLossRootIds (some lr) := by
  unfold rawScopeLossRootIds
  dsimp only
  exact List.mem_append_left _ (List.mem_append_left _ (List.mem_cons_self ..))

private theorem lossD2N_mem_raw (lr : G6ScopeLossRecord) {d2n n2d : List (StrictForm × String)}
    {nid : String} (hGc : lr.guardConn = .mutualImplication d2n n2d)
    (hn : nid ∈ d2n.map Prod.snd) :
    nid ∈ rawScopeLossRootIds (some lr) := by
  unfold rawScopeLossRootIds
  dsimp only
  rw [hGc]
  exact List.mem_append_left _ (List.mem_append_right _ (List.mem_append_left _ hn))

private theorem lossN2D_mem_raw (lr : G6ScopeLossRecord) {d2n n2d : List (StrictForm × String)}
    {nid : String} (hGc : lr.guardConn = .mutualImplication d2n n2d)
    (hn : nid ∈ n2d.map Prod.snd) :
    nid ∈ rawScopeLossRootIds (some lr) := by
  unfold rawScopeLossRootIds
  dsimp only
  rw [hGc]
  exact List.mem_append_left _ (List.mem_append_right _ (List.mem_append_right _ hn))

private theorem lossDJ_mem_raw (lr : G6ScopeLossRecord) {rx : ExcisedReexprCert}
    {nid : String} (hRx : lr.reexprCert? = some rx)
    (hn : nid ∈ rx.branchDefAndDisjNodes.foldr (fun (_, dId, jId) acc => dId :: jId :: acc) []) :
    nid ∈ rawScopeLossRootIds (some lr) := by
  unfold rawScopeLossRootIds
  dsimp only
  rw [hRx]
  exact List.mem_append_right _ (List.mem_append_left _ hn)

private theorem lossCov_mem_raw (lr : G6ScopeLossRecord) {rx : ExcisedReexprCert}
    {nid : String} (hRx : lr.reexprCert? = some rx)
    (hn : nid ∈ rx.canonCoverWitnesses.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) []) :
    nid ∈ rawScopeLossRootIds (some lr) := by
  unfold rawScopeLossRootIds
  dsimp only
  rw [hRx]
  exact List.mem_append_right _ (List.mem_append_right _ hn)

theorem itemEv_mem_itemRoots (item : G6ProtectedInvariantSpec) {nid : String}
    (h : nid ∈ rawItemEvidenceRootIds item.evidenceRoots.itemEvidence) :
    nid ∈ collectItemG6ProofRootIds item := by
  unfold collectItemG6ProofRootIds
  rw [mem_canonSortStrs]
  exact List.mem_append_right _ h

/-! ### 2. `Gate A0`, `Gate A2`, & `Gate A8.(1)` Sub-Checker Soundness Lemmas -/

/-- **`Gate A0` (`T_B2_A0_AncestorLineageAndSlotCompatibility`)**:
    Verifies read-only lineage inheritance of `P1B1` proof-bearing `SlotWitness`, `P1A0`
    `undefined` vs `definedFalse` separation, and `P1B2A` `ModelsStrictForm` partial semantics. -/
theorem T_B2_A0_AncestorLineageAndSlotCompatibility :
    (∀ {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer},
       SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified →
       ∃ suite : G6ProtectedSuite, isG6SuiteVerifiedBool fuel Γ C suite = true) ∧
    (¬ ratPartialRecipEqOnePred.defined 0 ∧
      ratSqPosPred.defined 0 ∧ ¬ ratSqPosPred.rawSat 0) ∧
    (∀ (φ : StrictForm) (ρ : Env2),
      ModelsStrictForm φ ρ ↔ (FormDefined φ ρ ∧ FormRawSat φ ρ)) := by
  refine ⟨fun w => verified_slot_has_checked_cert w, ?_, fun _ _ => Iff.rfl⟩
  have hA0 := T_A0_05_undefined_vs_defined_false_separation
  exact ⟨hA0.2.1.1.2, hA0.2.2.1.2.1, hA0.2.2.1.2.2⟩

/-- **`Gate A2` (`T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound`)**:
    `checkG6ParamBindingWfBool item = true` implies `SemValidG6ParamBinding` and exact
    `L_B2B_ParamSubst` definedness & satisfaction equivalence on both `domOld` and `domNew`. -/
theorem T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound
    (item : G6ProtectedInvariantSpec)
    (hParam : checkG6ParamBindingWfBool item = true) :
    SemValidG6ParamBinding
      item.oldNewState.domOld item.oldNewState.guardsOld item.oldNewState.formOldInst
      item.oldNewState.domNew item.oldNewState.guardsNew item.oldNewState.formNewInst
      item.protectedFormula item.parameterBinding ∧
    (∀ tpl θOldN θOldD θNewN θNewD,
      item.protectedFormula = .cellParamForm tpl →
      item.parameterBinding = .boundCellParam θOldN θOldD θNewN θNewD →
      ∀ ρ : Env2, inG7Dom item.oldNewState.domNew ρ →
        ρ.2 = 0 ∧
        (FormDefined item.oldNewState.formNewInst ρ ↔
          FormDefined tpl (ρ.1, (θNewN : Rat) / ((θNewD : Int) : Rat))) ∧
        (ModelsStrictForm item.oldNewState.formNewInst ρ ↔
          ModelsStrictForm tpl (ρ.1, (θNewN : Rat) / ((θNewD : Int) : Rat)))) := by
  have hSem : SemValidG6ParamBinding
      item.oldNewState.domOld item.oldNewState.guardsOld item.oldNewState.formOldInst
      item.oldNewState.domNew item.oldNewState.guardsNew item.oldNewState.formNewInst
      item.protectedFormula item.parameterBinding := by
    unfold checkG6ParamBindingWfBool at hParam
    unfold SemValidG6ParamBinding
    cases hKind : item.protectedFormula with
    | fixedStateForm φ =>
        cases hBind : item.parameterBinding with
        | noParam =>
            rw [hKind, hBind] at hParam
            simp only [Bool.and_eq_true] at hParam
            exact ⟨eq_of_beq hParam.1, eq_of_beq hParam.2⟩
        | boundCellParam _ _ _ _ =>
            rw [hKind, hBind] at hParam; nomatch hParam
    | cellParamForm tpl =>
        cases hBind : item.parameterBinding with
        | noParam =>
            rw [hKind, hBind] at hParam; nomatch hParam
        | boundCellParam θOldN θOldD θNewN θNewD =>
            rw [hKind, hBind] at hParam
            simp only [Bool.and_eq_true] at hParam
            rcases hParam with ⟨⟨⟨⟨⟨hOldPosB, hNewPosB⟩, hWfOld⟩, hWfNew⟩, hEqOld⟩, hEqNew⟩
            have hOldPos : 0 < θOldD := of_decide_eq_true hOldPosB
            have hNewPos : 0 < θNewD := of_decide_eq_true hNewPosB
            have hSubOld := L_B2B_ParamSubst (θNum := θOldN) hWfOld hOldPos
            have hSubNew := L_B2B_ParamSubst (θNum := θNewN) hWfNew hNewPos
            have hOldDom1D : item.oldNewState.domOld = .domQ ∨
                item.oldNewState.domOld = .domQNonzero := by
              unfold checkWellFormedParamSpecBool at hWfOld
              simp only [Bool.and_eq_true, Bool.or_eq_true] at hWfOld
              rcases hWfOld.1 with h1 | h2
              · exact Or.inl (eq_of_beq h1)
              · exact Or.inr (eq_of_beq h2)
            have hNewDom1D : item.oldNewState.domNew = .domQ ∨
                item.oldNewState.domNew = .domQNonzero := by
              unfold checkWellFormedParamSpecBool at hWfNew
              simp only [Bool.and_eq_true, Bool.or_eq_true] at hWfNew
              rcases hWfNew.1 with h1 | h2
              · exact Or.inl (eq_of_beq h1)
              · exact Or.inr (eq_of_beq h2)
            have hFOld := eq_of_beq hEqOld
            have hFNew := eq_of_beq hEqNew
            refine ⟨hOldPos, hNewPos, hOldDom1D, hNewDom1D,
              fun γ hM => (formUsesVarYBool_false_iff_free γ).mp (hSubOld.1 γ hM),
              fun γ hM => (formUsesVarYBool_false_iff_free γ).mp (hSubNew.1 γ hM),
              hFOld, hFNew, ?_, ?_⟩
            · intro ρ hIn
              rw [hFOld]
              exact hSubOld.2 ρ hIn
            · intro ρ hIn
              rw [hFNew]
              exact hSubNew.2 ρ hIn
  refine ⟨hSem, ?_⟩
  intro tpl θOldN θOldD θNewN θNewD hK hB ρ hInNew
  unfold SemValidG6ParamBinding at hSem
  rw [hK, hB] at hSem
  exact hSem.2.2.2.2.2.2.2.2.2 ρ hInNew

/-- Generic root-bounded `G7` sequent soundness over arbitrary root list `roots`. -/
private theorem exactG7Sequent_sound_on_roots {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {roots : List String} {nid : String}
    {domTag : G7DomTag} {specId : String} {guards : List StrictForm} {conclusion : StrictForm}
    (hVal  : ValidContainer C)
    (hPrem : ∀ pid ∈ multiRootTransitivePrimDeps Γ C roots, SemValidPrimId Γ pid)
    (hRoot : nid ∈ roots)
    (hChk  : checkExactG7SequentBool fuel Γ C nid domTag specId guards conclusion = true) :
    SemValidSequent ⟨domTag, specId, guards, conclusion⟩ := by
  unfold checkExactG7SequentBool at hChk
  exact A0_05_4_SemanticDependencyClosure fuel Γ C roots hVal hPrem
    nid hRoot ⟨domTag, specId, guards, conclusion⟩ (eq_of_beq hChk)

private theorem guardEntailment_sound_on_roots {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {roots : List String}
    {domSrc : G7DomTag} {specId : String} {guardsSrc targetGuards : List StrictForm}
    {pairs : List (StrictForm × String)}
    (hVal   : ValidContainer C)
    (hPrem  : ∀ pid ∈ multiRootTransitivePrimDeps Γ C roots, SemValidPrimId Γ pid)
    (hRoots : ∀ nid ∈ pairs.map Prod.snd, nid ∈ roots)
    (hChk   : checkGuardEntailmentListBool fuel Γ C domSrc specId guardsSrc targetGuards pairs = true) :
    ∀ ρ : Env2, inG7Dom domSrc ρ → (∀ g ∈ guardsSrc, ModelsStrictForm g ρ) →
      ∀ γ ∈ targetGuards, ModelsStrictForm γ ρ := by
  unfold checkGuardEntailmentListBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨hMapEq, hAllOk⟩
  intro ρ hDom hSatSrc γ hMemTarget
  rw [← eq_of_beq hMapEq] at hMemTarget
  rcases mem_map_fst_exists_pair_b2 hMemTarget with ⟨nid, hPairMem⟩
  have hNidInMap : nid ∈ pairs.map Prod.snd := List.mem_map_of_mem hPairMem
  have hSeqOk : checkExactG7SequentBool fuel Γ C nid domSrc specId guardsSrc γ = true :=
    List.all_eq_true.mp hAllOk (γ, nid) hPairMem
  have hSem := exactG7Sequent_sound_on_roots hVal hPrem (hRoots nid hNidInMap) hSeqOk
  exact hSem.2 ρ hDom hSatSrc

private theorem sameEffDomCore_sound_on_roots {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {roots : List String}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {step : BaseDomEquivStep} {oldDefNid? : Option String}
    {oldToNew newToOld : List (StrictForm × String)}
    (hVal       : ValidContainer C)
    (hPrem      : ∀ pid ∈ multiRootTransitivePrimDeps Γ C roots, SemValidPrimId Γ pid)
    (hNewTel    : ∀ ρ : Env2, inG7Dom D_new ρ → TelescopicGuardsDefined Γ_new ρ)
    (hStepRoots : ∀ nid ∈ (match step with
                            | .sameBaseDom _        => []
                            | .qGuardNzToNonzero id => [id]
                            | .nonzeroToQGuardNz id => [id]), nid ∈ roots)
    (hDefRoots  : ∀ nid ∈ oldDefNid?.toList, nid ∈ roots)
    (hO2NRoots  : ∀ nid ∈ oldToNew.map Prod.snd, nid ∈ roots)
    (hN2ORoots  : ∀ nid ∈ newToOld.map Prod.snd, nid ∈ roots)
    (hChk       : checkSameEffDomCoreBool fuel Γ C D_old Γ_old D_new Γ_new specNewId
                    step oldDefNid? oldToNew newToOld = true) :
    SemSameEffDom D_old Γ_old D_new Γ_new := by
  unfold checkSameEffDomCoreBool at hChk
  by_cases hSameSyntax : ((D_old == D_new) && (Γ_old == Γ_new)) = true
  · simp only [Bool.and_eq_true] at hSameSyntax
    rw [eq_of_beq hSameSyntax.1, eq_of_beq hSameSyntax.2]
    exact semSameEffDom_refl D_new Γ_new
  · rw [if_neg hSameSyntax] at hChk
    simp only [Bool.and_eq_true] at hChk
    rcases hChk with ⟨⟨⟨hBaseOk, hOldDefOk⟩, hO2N⟩, hN2O⟩
    have hOldTel : ∀ ρ : Env2, inG7Dom D_old ρ → TelescopicGuardsDefined Γ_old ρ := by
      cases Γ_old with
      | nil => intro _ _; trivial
      | cons _ _ =>
          dsimp [List.isEmpty] at hOldDefOk
          cases hOpt : oldDefNid? with
          | none     => rw [hOpt] at hOldDefOk; nomatch hOldDefOk
          | some did =>
              rw [hOpt] at hOldDefOk
              have hR : did ∈ roots := by
                apply hDefRoots did
                rw [hOpt]; exact List.mem_cons_self ..
              exact (exactG7Sequent_sound_on_roots hVal hPrem hR hOldDefOk).1
    have hFwd := guardEntailment_sound_on_roots hVal hPrem hO2NRoots hO2N
    have hBwd := guardEntailment_sound_on_roots hVal hPrem hN2ORoots hN2O
    have hBaseIff :
        (∀ ρ : Env2, inG7Dom D_old ρ → (∀ g ∈ Γ_old, ModelsStrictForm g ρ) → inG7Dom D_new ρ) ∧
        (∀ ρ : Env2, inG7Dom D_new ρ → (∀ g ∈ Γ_new, ModelsStrictForm g ρ) → inG7Dom D_old ρ) := by
      cases step with
      | sameBaseDom D =>
          simp only [Bool.and_eq_true] at hBaseOk
          rw [eq_of_beq hBaseOk.1, eq_of_beq hBaseOk.2]
          exact ⟨fun _ h _ => h, fun _ h _ => h⟩
      | qGuardNzToNonzero nzNid =>
          simp only [Bool.and_eq_true] at hBaseOk
          rcases hBaseOk with ⟨⟨hdOld, hdNew⟩, hNzOk⟩
          rw [eq_of_beq hdOld, eq_of_beq hdNew]
          have hSemNz := exactG7Sequent_sound_on_roots hVal hPrem
            (hStepRoots nzNid (List.mem_cons_self ..)) hNzOk
          refine ⟨?_, fun _ hDomNew _ => hDomNew.2⟩
          intro ρ hDomQ hSatOld
          rcases (hSemNz.2 ρ hDomQ hSatOld).2 with ⟨v, hv, hne⟩
          cases hv
          exact ⟨hne, hDomQ⟩
      | nonzeroToQGuardNz nzNid =>
          simp only [Bool.and_eq_true] at hBaseOk
          rcases hBaseOk with ⟨⟨hdOld, hdNew⟩, hNzOk⟩
          rw [eq_of_beq hdOld, eq_of_beq hdNew]
          have hSemNz := exactG7Sequent_sound_on_roots hVal hPrem
            (hStepRoots nzNid (List.mem_cons_self ..)) hNzOk
          refine ⟨fun _ hDomOld _ => hDomOld.2, ?_⟩
          intro ρ hDomQ hSatNew
          rcases (hSemNz.2 ρ hDomQ hSatNew).2 with ⟨v, hv, hne⟩
          cases hv
          exact ⟨hne, hDomQ⟩
    intro ρ
    constructor
    · rintro ⟨hDomOld, _, hSatOld⟩
      have hDomNew : inG7Dom D_new ρ := hBaseIff.1 ρ hDomOld hSatOld
      exact ⟨hDomNew, hNewTel ρ hDomNew, hFwd ρ hDomOld hSatOld⟩
    · rintro ⟨hDomNew, _, hSatNew⟩
      have hDomOld : inG7Dom D_old ρ := hBaseIff.2 ρ hDomNew hSatNew
      exact ⟨hDomOld, hOldTel ρ hDomOld, hBwd ρ hDomNew hSatNew⟩

private theorem baseDomExpandStep_sound_b2 {step : BaseDomExpandStep}
    {D_old D_new : G7DomTag} (h : checkBaseDomExpandStepBool step D_old D_new = true) :
    ∀ ρ : Env2, inG7Dom D_old ρ → inG7Dom D_new ρ := by
  cases step with
  | sameBaseDom D =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ hDom => hDom
  | qNonzeroToQ =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ hDom => hDom.2
  | qToQ2 =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ _ => trivial
  | qNonzeroToQ2 =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rw [eq_of_beq h.1, eq_of_beq h.2]
      exact fun _ _ => trivial
  | finiteGridSup L_old L_new =>
      unfold checkBaseDomExpandStepBool at h
      simp only [Bool.and_eq_true] at h
      rcases h with ⟨⟨hOld, hNew⟩, hSub⟩
      rw [eq_of_beq hOld, eq_of_beq hNew]
      rintro ρ ⟨p, hpMem, hpEq⟩
      exact ⟨p, List.contains_iff_mem.mp (List.all_eq_true.mp hSub p hpMem), hpEq⟩

private theorem excisedReexpr_sound_on_roots {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {roots : List String}
    {D_old : G7DomTag} {Γ_old : List StrictForm} {D_new : G7DomTag} {Γ_new : List StrictForm}
    {specNewId : String} {B_canon excisedBranches : ExcisedLocus} {rx : ExcisedReexprCert}
    (hVal      : ValidContainer C)
    (hPrem     : ∀ pid ∈ multiRootTransitivePrimDeps Γ C roots, SemValidPrimId Γ pid)
    (hCanon    : SemExactScopeLossPartition D_old Γ_old D_new Γ_new B_canon)
    (hDJRoots  : ∀ nid ∈ rx.branchDefAndDisjNodes.foldr
                   (fun (_, dId, jId) acc => dId :: jId :: acc) [], nid ∈ roots)
    (hCovRoots : ∀ nid ∈ rx.canonCoverWitnesses.foldr
                   (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) [], nid ∈ roots)
    (hChk      : checkExcisedReexprBool fuel Γ C D_old Γ_old D_new Γ_new specNewId
                   B_canon excisedBranches rx = true) :
    SemExactScopeLossPartition D_old Γ_old D_new Γ_new excisedBranches := by
  unfold checkExcisedReexprBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨⟨⟨hExcMap, hAllDJ⟩, hCanonMap⟩, hAllCov⟩
  have hBranchProps : ∀ E_i ∈ excisedBranches,
      (∀ ρ : Env2, inG7Dom D_old ρ → TelescopicGuardsDefined (Γ_old ++ E_i) ρ) ∧
      (∀ ρ : Env2, InEffDom D_new Γ_new ρ → ¬ ModelsExcisedBranch E_i ρ) := by
    intro E_i hEMem
    rw [← eq_of_beq hExcMap] at hEMem
    rcases mem_map_fst_triple_b2 hEMem with ⟨defNid, disjNid, hTripMem⟩
    have hPairOk := List.all_eq_true.mp hAllDJ (E_i, defNid, disjNid) hTripMem
    simp only [Bool.and_eq_true] at hPairOk
    rcases mem_foldr_pair_ids_b2 rx.branchDefAndDisjNodes hTripMem with ⟨hDefIn, hDisjIn⟩
    have hDefSem := exactG7Sequent_sound_on_roots hVal hPrem (hDJRoots defNid hDefIn) hPairOk.1
    have hDisjSem := exactG7Sequent_sound_on_roots hVal hPrem (hDJRoots disjNid hDisjIn) hPairOk.2
    refine ⟨hDefSem.1, ?_⟩
    intro ρ hInNew hExcBr
    have hZeroPos : ModelsStrictForm (.pos (.const 0)) ρ := by
      apply hDisjSem.2 ρ hInNew.1
      intro φ hPhi
      rcases List.mem_append.mp hPhi with hInG | hInE
      · exact hInNew.2.2 φ hInG
      · exact hExcBr.2 φ hInE
    rcases hZeroPos.2 with ⟨v, hv, hpos⟩
    cases hv
    exact Rat.lt_irrefl hpos
  apply mkSemExactScopeLossPartition
  · rintro ρ ⟨hInNew, ⟨E_i, hEMem, hEBr⟩⟩
    exact (hBranchProps E_i hEMem).2 ρ hInNew hEBr
  · intro ρ hInOld
    rcases hCanon.old_covered_by_new_or_excised ρ hInOld with hInNew | ⟨B_j, hBMem, hBBr⟩
    · exact Or.inl hInNew
    · rw [← eq_of_beq hCanonMap] at hBMem
      rcases mem_map_fst_triple_b2 hBMem with ⟨E_target, psiNodes, hCovMem⟩
      have hCovOk := List.all_eq_true.mp hAllCov (B_j, E_target, psiNodes) hCovMem
      simp only [Bool.and_eq_true] at hCovOk
      have hETargetMem : E_target ∈ excisedBranches := List.contains_iff_mem.mp hCovOk.1
      have hEntails := guardEntailment_sound_on_roots hVal hPrem
        (fun nid hn => hCovRoots nid (mem_foldr_cover_ids_b2 rx.canonCoverWitnesses hCovMem hn))
        hCovOk.2
      have hTelAll : TelescopicGuardsDefined (Γ_old ++ E_target) ρ :=
        (hBranchProps E_target hETargetMem).1 ρ hInOld.1
      have hTelE : TelescopicGuardsDefined E_target ρ :=
        ((telescopicGuardsDefined_append_iff Γ_old E_target ρ).mp hTelAll).2 hInOld.2.2
      exact Or.inr ⟨E_target, hETargetMem, hTelE, hEntails ρ hInOld.1 hBBr.2⟩
  · exact hCanon.new_subset_old

/-- **`Gate A8.(1)` (`T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound`)**:
    Under `ValidContainer C` and `SemValidPrimId` on `multiRootTransitivePrimDeps Γ C (collectItemG6ProofRootIds item)`,
    `checkG6ItemScopeBool fuel Γ C item = true` guarantees post-domain guard definedness AND
    exact policy-specific `SemValidG6ScopeRelation item.oldNewState item.scopeLossRecord?`. -/
theorem T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound
    {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {item : G6ProtectedInvariantSpec}
    (hVal  : ValidContainer C)
    (hPrem : ∀ pid ∈ multiRootTransitivePrimDeps Γ C (collectItemG6ProofRootIds item),
               SemValidPrimId Γ pid)
    (hScope : checkG6ItemScopeBool fuel Γ C item = true) :
    (∀ ρ : Env2, inG7Dom item.oldNewState.domNew ρ →
      TelescopicGuardsDefined item.oldNewState.guardsNew ρ) ∧
    SemValidG6ScopeRelation item.oldNewState item.scopeLossRecord? := by
  unfold checkG6ItemScopeBool at hScope
  dsimp only at hScope
  simp only [Bool.and_eq_true] at hScope
  rcases hScope with ⟨hNewDefOk, hPolOk⟩
  have hNewTel : ∀ ρ : Env2, inG7Dom item.oldNewState.domNew ρ →
      TelescopicGuardsDefined item.oldNewState.guardsNew ρ := by
    cases hGNew : item.oldNewState.guardsNew with
    | nil => intro _ _; trivial
    | cons _ _ =>
        rw [hGNew] at hNewDefOk
        dsimp [List.isEmpty] at hNewDefOk
        cases hNd : item.oldNewState.newGuardsDefNodeId? with
        | none => rw [hNd] at hNewDefOk; nomatch hNewDefOk
        | some ndid =>
            rw [hNd] at hNewDefOk
            have hRoot : ndid ∈ collectItemG6ProofRootIds item := by
              apply newGuardsDef_mem_itemRoots item
              rw [hNd]; exact List.mem_cons_self ..
            have hSem := exactG7Sequent_sound_on_roots hVal hPrem hRoot hNewDefOk
            exact hSem.1
  refine ⟨hNewTel, ?_⟩
  unfold SemValidG6ScopeRelation
  cases hPol : item.oldNewState.scopePolicy with
  | globalPostSameDom r =>
      cases hLoss : item.scopeLossRecord? with
      | some _ => rw [hPol, hLoss] at hPolOk; nomatch hPolOk
      | none =>
          rw [hPol, hLoss] at hPolOk
          dsimp only at hPolOk ⊢
          simp only [Bool.and_eq_true] at hPolOk
          apply sameEffDomCore_sound_on_roots hVal hPrem hNewTel _ _ _ _ hPolOk.2
          · intro nid hn
            apply scopePol_mem_itemRoots item
            rw [hPol]; dsimp [rawScopePolicyRootIds]
            exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
              (List.mem_append_left _ hn)))
          · intro nid hn
            apply scopePol_mem_itemRoots item
            rw [hPol]; dsimp [rawScopePolicyRootIds]
            exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
              (List.mem_append_right _ hn)))
          · intro nid hn
            apply scopePol_mem_itemRoots item
            rw [hPol]; dsimp [rawScopePolicyRootIds]
            exact List.mem_append_left _ (List.mem_append_left _ (List.mem_append_right _ hn))
          · intro nid hn
            apply scopePol_mem_itemRoots item
            rw [hPol]; dsimp [rawScopePolicyRootIds]
            exact List.mem_append_left _ (List.mem_append_right _ hn)
  | oldScopeInclusion step oldDef? o2n n2o scopeExp expWit? =>
      cases hLoss : item.scopeLossRecord? with
      | some _ => rw [hPol, hLoss] at hPolOk; nomatch hPolOk
      | none =>
          rw [hPol, hLoss] at hPolOk
          dsimp only at hPolOk ⊢
          simp only [Bool.and_eq_true] at hPolOk
          rcases hPolOk with ⟨⟨hBaseExp, hInclGuards⟩, hScopeAcc⟩
          have hBaseIncl := baseDomExpandStep_sound_b2 hBaseExp
          have hDomIncl : ∀ ρ : Env2,
              InEffDom item.oldNewState.domOld item.oldNewState.guardsOld ρ →
              InEffDom item.oldNewState.domNew item.oldNewState.guardsNew ρ := by
            intro ρ ⟨hDomOld, _, hSatOld⟩
            have hDomNew : inG7Dom item.oldNewState.domNew ρ := hBaseIncl ρ hDomOld
            refine ⟨hDomNew, hNewTel ρ hDomNew, ?_⟩
            by_cases hSameG : (item.oldNewState.guardsNew == item.oldNewState.guardsOld) = true
            · rw [eq_of_beq hSameG]; exact hSatOld
            · rw [if_neg hSameG] at hInclGuards
              have hEnt := guardEntailment_sound_on_roots hVal hPrem
                (fun nid hn => by
                  apply scopePol_mem_itemRoots item
                  rw [hPol]; dsimp [rawScopePolicyRootIds]
                  exact List.mem_append_left _ (List.mem_append_right _ hn))
                hInclGuards
              exact hEnt ρ hDomOld hSatOld
          refine ⟨hDomIncl, ?_⟩
          cases scopeExp with
          | true =>
              simp only [ite_true, Bool.and_eq_true] at hScopeAcc
              rcases hScopeAcc with ⟨⟨_, _⟩, hExpOpt⟩
              cases hExpEq : expWit? with
              | none => rw [hExpEq] at hExpOpt; nomatch hExpOpt
              | some pt_exp =>
                  rw [hExpEq] at hExpOpt
                  simp only [Bool.and_eq_true] at hExpOpt
                  rcases checkInEffDomRatCoordBool_sound fuel item.oldNewState.domNew
                    item.oldNewState.guardsNew pt_exp hExpOpt.1 with ⟨hx, hy, hInNew⟩
                  have hNotOld := (checkNotInEffDomRatCoordBool_sound fuel item.oldNewState.domOld
                    item.oldNewState.guardsOld pt_exp hExpOpt.2).2.2
                  exact ⟨pt_exp, rfl, hx, hy, hInNew, hNotOld⟩
          | false =>
              simp only [Bool.false_eq_true, ite_false, Bool.and_eq_true] at hScopeAcc
              rcases hScopeAcc with ⟨hExpNone, hStepMatch⟩
              refine ⟨Option.isNone_iff_eq_none.mp hExpNone, ?_⟩
              cases hStepEq : step with
              | qNonzeroToQ      => rw [hStepEq] at hStepMatch; nomatch hStepMatch
              | qToQ2            => rw [hStepEq] at hStepMatch; nomatch hStepMatch
              | qNonzeroToQ2     => rw [hStepEq] at hStepMatch; nomatch hStepMatch
              | finiteGridSup _ _ => rw [hStepEq] at hStepMatch; nomatch hStepMatch
              | sameBaseDom D =>
                  rw [hStepEq] at hStepMatch
                  dsimp only at hStepMatch
                  exact sameEffDomCore_sound_on_roots (step := .sameBaseDom D)
                    hVal hPrem hNewTel
                    (fun _ h => nomatch h)
                    (fun nid hn => by
                      apply scopePol_mem_itemRoots item
                      rw [hPol]; dsimp [rawScopePolicyRootIds]
                      exact List.mem_append_left _ (List.mem_append_left _ hn))
                    (fun nid hn => by
                      apply scopePol_mem_itemRoots item
                      rw [hPol]; dsimp [rawScopePolicyRootIds]
                      by_cases hEqG : (item.oldNewState.guardsNew == item.oldNewState.guardsOld) = true
                      · rw [if_pos hEqG] at hn; nomatch hn
                      · rw [if_neg hEqG] at hn
                        exact List.mem_append_left _ (List.mem_append_right _ hn))
                    (fun nid hn => by
                      apply scopePol_mem_itemRoots item
                      rw [hPol]; dsimp [rawScopePolicyRootIds]
                      exact List.mem_append_right _ hn)
                    hStepMatch
  | retreatWithLossAccounting =>
      cases hLoss : item.scopeLossRecord? with
      | none => rw [hPol, hLoss] at hPolOk; nomatch hPolOk
      | some lr =>
          rw [hPol, hLoss] at hPolOk
          dsimp only at hPolOk ⊢
          unfold checkG6ScopeLossRecordBool at hPolOk
          simp only [Bool.and_eq_true] at hPolOk
          rcases hPolOk with
            ⟨⟨⟨⟨⟨⟨⟨hBaseStep, hAtoms⟩, hPrefixOk⟩, hConnOk⟩, hExcOk⟩,
                hLossOld⟩, hLossExc⟩, hAnchorsOk⟩
          have hPrefixRoot : lr.prefixDefNodeId ∈ collectItemG6ProofRootIds item :=
            scopeLoss_mem_itemRoots item (by rw [hLoss]; exact lossPrefix_mem_raw lr)
          have hPrefixAcc : verifyReachableDerivation fuel Γ C lr.prefixDefNodeId =
              .accept ⟨item.oldNewState.domNew, item.oldNewState.specNewId,
                       item.oldNewState.guardsOld ++ lr.deltaGuards, .eqZero (.const 0)⟩ :=
            eq_of_beq hPrefixOk
          have hPrefixPrem : ∀ p ∈ extractTransitivePrimDeps Γ C lr.prefixDefNodeId,
              SemValidPrimId Γ p :=
            fun p hp => hPrem p (mem_multiRootTransitivePrimDeps Γ C hPrefixRoot hp)
          have hPrefixSem := exactG7Sequent_sound_on_roots hVal hPrem hPrefixRoot hPrefixOk
          have hGuardConn : SemSameEffDom item.oldNewState.domNew item.oldNewState.guardsNew
              item.oldNewState.domNew (item.oldNewState.guardsOld ++ lr.deltaGuards) := by
            cases hConnM : lr.guardConn with
            | syntacticConcat =>
                rw [hConnM] at hConnOk
                rw [eq_of_beq hConnOk]
                exact semSameEffDom_refl _ _
            | mutualImplication d2n n2d =>
                rw [hConnM] at hConnOk
                simp only [Bool.and_eq_true] at hConnOk
                have hD2N := guardEntailment_sound_on_roots hVal hPrem
                  (fun nid hn => scopeLoss_mem_itemRoots item
                    (by rw [hLoss]; exact lossD2N_mem_raw lr hConnM hn))
                  hConnOk.1
                have hN2D := guardEntailment_sound_on_roots hVal hPrem
                  (fun nid hn => scopeLoss_mem_itemRoots item
                    (by rw [hLoss]; exact lossN2D_mem_raw lr hConnM hn))
                  hConnOk.2
                intro ρ
                constructor
                · rintro ⟨hDom, _, hSatNew⟩
                  exact ⟨hDom, hPrefixSem.1 ρ hDom, hN2D ρ hDom hSatNew⟩
                · rintro ⟨hDom, _, hSatDelta⟩
                  exact ⟨hDom, hNewTel ρ hDom, hD2N ρ hDom hSatDelta⟩
          have hCanonPart := L_B2B_TelescopicPartition_from_G7 hVal hBaseStep hAtoms
            hPrefixAcc hPrefixPrem hGuardConn
          have hExactPart : SemExactScopeLossPartition item.oldNewState.domOld
              item.oldNewState.guardsOld item.oldNewState.domNew item.oldNewState.guardsNew
              lr.excisedBranches := by
            cases hRx : lr.reexprCert? with
            | none =>
                rw [hRx] at hExcOk
                rw [eq_of_beq hExcOk]
                exact hCanonPart
            | some rx =>
                rw [hRx] at hExcOk
                exact excisedReexpr_sound_on_roots hVal hPrem hCanonPart
                  (fun nid hn => scopeLoss_mem_itemRoots item
                    (by rw [hLoss]; exact lossDJ_mem_raw lr hRx hn))
                  (fun nid hn => scopeLoss_mem_itemRoots item
                    (by rw [hLoss]; exact lossCov_mem_raw lr hRx hn))
                  hExcOk
          rcases checkInEffDomRatCoordBool_sound fuel item.oldNewState.domOld
            item.oldNewState.guardsOld lr.strictLossWitness hLossOld with ⟨hxL, hyL, hLossOldSem⟩
          have hLossExcSem := checkModelsExcisedRatCoordBool_sound fuel lr.excisedBranches
            lr.strictLossWitness hLossExc
          have hLossNotNew : ¬ InEffDom item.oldNewState.domNew item.oldNewState.guardsNew
              (ratCoordToEnv2 lr.strictLossWitness) :=
            fun hNew => hExactPart.disjoint_new_excised _ ⟨hNew, hLossExcSem⟩
          have hAnchorsSem : ∀ pt_a ∈ lr.claimedRetentionAnchors,
              0 < pt_a.xDenPos ∧ 0 < pt_a.yDenPos ∧
              InEffDom item.oldNewState.domNew item.oldNewState.guardsNew (ratCoordToEnv2 pt_a) := by
            intro pt_a hM
            exact checkInEffDomRatCoordBool_sound fuel item.oldNewState.domNew
              item.oldNewState.guardsNew pt_a (List.all_eq_true.mp hAnchorsOk pt_a hM)
          exact ⟨hxL, hyL, hExactPart, hLossOldSem, hLossExcSem, hLossNotNew, hAnchorsSem⟩

/-! ### 3. Item-List Unpacking Lemmas for `evalG6ItemsList` -/

private theorem evalG6ItemsList_ok_mem {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {evalEpoch : Nat} :
    ∀ {items : List G6ProtectedInvariantSpec} {pairs : List (String × G6ItemClass)},
      evalG6ItemsList fuel Γ C evalEpoch items = .ok pairs →
      pairs.map Prod.fst = items.map (·.invariantId) ∧
      (∀ item ∈ items, ∃ cls : G6ItemClass,
        evalSingleG6Item fuel Γ C evalEpoch item = .ok cls ∧
        (item.invariantId, cls) ∈ pairs) ∧
      (∀ (id : String) (cls : G6ItemClass),
        (id, cls) ∈ pairs →
        ∃ item ∈ items, item.invariantId = id ∧
          evalSingleG6Item fuel Γ C evalEpoch item = .ok cls)
  | [], pairs, hOk => by
      unfold evalG6ItemsList at hOk
      injection hOk with hp
      subst hp
      exact ⟨rfl, (fun _ h => nomatch h), (fun _ _ h => nomatch h)⟩
  | it :: rest, pairs, hOk => by
      unfold evalG6ItemsList at hOk
      cases hHead : evalSingleG6Item fuel Γ C evalEpoch it with
      | error _ => rw [hHead] at hOk; nomatch hOk
      | ok cls =>
          rw [hHead] at hOk
          cases hTail : evalG6ItemsList fuel Γ C evalEpoch rest with
          | error _ => rw [hTail] at hOk; nomatch hOk
          | ok tailCs =>
              rw [hTail] at hOk
              injection hOk with hp
              subst hp
              rcases evalG6ItemsList_ok_mem hTail with ⟨hMapEq, hFwd, hBwd⟩
              refine ⟨by simp [hMapEq], ?_, ?_⟩
              · intro item hMem
                rcases List.mem_cons.mp hMem with rfl | hInRest
                · exact ⟨cls, hHead, List.mem_cons_self ..⟩
                · rcases hFwd item hInRest with ⟨c', hc', hm'⟩
                  exact ⟨c', hc', List.mem_cons_of_mem _ hm'⟩
              · intro id c hMemP
                rcases List.mem_cons.mp hMemP with hEqP | hInTail
                · injection hEqP with hid hc
                  subst hid; subst hc
                  exact ⟨it, List.mem_cons_self .., rfl, hHead⟩
                · rcases hBwd id c hInTail with ⟨item, hInR, hidEq, hEv⟩
                  exact ⟨item, List.mem_cons_of_mem _ hInR, hidEq, hEv⟩

private def evalSingleG6ItemBody (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (item : G6ProtectedInvariantSpec) : Except G6InvalidReason G6ItemClass :=
  let st := item.oldNewState
  match item.evidenceRoots.itemEvidence with
  | .claimVerified rootNid =>
      if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew st.postDomNonEmptyWitness then
        .error (.forgedVerificationProof item.invariantId)
      else if evalStrictFormRatCoord fuel st.formNewInst st.postDomNonEmptyWitness ==
                FormEvalRes.undefinedTerm then
        .error (.undefinedPointTreatedAsTrue item.invariantId)
      else if checkExactG7SequentBool fuel Γ C rootNid st.domNew st.specNewId
                st.guardsNew st.formNewInst then
        .ok .itemVerified
      else
        .error (.forgedVerificationProof item.invariantId)
  | .claimViolated (.counterexamplePoint violPt) =>
      if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew violPt then
        .error (.outOfDomainCounterexample item.invariantId)
      else if evalStrictFormRatCoord fuel st.formNewInst violPt == FormEvalRes.satDefinedFalse then
        .ok .itemViolated
      else
        .error (.invalidRefutationEvidence item.invariantId)
  | .claimViolated (.derivedRefutationNode refutNid witPt) =>
      if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew witPt then
        .error (.outOfDomainCounterexample item.invariantId)
      else if isAtomicStrictFormBool st.formNewInst &&
              checkExactG7SequentBool fuel Γ C refutNid st.domNew st.specNewId
                st.guardsNew (atomicComplement st.formNewInst) then
        .ok .itemViolated
      else
        .error (.invalidRefutationEvidence item.invariantId)
  | .claimUnresolved _ =>
      .ok .itemUnresolved

private theorem evalSingleG6Item_ok_common {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {evalEpoch : Nat} {item : G6ProtectedInvariantSpec} {cls : G6ItemClass}
    (hOk : evalSingleG6Item fuel Γ C evalEpoch item = .ok cls) :
    item.versionEpoch.revokedBool = false ∧
    item.versionEpoch.effectiveFromEpoch ≤ evalEpoch ∧
    evalEpoch < item.versionEpoch.expiresAtEpoch ∧
    checkG6ParamBindingWfBool item = true ∧
    item.evidenceRoots.declaredItemProofNids = collectItemG6ProofRootIds item ∧
    (∀ oldNid : String, item.oldNewState.oldBaselineProofNodeId? = some oldNid →
      checkExactG7SequentBool fuel Γ C oldNid item.oldNewState.domOld
        item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst = true) ∧
    checkG6ItemScopeBool fuel Γ C item = true ∧
    evalSingleG6ItemBody fuel Γ C item = .ok cls := by
  unfold evalSingleG6Item at hOk
  by_cases hVerEp : (item.versionEpoch.revokedBool ||
      !decide (item.versionEpoch.effectiveFromEpoch ≤ evalEpoch) ||
      !decide (evalEpoch < item.versionEpoch.expiresAtEpoch)) = true
  · rw [if_pos hVerEp] at hOk; nomatch hOk
  · rw [if_neg hVerEp] at hOk
    simp only [Bool.or_eq_true, not_or] at hVerEp
    have hRevF : item.versionEpoch.revokedBool = false := Bool.eq_false_iff.mpr hVerEp.1.1
    have hEffLe : item.versionEpoch.effectiveFromEpoch ≤ evalEpoch := by
      cases hd : decide (item.versionEpoch.effectiveFromEpoch ≤ evalEpoch) with
      | true => exact of_decide_eq_true hd
      | false => exfalso; exact hVerEp.1.2 (by rw [hd]; rfl)
    have hExpLt : evalEpoch < item.versionEpoch.expiresAtEpoch := by
      cases hd : decide (evalEpoch < item.versionEpoch.expiresAtEpoch) with
      | true => exact of_decide_eq_true hd
      | false => exfalso; exact hVerEp.2 (by rw [hd]; rfl)
    by_cases hPar : (!checkG6ParamBindingWfBool item) = true
    · rw [if_pos hPar] at hOk; nomatch hOk
    · rw [if_neg hPar] at hOk
      have hParT : checkG6ParamBindingWfBool item = true := by
        cases hb : checkG6ParamBindingWfBool item with
        | true => rfl
        | false => exfalso; exact hPar (by rw [hb]; rfl)
      by_cases hMan : (item.evidenceRoots.declaredItemProofNids != collectItemG6ProofRootIds item) = true
      · rw [if_pos hMan] at hOk; nomatch hOk
      · rw [if_neg hMan] at hOk
        have hManEq : item.evidenceRoots.declaredItemProofNids = collectItemG6ProofRootIds item := by
          cases hb : (item.evidenceRoots.declaredItemProofNids == collectItemG6ProofRootIds item) with
          | true => exact eq_of_beq hb
          | false => exfalso; exact hMan (by simp [bne, hb])
        let oldBaseOk : Bool :=
          match item.oldNewState.oldBaselineProofNodeId? with
          | none => true
          | some oldNid =>
              checkExactG7SequentBool fuel Γ C oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld
                item.oldNewState.formOldInst
        change (if (!oldBaseOk) = true then
            Except.error (G6InvalidReason.forgedVerificationProof item.invariantId)
          else if (!checkG6ItemScopeBool fuel Γ C item) = true then
            Except.error (G6InvalidReason.uncertifiedScopeShrinkOrPolicy item.invariantId)
          else evalSingleG6ItemBody fuel Γ C item) = Except.ok cls at hOk
        by_cases hOldB : (!oldBaseOk) = true
        · rw [if_pos hOldB] at hOk; nomatch hOk
        · rw [if_neg hOldB] at hOk
          have hOldFn : ∀ oldNid : String, item.oldNewState.oldBaselineProofNodeId? = some oldNid →
              checkExactG7SequentBool fuel Γ C oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld
                item.oldNewState.formOldInst = true := by
            intro oldNid hSome
            dsimp [oldBaseOk] at hOldB
            rw [hSome] at hOldB
            dsimp only at hOldB
            cases hb : checkExactG7SequentBool fuel Γ C oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld
                item.oldNewState.formOldInst with
            | true => rfl
            | false => exfalso; exact hOldB (by rw [hb]; rfl)
          by_cases hSc : (!checkG6ItemScopeBool fuel Γ C item) = true
          · rw [if_pos hSc] at hOk; nomatch hOk
          · rw [if_neg hSc] at hOk
            have hScT : checkG6ItemScopeBool fuel Γ C item = true := by
              cases hb : checkG6ItemScopeBool fuel Γ C item with
              | true => rfl
              | false => exfalso; exact hSc (by rw [hb]; rfl)
            exact ⟨hRevF, hEffLe, hExpLt, hParT, hManEq, hOldFn, hScT, hOk⟩

/-! ### 4. `Gate A1`, `Gate A3`, `Gate A4` (`F-B2-T11-03` & `F-B2-T12-03`) -/

private theorem unpack_nonInvalid_checkG6Suite {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {suite : G6ProtectedSuite}
    (hNotInv : ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r) :
    checkPrimEnvIntegrityBool Γ = true ∧
    ValidContainer C ∧
    isStrictCanonStrList suite.claimedPrimDeps.primDepIds = true ∧
    suite.claimedPrimDeps.primDepIds = deriveG6PrimDeps Γ C suite ∧
    checkG6SuiteHeaderBasicBool suite = true ∧
    nodupStrsBool suite.declaredInvariantIds = true ∧
    (∀ id ∈ suite.declaredInvariantIds, id ≠ "") ∧
    suite.items.map (·.invariantId) = suite.declaredInvariantIds ∧
    (∀ item ∈ suite.items,
      item.oldNewState.specOldId = suite.specOldId ∧
      item.oldNewState.specNewId = suite.specNewId) ∧
    checkG6Suite fuel Γ C suite = evalG6SuiteCore fuel Γ C suite := by
  have h1 : (!checkPrimEnvIntegrityBool Γ || !checkContainerIntegrityBool C) = false := by
    cases hb : (!checkPrimEnvIntegrityBool Γ || !checkContainerIntegrityBool C) with
    | false => rfl
    | true =>
        exfalso
        apply hNotInv .malformedEnvOrContainer
        unfold checkG6Suite
        rw [if_pos hb]
  have hEnvOk : checkPrimEnvIntegrityBool Γ = true := by
    cases hb : checkPrimEnvIntegrityBool Γ with
    | true => rfl
    | false => simp [hb] at h1
  have hContOk : checkContainerIntegrityBool C = true := by
    cases hb : checkContainerIntegrityBool C with
    | true => rfl
    | false => simp [hEnvOk, hb] at h1
  have h2 : (!isStrictCanonStrList suite.claimedPrimDeps.primDepIds ||
      (suite.claimedPrimDeps.primDepIds != deriveG6PrimDeps Γ C suite)) = false := by
    cases hb : (!isStrictCanonStrList suite.claimedPrimDeps.primDepIds ||
        (suite.claimedPrimDeps.primDepIds != deriveG6PrimDeps Γ C suite)) with
    | false => rfl
    | true =>
        exfalso
        apply hNotInv .primDepsClosureMismatch
        unfold checkG6Suite
        rw [if_neg (by rw [h1]; decide), if_pos hb]
  have hCanonDeps : isStrictCanonStrList suite.claimedPrimDeps.primDepIds = true := by
    cases hb : isStrictCanonStrList suite.claimedPrimDeps.primDepIds with
    | true => rfl
    | false => simp [hb] at h2
  have hDepsEq : suite.claimedPrimDeps.primDepIds = deriveG6PrimDeps Γ C suite := by
    cases hb : (suite.claimedPrimDeps.primDepIds == deriveG6PrimDeps Γ C suite) with
    | true => exact eq_of_beq hb
    | false => simp [hCanonDeps, bne, hb] at h2
  have hEqCore : checkG6Suite fuel Γ C suite = evalG6SuiteCore fuel Γ C suite := by
    unfold checkG6Suite
    rw [if_neg (by rw [h1]; decide), if_neg (by rw [h2]; decide)]
  have hNotInvCore : ∀ r, evalG6SuiteCore fuel Γ C suite ≠ .invalid r := by
    intro r hr; exact hNotInv r (hEqCore.trans hr)
  have h3 : (!checkG6SuiteHeaderBasicBool suite) = false := by
    cases hb : (!checkG6SuiteHeaderBasicBool suite) with
    | false => rfl
    | true =>
        exfalso
        apply hNotInvCore .nonCanonicalSuiteHeader
        unfold evalG6SuiteCore; rw [if_pos hb]
  have hHdrOk : checkG6SuiteHeaderBasicBool suite = true := by
    cases hb : checkG6SuiteHeaderBasicBool suite with
    | true => rfl
    | false => simp [hb] at h3
  have h4 : (!nodupStrsBool suite.declaredInvariantIds ||
      suite.declaredInvariantIds.any (fun id => id == "")) = false := by
    cases hb : (!nodupStrsBool suite.declaredInvariantIds ||
        suite.declaredInvariantIds.any (fun id => id == "")) with
    | false => rfl
    | true =>
        exfalso
        apply hNotInvCore .duplicateOrEmptyInvariantId
        unfold evalG6SuiteCore
        rw [if_neg (by rw [h3]; decide), if_pos hb]
  have hNodupB : nodupStrsBool suite.declaredInvariantIds = true := by
    cases hb : nodupStrsBool suite.declaredInvariantIds with
    | true => rfl
    | false => simp [hb] at h4
  have hIdNe : ∀ id ∈ suite.declaredInvariantIds, id ≠ "" := by
    intro id hid hEmpty
    subst hEmpty
    have hAny : suite.declaredInvariantIds.any (fun x => x == "") = true :=
      List.any_eq_true.mpr ⟨"", hid, rfl⟩
    rw [hNodupB, hAny] at h4
    nomatch h4
  have h5 : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
      suite.items.any (fun item =>
        (item.oldNewState.specOldId != suite.specOldId) ||
        (item.oldNewState.specNewId != suite.specNewId))) = false := by
    cases hb : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
        suite.items.any (fun item =>
          (item.oldNewState.specOldId != suite.specOldId) ||
          (item.oldNewState.specNewId != suite.specNewId))) with
    | false => rfl
    | true =>
        exfalso
        apply hNotInvCore .suiteCoverageMismatch
        unfold evalG6SuiteCore
        rw [if_neg (by rw [h3]; decide), if_neg (by rw [h4]; decide), if_pos hb]
  have hMapEq : suite.items.map (·.invariantId) = suite.declaredInvariantIds := by
    cases hb : (suite.items.map (·.invariantId) == suite.declaredInvariantIds) with
    | true => exact eq_of_beq hb
    | false => simp [bne, hb] at h5
  have hSpecsEq : ∀ item ∈ suite.items,
      item.oldNewState.specOldId = suite.specOldId ∧
      item.oldNewState.specNewId = suite.specNewId := by
    intro item hIn
    have hAnyF : suite.items.any (fun it =>
        (it.oldNewState.specOldId != suite.specOldId) ||
        (it.oldNewState.specNewId != suite.specNewId)) = false := by
      cases ha : suite.items.any (fun it =>
          (it.oldNewState.specOldId != suite.specOldId) ||
          (it.oldNewState.specNewId != suite.specNewId)) with
      | false => rfl
      | true => rw [ha, Bool.or_true] at h5; nomatch h5
    constructor
    · cases hs1 : (item.oldNewState.specOldId == suite.specOldId) with
      | true => exact eq_of_beq hs1
      | false =>
          have hBad : suite.items.any (fun it =>
              (it.oldNewState.specOldId != suite.specOldId) ||
              (it.oldNewState.specNewId != suite.specNewId)) = true :=
            List.any_eq_true.mpr ⟨item, hIn, by simp [bne, hs1]⟩
          rw [hBad] at hAnyF; nomatch hAnyF
    · cases hs2 : (item.oldNewState.specNewId == suite.specNewId) with
      | true => exact eq_of_beq hs2
      | false =>
          have hBad : suite.items.any (fun it =>
              (it.oldNewState.specOldId != suite.specOldId) ||
              (it.oldNewState.specNewId != suite.specNewId)) = true :=
            List.any_eq_true.mpr ⟨item, hIn, by simp [bne, hs2]⟩
          rw [hBad] at hAnyF; nomatch hAnyF
  exact ⟨hEnvOk, hContOk, hCanonDeps, hDepsEq, hHdrOk, hNodupB, hIdNe, hMapEq, hSpecsEq, hEqCore⟩

/-- **`Gate A1` (`T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage`)**:
    Any non-`Invalid` `G6` suite satisfies canonical headers, `Nodup` non-empty IDs,
    `100%` submitted-suite coverage, active version/epoch bounds on all items, and routes
    `suite.items = []` strictly to `.emptySuiteAccepted` (never `.verified`). -/
theorem T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite)
    (hNotInv : ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r) :
    suite.suiteVersion = "g6_b2_v1" ∧
    suite.suiteCid ≠ "" ∧
    suite.rflxCid ≠ "" ∧
    suite.baseId = "base_Q" ∧
    suite.declaredInvariantIds.Nodup ∧
    (∀ id ∈ suite.declaredInvariantIds, id ≠ "") ∧
    suite.items.map (·.invariantId) = suite.declaredInvariantIds ∧
    (suite.items = [] →
      ∃ polCid : String,
        polCid ≠ "" ∧
        suite.emptySuitePolicy = .allowExplicitEmpty polCid ∧
        checkG6Suite fuel Γ C suite = .emptySuiteAccepted polCid) ∧
    (∀ item ∈ suite.items,
      item.invariantId ∈ suite.declaredInvariantIds ∧
      item.versionEpoch.revokedBool = false ∧
      item.versionEpoch.effectiveFromEpoch ≤ suite.evaluationEpoch ∧
      suite.evaluationEpoch < item.versionEpoch.expiresAtEpoch) := by
  rcases unpack_nonInvalid_checkG6Suite hNotInv with
    ⟨_, _, _, _, hHdrOk, hNodupB, hIdNe, hMapEq, _, hEqCore⟩
  unfold checkG6SuiteHeaderBasicBool at hHdrOk
  simp only [Bool.and_eq_true] at hHdrOk
  rcases hHdrOk with ⟨⟨⟨⟨⟨⟨⟨⟨hVer, hCid⟩, hRflx⟩, _⟩, _⟩, hBase⟩, _⟩, _⟩, _⟩
  refine ⟨eq_of_beq hVer,
          (fun h => by rw [h] at hCid; nomatch hCid),
          (fun h => by rw [h] at hRflx; nomatch hRflx),
          eq_of_beq hBase,
          nodupStrsBool_sound _ hNodupB,
          hIdNe,
          hMapEq,
          ?_,
          ?_⟩
  · intro hEmpty
    have hCoreEq : checkG6Suite fuel Γ C suite =
        (match suite.emptySuitePolicy with
         | .forbidEmptySuite => .invalid .unauthorizedEmptySuite
         | .allowExplicitEmpty polCid =>
             if polCid == "" then .invalid .unauthorizedEmptySuite
             else .emptySuiteAccepted polCid) := by
      rw [hEqCore]
      unfold evalG6SuiteCore
      have hB1 : (!checkG6SuiteHeaderBasicBool suite) = false := by
        cases hb : checkG6SuiteHeaderBasicBool suite with
        | true => rfl
        | false =>
            exfalso; apply hNotInv .nonCanonicalSuiteHeader
            rw [hEqCore]; unfold evalG6SuiteCore; rw [if_pos (by rw [hb]; rfl)]
      have hB2 : (!nodupStrsBool suite.declaredInvariantIds ||
          suite.declaredInvariantIds.any (fun id => id == "")) = false := by
        cases hb : (!nodupStrsBool suite.declaredInvariantIds ||
            suite.declaredInvariantIds.any (fun id => id == "")) with
        | false => rfl
        | true =>
            exfalso; apply hNotInv .duplicateOrEmptyInvariantId
            rw [hEqCore]; unfold evalG6SuiteCore; rw [if_neg (by rw [hB1]; decide), if_pos hb]
      have hB3 : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
          suite.items.any (fun item =>
            (item.oldNewState.specOldId != suite.specOldId) ||
            (item.oldNewState.specNewId != suite.specNewId))) = false := by
        cases hb : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
            suite.items.any (fun item =>
              (item.oldNewState.specOldId != suite.specOldId) ||
              (item.oldNewState.specNewId != suite.specNewId))) with
        | false => rfl
        | true =>
            exfalso; apply hNotInv .suiteCoverageMismatch
            rw [hEqCore]; unfold evalG6SuiteCore
            rw [if_neg (by rw [hB1]; decide), if_neg (by rw [hB2]; decide), if_pos hb]
      rw [if_neg (by rw [hB1]; decide), if_neg (by rw [hB2]; decide),
          if_neg (by rw [hB3]; decide), hEmpty]
      rfl
    cases hPol : suite.emptySuitePolicy with
    | forbidEmptySuite =>
        rw [hPol] at hCoreEq
        exact False.elim (hNotInv .unauthorizedEmptySuite hCoreEq)
    | allowExplicitEmpty polCid =>
        rw [hPol] at hCoreEq
        dsimp only at hCoreEq
        by_cases hp : (polCid == "") = true
        · rw [if_pos hp] at hCoreEq
          exact False.elim (hNotInv .unauthorizedEmptySuite hCoreEq)
        · rw [if_neg hp] at hCoreEq
          have hpNe : polCid ≠ "" := fun he => hp (beq_iff_eq.mpr he)
          exact ⟨polCid, hpNe, rfl, hCoreEq⟩
  · intro item hIn
    have hInDecl : item.invariantId ∈ suite.declaredInvariantIds := by
      rw [← hMapEq]; exact List.mem_map_of_mem hIn
    cases hItems : suite.items with
    | nil => rw [hItems] at hIn; nomatch hIn
    | cons it0 rest =>
        have hListOk : ∃ pairs, evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) = .ok pairs := by
          cases hEv : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
          | ok ps => exact ⟨ps, rfl⟩
          | error r =>
              exfalso; apply hNotInv r
              rw [hEqCore]; unfold evalG6SuiteCore
              have hB1 : (!checkG6SuiteHeaderBasicBool suite) = false := by
                cases hb : checkG6SuiteHeaderBasicBool suite with
                | true => rfl
                | false =>
                    exfalso; apply hNotInv .nonCanonicalSuiteHeader
                    rw [hEqCore]; unfold evalG6SuiteCore; rw [if_pos (by rw [hb]; rfl)]
              have hB2 : (!nodupStrsBool suite.declaredInvariantIds ||
                  suite.declaredInvariantIds.any (fun id => id == "")) = false := by
                cases hb : (!nodupStrsBool suite.declaredInvariantIds ||
                    suite.declaredInvariantIds.any (fun id => id == "")) with
                | false => rfl
                | true =>
                    exfalso; apply hNotInv .duplicateOrEmptyInvariantId
                    rw [hEqCore]; unfold evalG6SuiteCore; rw [if_neg (by rw [hB1]; decide), if_pos hb]
              have hB3 : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
                  suite.items.any (fun item =>
                    (item.oldNewState.specOldId != suite.specOldId) ||
                    (item.oldNewState.specNewId != suite.specNewId))) = false := by
                cases hb : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
                    suite.items.any (fun item =>
                      (item.oldNewState.specOldId != suite.specOldId) ||
                      (item.oldNewState.specNewId != suite.specNewId))) with
                | false => rfl
                | true =>
                    exfalso; apply hNotInv .suiteCoverageMismatch
                    rw [hEqCore]; unfold evalG6SuiteCore
                    rw [if_neg (by rw [hB1]; decide), if_neg (by rw [hB2]; decide), if_pos hb]
              rw [if_neg (by rw [hB1]; decide), if_neg (by rw [hB2]; decide),
                  if_neg (by rw [hB3]; decide), hItems]
              dsimp only; rw [hEv]
        rcases hListOk with ⟨pairs, hPairs⟩
        have hInCons : item ∈ it0 :: rest := by rwa [← hItems]
        rcases (evalG6ItemsList_ok_mem hPairs).2.1 item hInCons with ⟨cls, hSingle, _⟩
        rcases evalSingleG6Item_ok_common hSingle with ⟨hRev, hEff, hExp, _⟩
        exact ⟨hInDecl, hRev, hEff, hExp⟩

/-- **`Gate A3` (`T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness` — `Corrigendum 01` §1.4)**:
    Whenever `checkG6Suite fuel Γ C suite = .verified hasLoss` and all `Deps_G6` premises satisfy
    `SemValidPrimId Γ p`, `suite.items ≠ []` holds unconditionally and `SemValidG6ProtectedSuite suite`
    holds with exact `hasLoss` accounting! -/
theorem T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) (hasLoss : Bool)
    (hVer : checkG6Suite fuel Γ C suite = .verified hasLoss)
    (hPremValid : ∀ p ∈ deriveG6PrimDeps Γ C suite, SemValidPrimId Γ p) :
    checkPrimEnvIntegrityBool Γ = true ∧
    ValidContainer C ∧
    suite.items ≠ [] ∧
    suite.declaredInvariantIds ≠ [] ∧
    suite.claimedPrimDeps.primDepIds = deriveG6PrimDeps Γ C suite ∧
    SemValidG6ProtectedSuite suite ∧
    (hasLoss = true ↔ ∃ item ∈ suite.items, item.scopeLossRecord?.isSome = true) := by
  have hNotInv : ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r := by
    intro r hr; rw [hVer] at hr; nomatch hr
  rcases unpack_nonInvalid_checkG6Suite hNotInv with
    ⟨hEnvOk, hContOk, _, hDepsEq, hHdrB, hNodupB, hIdNe, hMapEq, hSpecsEq, hEqCore⟩
  have hIsVer : isG6SuiteVerifiedBool fuel Γ C suite = true := by
    unfold isG6SuiteVerifiedBool; rw [hVer]
  have hNonEmptyItems : suite.items ≠ [] := (isG6SuiteVerifiedBool_implies_nonEmpty hIsVer).1
  have hNonEmptyDecl : suite.declaredInvariantIds ≠ [] := by
    intro hDeclNil
    rw [hDeclNil] at hMapEq
    cases hs : suite.items with
    | nil => exact hNonEmptyItems hs
    | cons _ _ => rw [hs] at hMapEq; nomatch hMapEq
  unfold checkG6SuiteHeaderBasicBool at hHdrB
  simp only [Bool.and_eq_true] at hHdrB
  rcases hHdrB with
    ⟨⟨⟨⟨⟨⟨⟨⟨hVerStr, hCid⟩, hRflx⟩, hCOld⟩, hCNew⟩, hBase⟩, hSOld⟩, hSNew⟩, hItemsHdr⟩
  -- Unpack evalG6SuiteCore to extract evalG6ItemsList = .ok pairs with vIds = [] and uIds = []
  have hVerCore : evalG6SuiteCore fuel Γ C suite = .verified hasLoss := hEqCore.symm.trans hVer
  unfold evalG6SuiteCore at hVerCore
  by_cases hb1 : (!checkG6SuiteHeaderBasicBool suite) = true
  · rw [if_pos hb1] at hVerCore; nomatch hVerCore
  · rw [if_neg hb1] at hVerCore
    by_cases hb2 : (!nodupStrsBool suite.declaredInvariantIds ||
        suite.declaredInvariantIds.any (fun id => id == "")) = true
    · rw [if_pos hb2] at hVerCore; nomatch hVerCore
    · rw [if_neg hb2] at hVerCore
      by_cases hb3 : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
          suite.items.any (fun item =>
            (item.oldNewState.specOldId != suite.specOldId) ||
            (item.oldNewState.specNewId != suite.specNewId))) = true
      · rw [if_pos hb3] at hVerCore; nomatch hVerCore
      · rw [if_neg hb3] at hVerCore
        cases hItEq : suite.items with
        | nil => exact False.elim (hNonEmptyItems hItEq)
        | cons it0 rest =>
            rw [hItEq] at hVerCore
            dsimp only at hVerCore
            cases hEvL : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
            | error _ => rw [hEvL] at hVerCore; nomatch hVerCore
            | ok pairs =>
                rw [hEvL] at hVerCore
                dsimp only at hVerCore
                let vIds := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
                let uIds := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
                by_cases hv : (!vIds.isEmpty) = true
                · change (if (!vIds.isEmpty) = true then _ else _) = _ at hVerCore
                  rw [if_pos hv] at hVerCore; nomatch hVerCore
                · change (if (!vIds.isEmpty) = true then _ else _) = _ at hVerCore
                  rw [if_neg hv] at hVerCore
                  by_cases hu : (!uIds.isEmpty) = true
                  · change (if (!uIds.isEmpty) = true then _ else _) = _ at hVerCore
                    rw [if_pos hu] at hVerCore; nomatch hVerCore
                  · change (if (!uIds.isEmpty) = true then _ else _) = _ at hVerCore
                    rw [if_neg hu] at hVerCore
                    injection hVerCore with hLossEq
                    have hHasLossIff : hasLoss = true ↔
                        ∃ item ∈ suite.items, item.scopeLossRecord?.isSome = true := by
                      rw [← hLossEq, ← hItEq, List.any_eq_true]
                    have hAllItemsSem : ∀ item ∈ suite.items,
                        SemValidG6InvariantItem suite.evaluationEpoch item := by
                      intro item hInSuite
                      have hInCons : item ∈ it0 :: rest := by rwa [← hItEq]
                      rcases (evalG6ItemsList_ok_mem hEvL).2.1 item hInCons with
                        ⟨cls, hSingleOk, hMemPairs⟩
                      -- cls cannot be .itemViolated or .itemUnresolved since vIds, uIds are empty!
                      have hClsVer : cls = .itemVerified := by
                        cases hCls : cls with
                        | itemVerified => rfl
                        | itemViolated =>
                            rw [hCls] at hMemPairs
                            have hInFilt : (item.invariantId, .itemViolated) ∈
                                pairs.filter (fun p => p.2 == .itemViolated) :=
                              List.mem_filter.mpr ⟨hMemPairs, rfl⟩
                            have hInV : item.invariantId ∈ vIds := List.mem_map_of_mem hInFilt
                            cases hvL : vIds with
                            | nil => rw [hvL] at hInV; nomatch hInV
                            | cons _ _ =>
                                exfalso; apply hv; rw [hvL]; rfl
                        | itemUnresolved =>
                            rw [hCls] at hMemPairs
                            have hInFilt : (item.invariantId, .itemUnresolved) ∈
                                pairs.filter (fun p => p.2 == .itemUnresolved) :=
                              List.mem_filter.mpr ⟨hMemPairs, rfl⟩
                            have hInU : item.invariantId ∈ uIds := List.mem_map_of_mem hInFilt
                            cases huL : uIds with
                            | nil => rw [huL] at hInU; nomatch hInU
                            | cons _ _ =>
                                exfalso; apply hu; rw [huL]; rfl
                      subst hClsVer
                      rcases evalSingleG6Item_ok_common hSingleOk with
                        ⟨hRev, hEff, hExp, hParOk, _, hOldFn, hScOk, hBodyOk⟩
                      have hItemPrem : ∀ pid ∈ multiRootTransitivePrimDeps Γ C
                          (collectItemG6ProofRootIds item), SemValidPrimId Γ pid := by
                        intro pid hp
                        unfold multiRootTransitivePrimDeps at hp
                        rw [mem_canonSortStrs] at hp
                        -- every root r in collectItemG6ProofRootIds item is in collectG6ProofRootIds suite
                        have hSub : ∀ (rs : List String),
                            (∀ r ∈ rs, r ∈ collectG6ProofRootIds suite) →
                            pid ∈ rs.foldr (fun r acc => extractTransitivePrimDeps Γ C r ++ acc) [] →
                            pid ∈ deriveG6PrimDeps Γ C suite := by
                          intro rs hRSub hFold
                          induction rs with
                          | nil => nomatch hFold
                          | cons r tail ih =>
                              dsimp only [List.foldr] at hFold
                              rcases List.mem_append.mp hFold with hHead | hRest
                              · exact mem_multiRootTransitivePrimDeps Γ C
                                  (hRSub r (List.mem_cons_self ..)) hHead
                              · exact ih (fun u hu => hRSub u (List.mem_cons_of_mem r hu)) hRest
                        exact hPremValid pid (hSub (collectItemG6ProofRootIds item)
                          (fun r hr => itemRoot_mem_suiteRoots hInSuite hr) hp)
                      have hHdrIt := List.all_eq_true.mp hItemsHdr item hInSuite
                      simp only [Bool.and_eq_true] at hHdrIt
                      rcases hHdrIt with ⟨⟨⟨⟨hInvNe, hSpNe⟩, hSpEq⟩, hDomEq⟩, hGdsEq⟩
                      have hScopeSem := (T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound
                        hContOk hItemPrem hScOk).2
                      have hParamSem := (T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound
                        item hParOk).1
                      -- Extract .claimVerified rootNid from hBodyOk
                      have hPostAndWit :
                          (0 < item.oldNewState.postDomNonEmptyWitness.xDenPos ∧
                           0 < item.oldNewState.postDomNonEmptyWitness.yDenPos ∧
                           InEffDom item.oldNewState.domNew item.oldNewState.guardsNew
                             (ratCoordToEnv2 item.oldNewState.postDomNonEmptyWitness)) ∧
                          (∀ ρ : Env2, InEffDom item.oldNewState.domNew item.oldNewState.guardsNew ρ →
                            ModelsStrictForm item.oldNewState.formNewInst ρ) := by
                        unfold evalSingleG6ItemBody at hBodyOk
                        dsimp only at hBodyOk
                        cases hEv : item.evidenceRoots.itemEvidence with
                        | claimUnresolved _ =>
                            rw [hEv] at hBodyOk; nomatch hBodyOk
                        | claimViolated refc =>
                            rw [hEv] at hBodyOk
                            cases refc with
                            | counterexamplePoint violPt =>
                                dsimp only at hBodyOk
                                by_cases b1 : (!checkInEffDomRatCoordBool fuel
                                    item.oldNewState.domNew item.oldNewState.guardsNew violPt) = true
                                · rw [if_pos b1] at hBodyOk; nomatch hBodyOk
                                · rw [if_neg b1] at hBodyOk
                                  by_cases b2 : (evalStrictFormRatCoord fuel
                                      item.oldNewState.formNewInst violPt ==
                                      FormEvalRes.satDefinedFalse) = true
                                  · rw [if_pos b2] at hBodyOk; nomatch hBodyOk
                                  · rw [if_neg b2] at hBodyOk; nomatch hBodyOk
                            | derivedRefutationNode refutNid witPt =>
                                dsimp only at hBodyOk
                                by_cases b1 : (!checkInEffDomRatCoordBool fuel
                                    item.oldNewState.domNew item.oldNewState.guardsNew witPt) = true
                                · rw [if_pos b1] at hBodyOk; nomatch hBodyOk
                                · rw [if_neg b1] at hBodyOk
                                  by_cases b2 : (isAtomicStrictFormBool item.oldNewState.formNewInst &&
                                      checkExactG7SequentBool fuel Γ C refutNid
                                        item.oldNewState.domNew item.oldNewState.specNewId
                                        item.oldNewState.guardsNew
                                        (atomicComplement item.oldNewState.formNewInst)) = true
                                  · rw [if_pos b2] at hBodyOk; nomatch hBodyOk
                                  · rw [if_neg b2] at hBodyOk; nomatch hBodyOk
                        | claimVerified rootNid =>
                            rw [hEv] at hBodyOk
                            dsimp only at hBodyOk
                            by_cases hWit : (!checkInEffDomRatCoordBool fuel
                                item.oldNewState.domNew item.oldNewState.guardsNew
                                item.oldNewState.postDomNonEmptyWitness) = true
                            · rw [if_pos hWit] at hBodyOk; nomatch hBodyOk
                            · rw [if_neg hWit] at hBodyOk
                              have hWitOk : checkInEffDomRatCoordBool fuel
                                  item.oldNewState.domNew item.oldNewState.guardsNew
                                  item.oldNewState.postDomNonEmptyWitness = true := by
                                cases hb : checkInEffDomRatCoordBool fuel
                                    item.oldNewState.domNew item.oldNewState.guardsNew
                                    item.oldNewState.postDomNonEmptyWitness with
                                | true => rfl
                                | false => exfalso; exact hWit (by rw [hb]; rfl)
                              by_cases hUnd : (evalStrictFormRatCoord fuel
                                  item.oldNewState.formNewInst
                                  item.oldNewState.postDomNonEmptyWitness ==
                                  FormEvalRes.undefinedTerm) = true
                              · rw [if_pos hUnd] at hBodyOk; nomatch hBodyOk
                              · rw [if_neg hUnd] at hBodyOk
                                by_cases hSeq : checkExactG7SequentBool fuel Γ C rootNid
                                    item.oldNewState.domNew item.oldNewState.specNewId
                                    item.oldNewState.guardsNew
                                    item.oldNewState.formNewInst = true
                                · have hRootIn : rootNid ∈ collectItemG6ProofRootIds item := by
                                    apply itemEv_mem_itemRoots item
                                    rw [hEv]; exact List.mem_cons_self ..
                                  have hGoalSem := exactG7Sequent_sound_on_roots
                                    hContOk hItemPrem hRootIn hSeq
                                  exact ⟨checkInEffDomRatCoordBool_sound fuel
                                      item.oldNewState.domNew item.oldNewState.guardsNew
                                      item.oldNewState.postDomNonEmptyWitness hWitOk,
                                    fun ρ hIn => hGoalSem.2 ρ hIn.1 hIn.2.2⟩
                                · rw [if_neg hSeq] at hBodyOk; nomatch hBodyOk
                      have hOldBaseSem : item.oldNewState.oldBaselineProofNodeId?.isSome = true →
                          ∀ ρ : Env2, InEffDom item.oldNewState.domOld item.oldNewState.guardsOld ρ →
                            ModelsStrictForm item.oldNewState.formOldInst ρ := by
                        intro hSome ρ hInOld
                        cases hOpt : item.oldNewState.oldBaselineProofNodeId? with
                        | none => rw [hOpt] at hSome; nomatch hSome
                        | some oldNid =>
                            have hOldChk := hOldFn oldNid hOpt
                            have hOldRoot : oldNid ∈ collectItemG6ProofRootIds item := by
                              apply oldBase_mem_itemRoots item
                              rw [hOpt]; exact List.mem_cons_self ..
                            have hOldS := exactG7Sequent_sound_on_roots hContOk hItemPrem
                              hOldRoot hOldChk
                            exact hOldS.2 ρ hInOld.1 hInOld.2.2
                      exact {
                        nonEmptyIds := ⟨(fun h => by rw [h] at hInvNe; nomatch hInvNe),
                                        (fun h => by rw [h] at hSpNe; nomatch hSpNe),
                                        eq_of_beq hSpEq, eq_of_beq hDomEq, eq_of_beq hGdsEq⟩
                        activeVersionEpoch := ⟨hRev, hEff, hExp⟩
                        validParamBinding := hParamSem
                        validScopeRelation := hScopeSem
                        nonEmptyPostDomain := hPostAndWit.1
                        oldBaselineHoldsIfClaimed := hOldBaseSem
                        postInvariantHolds := hPostAndWit.2
                      }
                    have hHasLossCons : hasLoss = true ↔
                        ∃ item ∈ (it0 :: rest), item.scopeLossRecord?.isSome = true := by
                      rwa [← hItEq]
                    refine ⟨hEnvOk, hContOk, (fun h => nomatch h), hNonEmptyDecl,
                            hDepsEq, ?_, hHasLossCons⟩
                    exact {
                      canonicalSuiteHeader := ⟨eq_of_beq hVerStr,
                        (fun h => by rw [h] at hCid; nomatch hCid),
                        (fun h => by rw [h] at hRflx; nomatch hRflx),
                        (fun h => by rw [h] at hCOld; nomatch hCOld),
                        (fun h => by rw [h] at hCNew; nomatch hCNew),
                        eq_of_beq hBase,
                        (fun h => by rw [h] at hSOld; nomatch hSOld),
                        (fun h => by rw [h] at hSNew; nomatch hSNew)⟩
                      nonEmptyProtectedSuite := ⟨hNonEmptyItems, hNonEmptyDecl⟩
                      submittedSuiteCoverage := ⟨nodupStrsBool_sound _ hNodupB, hIdNe, hMapEq, hSpecsEq⟩
                      allItemsSemanticallyPreserved := hAllItemsSem
                    }

/-- Companion notice theorem for `.emptySuiteAccepted`: yields `SemValidEmptyG6Notice` and
    strictly refutes `SemValidG6ProtectedSuite` (`F-B2-T11-01`). -/
theorem T_B2_A3b_EmptySuiteAccepted_NoticeSound
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) (polCid : String)
    (hEmpAcc : checkG6Suite fuel Γ C suite = .emptySuiteAccepted polCid) :
    SemValidEmptyG6Notice suite polCid ∧ ¬ SemValidG6ProtectedSuite suite := by
  have hNotInv : ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r := by
    intro r hr; rw [hEmpAcc] at hr; nomatch hr
  rcases unpack_nonInvalid_checkG6Suite hNotInv with
    ⟨_, _, _, hDepsEq, hHdrB, _, _, hMapEq, _, hEqCore⟩
  have hItemsNil : suite.items = [] := by
    have hCore : evalG6SuiteCore fuel Γ C suite = .emptySuiteAccepted polCid :=
      hEqCore.symm.trans hEmpAcc
    unfold evalG6SuiteCore at hCore
    split at hCore
    · nomatch hCore
    · split at hCore
      · nomatch hCore
      · split at hCore
        · nomatch hCore
        · cases hs : suite.items with
          | nil => rfl
          | cons it0 rest =>
              rw [hs] at hCore; dsimp only at hCore
              cases hEv : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
              | error _ => rw [hEv] at hCore; nomatch hCore
              | ok ps =>
                  rw [hEv] at hCore; dsimp only at hCore
                  let vL := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
                  let uL := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
                  by_cases hv : (!vL.isEmpty) = true
                  · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                    rw [if_pos hv] at hCore; nomatch hCore
                  · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                    rw [if_neg hv] at hCore
                    by_cases hu : (!uL.isEmpty) = true
                    · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                      rw [if_pos hu] at hCore; nomatch hCore
                    · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                      rw [if_neg hu] at hCore; nomatch hCore
  have hDeclNil : suite.declaredInvariantIds = [] := by
    rw [← hMapEq, hItemsNil]; rfl
  have hRootsNil : collectG6ProofRootIds suite = [] := by
    unfold collectG6ProofRootIds; rw [hItemsNil]; rfl
  have hDeriveNil : deriveG6PrimDeps Γ C suite = [] := by
    unfold deriveG6PrimDeps; rw [hRootsNil]; rfl
  have hDepsNil : suite.claimedPrimDeps.primDepIds = [] := hDepsEq.trans hDeriveNil
  rcases (T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage fuel Γ C suite hNotInv).2.2.2.2.2.2.2.1
    hItemsNil with ⟨pCid, hpNe, hPolEq, hChkEq⟩
  rw [hEmpAcc] at hChkEq
  injection hChkEq with hpEq
  subst hpEq
  unfold checkG6SuiteHeaderBasicBool at hHdrB
  simp only [Bool.and_eq_true] at hHdrB
  rcases hHdrB with ⟨⟨⟨⟨⟨⟨⟨⟨hVerS, hCid⟩, hRflx⟩, hCOld⟩, hCNew⟩, hBase⟩, hSOld⟩, hSNew⟩, _⟩
  refine ⟨?_, fun hSem => hSem.nonEmptyProtectedSuite.1 hItemsNil⟩
  exact {
    canonicalSuiteHeader := ⟨eq_of_beq hVerS,
      (fun h => by rw [h] at hCid; nomatch hCid),
      (fun h => by rw [h] at hRflx; nomatch hRflx),
      (fun h => by rw [h] at hCOld; nomatch hCOld),
      (fun h => by rw [h] at hCNew; nomatch hCNew),
      eq_of_beq hBase,
      (fun h => by rw [h] at hSOld; nomatch hSOld),
      (fun h => by rw [h] at hSNew; nomatch hSNew)⟩
    emptyItemsAndDeps := ⟨hItemsNil, hDeclNil, hDepsNil⟩
    unauthenticatedPolicyTag := ⟨hpNe, hPolEq⟩
  }

/-! ### 5. `Gate A4` + `F-B2-T11-03` + `F-B2-T12-03`: 3-Tier `Violated` Soundness Hierarchy -/

private theorem unpack_violated_checkG6Suite {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {suite : G6ProtectedSuite} {vIds uIds : List String}
    (hViol : checkG6Suite fuel Γ C suite = .violated vIds uIds) :
    checkPrimEnvIntegrityBool Γ = true ∧
    ValidContainer C ∧
    suite.suiteVersion = "g6_b2_v1" ∧
    suite.items ≠ [] ∧
    suite.declaredInvariantIds.Nodup ∧
    suite.items.map (·.invariantId) = suite.declaredInvariantIds ∧
    vIds ≠ [] ∧
    ∃ pairs : List (String × G6ItemClass),
      evalG6ItemsList fuel Γ C suite.evaluationEpoch suite.items = .ok pairs ∧
      vIds = (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst ∧
      uIds = (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst := by
  have hNotInv : ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r := by
    intro r hr; rw [hViol] at hr; nomatch hr
  rcases unpack_nonInvalid_checkG6Suite hNotInv with
    ⟨hEnvOk, hContOk, _, _, hHdrB, hNodupB, _, hMapEq, _, hEqCore⟩
  unfold checkG6SuiteHeaderBasicBool at hHdrB
  simp only [Bool.and_eq_true] at hHdrB
  have hVerS : suite.suiteVersion = "g6_b2_v1" := eq_of_beq hHdrB.1.1.1.1.1.1.1.1
  have hCore : evalG6SuiteCore fuel Γ C suite = .violated vIds uIds := hEqCore.symm.trans hViol
  unfold evalG6SuiteCore at hCore
  split at hCore
  · nomatch hCore
  · split at hCore
    · nomatch hCore
    · split at hCore
      · nomatch hCore
      · cases hIt : suite.items with
        | nil =>
            rw [hIt] at hCore; dsimp only at hCore
            cases hPol : suite.emptySuitePolicy with
            | forbidEmptySuite => rw [hPol] at hCore; nomatch hCore
            | allowExplicitEmpty polCid =>
                rw [hPol] at hCore; dsimp only at hCore
                by_cases hp : (polCid == "") = true
                · rw [if_pos hp] at hCore; nomatch hCore
                · rw [if_neg hp] at hCore; nomatch hCore
        | cons it0 rest =>
            rw [hIt] at hCore; dsimp only at hCore
            cases hEvL : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
            | error _ => rw [hEvL] at hCore; nomatch hCore
            | ok pairs =>
                rw [hEvL] at hCore; dsimp only at hCore
                let vL := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
                let uL := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
                by_cases hv : (!vL.isEmpty) = true
                · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                  rw [if_pos hv] at hCore
                  injection hCore with hvEq huEq
                  change vL = vIds at hvEq
                  have hvNe : vIds ≠ [] := by
                    rw [← hvEq]
                    intro hNil; rw [hNil] at hv; nomatch hv
                  refine ⟨hEnvOk, hContOk, hVerS, (fun h => nomatch h),
                    nodupStrsBool_sound _ hNodupB, by rwa [← hIt], hvNe,
                    pairs, rfl, hvEq.symm, huEq.symm⟩
                · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                  rw [if_neg hv] at hCore
                  by_cases hu : (!uL.isEmpty) = true
                  · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                    rw [if_pos hu] at hCore; nomatch hCore
                  · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                    rw [if_neg hu] at hCore; nomatch hCore

/-- **`Gate A4a` (`T_B2_A4a_CounterexampleSound_Unconditional` — `F-B2-T11-03` & `F-B2-T12-03`)**:
    Unconditional `CounterexampleSound`: when violations are point-based (`allViolationsPointBasedBool = true`),
    `checkG6Suite ... = .violated vIds uIds` guarantees genuine in-domain defined-false rational
    counterexamples and parameter-binding soundness **with ZERO `SemValidPrimId` assumptions**! -/
theorem T_B2_A4a_CounterexampleSound_Unconditional
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) (vIds uIds : List String)
    (hViol : checkG6Suite fuel Γ C suite = .violated vIds uIds)
    (hPointOnly : allViolationsPointBasedBool suite = true) :
    checkPrimEnvIntegrityBool Γ = true ∧
    ValidContainer C ∧
    SemPointCounterexampleOnNewDom suite vIds := by
  rcases unpack_violated_checkG6Suite hViol with
    ⟨hEnvOk, hContOk, _, _, _, _, hvNe, pairs, hEvL, hvEq, _⟩
  refine ⟨hEnvOk, hContOk, ⟨hvNe, ?_⟩⟩
  intro vid hVidIn
  rw [hvEq] at hVidIn
  rcases mem_map_fst_exists_pair_b2 hVidIn with ⟨cls, hInFilt⟩
  rcases List.mem_filter.mp hInFilt with ⟨hInPairs, hClsViolB⟩
  have hClsEq : cls = .itemViolated := eq_of_beq hClsViolB
  subst hClsEq
  rcases (evalG6ItemsList_ok_mem hEvL).2.2 vid .itemViolated hInPairs with
    ⟨item, hItemIn, hIdEq, hSingleOk⟩
  rcases evalSingleG6Item_ok_common hSingleOk with
    ⟨_, _, _, hParamOk, _, _, _, hBodyOk⟩
  have hParamSem := (T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound item hParamOk).1
  have hPtOnlyIt : (match item.evidenceRoots.itemEvidence with
      | .claimViolated (.derivedRefutationNode _ _) => false
      | _ => true) = true :=
    List.all_eq_true.mp hPointOnly item hItemIn
  -- Extract counterexamplePoint from hBodyOk
  unfold evalSingleG6ItemBody at hBodyOk
  dsimp only at hBodyOk
  cases hEv : item.evidenceRoots.itemEvidence with
  | claimVerified rootNid =>
      rw [hEv] at hBodyOk; dsimp only at hBodyOk
      by_cases b1 : (!checkInEffDomRatCoordBool fuel item.oldNewState.domNew
          item.oldNewState.guardsNew item.oldNewState.postDomNonEmptyWitness) = true
      · rw [if_pos b1] at hBodyOk; nomatch hBodyOk
      · rw [if_neg b1] at hBodyOk
        by_cases b2 : (evalStrictFormRatCoord fuel item.oldNewState.formNewInst
            item.oldNewState.postDomNonEmptyWitness == FormEvalRes.undefinedTerm) = true
        · rw [if_pos b2] at hBodyOk; nomatch hBodyOk
        · rw [if_neg b2] at hBodyOk
          by_cases b3 : checkExactG7SequentBool fuel Γ C rootNid item.oldNewState.domNew
              item.oldNewState.specNewId item.oldNewState.guardsNew
              item.oldNewState.formNewInst = true
          · rw [if_pos b3] at hBodyOk; nomatch hBodyOk
          · rw [if_neg b3] at hBodyOk; nomatch hBodyOk
  | claimUnresolved _ =>
      rw [hEv] at hBodyOk; nomatch hBodyOk
  | claimViolated refc =>
      cases refc with
      | derivedRefutationNode _ _ =>
          rw [hEv] at hPtOnlyIt; nomatch hPtOnlyIt
      | counterexamplePoint violPt =>
          rw [hEv] at hBodyOk; dsimp only at hBodyOk
          by_cases hInD : (!checkInEffDomRatCoordBool fuel item.oldNewState.domNew
              item.oldNewState.guardsNew violPt) = true
          · rw [if_pos hInD] at hBodyOk; nomatch hBodyOk
          · rw [if_neg hInD] at hBodyOk
            have hInDOk : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                item.oldNewState.guardsNew violPt = true := by
              cases hb : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                  item.oldNewState.guardsNew violPt with
              | true => rfl
              | false => exfalso; exact hInD (by rw [hb]; rfl)
            by_cases hFalse : (evalStrictFormRatCoord fuel item.oldNewState.formNewInst
                violPt == FormEvalRes.satDefinedFalse) = true
            · rcases checkInEffDomRatCoordBool_sound fuel item.oldNewState.domNew
                item.oldNewState.guardsNew violPt hInDOk with ⟨hx, hy, hInEff⟩
              have hWfPt : checkRatCoordWfBool violPt = true :=
                (checkRatCoordWfBool_iff violPt).mpr ⟨hx, hy⟩
              rcases (evalStrictFormRatCoord_sound violPt hWfPt fuel
                item.oldNewState.formNewInst).2.1 (eq_of_beq hFalse) with
                ⟨hDef, hNotRaw⟩
              exact ⟨item, hItemIn, violPt, hIdEq, hx, hy, hParamSem,
                hInEff, hDef, fun hM => hNotRaw hM.2⟩
            · rw [if_neg hFalse] at hBodyOk; nomatch hBodyOk

/-- **`Gate A4b` (`T_B2_A4b_FullViolationRecordSound_Conditional` — `F-B2-T11-03` & `F-B2-T12-03`)**:
    Under `∀ p ∈ deriveG6PrimDeps Γ C suite, SemValidPrimId Γ p`, `checkG6Suite ... = .violated vIds uIds`
    establishes full `SemViolatedG6ProtectedSuite suite vIds` (covering both `.counterexamplePoint`
    and `.derivedRefutationNode`, full `SemValidG6ScopeRelation`, and optional old baseline validity). -/
theorem T_B2_A4b_FullViolationRecordSound_Conditional
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) (vIds uIds : List String)
    (hViol : checkG6Suite fuel Γ C suite = .violated vIds uIds)
    (hPremValid : ∀ p ∈ deriveG6PrimDeps Γ C suite, SemValidPrimId Γ p) :
    SemViolatedG6ProtectedSuite suite vIds := by
  rcases unpack_violated_checkG6Suite hViol with
    ⟨_, hContOk, hVerS, hNonEmpty, hNodup, hMapEq, hvNe, pairs, hEvL, hvEq, _⟩
  refine {
    canonicalHeaderAndCoverage := ⟨hVerS, hNonEmpty, hNodup, hMapEq⟩
    nonEmptyViolatedIds := hvNe
    allViolatedRecordsSound := ?_
  }
  intro vid hVidIn
  rw [hvEq] at hVidIn
  rcases mem_map_fst_exists_pair_b2 hVidIn with ⟨cls, hInFilt⟩
  rcases List.mem_filter.mp hInFilt with ⟨hInPairs, hClsViolB⟩
  have hClsEq : cls = .itemViolated := eq_of_beq hClsViolB
  subst hClsEq
  rcases (evalG6ItemsList_ok_mem hEvL).2.2 vid .itemViolated hInPairs with
    ⟨item, hItemIn, hIdEq, hSingleOk⟩
  rcases evalSingleG6Item_ok_common hSingleOk with
    ⟨_, _, _, hParOk, _, hOldFn, hScOk, hBodyOk⟩
  have hItemPrem : ∀ pid ∈ multiRootTransitivePrimDeps Γ C (collectItemG6ProofRootIds item),
      SemValidPrimId Γ pid := by
    intro pid hp
    unfold multiRootTransitivePrimDeps at hp
    rw [mem_canonSortStrs] at hp
    have hSub : ∀ (rs : List String),
        (∀ r ∈ rs, r ∈ collectG6ProofRootIds suite) →
        pid ∈ rs.foldr (fun r acc => extractTransitivePrimDeps Γ C r ++ acc) [] →
        pid ∈ deriveG6PrimDeps Γ C suite := by
      intro rs hRSub hFold
      induction rs with
      | nil => nomatch hFold
      | cons r tail ih =>
          dsimp only [List.foldr] at hFold
          rcases List.mem_append.mp hFold with hHead | hRest
          · exact mem_multiRootTransitivePrimDeps Γ C (hRSub r (List.mem_cons_self ..)) hHead
          · exact ih (fun u hu => hRSub u (List.mem_cons_of_mem r hu)) hRest
    exact hPremValid pid (hSub (collectItemG6ProofRootIds item)
      (fun r hr => itemRoot_mem_suiteRoots hItemIn hr) hp)
  have hParamSem := (T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound item hParOk).1
  have hScopeSem := (T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound
    hContOk hItemPrem hScOk).2
  have hOldBaseSem : item.oldNewState.oldBaselineProofNodeId?.isSome = true →
      ∀ ρ : Env2, InEffDom item.oldNewState.domOld item.oldNewState.guardsOld ρ →
        ModelsStrictForm item.oldNewState.formOldInst ρ := by
    intro hSome ρ hInOld
    cases hOpt : item.oldNewState.oldBaselineProofNodeId? with
    | none => rw [hOpt] at hSome; nomatch hSome
    | some oldNid =>
        have hOldChk := hOldFn oldNid hOpt
        have hOldRoot : oldNid ∈ collectItemG6ProofRootIds item := by
          apply oldBase_mem_itemRoots item
          rw [hOpt]; exact List.mem_cons_self ..
        have hOldS := exactG7Sequent_sound_on_roots hContOk hItemPrem hOldRoot hOldChk
        exact hOldS.2 ρ hInOld.1 hInOld.2.2
  -- Extract violation witness (either counterexamplePoint or derivedRefutationNode)
  have hViolWit : ∃ ρ_viol : Env2,
      InEffDom item.oldNewState.domNew item.oldNewState.guardsNew ρ_viol ∧
      FormDefined item.oldNewState.formNewInst ρ_viol ∧
      ¬ ModelsStrictForm item.oldNewState.formNewInst ρ_viol := by
    unfold evalSingleG6ItemBody at hBodyOk
    dsimp only at hBodyOk
    cases hEv : item.evidenceRoots.itemEvidence with
    | claimVerified rootNid =>
        rw [hEv] at hBodyOk; dsimp only at hBodyOk
        by_cases b1 : (!checkInEffDomRatCoordBool fuel item.oldNewState.domNew
            item.oldNewState.guardsNew item.oldNewState.postDomNonEmptyWitness) = true
        · rw [if_pos b1] at hBodyOk; nomatch hBodyOk
        · rw [if_neg b1] at hBodyOk
          by_cases b2 : (evalStrictFormRatCoord fuel item.oldNewState.formNewInst
              item.oldNewState.postDomNonEmptyWitness == FormEvalRes.undefinedTerm) = true
          · rw [if_pos b2] at hBodyOk; nomatch hBodyOk
          · rw [if_neg b2] at hBodyOk
            by_cases b3 : checkExactG7SequentBool fuel Γ C rootNid item.oldNewState.domNew
                item.oldNewState.specNewId item.oldNewState.guardsNew
                item.oldNewState.formNewInst = true
            · rw [if_pos b3] at hBodyOk; nomatch hBodyOk
            · rw [if_neg b3] at hBodyOk; nomatch hBodyOk
    | claimUnresolved _ =>
        rw [hEv] at hBodyOk; nomatch hBodyOk
    | claimViolated refc =>
        cases refc with
        | counterexamplePoint violPt =>
            rw [hEv] at hBodyOk; dsimp only at hBodyOk
            by_cases hInD : (!checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                item.oldNewState.guardsNew violPt) = true
            · rw [if_pos hInD] at hBodyOk; nomatch hBodyOk
            · rw [if_neg hInD] at hBodyOk
              have hInDOk : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                  item.oldNewState.guardsNew violPt = true := by
                cases hb : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                    item.oldNewState.guardsNew violPt with
                | true => rfl
                | false => exfalso; exact hInD (by rw [hb]; rfl)
              by_cases hFalse : (evalStrictFormRatCoord fuel item.oldNewState.formNewInst
                  violPt == FormEvalRes.satDefinedFalse) = true
              · rcases checkInEffDomRatCoordBool_sound fuel item.oldNewState.domNew
                  item.oldNewState.guardsNew violPt hInDOk with ⟨hx, hy, hInEff⟩
                have hWfPt := (checkRatCoordWfBool_iff violPt).mpr ⟨hx, hy⟩
                rcases (evalStrictFormRatCoord_sound violPt hWfPt fuel
                  item.oldNewState.formNewInst).2.1 (eq_of_beq hFalse) with
                  ⟨hDef, hNotRaw⟩
                exact ⟨ratCoordToEnv2 violPt, hInEff, hDef, fun hM => hNotRaw hM.2⟩
              · rw [if_neg hFalse] at hBodyOk; nomatch hBodyOk
        | derivedRefutationNode refutNid witPt =>
            rw [hEv] at hBodyOk; dsimp only at hBodyOk
            by_cases hInD : (!checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                item.oldNewState.guardsNew witPt) = true
            · rw [if_pos hInD] at hBodyOk; nomatch hBodyOk
            · rw [if_neg hInD] at hBodyOk
              have hInDOk : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                  item.oldNewState.guardsNew witPt = true := by
                cases hb : checkInEffDomRatCoordBool fuel item.oldNewState.domNew
                    item.oldNewState.guardsNew witPt with
                | true => rfl
                | false => exfalso; exact hInD (by rw [hb]; rfl)
              by_cases hRefOk : (isAtomicStrictFormBool item.oldNewState.formNewInst &&
                  checkExactG7SequentBool fuel Γ C refutNid item.oldNewState.domNew
                    item.oldNewState.specNewId item.oldNewState.guardsNew
                    (atomicComplement item.oldNewState.formNewInst)) = true
              · simp only [Bool.and_eq_true] at hRefOk
                have hInEff := (checkInEffDomRatCoordBool_sound fuel
                  item.oldNewState.domNew item.oldNewState.guardsNew witPt hInDOk).2.2
                have hRefRoot : refutNid ∈ collectItemG6ProofRootIds item := by
                  apply itemEv_mem_itemRoots item
                  rw [hEv]; exact List.mem_cons_self ..
                have hCompSem := exactG7Sequent_sound_on_roots hContOk hItemPrem
                  hRefRoot hRefOk.2
                have hCompTrue : ModelsStrictForm
                    (atomicComplement item.oldNewState.formNewInst)
                    (ratCoordToEnv2 witPt) :=
                  hCompSem.2 (ratCoordToEnv2 witPt) hInEff.1 hInEff.2.2
                have hDefOrig : FormDefined item.oldNewState.formNewInst
                    (ratCoordToEnv2 witPt) := by
                  have hCompDef := hCompTrue.1
                  cases hf : item.oldNewState.formNewInst with
                  | conj _ _ => rw [hf] at hRefOk; nomatch hRefOk.1
                  | impStrict _ _ => rw [hf] at hRefOk; nomatch hRefOk.1
                  | eqZero e =>
                      rw [hf] at hCompDef; exact hCompDef
                  | neqZero e =>
                      rw [hf] at hCompDef; exact hCompDef
                  | pos e =>
                      rw [hf] at hCompDef
                      rcases hCompDef with ⟨_, hNeg⟩
                      cases hNeg with | neg hv => exact ⟨_, hv⟩
                  | nonneg e =>
                      rw [hf] at hCompDef
                      rcases hCompDef with ⟨_, hNeg⟩
                      cases hNeg with | neg hv => exact ⟨_, hv⟩
                rcases (atomicComplement_defined_xor hRefOk.1 hDefOrig).2 with
                  ⟨_, hNotComp⟩ | ⟨hNotOrig, _⟩
                · exact False.elim (hNotComp hCompTrue)
                · exact ⟨ratCoordToEnv2 witPt, hInEff, hDefOrig, hNotOrig⟩
              · rw [if_neg hRefOk] at hBodyOk; nomatch hBodyOk
  exact ⟨item, hItemIn, hIdEq, hParamSem, hScopeSem, hOldBaseSem, hViolWit⟩

/-- **`Gate A4c` (`T_B2_A4c_PremiseFreeViolation_BridgeViaA4b` — `F-B2-T12-03` Exact Bridge)**:
    Requires `hViol : checkG6Suite fuel Γ C suite = .violated vIds uIds` (so container, scope,
    and refutation checks have genuinely passed!) together with `deriveG6PrimDeps Γ C suite = []`,
    and routes directly through `T_B2_A4b_FullViolationRecordSound_Conditional` via vacuous
    satisfaction of `hPremValid`. -/
theorem T_B2_A4c_PremiseFreeViolation_BridgeViaA4b
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) (vIds uIds : List String)
    (hViol : checkG6Suite fuel Γ C suite = .violated vIds uIds)
    (hNoPrimDeps : deriveG6PrimDeps Γ C suite = []) :
    SemViolatedG6ProtectedSuite suite vIds :=
  T_B2_A4b_FullViolationRecordSound_Conditional fuel Γ C suite vIds uIds hViol
    (fun p hp => by rw [hNoPrimDeps] at hp; nomatch hp)

/-! ### 6. `Gate A5`, `F-B2-T12-02` (Function- vs Type-Level Empty-Suite Separation), & `Gate A6` -/

/-- **`Gate A5` (`T_B2_A5_Unresolved_ConservativeHold_And_NonPromotion`)**:
    (1) Any `suite` containing even a single `.claimUnresolved` item can NEVER evaluate to
        `.verified`, `isG6SuiteVerifiedBool = true`, or `qualifyG6Isolated? = some _`;
    (2) Whenever `checkG6Suite fuel Γ C suite = .unresolved uIds`, `uIds ≠ []` and no
        `G6QualifiedRecord` can ever wrap `suite`. -/
theorem T_B2_A5_Unresolved_ConservativeHold_And_NonPromotion
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite) :
    ((∃ item ∈ suite.items, ∃ r : G6UnresolvedReason,
        item.evidenceRoots.itemEvidence = .claimUnresolved r) →
      (∀ hasLoss : Bool, checkG6Suite fuel Γ C suite ≠ .verified hasLoss) ∧
      isG6SuiteVerifiedBool fuel Γ C suite = false ∧
      qualifyG6Isolated? fuel Γ C suite = none) ∧
    (∀ uIds : List String,
      checkG6Suite fuel Γ C suite = .unresolved uIds →
      uIds ≠ [] ∧
      isG6SuiteVerifiedBool fuel Γ C suite = false ∧
      qualifyG6Isolated? fuel Γ C suite = none ∧
      ¬ ∃ rec : G6QualifiedRecord fuel Γ C,
          extractVerifiedG6Suite rec.verifiedG6Slot = suite) := by
  refine ⟨?_, ?_⟩
  · rintro ⟨item, hItemIn, reason, hUnresEv⟩
    have hNotVer : ∀ hasLoss : Bool, checkG6Suite fuel Γ C suite ≠ .verified hasLoss := by
      intro hasLoss hVer
      have hNotInv : ∀ r, checkG6Suite fuel Γ C suite ≠ .invalid r := by
        intro r hr; rw [hVer] at hr; nomatch hr
      rcases unpack_nonInvalid_checkG6Suite hNotInv with ⟨_, _, _, _, _, _, _, _, _, hEqCore⟩
      have hVerCore : evalG6SuiteCore fuel Γ C suite = .verified hasLoss := hEqCore.symm.trans hVer
      unfold evalG6SuiteCore at hVerCore
      split at hVerCore
      · nomatch hVerCore
      · split at hVerCore
        · nomatch hVerCore
        · split at hVerCore
          · nomatch hVerCore
          · cases hIt : suite.items with
            | nil => rw [hIt] at hItemIn; nomatch hItemIn
            | cons it0 rest =>
                rw [hIt] at hVerCore; dsimp only at hVerCore
                cases hEvL : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
                | error _ => rw [hEvL] at hVerCore; nomatch hVerCore
                | ok pairs =>
                    rw [hEvL] at hVerCore; dsimp only at hVerCore
                    have hInCons : item ∈ it0 :: rest := by rwa [← hIt]
                    rcases (evalG6ItemsList_ok_mem hEvL).2.1 item hInCons with
                      ⟨cls, hSingleOk, hInPairs⟩
                    have hClsU : cls = .itemUnresolved := by
                      rcases evalSingleG6Item_ok_common hSingleOk with
                        ⟨_, _, _, _, _, _, _, hBodyOk⟩
                      unfold evalSingleG6ItemBody at hBodyOk
                      dsimp only at hBodyOk
                      rw [hUnresEv] at hBodyOk
                      injection hBodyOk with hc
                      exact hc.symm
                    subst hClsU
                    let vIds := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
                    let uIds := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
                    have hInU : item.invariantId ∈ uIds :=
                      List.mem_map_of_mem (List.mem_filter.mpr ⟨hInPairs, rfl⟩)
                    by_cases hv : (!vIds.isEmpty) = true
                    · change (if (!vIds.isEmpty) = true then _ else _) = _ at hVerCore
                      rw [if_pos hv] at hVerCore; nomatch hVerCore
                    · change (if (!vIds.isEmpty) = true then _ else _) = _ at hVerCore
                      rw [if_neg hv] at hVerCore
                      have hu : (!uIds.isEmpty) = true := by
                        cases huL : uIds with
                        | nil => rw [huL] at hInU; nomatch hInU
                        | cons _ _ => rfl
                      change (if (!uIds.isEmpty) = true then _ else _) = _ at hVerCore
                      rw [if_pos hu] at hVerCore; nomatch hVerCore
    have hIsVerF : isG6SuiteVerifiedBool fuel Γ C suite = false := by
      unfold isG6SuiteVerifiedBool
      cases hc : checkG6Suite fuel Γ C suite with
      | verified b => exact False.elim (hNotVer b hc)
      | _ => rfl
    have hQualNone : qualifyG6Isolated? fuel Γ C suite = none := by
      unfold qualifyG6Isolated?
      rw [dif_neg (by rw [hIsVerF]; decide)]
    exact ⟨hNotVer, hIsVerF, hQualNone⟩
  · intro uIds hUnr
    have hNotInv : ∀ r, checkG6Suite fuel Γ C suite ≠ .invalid r := by
      intro r hr; rw [hUnr] at hr; nomatch hr
    rcases unpack_nonInvalid_checkG6Suite hNotInv with ⟨_, _, _, _, _, _, _, _, _, hEqCore⟩
    have hCore : evalG6SuiteCore fuel Γ C suite = .unresolved uIds := hEqCore.symm.trans hUnr
    have huNe : uIds ≠ [] := by
      unfold evalG6SuiteCore at hCore
      split at hCore
      · nomatch hCore
      · split at hCore
        · nomatch hCore
        · split at hCore
          · nomatch hCore
          · cases hIt : suite.items with
            | nil =>
                rw [hIt] at hCore; dsimp only at hCore
                cases hPol : suite.emptySuitePolicy with
                | forbidEmptySuite => rw [hPol] at hCore; nomatch hCore
                | allowExplicitEmpty polCid =>
                    rw [hPol] at hCore; dsimp only at hCore
                    by_cases hp : (polCid == "") = true
                    · rw [if_pos hp] at hCore; nomatch hCore
                    · rw [if_neg hp] at hCore; nomatch hCore
            | cons it0 rest =>
                rw [hIt] at hCore; dsimp only at hCore
                cases hEvL : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
                | error _ => rw [hEvL] at hCore; nomatch hCore
                | ok pairs =>
                    rw [hEvL] at hCore; dsimp only at hCore
                    let vL := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
                    let uL := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
                    by_cases hv : (!vL.isEmpty) = true
                    · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                      rw [if_pos hv] at hCore; nomatch hCore
                    · change (if (!vL.isEmpty) = true then _ else _) = _ at hCore
                      rw [if_neg hv] at hCore
                      by_cases hu : (!uL.isEmpty) = true
                      · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                        rw [if_pos hu] at hCore
                        injection hCore with huEq
                        change uL = uIds at huEq
                        rw [← huEq]
                        intro hNil; rw [hNil] at hu; nomatch hu
                      · change (if (!uL.isEmpty) = true then _ else _) = _ at hCore
                        rw [if_neg hu] at hCore; nomatch hCore
    have hIsVerF : isG6SuiteVerifiedBool fuel Γ C suite = false := by
      unfold isG6SuiteVerifiedBool; rw [hUnr]
    have hQualNone : qualifyG6Isolated? fuel Γ C suite = none := by
      unfold qualifyG6Isolated?; rw [dif_neg (by rw [hIsVerF]; decide)]
    refine ⟨huNe, hIsVerF, hQualNone, ?_⟩
    rintro ⟨rec, hSubEq⟩
    cases hs : rec.verifiedG6Slot with
    | mkVerified c =>
        unfold extractVerifiedG6Suite at hSubEq
        rw [hs] at hSubEq
        dsimp only at hSubEq
        have hc2 := c.2
        rw [hSubEq, hIsVerF] at hc2
        nomatch hc2

/-- **`F-B2-T12-02` Part A (`T_B2_F12_02A_EmptySuite_FunctionNeverIssues`)**:
    Function-level non-issuance theorem: for ANY `suite` with `suite.items = []`,
    `checkG6Suite` never returns `.verified`, `isG6SuiteVerifiedBool = false`,
    `qualifyG6Isolated? = none`, and `¬ SemValidG6ProtectedSuite suite`. -/
theorem T_B2_F12_02A_EmptySuite_FunctionNeverIssues
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite)
    (hEmpty : suite.items = []) :
    (∀ hasLoss : Bool, checkG6Suite fuel Γ C suite ≠ .verified hasLoss) ∧
    isG6SuiteVerifiedBool fuel Γ C suite = false ∧
    qualifyG6Isolated? fuel Γ C suite = none ∧
    ¬ SemValidG6ProtectedSuite suite := by
  have hIsVerF : isG6SuiteVerifiedBool fuel Γ C suite = false := by
    cases hb : isG6SuiteVerifiedBool fuel Γ C suite with
    | false => rfl
    | true => exact False.elim ((isG6SuiteVerifiedBool_implies_nonEmpty hb).1 hEmpty)
  have hNotVer : ∀ hasLoss : Bool, checkG6Suite fuel Γ C suite ≠ .verified hasLoss := by
    intro hasLoss hVer
    have hT : isG6SuiteVerifiedBool fuel Γ C suite = true := by
      unfold isG6SuiteVerifiedBool; rw [hVer]
    rw [hIsVerF] at hT; nomatch hT
  have hQualNone : qualifyG6Isolated? fuel Γ C suite = none := by
    unfold qualifyG6Isolated?; rw [dif_neg (by rw [hIsVerF]; decide)]
  exact ⟨hNotVer, hIsVerF, hQualNone, fun hSem => hSem.nonEmptyProtectedSuite.1 hEmpty⟩

/-- **`F-B2-T12-02` Part B (`T_B2_F12_02B_EmptySuite_TypeForbidsRecord`)**:
    Type-level impossibility theorem: BOTH `SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified`
    AND `G6QualifiedRecord fuel Γ C` intrinsically forbid empty-suite inhabitants at the type level! -/
theorem T_B2_F12_02B_EmptySuite_TypeForbidsRecord
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) :
    (∀ w : SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified,
      (extractVerifiedG6Suite w).items ≠ []) ∧
    (∀ rec : G6QualifiedRecord fuel Γ C,
      (extractVerifiedG6Suite rec.verifiedG6Slot).items ≠ [] ∧
      0 < rec.verifiedInvariantCount ∧
      rec.verifiedInvariantCount = (extractVerifiedG6Suite rec.verifiedG6Slot).items.length) ∧
    (∀ suite : G6ProtectedSuite,
      suite.items = [] →
      ¬ ∃ rec : G6QualifiedRecord fuel Γ C,
          extractVerifiedG6Suite rec.verifiedG6Slot = suite) := by
  refine ⟨?_, ?_, ?_⟩
  · intro w
    cases w with
    | mkVerified c =>
        exact (isG6SuiteVerifiedBool_implies_nonEmpty c.2).1
  · intro rec
    have hPos := rec.verifiedCountPos
    have hEq := rec.verifiedCount_eq_itemsLength
    have hNe : (extractVerifiedG6Suite rec.verifiedG6Slot).items ≠ [] := by
      intro hNil
      rw [hNil, List.length_nil] at hEq
      omega
    exact ⟨hNe, hPos, hEq⟩
  · intro suite hEmpty ⟨rec, hEqSuite⟩
    have hNe : (extractVerifiedG6Suite rec.verifiedG6Slot).items ≠ [] := by
      have hPos := rec.verifiedCountPos
      have hEq := rec.verifiedCount_eq_itemsLength
      intro hNil; rw [hNil, List.length_nil] at hEq; omega
    rw [hEqSuite] at hNe
    exact hNe hEmpty

/-- Count of `ItemViolated` entries when `evalG6ItemsList` succeeds (`0` otherwise). -/
def countEvaluatedViolated (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Nat :=
  match evalG6ItemsList fuel Γ C suite.evaluationEpoch suite.items with
  | .error _ => 0
  | .ok ps   => (ps.filter (fun p => p.2 == .itemViolated)).length

/-- Count of `ItemUnresolved` entries when `evalG6ItemsList` succeeds (`0` otherwise). -/
def countEvaluatedUnresolved (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Nat :=
  match evalG6ItemsList fuel Γ C suite.evaluationEpoch suite.items with
  | .error _ => 0
  | .ok ps   => (ps.filter (fun p => p.2 == .itemUnresolved)).length

/-- **`Gate A6` (`T_B2_A6_VerdictPriorityLattice_And_ExactClassification` — `Corrigendum 01` §1.4)**:
    Exact 5-branch deterministic priority characterization:
    (1) `Invalid` iff `hasAnyG6StructuralOrCertDefectBool = true`,
    (2) `EmptySuiteAccepted` iff defect-free AND `suite.items = []`,
    (3) On defect-free non-empty suites (`suite.items ≠ []`), `Violated > Unresolved > Verified`
        holds as an exact biconditional partition! -/
theorem T_B2_A6_VerdictPriorityLattice_And_ExactClassification
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite) :
    -- (1) Invalid iff structural/cert defect
    (hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = true ↔
      ∃ r : G6InvalidReason, checkG6Suite fuel Γ C suite = .invalid r) ∧
    -- (2) EmptySuiteAccepted iff defect-free AND suite.items = []
    ((∃ polCid : String, checkG6Suite fuel Γ C suite = .emptySuiteAccepted polCid) ↔
      (hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false ∧ suite.items = [])) ∧
    -- (3) Violated iff defect-free, non-empty, AND 0 < countEvaluatedViolated
    ((∃ vIds uIds, checkG6Suite fuel Γ C suite = .violated vIds uIds) ↔
      (hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false ∧
       suite.items ≠ [] ∧
       0 < countEvaluatedViolated fuel Γ C suite)) ∧
    -- (4) Unresolved iff defect-free, non-empty, Violated = 0, AND 0 < countEvaluatedUnresolved
    ((∃ uIds, checkG6Suite fuel Γ C suite = .unresolved uIds) ↔
      (hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false ∧
       suite.items ≠ [] ∧
       countEvaluatedViolated fuel Γ C suite = 0 ∧
       0 < countEvaluatedUnresolved fuel Γ C suite)) ∧
    -- (5) Verified iff defect-free, non-empty, Violated = 0, AND Unresolved = 0
    ((∃ hasLoss, checkG6Suite fuel Γ C suite = .verified hasLoss) ↔
      (hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false ∧
       suite.items ≠ [] ∧
       countEvaluatedViolated fuel Γ C suite = 0 ∧
       countEvaluatedUnresolved fuel Γ C suite = 0)) := by
  have hInvIff : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = true ↔
      ∃ r : G6InvalidReason, checkG6Suite fuel Γ C suite = .invalid r := by
    unfold hasAnyG6StructuralOrCertDefectBool
    cases hc : checkG6Suite fuel Γ C suite with
    | invalid r => exact Iff.intro (fun _ => ⟨r, rfl⟩) (fun _ => rfl)
    | violated _ _ => exact Iff.intro (fun h => nomatch h) (fun ⟨_, hr⟩ => nomatch hr)
    | unresolved _ => exact Iff.intro (fun h => nomatch h) (fun ⟨_, hr⟩ => nomatch hr)
    | emptySuiteAccepted _ => exact Iff.intro (fun h => nomatch h) (fun ⟨_, hr⟩ => nomatch hr)
    | verified _ => exact Iff.intro (fun h => nomatch h) (fun ⟨_, hr⟩ => nomatch hr)
  have hNotDefIff : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false ↔
      ∀ r : G6InvalidReason, checkG6Suite fuel Γ C suite ≠ .invalid r := by
    constructor
    · intro hF r hr
      have hT := hInvIff.mpr ⟨r, hr⟩
      rw [hF] at hT; nomatch hT
    · intro hAll
      cases hb : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite with
      | false => rfl
      | true => rcases hInvIff.mp hb with ⟨r, hr⟩; exact False.elim (hAll r hr)
  -- Helper unfolding defect-free non-empty suite
  have hNonEmptyCore :
      hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false →
      suite.items ≠ [] →
      ∃ pairs : List (String × G6ItemClass),
        evalG6ItemsList fuel Γ C suite.evaluationEpoch suite.items = .ok pairs ∧
        checkG6Suite fuel Γ C suite =
          (let vIds := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
           let uIds := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
           if !vIds.isEmpty then .violated vIds uIds
           else if !uIds.isEmpty then .unresolved uIds
           else .verified (suite.items.any (fun it => it.scopeLossRecord?.isSome))) := by
    intro hDefF hNe
    have hNotInv := hNotDefIff.mp hDefF
    rcases unpack_nonInvalid_checkG6Suite hNotInv with ⟨_, _, _, _, _, _, _, _, _, hEqCore⟩
    have hNotInvCore : ∀ r, evalG6SuiteCore fuel Γ C suite ≠ .invalid r :=
      fun r hr => hNotInv r (hEqCore.trans hr)
    unfold evalG6SuiteCore at hEqCore hNotInvCore
    by_cases b1 : (!checkG6SuiteHeaderBasicBool suite) = true
    · rw [if_pos b1] at hNotInvCore; exact False.elim (hNotInvCore _ rfl)
    · rw [if_neg b1] at hEqCore hNotInvCore
      by_cases b2 : (!nodupStrsBool suite.declaredInvariantIds ||
          suite.declaredInvariantIds.any (fun id => id == "")) = true
      · rw [if_pos b2] at hNotInvCore; exact False.elim (hNotInvCore _ rfl)
      · rw [if_neg b2] at hEqCore hNotInvCore
        by_cases b3 : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
            suite.items.any (fun item =>
              (item.oldNewState.specOldId != suite.specOldId) ||
              (item.oldNewState.specNewId != suite.specNewId))) = true
        · rw [if_pos b3] at hNotInvCore; exact False.elim (hNotInvCore _ rfl)
        · rw [if_neg b3] at hEqCore hNotInvCore
          cases hIt : suite.items with
          | nil => exact False.elim (hNe hIt)
          | cons it0 rest =>
              rw [hIt] at hEqCore hNotInvCore
              dsimp only at hEqCore hNotInvCore
              cases hEvL : evalG6ItemsList fuel Γ C suite.evaluationEpoch (it0 :: rest) with
              | error r =>
                  rw [hEvL] at hNotInvCore; exact False.elim (hNotInvCore r rfl)
              | ok ps =>
                  rw [hEvL] at hEqCore
                  exact ⟨ps, rfl, hEqCore⟩
  refine ⟨hInvIff, ?_, ?_, ?_, ?_⟩
  · -- (2) EmptySuiteAccepted
    constructor
    · rintro ⟨polCid, hEmp⟩
      have hDefF : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false := by
        unfold hasAnyG6StructuralOrCertDefectBool; rw [hEmp]
      exact ⟨hDefF, (T_B2_A3b_EmptySuiteAccepted_NoticeSound fuel Γ C suite polCid hEmp).1.emptyItemsAndDeps.1⟩
    · rintro ⟨hDefF, hEmpty⟩
      have hNotInv := hNotDefIff.mp hDefF
      rcases (T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage fuel Γ C suite hNotInv).2.2.2.2.2.2.2.1
        hEmpty with ⟨polCid, _, _, hChk⟩
      exact ⟨polCid, hChk⟩
  · -- (3) Violated
    constructor
    · rintro ⟨vIds, uIds, hViol⟩
      have hDefF : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false := by
        unfold hasAnyG6StructuralOrCertDefectBool; rw [hViol]
      rcases unpack_violated_checkG6Suite hViol with ⟨_, _, _, hNe, _, _, hvNe, ps, hEvL, hvEq, _⟩
      refine ⟨hDefF, hNe, ?_⟩
      unfold countEvaluatedViolated; rw [hEvL]; dsimp only
      cases hFilt : ps.filter (fun p => p.2 == .itemViolated) with
      | nil => rw [hFilt] at hvEq; exact False.elim (hvNe hvEq)
      | cons _ _ => exact Nat.succ_pos _
    · rintro ⟨hDefF, hNe, hVPos⟩
      rcases hNonEmptyCore hDefF hNe with ⟨ps, hEvL, hChkEq⟩
      unfold countEvaluatedViolated at hVPos; rw [hEvL] at hVPos; dsimp only at hVPos
      let vIds := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
      let uIds := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
      have hvNonEmp : (!vIds.isEmpty) = true := by
        cases hf : ps.filter (fun p => p.2 == .itemViolated) with
        | nil => rw [hf] at hVPos; nomatch hVPos
        | cons _ _ => dsimp [vIds]; rw [hf]; rfl
      refine ⟨vIds, uIds, ?_⟩
      rw [hChkEq]; dsimp only
      change (if (!vIds.isEmpty) = true then _ else _) = _
      rw [if_pos hvNonEmp]
  · -- (4) Unresolved
    constructor
    · rintro ⟨uIds, hUnr⟩
      have hDefF : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false := by
        unfold hasAnyG6StructuralOrCertDefectBool; rw [hUnr]
      have hNe : suite.items ≠ [] := by
        intro hEmpty
        rcases (T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage fuel Γ C suite
          (hNotDefIff.mp hDefF)).2.2.2.2.2.2.2.1 hEmpty with ⟨_, _, _, hEmp⟩
        rw [hUnr] at hEmp; nomatch hEmp
      rcases hNonEmptyCore hDefF hNe with ⟨ps, hEvL, hChkEq⟩
      rw [hUnr] at hChkEq; dsimp only at hChkEq
      unfold countEvaluatedViolated countEvaluatedUnresolved; rw [hEvL]; dsimp only
      let vIds := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
      let uL := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
      by_cases hv : (!vIds.isEmpty) = true
      · change _ = (if (!vIds.isEmpty) = true then _ else _) at hChkEq
        rw [if_pos hv] at hChkEq; nomatch hChkEq
      · change _ = (if (!vIds.isEmpty) = true then _ else _) at hChkEq
        rw [if_neg hv] at hChkEq
        have hvZero : (ps.filter (fun p => p.2 == .itemViolated)).length = 0 := by
          cases hf : ps.filter (fun p => p.2 == .itemViolated) with
          | nil => rfl
          | cons _ _ => exfalso; apply hv; dsimp [vIds]; rw [hf]; rfl
        by_cases hu : (!uL.isEmpty) = true
        · have huPos : 0 < (ps.filter (fun p => p.2 == .itemUnresolved)).length := by
            cases hf : ps.filter (fun p => p.2 == .itemUnresolved) with
            | nil => dsimp [uL] at hu; rw [hf] at hu; nomatch hu
            | cons _ _ => exact Nat.succ_pos _
          exact ⟨hDefF, hNe, hvZero, huPos⟩
        · change _ = (if (!uL.isEmpty) = true then _ else _) at hChkEq
          rw [if_neg hu] at hChkEq; nomatch hChkEq
    · rintro ⟨hDefF, hNe, hvZero, huPos⟩
      rcases hNonEmptyCore hDefF hNe with ⟨ps, hEvL, hChkEq⟩
      unfold countEvaluatedViolated at hvZero; rw [hEvL] at hvZero; dsimp only at hvZero
      unfold countEvaluatedUnresolved at huPos; rw [hEvL] at huPos; dsimp only at huPos
      let vIds := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
      let uIds := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
      have hvEmpty : (!vIds.isEmpty) = false := by
        cases hf : ps.filter (fun p => p.2 == .itemViolated) with
        | nil => dsimp [vIds]; rw [hf]; rfl
        | cons _ _ => rw [hf, List.length_cons] at hvZero; omega
      have huNonEmp : (!uIds.isEmpty) = true := by
        cases hf : ps.filter (fun p => p.2 == .itemUnresolved) with
        | nil => rw [hf] at huPos; nomatch huPos
        | cons _ _ => dsimp [uIds]; rw [hf]; rfl
      refine ⟨uIds, ?_⟩
      rw [hChkEq]; dsimp only
      change (if (!vIds.isEmpty) = true then _ else _) = _
      rw [if_neg (by rw [hvEmpty]; decide)]
      change (if (!uIds.isEmpty) = true then _ else _) = _
      rw [if_pos huNonEmp]
  · -- (5) Verified
    constructor
    · rintro ⟨hasLoss, hVer⟩
      have hDefF : hasAnyG6StructuralOrCertDefectBool fuel Γ C suite = false := by
        unfold hasAnyG6StructuralOrCertDefectBool; rw [hVer]
      have hIsV : isG6SuiteVerifiedBool fuel Γ C suite = true := by
        unfold isG6SuiteVerifiedBool; rw [hVer]
      have hNe := (isG6SuiteVerifiedBool_implies_nonEmpty hIsV).1
      rcases hNonEmptyCore hDefF hNe with ⟨ps, hEvL, hChkEq⟩
      rw [hVer] at hChkEq; dsimp only at hChkEq
      unfold countEvaluatedViolated countEvaluatedUnresolved; rw [hEvL]; dsimp only
      let vIds := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
      let uIds := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
      by_cases hv : (!vIds.isEmpty) = true
      · change _ = (if (!vIds.isEmpty) = true then _ else _) at hChkEq
        rw [if_pos hv] at hChkEq; nomatch hChkEq
      · change _ = (if (!vIds.isEmpty) = true then _ else _) at hChkEq
        rw [if_neg hv] at hChkEq
        by_cases hu : (!uIds.isEmpty) = true
        · change _ = (if (!uIds.isEmpty) = true then _ else _) at hChkEq
          rw [if_pos hu] at hChkEq; nomatch hChkEq
        · have hvZ : (ps.filter (fun p => p.2 == .itemViolated)).length = 0 := by
            cases hf : ps.filter (fun p => p.2 == .itemViolated) with
            | nil => rfl
            | cons _ _ => exfalso; apply hv; dsimp [vIds]; rw [hf]; rfl
          have huZ : (ps.filter (fun p => p.2 == .itemUnresolved)).length = 0 := by
            cases hf : ps.filter (fun p => p.2 == .itemUnresolved) with
            | nil => rfl
            | cons _ _ => exfalso; apply hu; dsimp [uIds]; rw [hf]; rfl
          exact ⟨hDefF, hNe, hvZ, huZ⟩
    · rintro ⟨hDefF, hNe, hvZ, huZ⟩
      rcases hNonEmptyCore hDefF hNe with ⟨ps, hEvL, hChkEq⟩
      unfold countEvaluatedViolated at hvZ; rw [hEvL] at hvZ; dsimp only at hvZ
      unfold countEvaluatedUnresolved at huZ; rw [hEvL] at huZ; dsimp only at huZ
      let vIds := (ps.filter (fun p => p.2 == .itemViolated)).map Prod.fst
      let uIds := (ps.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
      have hvEmpty : (!vIds.isEmpty) = false := by
        cases hf : ps.filter (fun p => p.2 == .itemViolated) with
        | nil => dsimp [vIds]; rw [hf]; rfl
        | cons _ _ => rw [hf, List.length_cons] at hvZ; omega
      have huEmpty : (!uIds.isEmpty) = false := by
        cases hf : ps.filter (fun p => p.2 == .itemUnresolved) with
        | nil => dsimp [uIds]; rw [hf]; rfl
        | cons _ _ => rw [hf, List.length_cons] at huZ; omega
      refine ⟨suite.items.any (fun it => it.scopeLossRecord?.isSome), ?_⟩
      rw [hChkEq]; dsimp only
      change (if (!vIds.isEmpty) = true then _ else _) = _
      rw [if_neg (by rw [hvEmpty]; decide)]
      change (if (!uIds.isEmpty) = true then _ else _) = _
      rw [if_neg (by rw [huEmpty]; decide)]

/-! ### 7. `Gate A7` + `F-B2-T11-04` + `F-B2-T12-04`: 4-Part Closure & Full Non-Interference -/

private theorem map_eq_imp_forall_mem_eq_b2 {α β : Type} {f g : α → β} :
    ∀ {L : List α}, L.map f = L.map g → ∀ x ∈ L, f x = g x
  | [],     _,    _, hx => nomatch hx
  | _ :: _, hMap, _, hx => by
      simp only [List.map_cons] at hMap
      injection hMap with hHead hTail
      rcases List.mem_cons.mp hx with rfl | hRest
      · exact hHead
      · exact map_eq_imp_forall_mem_eq_b2 hTail _ hRest

private theorem list_all_congr_b2 {α : Type} {f g : α → Bool} :
    ∀ (L : List α), (∀ x ∈ L, f x = g x) → L.all f = L.all g
  | [],     _ => rfl
  | a :: as, h => by
      simp only [List.all_cons]
      rw [h a (List.mem_cons_self ..),
          list_all_congr_b2 as (fun x hx => h x (List.mem_cons_of_mem a hx))]

private theorem checkExactG7SequentBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (nid : String) (domTag : G7DomTag) (specId : String)
    (guards : List StrictForm) (conclusion : StrictForm)
    (hEq : verifyReachableDerivation fuel Γ1 C1 nid = verifyReachableDerivation fuel Γ2 C2 nid) :
    checkExactG7SequentBool fuel Γ1 C1 nid domTag specId guards conclusion =
    checkExactG7SequentBool fuel Γ2 C2 nid domTag specId guards conclusion := by
  unfold checkExactG7SequentBool
  rw [hEq]

private theorem checkGuardEntailmentListBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} {roots : List String}
    (domSrc : G7DomTag) (specId : String) (guardsSrc targetGuards : List StrictForm)
    (pairs : List (StrictForm × String))
    (hRootEq : ∀ r ∈ roots,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r)
    (hSub : ∀ nid ∈ pairs.map Prod.snd, nid ∈ roots) :
    checkGuardEntailmentListBool fuel Γ1 C1 domSrc specId guardsSrc targetGuards pairs =
    checkGuardEntailmentListBool fuel Γ2 C2 domSrc specId guardsSrc targetGuards pairs := by
  unfold checkGuardEntailmentListBool
  congr 1
  apply list_all_congr_b2
  intro gn hMem
  exact checkExactG7SequentBool_congr_b2 fuel gn.2 domSrc specId guardsSrc gn.1
    (hRootEq gn.2 (hSub gn.2 (List.mem_map_of_mem hMem)))

private theorem bool_and_congr_b2 {a1 a2 b1 b2 : Bool} (ha : a1 = a2) (hb : b1 = b2) :
    (a1 && b1) = (a2 && b2) := by
  rw [ha, hb]

private theorem checkSameEffDomCoreBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} {roots : List String}
    (D_old : G7DomTag) (Γ_old : List StrictForm) (D_new : G7DomTag) (Γ_new : List StrictForm)
    (specNewId : String) (step : BaseDomEquivStep) (oldDefNid? : Option String)
    (oldToNew newToOld : List (StrictForm × String))
    (hRootEq : ∀ r ∈ roots,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r)
    (hStep : ∀ nid ∈ (match step with
                      | .sameBaseDom _        => []
                      | .qGuardNzToNonzero id => [id]
                      | .nonzeroToQGuardNz id => [id]), nid ∈ roots)
    (hDef  : ∀ nid ∈ oldDefNid?.toList, nid ∈ roots)
    (hO2N  : ∀ nid ∈ oldToNew.map Prod.snd, nid ∈ roots)
    (hN2O  : ∀ nid ∈ newToOld.map Prod.snd, nid ∈ roots) :
    checkSameEffDomCoreBool fuel Γ1 C1 D_old Γ_old D_new Γ_new specNewId step oldDefNid? oldToNew newToOld =
    checkSameEffDomCoreBool fuel Γ2 C2 D_old Γ_old D_new Γ_new specNewId step oldDefNid? oldToNew newToOld := by
  revert hStep hDef
  have hBaseAux :
      (∀ nid ∈ (match step with
                | .sameBaseDom _        => []
                | .qGuardNzToNonzero id => [id]
                | .nonzeroToQGuardNz id => [id]), nid ∈ roots) →
      (match step with
       | .sameBaseDom D => (D_old == D) && (D_new == D)
       | .qGuardNzToNonzero nzNid =>
           (D_old == G7DomTag.domQ) && (D_new == G7DomTag.domQNonzero) &&
           checkExactG7SequentBool fuel Γ1 C1 nzNid G7DomTag.domQ specNewId Γ_old (.neqZero .varX)
       | .nonzeroToQGuardNz nzNid =>
           (D_old == G7DomTag.domQNonzero) && (D_new == G7DomTag.domQ) &&
           checkExactG7SequentBool fuel Γ1 C1 nzNid G7DomTag.domQ specNewId Γ_new (.neqZero .varX)) =
      (match step with
       | .sameBaseDom D => (D_old == D) && (D_new == D)
       | .qGuardNzToNonzero nzNid =>
           (D_old == G7DomTag.domQ) && (D_new == G7DomTag.domQNonzero) &&
           checkExactG7SequentBool fuel Γ2 C2 nzNid G7DomTag.domQ specNewId Γ_old (.neqZero .varX)
       | .nonzeroToQGuardNz nzNid =>
           (D_old == G7DomTag.domQNonzero) && (D_new == G7DomTag.domQ) &&
           checkExactG7SequentBool fuel Γ2 C2 nzNid G7DomTag.domQ specNewId Γ_new (.neqZero .varX)) := by
    cases step with
    | sameBaseDom _ => intro _; rfl
    | qGuardNzToNonzero nzNid =>
        intro hs
        dsimp only at hs ⊢
        rw [checkExactG7SequentBool_congr_b2 fuel nzNid G7DomTag.domQ specNewId Γ_old (.neqZero .varX)
              (hRootEq nzNid (hs nzNid (List.mem_cons_self ..)))]
    | nonzeroToQGuardNz nzNid =>
        intro hs
        dsimp only at hs ⊢
        rw [checkExactG7SequentBool_congr_b2 fuel nzNid G7DomTag.domQ specNewId Γ_new (.neqZero .varX)
              (hRootEq nzNid (hs nzNid (List.mem_cons_self ..)))]
  have hDefAux :
      (∀ nid ∈ oldDefNid?.toList, nid ∈ roots) →
      (if Γ_old.isEmpty then oldDefNid?.isNone
       else match oldDefNid? with
         | none => false
         | some did => checkExactG7SequentBool fuel Γ1 C1 did D_old specNewId Γ_old (.eqZero (.const 0))) =
      (if Γ_old.isEmpty then oldDefNid?.isNone
       else match oldDefNid? with
         | none => false
         | some did => checkExactG7SequentBool fuel Γ2 C2 did D_old specNewId Γ_old (.eqZero (.const 0))) := by
    by_cases hEmp : Γ_old.isEmpty = true
    · intro _; rw [if_pos hEmp, if_pos hEmp]
    · rw [if_neg hEmp, if_neg hEmp]
      cases oldDefNid? with
      | none => intro _; rfl
      | some did =>
          intro hd
          dsimp [Option.toList] at hd ⊢
          exact checkExactG7SequentBool_congr_b2 fuel did D_old specNewId Γ_old (.eqZero (.const 0))
            (hRootEq did (hd did (List.mem_cons_self ..)))
  intro hStep hDef
  unfold checkSameEffDomCoreBool
  dsimp only
  by_cases hSame : ((D_old == D_new) && (Γ_old == Γ_new)) = true
  · rw [if_pos hSame, if_pos hSame]
    exact bool_and_congr_b2 (bool_and_congr_b2 (bool_and_congr_b2 (hBaseAux hStep) rfl) rfl) rfl
  · rw [if_neg hSame, if_neg hSame]
    exact bool_and_congr_b2
      (bool_and_congr_b2 (bool_and_congr_b2 (hBaseAux hStep) (hDefAux hDef))
        (checkGuardEntailmentListBool_congr_b2 fuel D_old specNewId Γ_old Γ_new oldToNew hRootEq hO2N))
      (checkGuardEntailmentListBool_congr_b2 fuel D_new specNewId Γ_new Γ_old newToOld hRootEq hN2O)

private theorem checkExcisedReexprBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} {roots : List String}
    (D_old : G7DomTag) (Γ_old : List StrictForm) (D_new : G7DomTag) (Γ_new : List StrictForm)
    (specNewId : String) (B_canon excisedBranches : ExcisedLocus) (rx : ExcisedReexprCert)
    (hRootEq : ∀ r ∈ roots,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r)
    (hDJ  : ∀ nid ∈ rx.branchDefAndDisjNodes.foldr (fun (_, dId, jId) acc => dId :: jId :: acc) [],
              nid ∈ roots)
    (hCov : ∀ nid ∈ rx.canonCoverWitnesses.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) [],
              nid ∈ roots) :
    checkExcisedReexprBool fuel Γ1 C1 D_old Γ_old D_new Γ_new specNewId B_canon excisedBranches rx =
    checkExcisedReexprBool fuel Γ2 C2 D_old Γ_old D_new Γ_new specNewId B_canon excisedBranches rx := by
  unfold checkExcisedReexprBool
  have h1 : rx.branchDefAndDisjNodes.all (fun (E_i, defNid, disjNid) =>
      checkExactG7SequentBool fuel Γ1 C1 defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0)) &&
      checkExactG7SequentBool fuel Γ1 C1 disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))) =
    rx.branchDefAndDisjNodes.all (fun (E_i, defNid, disjNid) =>
      checkExactG7SequentBool fuel Γ2 C2 defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0)) &&
      checkExactG7SequentBool fuel Γ2 C2 disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))) := by
    apply list_all_congr_b2
    rintro ⟨E_i, defNid, disjNid⟩ hMem
    rcases mem_foldr_pair_ids_b2 rx.branchDefAndDisjNodes hMem with ⟨hd, hj⟩
    dsimp only
    rw [checkExactG7SequentBool_congr_b2 fuel defNid D_old specNewId (Γ_old ++ E_i) (.eqZero (.const 0))
          (hRootEq defNid (hDJ defNid hd)),
        checkExactG7SequentBool_congr_b2 fuel disjNid D_new specNewId (Γ_new ++ E_i) (.pos (.const 0))
          (hRootEq disjNid (hDJ disjNid hj))]
  have h2 : rx.canonCoverWitnesses.all (fun (B_j, E_target, psiNodes) =>
      excisedBranches.contains E_target &&
      checkGuardEntailmentListBool fuel Γ1 C1 D_old specNewId B_j E_target psiNodes) =
    rx.canonCoverWitnesses.all (fun (B_j, E_target, psiNodes) =>
      excisedBranches.contains E_target &&
      checkGuardEntailmentListBool fuel Γ2 C2 D_old specNewId B_j E_target psiNodes) := by
    apply list_all_congr_b2
    rintro ⟨B_j, E_target, psiNodes⟩ hMem
    dsimp only
    rw [checkGuardEntailmentListBool_congr_b2 fuel D_old specNewId B_j E_target psiNodes hRootEq
      (fun nid hn => hCov nid (mem_foldr_cover_ids_b2 rx.canonCoverWitnesses hMem hn))]
  rw [h1, h2]

private theorem checkG6ScopeLossRecordBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} {roots : List String}
    (st : G6OldNewStateBinding) (lr : G6ScopeLossRecord)
    (hRootEq : ∀ r ∈ roots,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r)
    (hSub : ∀ nid ∈ rawScopeLossRootIds (some lr), nid ∈ roots) :
    checkG6ScopeLossRecordBool fuel Γ1 C1 st lr =
    checkG6ScopeLossRecordBool fuel Γ2 C2 st lr := by
  unfold checkG6ScopeLossRecordBool
  have hPreEq :
      checkExactG7SequentBool fuel Γ1 C1 lr.prefixDefNodeId st.domNew st.specNewId
        (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0)) =
      checkExactG7SequentBool fuel Γ2 C2 lr.prefixDefNodeId st.domNew st.specNewId
        (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0)) :=
    checkExactG7SequentBool_congr_b2 fuel lr.prefixDefNodeId st.domNew st.specNewId
      (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0))
      (hRootEq lr.prefixDefNodeId (hSub lr.prefixDefNodeId (lossPrefix_mem_raw lr)))
  have hConnEq :
      (match lr.guardConn with
       | .syntacticConcat => st.guardsNew == st.guardsOld ++ lr.deltaGuards
       | .mutualImplication d2n n2d =>
           checkGuardEntailmentListBool fuel Γ1 C1 st.domNew st.specNewId
             (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n &&
           checkGuardEntailmentListBool fuel Γ1 C1 st.domNew st.specNewId
             st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d) =
      (match lr.guardConn with
       | .syntacticConcat => st.guardsNew == st.guardsOld ++ lr.deltaGuards
       | .mutualImplication d2n n2d =>
           checkGuardEntailmentListBool fuel Γ2 C2 st.domNew st.specNewId
             (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n &&
           checkGuardEntailmentListBool fuel Γ2 C2 st.domNew st.specNewId
             st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d) := by
    cases hGc : lr.guardConn with
    | syntacticConcat => rfl
    | mutualImplication d2n n2d =>
        dsimp only
        rw [checkGuardEntailmentListBool_congr_b2 fuel st.domNew st.specNewId
              (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n hRootEq
              (fun nid hn => hSub nid (lossD2N_mem_raw lr hGc hn)),
            checkGuardEntailmentListBool_congr_b2 fuel st.domNew st.specNewId
              st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d hRootEq
              (fun nid hn => hSub nid (lossN2D_mem_raw lr hGc hn))]
  have hRxEq :
      (match lr.reexprCert? with
       | none => lr.excisedBranches ==
           buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards
       | some rx =>
           checkExcisedReexprBool fuel Γ1 C1 st.domOld st.guardsOld st.domNew st.guardsNew
             st.specNewId (buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards)
             lr.excisedBranches rx) =
      (match lr.reexprCert? with
       | none => lr.excisedBranches ==
           buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards
       | some rx =>
           checkExcisedReexprBool fuel Γ2 C2 st.domOld st.guardsOld st.domNew st.guardsNew
             st.specNewId (buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards)
             lr.excisedBranches rx) := by
    cases hR : lr.reexprCert? with
    | none => rfl
    | some rx =>
        dsimp only
        exact checkExcisedReexprBool_congr_b2 fuel st.domOld st.guardsOld st.domNew st.guardsNew
          st.specNewId _ lr.excisedBranches rx hRootEq
          (fun nid hn => hSub nid (lossDJ_mem_raw lr hR hn))
          (fun nid hn => hSub nid (lossCov_mem_raw lr hR hn))
  let gc1 : Bool :=
    match lr.guardConn with
    | .syntacticConcat => st.guardsNew == st.guardsOld ++ lr.deltaGuards
    | .mutualImplication d2n n2d =>
        checkGuardEntailmentListBool fuel Γ1 C1 st.domNew st.specNewId
          (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n &&
        checkGuardEntailmentListBool fuel Γ1 C1 st.domNew st.specNewId
          st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d
  let gc2 : Bool :=
    match lr.guardConn with
    | .syntacticConcat => st.guardsNew == st.guardsOld ++ lr.deltaGuards
    | .mutualImplication d2n n2d =>
        checkGuardEntailmentListBool fuel Γ2 C2 st.domNew st.specNewId
          (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n &&
        checkGuardEntailmentListBool fuel Γ2 C2 st.domNew st.specNewId
          st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d
  let rx1 : Bool :=
    match lr.reexprCert? with
    | none => lr.excisedBranches ==
        buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards
    | some rx =>
        checkExcisedReexprBool fuel Γ1 C1 st.domOld st.guardsOld st.domNew st.guardsNew
          st.specNewId (buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards)
          lr.excisedBranches rx
  let rx2 : Bool :=
    match lr.reexprCert? with
    | none => lr.excisedBranches ==
        buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards
    | some rx =>
        checkExcisedReexprBool fuel Γ2 C2 st.domOld st.guardsOld st.domNew st.guardsNew
          st.specNewId (buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards)
          lr.excisedBranches rx
  change (checkBaseDomRetreatStepBool lr.baseStep st.domOld st.domNew &&
          lr.deltaGuards.all isAtomicStrictFormBool &&
          checkExactG7SequentBool fuel Γ1 C1 lr.prefixDefNodeId st.domNew st.specNewId
            (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0)) &&
          gc1 && rx1 &&
          checkInEffDomRatCoordBool fuel st.domOld st.guardsOld lr.strictLossWitness &&
          checkModelsExcisedRatCoordBool fuel lr.excisedBranches lr.strictLossWitness &&
          lr.claimedRetentionAnchors.all (checkInEffDomRatCoordBool fuel st.domNew st.guardsNew)) =
         (checkBaseDomRetreatStepBool lr.baseStep st.domOld st.domNew &&
          lr.deltaGuards.all isAtomicStrictFormBool &&
          checkExactG7SequentBool fuel Γ2 C2 lr.prefixDefNodeId st.domNew st.specNewId
            (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0)) &&
          gc2 && rx2 &&
          checkInEffDomRatCoordBool fuel st.domOld st.guardsOld lr.strictLossWitness &&
          checkModelsExcisedRatCoordBool fuel lr.excisedBranches lr.strictLossWitness &&
          lr.claimedRetentionAnchors.all (checkInEffDomRatCoordBool fuel st.domNew st.guardsNew))
  change gc1 = gc2 at hConnEq
  change rx1 = rx2 at hRxEq
  rw [hPreEq, hConnEq, hRxEq]

private theorem checkG6ItemScopeBool_congr_b2 (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (item : G6ProtectedInvariantSpec)
    (hRootEq : ∀ r ∈ collectItemG6ProofRootIds item,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r) :
    checkG6ItemScopeBool fuel Γ1 C1 item = checkG6ItemScopeBool fuel Γ2 C2 item := by
  unfold checkG6ItemScopeBool
  dsimp only
  congr 1
  · split
    · rfl
    · cases hNd : item.oldNewState.newGuardsDefNodeId? with
      | none => rfl
      | some ndid =>
          exact checkExactG7SequentBool_congr_b2 fuel ndid item.oldNewState.domNew
            item.oldNewState.specNewId item.oldNewState.guardsNew (.eqZero (.const 0))
            (hRootEq ndid (newGuardsDef_mem_itemRoots item
              (by rw [hNd]; exact List.mem_cons_self ..)))
  · cases hPol : item.oldNewState.scopePolicy with
    | globalPostSameDom r =>
        cases hLoss : item.scopeLossRecord? with
        | some _ => rfl
        | none =>
            dsimp only
            congr 1
            exact checkSameEffDomCoreBool_congr_b2 fuel item.oldNewState.domOld
              item.oldNewState.guardsOld item.oldNewState.domNew item.oldNewState.guardsNew
              item.oldNewState.specNewId r.baseEquivStep r.oldGuardsDefNodeId?
              r.oldEntailsNewGuardNodes r.newEntailsOldGuardNodes hRootEq
              (fun nid hn => scopePol_mem_itemRoots item (by
                rw [hPol]; dsimp [rawScopePolicyRootIds]
                exact List.mem_append_left _ (List.mem_append_left _
                  (List.mem_append_left _ (List.mem_append_left _ hn)))))
              (fun nid hn => scopePol_mem_itemRoots item (by
                rw [hPol]; dsimp [rawScopePolicyRootIds]
                exact List.mem_append_left _ (List.mem_append_left _
                  (List.mem_append_left _ (List.mem_append_right _ hn)))))
              (fun nid hn => scopePol_mem_itemRoots item (by
                rw [hPol]; dsimp [rawScopePolicyRootIds]
                exact List.mem_append_left _ (List.mem_append_left _
                  (List.mem_append_right _ hn))))
              (fun nid hn => scopePol_mem_itemRoots item (by
                rw [hPol]; dsimp [rawScopePolicyRootIds]
                exact List.mem_append_left _ (List.mem_append_right _ hn)))
    | oldScopeInclusion step oldDef? o2n n2o scopeExp expWit? =>
        cases hLoss : item.scopeLossRecord? with
        | some _ => rfl
        | none =>
            dsimp only
            congr 1
            · congr 1
              split
              · rfl
              · exact checkGuardEntailmentListBool_congr_b2 fuel item.oldNewState.domOld
                  item.oldNewState.specNewId item.oldNewState.guardsOld
                  item.oldNewState.guardsNew o2n hRootEq
                  (fun nid hn => scopePol_mem_itemRoots item (by
                    rw [hPol]; dsimp [rawScopePolicyRootIds]
                    exact List.mem_append_left _ (List.mem_append_right _ hn)))
            · cases scopeExp with
              | true => rfl
              | false =>
                  simp only [Bool.false_eq_true, ite_false]
                  congr 1
                  cases step with
                  | sameBaseDom D =>
                      dsimp only
                      exact checkSameEffDomCoreBool_congr_b2 fuel item.oldNewState.domOld
                        item.oldNewState.guardsOld item.oldNewState.domNew
                        item.oldNewState.guardsNew item.oldNewState.specNewId (.sameBaseDom D)
                        oldDef?
                        (if item.oldNewState.guardsNew == item.oldNewState.guardsOld then [] else o2n)
                        n2o hRootEq
                        (fun _ h => nomatch h)
                        (fun nid hn => scopePol_mem_itemRoots item (by
                          rw [hPol]; dsimp [rawScopePolicyRootIds]
                          exact List.mem_append_left _ (List.mem_append_left _ hn)))
                        (fun nid hn => scopePol_mem_itemRoots item (by
                          rw [hPol]; dsimp [rawScopePolicyRootIds]
                          by_cases hg : (item.oldNewState.guardsNew == item.oldNewState.guardsOld) = true
                          · rw [if_pos hg] at hn; nomatch hn
                          · rw [if_neg hg] at hn
                            exact List.mem_append_left _ (List.mem_append_right _ hn)))
                        (fun nid hn => scopePol_mem_itemRoots item (by
                          rw [hPol]; dsimp [rawScopePolicyRootIds]
                          exact List.mem_append_right _ hn))
                  | _ => rfl
    | retreatWithLossAccounting =>
        cases hLoss : item.scopeLossRecord? with
        | none => rfl
        | some lr =>
            dsimp only
            exact checkG6ScopeLossRecordBool_congr_b2 fuel item.oldNewState lr hRootEq
              (fun nid hn => scopeLoss_mem_itemRoots item (by rw [hLoss]; exact hn))

private theorem evalSingleG6Item_congr_on_roots (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (evalEpoch : Nat) (item : G6ProtectedInvariantSpec)
    (hRootEq : ∀ r ∈ collectItemG6ProofRootIds item,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r) :
    evalSingleG6Item fuel Γ1 C1 evalEpoch item =
    evalSingleG6Item fuel Γ2 C2 evalEpoch item := by
  unfold evalSingleG6Item
  dsimp only
  split
  · rfl
  · split
    · rfl
    · split
      · rfl
      · have hOldBaseEq :
            (match item.oldNewState.oldBaselineProofNodeId? with
             | none => true
             | some oldNid =>
                 checkExactG7SequentBool fuel Γ1 C1 oldNid item.oldNewState.domOld
                   item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst) =
            (match item.oldNewState.oldBaselineProofNodeId? with
             | none => true
             | some oldNid =>
                 checkExactG7SequentBool fuel Γ2 C2 oldNid item.oldNewState.domOld
                   item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst) := by
          cases hOpt : item.oldNewState.oldBaselineProofNodeId? with
          | none => rfl
          | some oldNid =>
              exact checkExactG7SequentBool_congr_b2 fuel oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst
                (hRootEq oldNid (oldBase_mem_itemRoots item
                  (by rw [hOpt]; exact List.mem_cons_self ..)))
        have hScopeEq := checkG6ItemScopeBool_congr_b2 fuel item hRootEq
        have hBodyEq : evalSingleG6ItemBody fuel Γ1 C1 item =
            evalSingleG6ItemBody fuel Γ2 C2 item := by
          unfold evalSingleG6ItemBody
          dsimp only
          cases hEv : item.evidenceRoots.itemEvidence with
          | claimUnresolved _ => rfl
          | claimVerified rootNid =>
              dsimp only
              rw [checkExactG7SequentBool_congr_b2 fuel rootNid item.oldNewState.domNew
                    item.oldNewState.specNewId item.oldNewState.guardsNew
                    item.oldNewState.formNewInst
                    (hRootEq rootNid (itemEv_mem_itemRoots item
                      (by rw [hEv]; exact List.mem_cons_self ..)))]
          | claimViolated refc =>
              cases refc with
              | counterexamplePoint _ => rfl
              | derivedRefutationNode refutNid _ =>
                  dsimp only
                  rw [checkExactG7SequentBool_congr_b2 fuel refutNid item.oldNewState.domNew
                        item.oldNewState.specNewId item.oldNewState.guardsNew
                        (atomicComplement item.oldNewState.formNewInst)
                        (hRootEq refutNid (itemEv_mem_itemRoots item
                          (by rw [hEv]; exact List.mem_cons_self ..)))]
        let oldB1 :=
          match item.oldNewState.oldBaselineProofNodeId? with
          | none => true
          | some oldNid =>
              checkExactG7SequentBool fuel Γ1 C1 oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst
        let oldB2 :=
          match item.oldNewState.oldBaselineProofNodeId? with
          | none => true
          | some oldNid =>
              checkExactG7SequentBool fuel Γ2 C2 oldNid item.oldNewState.domOld
                item.oldNewState.specOldId item.oldNewState.guardsOld item.oldNewState.formOldInst
        change (if !oldB1 then _ else if !checkG6ItemScopeBool fuel Γ1 C1 item then _
                else evalSingleG6ItemBody fuel Γ1 C1 item) =
               (if !oldB2 then _ else if !checkG6ItemScopeBool fuel Γ2 C2 item then _
                else evalSingleG6ItemBody fuel Γ2 C2 item)
        change oldB1 = oldB2 at hOldBaseEq
        rw [hOldBaseEq, hScopeEq, hBodyEq]

private theorem evalG6ItemsList_congr_on_roots (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (evalEpoch : Nat) :
    ∀ (items : List G6ProtectedInvariantSpec),
      (∀ it ∈ items, ∀ r ∈ collectItemG6ProofRootIds it,
        verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r) →
      evalG6ItemsList fuel Γ1 C1 evalEpoch items =
      evalG6ItemsList fuel Γ2 C2 evalEpoch items
  | [], _ => rfl
  | it :: rest, hEq => by
      unfold evalG6ItemsList
      rw [evalSingleG6Item_congr_on_roots fuel evalEpoch it
            (fun r hr => hEq it (List.mem_cons_self ..) r hr),
          evalG6ItemsList_congr_on_roots fuel evalEpoch rest
            (fun x hx r hr => hEq x (List.mem_cons_of_mem it hx) r hr)]

theorem evalG6SuiteCore_congr_on_roots (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (suite : G6ProtectedSuite)
    (hRootEq : ∀ r ∈ collectG6ProofRootIds suite,
      verifyReachableDerivation fuel Γ1 C1 r = verifyReachableDerivation fuel Γ2 C2 r) :
    evalG6SuiteCore fuel Γ1 C1 suite = evalG6SuiteCore fuel Γ2 C2 suite := by
  unfold evalG6SuiteCore
  cases hIt : suite.items with
  | nil => rfl
  | cons it0 rest =>
      dsimp only
      rw [evalG6ItemsList_congr_on_roots fuel suite.evaluationEpoch (it0 :: rest)
        (fun x hx r hr => hRootEq r (itemRoot_mem_suiteRoots (by rw [hIt]; exact hx) hr))]

/-- Permanent append-only retraction monotonicity of `retractedPremises` in `P1B1` ledger. -/
private theorem retractedPremises_append_mono (p : String) :
    ∀ (ΔL : List StructuralLedgerEvent) (st : StructuralLedgerState),
      p ∈ st.epistemic.retractedPremises →
      p ∈ (ΔL.foldl stepStructuralLedger st).epistemic.retractedPremises
  | [], st, hp => hp
  | ev :: rest, st, hp => by
      dsimp only [List.foldl]
      apply retractedPremises_append_mono p rest
      cases ev with
      | recordStructuralReflex _ => exact hp
      | retractPremise q =>
          dsimp [stepStructuralLedger, stepEpistemicState]
          exact List.mem_append_left _ hp
      | advanceEpoch _ => exact hp
      | issueGrantHeld _ => exact hp
      | revokeGrantHeld _ => exact hp

/-- **`Gate A7.0` (`T_B2_A7_0_PrimDepsEquation_And_PermanentRetraction`)**:
    (1) Every non-invalid `checkG6Suite` evaluation enforces `claimedPrimDeps == deriveG6PrimDeps`;
    (2) Retracting ANY premise in `claimedPrimDeps` permanently deactivates `checkActiveG6SuiteBool`
        across both `L` and any future append-only extension `L ++ ΔL`. -/
theorem T_B2_A7_0_PrimDepsEquation_And_PermanentRetraction
    (fuel : Nat) (suite : G6ProtectedSuite) :
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer),
      (∀ r, checkG6Suite fuel Γ C suite ≠ .invalid r) →
      suite.claimedPrimDeps.primDepIds = deriveG6PrimDeps Γ C suite) ∧
    (∀ (L ΔL : List StructuralLedgerEvent) (Γ : PrimPremiseEnv) (C : G7DagContainer) (pRet : String),
      pRet ∈ suite.claimedPrimDeps.primDepIds →
      pRet ∈ (foldStructuralLedger L).epistemic.retractedPremises →
      checkActiveG6SuiteBool L fuel Γ C suite = false ∧
      checkActiveG6SuiteBool (L ++ ΔL) fuel Γ C suite = false) := by
  refine ⟨fun _ _ hNotInv => (unpack_nonInvalid_checkG6Suite hNotInv).2.2.2.1, ?_⟩
  intro L ΔL Γ C pRet hpDep hpRet
  have hDeact : ∀ L' : List StructuralLedgerEvent,
      pRet ∈ (foldStructuralLedger L').epistemic.retractedPremises →
      checkActiveG6SuiteBool L' fuel Γ C suite = false := by
    intro L' hpIn
    unfold checkActiveG6SuiteBool
    dsimp only
    have hCont : (foldStructuralLedger L').epistemic.retractedPremises.contains pRet = true :=
      List.contains_iff_mem.mpr hpIn
    have hAllF : (suite.claimedPrimDeps.primDepIds.all
        (fun p => !(foldStructuralLedger L').epistemic.retractedPremises.contains p)) = false := by
      cases ha : suite.claimedPrimDeps.primDepIds.all
          (fun p => !(foldStructuralLedger L').epistemic.retractedPremises.contains p) with
      | false => rfl
      | true =>
          have hOk := List.all_eq_true.mp ha pRet hpDep
          rw [hCont] at hOk; nomatch hOk
    rw [hAllF]
    simp
  have hpFuture : pRet ∈ (foldStructuralLedger (L ++ ΔL)).epistemic.retractedPremises := by
    unfold foldStructuralLedger at hpRet ⊢
    rw [List.foldl_append]
    exact retractedPremises_append_mono pRet ΔL _ hpRet
  exact ⟨hDeact L hpRet, hDeact (L ++ ΔL) hpFuture⟩

/-- **`Gate A7.1` (`T_B2_A7_1_OutputCongruence` — `F-B2-T11-04` #1)**:
    Two-environment output congruence for BOTH `evalG6SuiteCore` and top-level `checkG6Suite`. -/
theorem T_B2_A7_1_OutputCongruence (fuel : Nat) (suite : G6ProtectedSuite) :
    (∀ (Γ1 Γ2 : PrimPremiseEnv) (C1 C2 : G7DagContainer),
      ValidContainer C1 →
      (∀ nid ∈ multiRootReachableNodes C1 (collectG6ProofRootIds suite),
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      (∀ pid ∈ deriveG6PrimDeps Γ1 C1 suite,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      evalG6SuiteCore fuel Γ1 C1 suite = evalG6SuiteCore fuel Γ2 C2 suite) ∧
    (∀ (Γ1 Γ2 : PrimPremiseEnv) (C1 C2 : G7DagContainer),
      checkPrimEnvIntegrityBool Γ1 = checkPrimEnvIntegrityBool Γ2 →
      ValidContainer C1 →
      ValidContainer C2 →
      deriveG6PrimDeps Γ1 C1 suite = deriveG6PrimDeps Γ2 C2 suite →
      (∀ nid ∈ multiRootReachableNodes C1 (collectG6ProofRootIds suite),
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      (∀ pid ∈ deriveG6PrimDeps Γ1 C1 suite,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      checkG6Suite fuel Γ1 C1 suite = checkG6Suite fuel Γ2 C2 suite) := by
  refine ⟨?_, ?_⟩
  · intro Γ1 Γ2 C1 C2 hVal1 hNodeEq hPrimEq
    have hMapEq := A0_05_1_OutputCongruence fuel (collectG6ProofRootIds suite) hVal1 hNodeEq hPrimEq
    exact evalG6SuiteCore_congr_on_roots fuel suite
      (map_eq_imp_forall_mem_eq_b2 hMapEq)
  · intro Γ1 Γ2 C1 C2 hEnvEq hVal1 hVal2 hDepsEq hNodeEq hPrimEq
    unfold checkG6Suite
    have hC1 : checkContainerIntegrityBool C1 = true := hVal1
    have hC2 : checkContainerIntegrityBool C2 = true := hVal2
    rw [hEnvEq, hC1, hC2, hDepsEq]
    split
    · rfl
    · split
      · rfl
      · have hMapEq := A0_05_1_OutputCongruence fuel (collectG6ProofRootIds suite)
          hVal1 hNodeEq hPrimEq
        exact evalG6SuiteCore_congr_on_roots fuel suite
          (map_eq_imp_forall_mem_eq_b2 hMapEq)

/-- **`Gate A7.2` (`T_B2_A7_2_RestrictionInvariance` — `F-B2-T11-04` #2)**:
    Cutting `(Γ, C)` to `(restrictPrimEnv Γ Deps_G6, restrictContainer C R*_G6)` preserves
    `evalG6SuiteCore` identically (proving `collectG6ProofRootIds` omits zero decision-relevant roots). -/
theorem T_B2_A7_2_RestrictionInvariance
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite)
    (hVal : ValidContainer C) :
    let RStar := multiRootReachableNodes C (collectG6ProofRootIds suite)
    let PStar := deriveG6PrimDeps Γ C suite
    evalG6SuiteCore fuel (restrictPrimEnv Γ PStar) (restrictContainer C RStar) suite =
    evalG6SuiteCore fuel Γ C suite := by
  dsimp only
  have hRestr := (A0_05_3_RestrictionInvariance fuel Γ C (collectG6ProofRootIds suite) hVal).2
  exact evalG6SuiteCore_congr_on_roots fuel suite
    (map_eq_imp_forall_mem_eq_b2 hRestr)

/-- **`Gate A7.3` (`T_B2_A7_3_ActualLookupConfinement` — `F-B2-T11-04` #3, Kept Independent)**:
    Under `ValidContainer C`, every node ID and primitive premise ID queried during instrumented
    execution `verifyMultiRootTraced` over `collectG6ProofRootIds suite` lies strictly inside
    `(R*_G6, Deps_G6)` (kept separate from `OutputCongruence` per `A0_05_2b`). -/
theorem T_B2_A7_3_ActualLookupConfinement
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite)
    (hVal : ValidContainer C) :
    LogConfinedTo
      (multiRootReachableNodes C (collectG6ProofRootIds suite))
      (deriveG6PrimDeps Γ C suite)
      (verifyMultiRootTraced fuel Γ C (collectG6ProofRootIds suite)).2 :=
  A0_05_2_ActualLookupConfinement fuel Γ C (collectG6ProofRootIds suite) hVal

-- Helper lemmas for `replacePrimFormulaInEnv` (`F-B2-T12-04`)
private theorem replacePrimFormula_map_premId (Γ : PrimPremiseEnv) (targetPid : String)
    (newFormula : StrictForm) :
    (replacePrimFormulaInEnv Γ targetPid newFormula).map (·.premId) = Γ.map (·.premId) := by
  induction Γ with
  | nil => rfl
  | cons e rest ih =>
      unfold replacePrimFormulaInEnv
      simp only [List.map_cons]
      have hHead : (if e.premId == targetPid then { e with formula := newFormula } else e).premId =
          e.premId := by
        split <;> rfl
      rw [hHead]
      exact congrArg (e.premId :: ·) ih

private theorem replacePrimFormula_toPremDag (Γ : PrimPremiseEnv) (targetPid : String)
    (newFormula : StrictForm) :
    toPremDag (replacePrimFormulaInEnv Γ targetPid newFormula) = toPremDag Γ := by
  induction Γ with
  | nil => rfl
  | cons e rest ih =>
      unfold toPremDag replacePrimFormulaInEnv
      simp only [List.map_cons]
      have hHead :
          (let x := if e.premId == targetPid then { e with formula := newFormula } else e
           (x.premId, x.parentPremIds)) = (e.premId, e.parentPremIds) := by
        split <;> rfl
      rw [hHead]
      exact congrArg ((e.premId, e.parentPremIds) :: ·) ih

private theorem lookupPrimPrem_isSome_replace (Γ : PrimPremiseEnv) (targetPid : String)
    (newFormula : StrictForm) (p : String) :
    (lookupPrimPrem? (replacePrimFormulaInEnv Γ targetPid newFormula) p).isSome =
    (lookupPrimPrem? Γ p).isSome := by
  induction Γ with
  | nil => rfl
  | cons e rest ih =>
      unfold lookupPrimPrem? replacePrimFormulaInEnv
      simp only [List.map_cons, List.find?]
      have hId : (if e.premId == targetPid then { e with formula := newFormula } else e).premId =
          e.premId := by split <;> rfl
      rw [hId]
      cases (e.premId == p) with
      | true  => rfl
      | false => exact ih

private theorem lookupPrimPrem_replace_of_ne (Γ : PrimPremiseEnv) {targetPid pid : String}
    (newFormula : StrictForm) (hNe : pid ≠ targetPid) :
    lookupPrimPrem? (replacePrimFormulaInEnv Γ targetPid newFormula) pid =
    lookupPrimPrem? Γ pid := by
  induction Γ with
  | nil => rfl
  | cons e rest ih =>
      unfold lookupPrimPrem? replacePrimFormulaInEnv
      simp only [List.map_cons, List.find?]
      have hId : (if e.premId == targetPid then { e with formula := newFormula } else e).premId =
          e.premId := by split <;> rfl
      rw [hId]
      by_cases hEq : (e.premId == pid) = true
      · rw [hEq]
        have heqPid : e.premId = pid := eq_of_beq hEq
        have hNotTarget : (e.premId == targetPid) = false := by
          cases ht : (e.premId == targetPid) with
          | false => rfl
          | true =>
              exfalso; apply hNe
              rw [← heqPid, eq_of_beq ht]
        rw [if_neg (by rw [hNotTarget]; decide)]
      · have hEqF : (e.premId == pid) = false := Bool.eq_false_iff.mpr hEq
        rw [hEqF]
        exact ih

private theorem checkPrimEnvIntegrityBool_replace (Γ : PrimPremiseEnv) (targetPid : String)
    (newFormula : StrictForm) :
    checkPrimEnvIntegrityBool (replacePrimFormulaInEnv Γ targetPid newFormula) =
    checkPrimEnvIntegrityBool Γ := by
  unfold checkPrimEnvIntegrityBool
  rw [replacePrimFormula_map_premId]
  congr 1
  have hAllAux : ∀ (L : List PrimPremiseEntry),
      (L.map (fun e => if e.premId == targetPid then { e with formula := newFormula } else e)).all
        (fun e =>
          e.premId != "" &&
          e.specId != "" &&
          isStrictCanonStrList e.parentPremIds &&
          e.parentPremIds.all (fun p =>
            (lookupPrimPrem? (replacePrimFormulaInEnv Γ targetPid newFormula) p).isSome)) =
      L.all (fun e =>
        e.premId != "" &&
        e.specId != "" &&
        isStrictCanonStrList e.parentPremIds &&
        e.parentPremIds.all (fun p => (lookupPrimPrem? Γ p).isSome)) := by
    intro L
    induction L with
    | nil => rfl
    | cons e rest ih =>
        simp only [List.map_cons, List.all_cons]
        rw [ih]
        congr 1
        have hFields :
            (let x := if e.premId == targetPid then { e with formula := newFormula } else e
             (x.premId, x.specId, x.parentPremIds)) =
            (e.premId, e.specId, e.parentPremIds) := by
          split <;> rfl
        have hp1 : (if e.premId == targetPid then { e with formula := newFormula } else e).premId =
            e.premId := congrArg Prod.fst hFields
        have hp2 : (if e.premId == targetPid then { e with formula := newFormula } else e).specId =
            e.specId := congrArg (fun t => t.2.1) hFields
        have hp3 : (if e.premId == targetPid then { e with formula := newFormula } else e).parentPremIds =
            e.parentPremIds := congrArg (fun t => t.2.2) hFields
        rw [hp1, hp2, hp3]
        congr 1
        apply list_all_congr_b2
        intro p _
        exact lookupPrimPrem_isSome_replace Γ targetPid newFormula p
  exact hAllAux Γ

/-- **`Gate A7.4` (`T_B2_A7_4_OutsidePremise_FullNonInterference` — `F-B2-T12-04` Complete Proof)**:
    Answers ALL FOUR `F-B2-T12-04` obligations simultaneously for ANY `pOut ∉ deriveG6PrimDeps Γ C suite`
    and ANY `newFormula : StrictForm` (`Γ' := replacePrimFormulaInEnv Γ pOut newFormula`):
    (1) `checkPrimEnvIntegrityBool Γ' = checkPrimEnvIntegrityBool Γ` (`ValidPrimEnv` preserved!),
    (2) `deriveG6PrimDeps Γ' C suite = deriveG6PrimDeps Γ C suite` (G6 transitive closure unchanged!),
    (3) `checkG6Suite fuel Γ' C suite = checkG6Suite fuel Γ C suite` (top-level checker invariant!),
    (4) `verifyMultiRootTraced fuel Γ' C (collectG6ProofRootIds suite) =
         verifyMultiRootTraced fuel Γ C (collectG6ProofRootIds suite)` (traced results & log identical!). -/
theorem T_B2_A7_4_OutsidePremise_FullNonInterference
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite)
    (hCont : ValidContainer C)
    (pOut : String) (hpNotInG6 : pOut ∉ deriveG6PrimDeps Γ C suite)
    (newFormula : StrictForm) :
    let Γ' := replacePrimFormulaInEnv Γ pOut newFormula
    checkPrimEnvIntegrityBool Γ' = checkPrimEnvIntegrityBool Γ ∧
    deriveG6PrimDeps Γ' C suite = deriveG6PrimDeps Γ C suite ∧
    checkG6Suite fuel Γ' C suite = checkG6Suite fuel Γ C suite ∧
    verifyMultiRootTraced fuel Γ' C (collectG6ProofRootIds suite) =
      verifyMultiRootTraced fuel Γ C (collectG6ProofRootIds suite) := by
  dsimp only
  let Γ' := replacePrimFormulaInEnv Γ pOut newFormula
  have hIntEq : checkPrimEnvIntegrityBool Γ' = checkPrimEnvIntegrityBool Γ :=
    checkPrimEnvIntegrityBool_replace Γ pOut newFormula
  have hDepsEq : deriveG6PrimDeps Γ' C suite = deriveG6PrimDeps Γ C suite := by
    unfold deriveG6PrimDeps multiRootTransitivePrimDeps
    have hFoldEq : ∀ rs : List String,
        rs.foldr (fun r acc => extractTransitivePrimDeps Γ' C r ++ acc) [] =
        rs.foldr (fun r acc => extractTransitivePrimDeps Γ C r ++ acc) [] := by
      intro rs
      induction rs with
      | nil => rfl
      | cons r tail ih =>
          dsimp only [List.foldr]
          have hSingle : extractTransitivePrimDeps Γ' C r = extractTransitivePrimDeps Γ C r := by
            unfold extractTransitivePrimDeps
            rw [replacePrimFormula_toPremDag]
          rw [hSingle, ih]
    rw [hFoldEq]
  have hPrimAgree : ∀ pid ∈ deriveG6PrimDeps Γ' C suite,
      lookupPrimPrem? Γ' pid = lookupPrimPrem? Γ pid := by
    intro pid hp
    rw [hDepsEq] at hp
    have hNe : pid ≠ pOut := fun hEq => hpNotInG6 (hEq ▸ hp)
    exact lookupPrimPrem_replace_of_ne Γ newFormula hNe
  have hSuiteEq : checkG6Suite fuel Γ' C suite = checkG6Suite fuel Γ C suite :=
    (T_B2_A7_1_OutputCongruence fuel suite).2 Γ' Γ C C hIntEq hCont hCont hDepsEq
      (fun _ _ => rfl) hPrimAgree
  have hTraceEq : verifyMultiRootTraced fuel Γ' C (collectG6ProofRootIds suite) =
      verifyMultiRootTraced fuel Γ C (collectG6ProofRootIds suite) :=
    verifyMultiRootTraced_congr fuel (collectG6ProofRootIds suite) hCont
      (fun _ _ => rfl) hPrimAgree
  exact ⟨hIntEq, hDepsEq, hSuiteEq, hTraceEq⟩

/-! ### 8. `Gate A10` + `F-B2-T12-01`: Constructor/Proof Sealing, Origin Invariance, & No-FullReflex -/

/-- Replace `registryOrigin` across every item in `suite` using `f : String → G6RegistryOrigin`. -/
def replaceSuiteRegistryOrigins (suite : G6ProtectedSuite)
    (f : String → G6RegistryOrigin) : G6ProtectedSuite :=
  { suite with
    items := suite.items.map (fun it => { it with registryOrigin := f it.invariantId }) }

private theorem collectItemRoots_replaceOrigin (it : G6ProtectedInvariantSpec)
    (orig : G6RegistryOrigin) :
    collectItemG6ProofRootIds { it with registryOrigin := orig } =
    collectItemG6ProofRootIds it := rfl

private theorem collectSuiteRoots_replaceOrigins (suite : G6ProtectedSuite)
    (f : String → G6RegistryOrigin) :
    collectG6ProofRootIds (replaceSuiteRegistryOrigins suite f) =
    collectG6ProofRootIds suite := by
  unfold collectG6ProofRootIds replaceSuiteRegistryOrigins
  dsimp only
  have hFold : ∀ L : List G6ProtectedInvariantSpec,
      (L.map (fun it => { it with registryOrigin := f it.invariantId })).foldr
        (fun item acc => collectItemG6ProofRootIds item ++ acc) [] =
      L.foldr (fun item acc => collectItemG6ProofRootIds item ++ acc) [] := by
    intro L
    induction L with
    | nil => rfl
    | cons a rest ih =>
        simp only [List.map_cons, List.foldr_cons]
        rw [collectItemRoots_replaceOrigin, ih]
  rw [hFold]

private theorem evalG6ItemsList_replaceOrigins (fuel : Nat) (Γ : PrimPremiseEnv)
    (C : G7DagContainer) (evalEpoch : Nat) (f : String → G6RegistryOrigin) :
    ∀ L : List G6ProtectedInvariantSpec,
      evalG6ItemsList fuel Γ C evalEpoch
        (L.map (fun it => { it with registryOrigin := f it.invariantId })) =
      evalG6ItemsList fuel Γ C evalEpoch L
  | [] => rfl
  | a :: rest => by
      simp only [List.map_cons, evalG6ItemsList]
      have hHead : evalSingleG6Item fuel Γ C evalEpoch
          { a with registryOrigin := f a.invariantId } =
          evalSingleG6Item fuel Γ C evalEpoch a := rfl
      rw [hHead, evalG6ItemsList_replaceOrigins fuel Γ C evalEpoch f rest]

/-- **`Gate A10` + `F-B2-T12-01` (`T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex`)**:
    (1) Type-level record sealing (`F-B2-T12-01`): for EVERY `rec : G6QualifiedRecord fuel Γ C`,
        `verifiedInvariantCount = items.length`, `0 < verifiedInvariantCount`,
        `submittedSuiteComplete = true`, `officialProtectionRegistryAuthenticated = false`,
        `officialRegistryBindingSlot = .mkUnchecked`, `g5DischargeSlot = .mkUnchecked`,
        `g1IntegritySlot = .mkUnchecked`, and `grantFlag = .noGrantFromMathCheck`;
    (2) Universal `registryOrigin` zero-privilege invariance: arbitrary alteration of
        `registryOrigin` (including flipping `claimedApprovedFlag`) leaves `deriveG6PrimDeps`
        and `checkG6Suite` 100% invariant;
    (3) `Pre-P1C` `FullReflexAdmitted` uninhabitability (`CE-G6-12`): even for ANY hypothetical
        coupled `G56` checker `c56`, `FullReflexAdmitted checkUnauthStageCertBool c56 checkCertifiedG7BundleBool`
        is provably uninhabited (`Empty`)! -/
theorem T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex :
    -- (1) Universal type-level sealing across ALL G6QualifiedRecord inhabitants (`F-B2-T12-01`):
    (∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
       (rec : G6QualifiedRecord fuel Γ C),
       isG6SuiteVerifiedBool fuel Γ C (extractVerifiedG6Suite rec.verifiedG6Slot) = true ∧
       rec.verifiedInvariantCount = (extractVerifiedG6Suite rec.verifiedG6Slot).items.length ∧
       0 < rec.verifiedInvariantCount ∧
       rec.submittedSuiteComplete = true ∧
       rec.officialProtectionRegistryAuthenticated = false ∧
       rec.officialRegistryBindingSlot = .mkUnchecked ∧
       rec.g5DischargeSlot = .mkUnchecked ∧
       rec.g1IntegritySlot = .mkUnchecked ∧
       rec.grantFlag = .noGrantFromMathCheck) ∧
    -- (2) Universal zero-privilege invariance of untrusted `registryOrigin`:
    (∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
       (suite : G6ProtectedSuite) (f : String → G6RegistryOrigin),
       deriveG6PrimDeps Γ C (replaceSuiteRegistryOrigins suite f) =
         deriveG6PrimDeps Γ C suite ∧
       checkG6Suite fuel Γ C (replaceSuiteRegistryOrigins suite f) =
         checkG6Suite fuel Γ C suite) ∧
    -- (3) Pre-P1C FullReflexAdmitted uninhabitability (`CE-G6-12`):
    (∀ {G56Raw : Type} (c56 : G56Raw → Bool),
       ¬ Nonempty (FullReflexAdmitted
           checkUnauthStageCertBool c56 checkCertifiedG7BundleBool)) := by
  refine ⟨?_, ?_, ?_⟩
  · intro fuel Γ C rec
    have hSlotVer : isG6SuiteVerifiedBool fuel Γ C (extractVerifiedG6Suite rec.verifiedG6Slot) = true := by
      cases hs : rec.verifiedG6Slot with
      | mkVerified c => exact c.2
    have hRegSlot : rec.officialRegistryBindingSlot = .mkUnchecked := by
      cases rec.officialRegistryBindingSlot; rfl
    have hG5Slot : rec.g5DischargeSlot = .mkUnchecked := by
      cases rec.g5DischargeSlot; rfl
    have hG1Slot : rec.g1IntegritySlot = .mkUnchecked := by
      cases rec.g1IntegritySlot; rfl
    exact ⟨hSlotVer,
           rec.verifiedCount_eq_itemsLength,
           rec.verifiedCountPos,
           rec.submittedSuiteComplete_eq_true,
           rec.officialRegistryAuth_eq_false,
           hRegSlot, hG5Slot, hG1Slot, rec.grantFlag_eq⟩
  · intro fuel Γ C suite f
    have hDeps : deriveG6PrimDeps Γ C (replaceSuiteRegistryOrigins suite f) =
        deriveG6PrimDeps Γ C suite := by
      unfold deriveG6PrimDeps
      rw [collectSuiteRoots_replaceOrigins]
    refine ⟨hDeps, ?_⟩
    unfold checkG6Suite
    have hClaims : (replaceSuiteRegistryOrigins suite f).claimedPrimDeps = suite.claimedPrimDeps := rfl
    rw [hClaims, hDeps]
    split
    · rfl
    · split
      · rfl
      · unfold evalG6SuiteCore
        have hHdr : checkG6SuiteHeaderBasicBool (replaceSuiteRegistryOrigins suite f) =
            checkG6SuiteHeaderBasicBool suite := by
          unfold checkG6SuiteHeaderBasicBool replaceSuiteRegistryOrigins
          dsimp only
          congr 1
          induction suite.items with
          | nil => rfl
          | cons a rest ih =>
              simp only [List.map_cons, List.all_cons]
              rw [ih]
        have hMapId : (replaceSuiteRegistryOrigins suite f).items.map (·.invariantId) =
            suite.items.map (·.invariantId) := by
          unfold replaceSuiteRegistryOrigins; dsimp only
          induction suite.items with
          | nil => rfl
          | cons a rest ih => simp only [List.map_cons]; rw [ih]
        have hAnySpec : (replaceSuiteRegistryOrigins suite f).items.any (fun item =>
            (item.oldNewState.specOldId != (replaceSuiteRegistryOrigins suite f).specOldId) ||
            (item.oldNewState.specNewId != (replaceSuiteRegistryOrigins suite f).specNewId)) =
          suite.items.any (fun item =>
            (item.oldNewState.specOldId != suite.specOldId) ||
            (item.oldNewState.specNewId != suite.specNewId)) := by
          unfold replaceSuiteRegistryOrigins; dsimp only
          induction suite.items with
          | nil => rfl
          | cons a rest ih => simp only [List.map_cons, List.any_cons]; rw [ih]
        have hDecl : (replaceSuiteRegistryOrigins suite f).declaredInvariantIds =
            suite.declaredInvariantIds := rfl
        rw [hHdr, hDecl, hMapId, hAnySpec]
        split
        · rfl
        · split
          · rfl
          · split
            · rfl
            · unfold replaceSuiteRegistryOrigins
              cases hIt : suite.items with
              | nil => rfl
              | cons it0 rest =>
                  simp only [List.map_cons]
                  have hEvEq := evalG6ItemsList_replaceOrigins fuel Γ C
                    suite.evaluationEpoch f (it0 :: rest)
                  simp only [List.map_cons] at hEvEq
                  rw [hEvEq]
                  have hAnyLoss :
                      ({ it0 with registryOrigin := f it0.invariantId } ::
                       List.map (fun it => { it with registryOrigin := f it.invariantId }) rest).any
                        (fun it => it.scopeLossRecord?.isSome) =
                      (it0 :: rest).any (fun it => it.scopeLossRecord?.isSome) := by
                    have hAux : ∀ L : List G6ProtectedInvariantSpec,
                        (L.map (fun it => { it with registryOrigin := f it.invariantId })).any
                          (fun it => it.scopeLossRecord?.isSome) =
                        L.any (fun it => it.scopeLossRecord?.isSome) := by
                      intro L
                      induction L with
                      | nil => rfl
                      | cons x xs ih => simp only [List.map_cons, List.any_cons]; rw [ih]
                    exact hAux (it0 :: rest)
                  rw [hAnyLoss]
  · intro G56Raw c56 ⟨full⟩
    rcases verified_slot_has_checked_cert full.slotG1 with ⟨_, hBad⟩
    nomatch hBad

end OmegaCellC1P1B2BB2
