/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  Root Library Module: OmegaCellC1P1B2BB2

  Strictly isolated G6 proof core covering ONLY B2_01 .. B2_04:
    - B2_01 (`G6` certificate types, 5-branch `G6CheckVerdict`, non-circular `S_sem_B2`)
    - B2_02 (`checkG6Suite`, `deriveG6PrimDeps`, sealed `G6QualifiedRecord`, `G6EmptySuiteNotice`)
    - B2_03 (`Gates A0..A10` + `F-B2-T12-01..04` soundness, priority, closure & non-interference)
    - B2_04 (`POS-G6-01..07`, `Gate A8.(2)`, `Gate A9`, `CE-G6-01..12`, `CE-G6-07B`, `NEG-G6-EMPTY-01`)

  Zero G5 × G6 coupled bundle (`B3`), zero 3-way coupling (`B4`), zero P1C/G1/GPED integration,
  zero official registry authentication, zero authority minting.
-/
import OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics
import OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification
import OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure
import OmegaCellC1P1B2BB2.B2_04_WitnessesAndCounterexamples
