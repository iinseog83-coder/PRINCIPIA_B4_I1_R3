/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Certified Higher Composition & Historical Retreat Algebra (`ACT-I0`)
  Module: OmegaCellC1P1B2BB4.B4_02_SpineCoherenceAndReification

  Gates & Binding Conditions Covered:
    - `I0-A3`, `I0-A4`, `I0-A5` (`F-B4-T22-01`, `F-B4-T22-03`, `Q-B4-R1-01`, `F-B4-T23-01`):
      * Context-free `B4RawPayload` & pure non-circular declarative semantics `SemB4PayloadValid`
        and `SemValidB4Spine` (`0` executable checker calls, `F-B4-T23-03` Stage 1 foundation).
      * `B4CanonicalSpine ctx`, `B4LeftPullback ctx`, and `B4RightPullback ctx` ALL unified over
        `B4ValidBase` (`CE-B4-20` eliminated + constructively contrasted on raw base).
      * Derivation of `ValidB4TransitionBaseInCtx` & universal epoch binding (`T_D0_R1_01`, `T_I0_T23_01`,
        `CE-B4-30`).
      * Constructor-sealed (`private mk ::`) `B4QualifiedRecord ctx`, 7-part Reification (`T_D0_A4_01..07`
        with projection-preserving universal uniqueness), Associativity Coherence (`T_D0_A5_01..03`),
        Provenance-Bound Consumer (`T_D0_A12_01..02`), and Authority Firewall (`T_D0_A14_01..03`).
-/
import OmegaCellC1P1B2BB4.B4_01_TypesBaseAndValidSlices

namespace OmegaCellC1P1B2BB4

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ### 1. Extensionality Helpers on Frozen Slot Witnesses -/

theorem slotUnchecked_unique
    (w1 w2 : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked) :
    w1 = w2 := by
  cases w1; cases w2; rfl

theorem structuralQualification_ext {sq1 sq2 : StructuralQualification}
    (hSum : extractSummary sq1 = extractSummary sq2) :
    sq1 = sq2 := by
  rcases sq1 with ⟨g1_1, s2348_1, g56_1, g7_1, gf1⟩
  rcases sq2 with ⟨g1_2, s2348_2, g56_2, g7_2, gf2⟩
  cases g1_1; cases g1_2
  cases g56_1; cases g56_2
  cases g7_1; cases g7_2
  cases gf1; cases gf2
  cases s2348_1 with
  | mkVerified c1 =>
      cases s2348_2 with
      | mkVerified c2 =>
          dsimp [extractSummary] at hSum
          have hc : c1 = c2 := Subtype.ext hSum
          subst hc
          rfl

theorem provenanceSlice2348_ext {a b : ProvenanceBoundG2348Slice}
    (hAst  : a.ast = b.ast)
    (hSum  : extractSummary a.sq = extractSummary b.sq)
    (hBase : a.claimedBase = b.claimedBase) :
    a = b := by
  have hSq : a.sq = b.sq := structuralQualification_ext hSum
  cases a; cases b
  dsimp only at hAst hSq hBase
  subst hAst; subst hSq; subst hBase
  rfl

/-! ### 2. Context-Free `B4RawPayload`, Joint Premise Closure, & Pure Declarative Semantics (`0` Checker Calls) -/

/-- Context-free raw `B4` mathematical payload (`F-B4-T23-03` Stage 1 separation). -/
structure B4RawPayload where
  ast        : StructuralReflexAST
  summary2348 : CheckedG2348Summary
  c56        : G56CouplingCert
  bundle7    : CertifiedG7Bundle
  base       : B4CommonTransitionBase
  bridgeMode : B4G7GoalBridgeMode
  deriving DecidableEq, Repr

/-- Joint 3-slot + interaction primitive premise closure `D_B4(Γ, C, c56, b7, mode)`. -/
def deriveB4JointPrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c56 : G56CouplingCert) (b7 : CertifiedG7Bundle) (mode : B4G7GoalBridgeMode) : List String :=
  canonSortStrs
    (c56.claimedJointPrimDeps.jointPrimDepIds ++
     b7.claimedPrimDeps ++
     deriveB4InteractionPrimDeps Γ C mode)

/-- Joint proof-root set `R_B4` across `G5`, `G6`, `G56` `L1` loss witnesses, `G7` bundle root, and `R_inter`. -/
def collectB4JointProofRoots (c56 : G56CouplingCert) (b7 : CertifiedG7Bundle)
    (mode : B4G7GoalBridgeMode) : List String :=
  canonSortStrs
    (collectG56JointProofRootIds c56.g5Cert c56.g6Suite c56.scopeCompatibility ++
     [b7.rootNodeId] ++
     bridgeRootsOfMode mode)

/-- Pure declarative payload alignment predicate (`0` executable checker calls!). -/
def SemB4PayloadAligned (epoch : Nat) (p : B4RawPayload) : Prop :=
  ValidB4TransitionBase p.base ∧
  p.base.assignedEvalEpoch = epoch ∧
  p.ast.baseId = p.base.baseId ∧
  p.ast.rflxCid = p.base.rflxCid ∧
  derivePathKey p.ast = p.base.pathKey ∧
  p.ast.parentPathKey? = p.base.parentPathKey? ∧
  p.ast.cellOldCid = p.base.cellOldCid ∧
  p.ast.obstCid = p.base.obstCid ∧
  p.ast.cellNewCid = p.base.cellNewCid ∧
  p.ast.specOldId = p.base.specOldId ∧
  p.ast.specNewId = p.base.specNewId ∧
  p.ast.domOldId = p.base.domOldId ∧
  p.ast.domNewId = p.base.domNewId ∧
  p.ast.reflexKind = p.base.reflexKind ∧
  p.summary2348.historicalRetreat = p.base.cumulativeHistRetreat ∧
  subjectKeyOfB1Summary p.summary2348 = p.base.toSubjectKey ∧
  p.c56.transitionBinding = p.base.toG56Binding ∧
  p.c56.g5Cert.obstCid = p.base.obstCid ∧
  p.c56.g5Cert.goalNew = p.base.postGoal ∧
  p.bundle7.subjectKey = p.base.toSubjectKey ∧
  p.bundle7.claimedDomTag = p.base.domNew ∧
  epoch < p.bundle7.expiresEpoch

/-- **Pure Non-Circular Declarative Payload Semantics `SemB4PayloadValid` (`F-B4-T23-03`, `0` Checker Calls!)**:
    Depends ONLY on mathematical model predicates (`SemStructuralValid`, `SemValidG56Coupling`,
    `inG7Dom`, `InEffDom`, `ModelsStrictForm`) and NEVER invokes any executable checker! -/
structure SemB4PayloadValid
    (regId : String) (store : StructuralStore) (L : List StructuralLedgerEvent)
    (epoch : Nat) (_P_env : PrimPremiseEnv) (p : B4RawPayload) : Prop where
  alignedPayload :
    SemB4PayloadAligned epoch p
  structuralValid :
    SemStructuralValid regId store L p.ast
  g56CouplingValid :
    SemValidG56Coupling p.c56
  g7BundleGoalValid :
    ∀ ρ : Env2, inG7Dom p.bundle7.claimedDomTag ρ → ModelsStrictForm p.bundle7.claimedGoal ρ
  postStateGoalValid :
    ∀ ρ : Env2, InEffDom p.base.domNew p.base.guardsNew ρ → ModelsStrictForm p.base.postGoal ρ

/-! ### 3. `B4CanonicalSpine`, Left/Right Valid Pullbacks, & Candidate Packet Evaluator (`I0-A3`, `I0-A5`) -/

/-- **`B4CanonicalSpine ctx` (`N_{I_3}^valid(ctx)`)**:
    Canonical 3-slot fiber product over unified valid base `B4ValidBase` (`F-B4-T22-01`). -/
structure B4CanonicalSpine (ctx : B4SharedContext) where
  base      : B4ValidBase
  fiber2348 : B4ValidSlotFiber ctx .s2348 base
  fiber56   : B4ValidSlotFiber ctx .s56 base
  fiber7    : B4ValidSlotFiber ctx .s7 base

def B4CanonicalSpine.slice2348 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : ValidSlice2348 ctx :=
  sp.fiber2348.1

def B4CanonicalSpine.slice56 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : ValidSlice56 ctx :=
  sp.fiber56.1

def B4CanonicalSpine.slice7 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : ValidSlice7 ctx :=
  sp.fiber7.1

def B4CanonicalSpine.ast {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : StructuralReflexAST :=
  sp.slice2348.1.1.ast

def B4CanonicalSpine.sq2348 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : StructuralQualification :=
  sp.slice2348.1.1.sq

def B4CanonicalSpine.c56 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : G56CouplingCert :=
  sp.slice56.1.1.c56

def B4CanonicalSpine.bundle7 {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : CertifiedG7Bundle :=
  sp.slice7.1.1.bundle

def B4CanonicalSpine.bridgeMode {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : B4G7GoalBridgeMode :=
  sp.slice7.1.1.bridgeMode

/-- Forgetful projection from `sp : B4CanonicalSpine ctx` to context-free `B4RawPayload`. -/
def B4CanonicalSpine.toPayload {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : B4RawPayload where
  ast         := sp.ast
  summary2348 := extractSummary sp.sq2348
  c56         := sp.c56
  bundle7     := sp.bundle7
  base        := sp.base.1
  bridgeMode  := sp.bridgeMode

/-- Joint premise closure `D_B4(sp)` of a `B4CanonicalSpine ctx`. -/
def deriveSpineB4PrimDeps (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) : List String :=
  deriveB4JointPrimDeps ctx.primEnv ctx.dagCont sp.c56 sp.bundle7 sp.bridgeMode

/-- **Declarative Spine Semantics `SemValidB4Spine` (`0` Executable Checker Calls!)**. -/
def SemValidB4Spine (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) : Prop :=
  SemB4PayloadValid ctx.regId ctx.structStore ctx.ledgerSnap ctx.assignedEvalEpoch ctx.primEnv sp.toPayload

/-- Tuple-level declarative semantics for `T_D0_A4_06_SemanticPreservation`. -/
def SemValidB4ThreeTuple (ctx : B4SharedContext)
    (s1 : ValidSlice2348 ctx) (s2 : ValidSlice56 ctx) (s3 : ValidSlice7 ctx) : Prop :=
  projValidSlice2348 s1 = projValidSlice56 s2 ∧
  projValidSlice56 s2 = projValidSlice7 s3 ∧
  SemB4PayloadValid ctx.regId ctx.structStore ctx.ledgerSnap ctx.assignedEvalEpoch ctx.primEnv
    { ast         := s1.1.1.ast
      summary2348 := extractSummary s1.1.1.sq
      c56         := s2.1.1.c56
      bundle7     := s3.1.1.bundle
      base        := s1.1.1.claimedBase
      bridgeMode  := s3.1.1.bridgeMode }

/-- Indexed dependent Pi-over-Sigma representation `Σ (t : B4ValidBase), ∀ (i : B4SlotIdx), Fiber ctx i t`. -/
abbrev B4IndexedSigma (ctx : B4SharedContext) : Type :=
  Σ (t : B4ValidBase), (i : B4SlotIdx) → B4ValidSlotFiber ctx i t

def toIndexedSigma {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : B4IndexedSigma ctx :=
  ⟨sp.base, fun i =>
    match i with
    | .s2348 => sp.fiber2348
    | .s56   => sp.fiber56
    | .s7    => sp.fiber7⟩

def ofIndexedSigma {ctx : B4SharedContext} (sig : B4IndexedSigma ctx) : B4CanonicalSpine ctx where
  base      := sig.1
  fiber2348 := sig.2 .s2348
  fiber56   := sig.2 .s56
  fiber7    := sig.2 .s7

/-- **`T_D0_A3_01` — Indexed Product / Canonical Spine Mutual Roundtrip Equivalence (`F-B4-T22-01`)**. -/
theorem T_D0_A3_01_IndexedProductRecordEquivalence (ctx : B4SharedContext) :
    (∀ sp : B4CanonicalSpine ctx, ofIndexedSigma (toIndexedSigma sp) = sp) ∧
    (∀ sig : B4IndexedSigma ctx, toIndexedSigma (ofIndexedSigma sig) = sig) := by
  refine ⟨fun sp => by cases sp; rfl, ?_⟩
  intro ⟨t, f⟩
  unfold toIndexedSigma ofIndexedSigma
  dsimp only
  congr
  funext i
  cases i <;> rfl

/-- Left-associated binary pullback `(S_2348^valid ×_{T_valid} S_56^valid) ×_{T_valid} S_7^valid` (`F-B4-T22-01`). -/
def B4LeftPullback12 (ctx : B4SharedContext) : Type :=
  { p : ValidSlice2348 ctx × ValidSlice56 ctx // projValidSlice2348 p.1 = projValidSlice56 p.2 }

def B4LeftPullback (ctx : B4SharedContext) : Type :=
  { p : B4LeftPullback12 ctx × ValidSlice7 ctx // projValidSlice56 p.1.1.2 = projValidSlice7 p.2 }

/-- Right-associated binary pullback `S_2348^valid ×_{T_valid} (S_56^valid ×_{T_valid} S_7^valid)` (`F-B4-T22-01`). -/
def B4RightPullback23 (ctx : B4SharedContext) : Type :=
  { p : ValidSlice56 ctx × ValidSlice7 ctx // projValidSlice56 p.1 = projValidSlice7 p.2 }

def B4RightPullback (ctx : B4SharedContext) : Type :=
  { p : ValidSlice2348 ctx × B4RightPullback23 ctx // projValidSlice2348 p.1 = projValidSlice56 p.2.1.1 }

def spineOfLeft {ctx : B4SharedContext} (pL : B4LeftPullback ctx) : B4CanonicalSpine ctx where
  base      := projValidSlice2348 pL.1.1.1.1
  fiber2348 := ⟨pL.1.1.1.1, rfl⟩
  fiber56   := ⟨pL.1.1.1.2, pL.1.1.2.symm⟩
  fiber7    := ⟨pL.1.2, (pL.1.1.2.trans pL.2).symm⟩

def leftOfSpine {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : B4LeftPullback ctx :=
  ⟨(⟨(sp.slice2348, sp.slice56), sp.fiber2348.2.trans sp.fiber56.2.symm⟩, sp.slice7),
   sp.fiber56.2.trans sp.fiber7.2.symm⟩

def spineOfRight {ctx : B4SharedContext} (pR : B4RightPullback ctx) : B4CanonicalSpine ctx where
  base      := projValidSlice2348 pR.1.1
  fiber2348 := ⟨pR.1.1, rfl⟩
  fiber56   := ⟨pR.1.2.1.1, pR.2.symm⟩
  fiber7    := ⟨pR.1.2.1.2, (pR.2.trans pR.1.2.2).symm⟩

def rightOfSpine {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : B4RightPullback ctx :=
  ⟨(sp.slice2348, ⟨(sp.slice56, sp.slice7), sp.fiber56.2.trans sp.fiber7.2.symm⟩),
   sp.fiber2348.2.trans sp.fiber56.2.symm⟩

def assocLeftToRight {ctx : B4SharedContext} (pL : B4LeftPullback ctx) : B4RightPullback ctx :=
  rightOfSpine (spineOfLeft pL)

def assocRightToLeft {ctx : B4SharedContext} (pR : B4RightPullback ctx) : B4LeftPullback ctx :=
  leftOfSpine (spineOfRight pR)

/-- Glue three base-aligned valid slices directly into `B4CanonicalSpine ctx`. -/
def glueValidSlices {ctx : B4SharedContext}
    (s1 : ValidSlice2348 ctx) (s2 : ValidSlice56 ctx) (s3 : ValidSlice7 ctx)
    (h12 : projValidSlice2348 s1 = projValidSlice56 s2)
    (h23 : projValidSlice56 s2 = projValidSlice7 s3) : B4CanonicalSpine ctx where
  base      := projValidSlice2348 s1
  fiber2348 := ⟨s1, rfl⟩
  fiber56   := ⟨s2, h12.symm⟩
  fiber7    := ⟨s3, (h12.trans h23).symm⟩

/-! ### 4. Candidate Packet & Provenance-Bound Diagnostic Consumer (`I0-A3`, `I0-A13`) -/

/-- Untrusted candidate packet submitted to the `B4` composite verifier. -/
structure B4CandidatePacket where
  s2348                    : ProvenanceBoundG2348Slice
  s56                      : BoundG56Slice
  s7                       : GoalAlignedG7Slice
  claimedCompositePrimDeps : List String

/-- Fine-grained `B4` composite rejection codes. -/
inductive B4CompositeError where
  | mismatchedSharedEnvOrDag      : B4CompositeError
  | mismatchedTransitionBase      : B4CompositeError
  | invalidTransitionBase         : B4CompositeError
  | invalidSlice2348              : B4CompositeError
  | invalidSlice56                : B4CompositeError
  | invalidSlice7                 : B4CompositeError
  | incompleteInteractionPremises : B4CompositeError
  deriving DecidableEq, Repr

/-- Evaluate exact composite error (`none` iff all 7 composite checks pass!). -/
def evalB4CompositeError? (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    Option B4CompositeError :=
  if (pkt.s7.bundle.primEnvSnapshot != ctx.primEnv) ||
     (pkt.s7.bundle.dagSnapshot != ctx.dagCont) then
    some .mismatchedSharedEnvOrDag
  else if (pkt.s2348.claimedBase != pkt.s56.claimedBase) ||
          (pkt.s56.claimedBase != pkt.s7.claimedBase) then
    some .mismatchedTransitionBase
  else if !checkValidB4TransitionBaseBool pkt.s2348.claimedBase then
    some .invalidTransitionBase
  else if !checkSlice2348Bool ctx pkt.s2348 then
    some .invalidSlice2348
  else if !checkSlice56Bool ctx pkt.s56 then
    some .invalidSlice56
  else if !checkSlice7Bool ctx pkt.s7 then
    some .invalidSlice7
  else if pkt.claimedCompositePrimDeps !=
          deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode then
    some .incompleteInteractionPremises
  else
    none

/-- Top-level executable boolean composite verifier. -/
def checkB4CompositeBool (ctx : B4SharedContext) (pkt : B4CandidatePacket) : Bool :=
  (evalB4CompositeError? ctx pkt).isNone

/-- Non-short-circuiting product diagnostic observation for `Born-T21` consumer gate (`I0-A13`). -/
structure B4DiagnosticObservation where
  sharedEnvAndDagOk   : Bool
  transitionAlignedOk : Bool
  validBaseOk         : Bool
  slice2348Ok         : Bool
  slice56Ok           : Bool
  slice7Ok            : Bool
  compositeDepsOk     : Bool
  firstError?         : Option B4CompositeError
  deriving DecidableEq, Repr

def evalB4Detailed (ctx : B4SharedContext) (pkt : B4CandidatePacket) : B4DiagnosticObservation where
  sharedEnvAndDagOk   := (pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) &&
                         (pkt.s7.bundle.dagSnapshot == ctx.dagCont)
  transitionAlignedOk := (pkt.s2348.claimedBase == pkt.s56.claimedBase) &&
                         (pkt.s56.claimedBase == pkt.s7.claimedBase)
  validBaseOk         := checkValidB4TransitionBaseBool pkt.s2348.claimedBase
  slice2348Ok         := checkSlice2348Bool ctx pkt.s2348
  slice56Ok           := checkSlice56Bool ctx pkt.s56
  slice7Ok            := checkSlice7Bool ctx pkt.s7
  compositeDepsOk     := pkt.claimedCompositePrimDeps ==
                         deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode
  firstError?         := evalB4CompositeError? ctx pkt

/-- Unbound consumer projection (`CE-B4-13`: spoofable if fed forged `B4DiagnosticObservation`!). -/
def projectUnboundB4DiagPassBool (obs : B4DiagnosticObservation) : Bool :=
  obs.sharedEnvAndDagOk && obs.transitionAlignedOk && obs.validBaseOk &&
  obs.slice2348Ok && obs.slice56Ok && obs.slice7Ok && obs.compositeDepsOk &&
  obs.firstError?.isNone

/-- Provenance-bound diagnostic wrapper (`F-B3-T19-01` / `Born-T21` Gate 2). -/
structure ProvenanceBoundB4Diagnostic (ctx : B4SharedContext) (pkt : B4CandidatePacket) where
  obs   : B4DiagnosticObservation
  hProv : obs = evalB4Detailed ctx pkt

def consumeBoundB4Verdict {ctx : B4SharedContext} {pkt : B4CandidatePacket}
    (d : ProvenanceBoundB4Diagnostic ctx pkt) : Bool :=
  projectUnboundB4DiagPassBool d.obs

/-! ### 5. Constructor-Sealed `B4QualifiedRecord` (`private mk ::`) & Reification (`I0-A4`, `I0-A15`) -/

/-- Partial 4-slot qualification spine inhabited by `B4`: `(.unchecked, .verified, .verified, .verified)`
    (`G1` strictly `.unchecked`!). -/
abbrev B4ThreeSlotQualification (ctx : B4SharedContext) : Type :=
  ReflexQualification
    checkUnauthStageCertBool
    (isG56CouplingVerifiedBool ctx.toG56Context)
    checkCertifiedG7BundleBool
    .unchecked .verified .verified .verified

def extractSlot2348Summary {ctx : B4SharedContext} (q : B4ThreeSlotQualification ctx) : CheckedG2348Summary :=
  match q.slot2348 with | .mkVerified c => c.1

def extractSlot56Cert {ctx : B4SharedContext} (q : B4ThreeSlotQualification ctx) : G56CouplingCert :=
  match q.slotG56 with | .mkVerified c => c.1

def extractSlot7Bundle {ctx : B4SharedContext} (q : B4ThreeSlotQualification ctx) : CertifiedG7Bundle :=
  match q.slotG7 with | .mkVerified c => c.1

/-- **Constructor-Sealed `B4QualifiedRecord ctx` (`private mk ::`)**:
    Cannot be forged or tagged with uncanonical extra strings; every data field is propositionally
    equality-bound to `spine : B4CanonicalSpine ctx`! -/
structure B4QualifiedRecord (ctx : B4SharedContext) where
  private mk ::
  spine                    : B4CanonicalSpine ctx
  threeSlotQual            : B4ThreeSlotQualification ctx
  b4CompositeSlot          : SlotWitness (B4CanonicalSpine ctx) (fun _ => true) .verified
  g1IntegritySlot          : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  officialRegistryAuth     : Bool
  grantFlag                : CheckDerivesNoGrant
  jointPrimDeps            : List String
  hQual2348_eq             : extractSlot2348Summary threeSlotQual = extractSummary spine.sq2348
  hQual56_eq               : extractSlot56Cert threeSlotQual = spine.c56
  hQual7_eq                : extractSlot7Bundle threeSlotQual = spine.bundle7
  hCompSlot_eq             : (match b4CompositeSlot with | .mkVerified c => c.1) = spine
  hOfficialAuth_eq_false   : officialRegistryAuth = false
  hGrant_eq                : grantFlag = .noGrantFromMathCheck
  hJointDeps_eq            : jointPrimDeps = deriveSpineB4PrimDeps ctx spine

/-- Canonical Reifier `Q_B4 : B4CanonicalSpine ctx → B4QualifiedRecord ctx`. -/
def reifyB4Spine (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) : B4QualifiedRecord ctx :=
  have h2348 : checkG2348SummaryBool (extractSummary sp.sq2348) = true := by
    have hs := sp.slice2348.1.2
    unfold checkSlice2348Bool at hs
    simp only [Bool.and_eq_true] at hs
    exact hs.1.2
  have h56 : isG56CouplingVerifiedBool ctx.toG56Context sp.c56 = true := by
    have hs := sp.slice56.1.2
    unfold checkSlice56Bool at hs
    simp only [Bool.and_eq_true] at hs
    exact hs.1.1.1.1
  have h7 : checkCertifiedG7BundleBool sp.bundle7 = true := by
    have hs := sp.slice7.1.2
    unfold checkSlice7Bool at hs
    simp only [Bool.and_eq_true] at hs
    exact hs.1.1.1.2
  B4QualifiedRecord.mk
    sp
    { slotG1    := .mkUnchecked
      slot2348  := .mkVerified ⟨extractSummary sp.sq2348, h2348⟩
      slotG56   := .mkVerified ⟨sp.c56, h56⟩
      slotG7    := .mkVerified ⟨sp.bundle7, h7⟩
      grantFlag := .noGrantFromMathCheck }
    (.mkVerified ⟨sp, rfl⟩)
    .mkUnchecked
    false
    .noGrantFromMathCheck
    (deriveSpineB4PrimDeps ctx sp)
    rfl rfl rfl rfl rfl rfl rfl

/-- Canonical Extractor `E_B4 : B4QualifiedRecord ctx → B4CanonicalSpine ctx`. -/
def extractB4Spine {ctx : B4SharedContext} (rec : B4QualifiedRecord ctx) : B4CanonicalSpine ctx :=
  rec.spine

/-- Unpack `checkB4CompositeBool ctx pkt = true` into all 7 verified component facts. -/
theorem unpack_checkB4CompositeBool {ctx : B4SharedContext} {pkt : B4CandidatePacket}
    (h : checkB4CompositeBool ctx pkt = true) :
    pkt.s7.bundle.primEnvSnapshot = ctx.primEnv ∧
    pkt.s7.bundle.dagSnapshot = ctx.dagCont ∧
    pkt.s2348.claimedBase = pkt.s56.claimedBase ∧
    pkt.s56.claimedBase = pkt.s7.claimedBase ∧
    ValidB4TransitionBase pkt.s2348.claimedBase ∧
    checkSlice2348Bool ctx pkt.s2348 = true ∧
    checkSlice56Bool ctx pkt.s56 = true ∧
    checkSlice7Bool ctx pkt.s7 = true ∧
    pkt.claimedCompositePrimDeps =
      deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode := by
  unfold checkB4CompositeBool evalB4CompositeError? at h
  by_cases c1 : ((pkt.s7.bundle.primEnvSnapshot != ctx.primEnv) ||
                 (pkt.s7.bundle.dagSnapshot != ctx.dagCont)) = true
  · rw [if_pos c1] at h; nomatch h
  · rw [if_neg c1] at h
    by_cases c2 : ((pkt.s2348.claimedBase != pkt.s56.claimedBase) ||
                   (pkt.s56.claimedBase != pkt.s7.claimedBase)) = true
    · rw [if_pos c2] at h; nomatch h
    · rw [if_neg c2] at h
      by_cases c3 : (!checkValidB4TransitionBaseBool pkt.s2348.claimedBase) = true
      · rw [if_pos c3] at h; nomatch h
      · rw [if_neg c3] at h
        by_cases c4 : (!checkSlice2348Bool ctx pkt.s2348) = true
        · rw [if_pos c4] at h; nomatch h
        · rw [if_neg c4] at h
          by_cases c5 : (!checkSlice56Bool ctx pkt.s56) = true
          · rw [if_pos c5] at h; nomatch h
          · rw [if_neg c5] at h
            by_cases c6 : (!checkSlice7Bool ctx pkt.s7) = true
            · rw [if_pos c6] at h; nomatch h
            · rw [if_neg c6] at h
              by_cases c7 : (pkt.claimedCompositePrimDeps !=
                  deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode) = true
              · rw [if_pos c7] at h; nomatch h
              · have he1 : pkt.s7.bundle.primEnvSnapshot = ctx.primEnv := by
                  cases hb : (pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) <;> simp_all [bne]
                have he2 : pkt.s7.bundle.dagSnapshot = ctx.dagCont := by
                  cases hb : (pkt.s7.bundle.dagSnapshot == ctx.dagCont) <;> simp_all [bne]
                have hb12 : pkt.s2348.claimedBase = pkt.s56.claimedBase := by
                  cases hb : (pkt.s2348.claimedBase == pkt.s56.claimedBase) <;> simp_all [bne]
                have hb23 : pkt.s56.claimedBase = pkt.s7.claimedBase := by
                  cases hb : (pkt.s56.claimedBase == pkt.s7.claimedBase) <;> simp_all [bne]
                have hvB : checkValidB4TransitionBaseBool pkt.s2348.claimedBase = true := by
                  cases hb : checkValidB4TransitionBaseBool pkt.s2348.claimedBase <;> simp_all
                have hs1 : checkSlice2348Bool ctx pkt.s2348 = true := by
                  cases hb : checkSlice2348Bool ctx pkt.s2348 <;> simp_all
                have hs2 : checkSlice56Bool ctx pkt.s56 = true := by
                  cases hb : checkSlice56Bool ctx pkt.s56 <;> simp_all
                have hs3 : checkSlice7Bool ctx pkt.s7 = true := by
                  cases hb : checkSlice7Bool ctx pkt.s7 <;> simp_all
                have hd : pkt.claimedCompositePrimDeps =
                    deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode := by
                  cases hb : (pkt.claimedCompositePrimDeps ==
                    deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode) <;>
                    simp_all [bne]
                exact ⟨he1, he2, hb12, hb23, (checkValidB4TransitionBaseBool_iff _).mp hvB, hs1, hs2, hs3, hd⟩

/-- Construct `B4CanonicalSpine ctx` from a verified `pkt : B4CandidatePacket`. -/
def spineOfVerifiedPacket (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (hVer : checkB4CompositeBool ctx pkt = true) : B4CanonicalSpine ctx :=
  let u := unpack_checkB4CompositeBool hVer
  have hv1 : ValidB4TransitionBase pkt.s2348.claimedBase := u.2.2.2.2.1
  have hv2 : ValidB4TransitionBase pkt.s56.claimedBase := u.2.2.1 ▸ hv1
  have hv3 : ValidB4TransitionBase pkt.s7.claimedBase := u.2.2.2.1 ▸ hv2
  let sl1 : ValidSlice2348 ctx := ⟨⟨pkt.s2348, u.2.2.2.2.2.1⟩, hv1⟩
  let sl2 : ValidSlice56 ctx   := ⟨⟨pkt.s56,   u.2.2.2.2.2.2.1⟩, hv2⟩
  let sl3 : ValidSlice7 ctx    := ⟨⟨pkt.s7,    u.2.2.2.2.2.2.2.1⟩, hv3⟩
  glueValidSlices sl1 sl2 sl3 (Subtype.ext u.2.2.1) (Subtype.ext u.2.2.2.1)

/-- Top-level deterministic qualifier `qualifyB4Composite?`. -/
def qualifyB4Composite? (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    Option (B4QualifiedRecord ctx) :=
  if hVer : checkB4CompositeBool ctx pkt = true then
    some (reifyB4Spine ctx (spineOfVerifiedPacket ctx pkt hVer))
  else
    none

/-! ### 6. Theorems `T_D0_R1_01`, `T_I0_T23_01`, `T_D0_A3_03`, `T_D0_A4_01..07`, `T_D0_A5_01..03`, `T_D0_A12_01..02`, `T_D0_A14_01..03` -/

/-- **`T_D0_R1_01` — Universal Common Epoch Binding Derived from Verified Slots (`F-B4-T22-03`, `F-B4-T23-01`)**:
    Without assuming `t.assignedEvalEpoch = ctx.assignedEvalEpoch` inside `B4ValidBase`, every
    `sp : B4CanonicalSpine ctx` provably satisfies exact context-epoch binding across `sp.base`,
    `toG56Binding`, `g6Suite.evaluationEpoch`, and `< bundle7.expiresEpoch`! -/
theorem T_D0_R1_01_SpineCommonEpochBinding
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    sp.base.1.assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    (sp.base.1.toG56Binding).assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    sp.c56.g6Suite.evaluationEpoch = ctx.assignedEvalEpoch ∧
    sp.base.1.assignedEvalEpoch < sp.bundle7.expiresEpoch := by
  have h56 := sp.slice56.1.2
  unfold checkSlice56Bool at h56
  simp only [Bool.and_eq_true, beq_iff_eq] at h56
  rcases h56 with ⟨⟨⟨⟨hVer56, hProjEq⟩, hTbEq⟩, _⟩, _⟩
  have hBaseEq : sp.slice56.1.1.claimedBase = sp.base.1 :=
    congrArg Subtype.val sp.fiber56.2
  have hEp1 : sp.slice56.1.1.claimedBase.assignedEvalEpoch = ctx.assignedEvalEpoch :=
    (congrArg G56TransitionBinding.assignedEvalEpoch hProjEq).symm
  have hEpBase : sp.base.1.assignedEvalEpoch = ctx.assignedEvalEpoch := by
    rwa [hBaseEq] at hEp1
  have hRel := (verifiedG56_projects_bindingAndFlags ctx.toG56Context ⟨sp.c56, hVer56⟩).2.1
  have hG6Ep : sp.c56.g6Suite.evaluationEpoch = sp.c56.transitionBinding.assignedEvalEpoch :=
    hRel.2.1
  have hG6Ctx : sp.c56.g6Suite.evaluationEpoch = ctx.assignedEvalEpoch := by
    rw [hG6Ep]
    unfold B4CanonicalSpine.c56
    rw [hTbEq, hBaseEq]
    exact hEpBase
  have h7 := sp.slice7.1.2
  unfold checkSlice7Bool at h7
  simp only [Bool.and_eq_true, decide_eq_true_eq] at h7
  have hLtCtx : ctx.assignedEvalEpoch < sp.bundle7.expiresEpoch := h7.1.2
  refine ⟨hEpBase, hEpBase, hG6Ctx, ?_⟩
  rwa [hEpBase]

/-- **`T_I0_T23_01` — Relationship Between `ValidB4TransitionBase` & `ValidB4TransitionBaseInCtx` (`F-B4-T23-01`, `CE-B4-30`)**:
    (1) Every `sp : B4CanonicalSpine ctx` entails `ValidB4TransitionBaseInCtx ctx sp.base.1`;
    (2) Conversely, on uncoupled bases (`CE-B4-30`), `ValidB4TransitionBase` does NOT imply
        `ValidB4TransitionBaseInCtx` when `ctx.assignedEvalEpoch ≠ t.assignedEvalEpoch`. -/
theorem T_I0_T23_01_ValidBaseInCtxDerivedFromSpine :
    (∀ (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       ValidB4TransitionBaseInCtx ctx sp.base.1) ∧
    (∀ (ctx : B4SharedContext),
       ctx.assignedEvalEpoch = 99 →
       ValidB4TransitionBase t_nonSurjValidBase.1 ∧
       ¬ ValidB4TransitionBaseInCtx ctx t_nonSurjValidBase.1) := by
  refine ⟨fun ctx sp => ⟨sp.base.2, (T_D0_R1_01_SpineCommonEpochBinding ctx sp).1⟩, ?_⟩
  intro ctx hEp99
  refine ⟨t_nonSurjValidBase.2, ?_⟩
  rintro ⟨_, hEq⟩
  rw [hEp99] at hEq
  dsimp [t_nonSurjValidBase] at hEq
  nomatch hEq

/-- **`T_D0_A3_03` — Split-Transition or Split-Context Packet Deterministic Rejection (`CE-B4-01`, `CE-B4-02`, `CE-B4-06`)**. -/
theorem T_D0_A3_03_SplitTransitionOrContextRejection
    (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    ((pkt.s7.bundle.primEnvSnapshot ≠ ctx.primEnv ∨ pkt.s7.bundle.dagSnapshot ≠ ctx.dagCont) →
       evalB4CompositeError? ctx pkt = some .mismatchedSharedEnvOrDag ∧
       checkB4CompositeBool ctx pkt = false) ∧
    ((pkt.s7.bundle.primEnvSnapshot = ctx.primEnv ∧ pkt.s7.bundle.dagSnapshot = ctx.dagCont) →
     (pkt.s2348.claimedBase ≠ pkt.s56.claimedBase ∨ pkt.s56.claimedBase ≠ pkt.s7.claimedBase) →
       evalB4CompositeError? ctx pkt = some .mismatchedTransitionBase ∧
       checkB4CompositeBool ctx pkt = false) := by
  refine ⟨?_, ?_⟩
  · intro hMis
    have hc1 : ((pkt.s7.bundle.primEnvSnapshot != ctx.primEnv) ||
                (pkt.s7.bundle.dagSnapshot != ctx.dagCont)) = true := by
      rcases hMis with hE | hD
      · simp [Bool.or_eq_true, bne_iff_ne, hE]
      · simp [Bool.or_eq_true, bne_iff_ne, hD]
    unfold checkB4CompositeBool evalB4CompositeError?
    rw [if_pos hc1]
    exact ⟨rfl, rfl⟩
  · rintro ⟨hE, hD⟩ hBaseMis
    have hc1 : ¬ ((pkt.s7.bundle.primEnvSnapshot != ctx.primEnv) ||
                  (pkt.s7.bundle.dagSnapshot != ctx.dagCont)) = true := by
      simp [hE, hD]
    have hc2 : ((pkt.s2348.claimedBase != pkt.s56.claimedBase) ||
                (pkt.s56.claimedBase != pkt.s7.claimedBase)) = true := by
      rcases hBaseMis with h12 | h23
      · simp [Bool.or_eq_true, bne_iff_ne, h12]
      · simp [Bool.or_eq_true, bne_iff_ne, h23]
    unfold checkB4CompositeBool evalB4CompositeError?
    rw [if_neg hc1, if_pos hc2]
    exact ⟨rfl, rfl⟩

/-- **`T_D0_A4_01` — Spine Qualification Existence & Biconditional Totality**. -/
theorem T_D0_A4_01_SpineExistence (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    ((qualifyB4Composite? ctx pkt).isSome = true ↔ checkB4CompositeBool ctx pkt = true) ∧
    (∀ hVer : checkB4CompositeBool ctx pkt = true,
       qualifyB4Composite? ctx pkt = some (reifyB4Spine ctx (spineOfVerifiedPacket ctx pkt hVer))) := by
  refine ⟨?_, fun hVer => by unfold qualifyB4Composite?; rw [dif_pos hVer]⟩
  unfold qualifyB4Composite?
  by_cases hVer : checkB4CompositeBool ctx pkt = true
  · rw [dif_pos hVer]; simp [hVer]
  · rw [dif_neg hVer]; simp [hVer]

/-- **`T_D0_A4_05` — Projection & `ReflexSubjectKey` Preservation Across All 3 Slots**. -/
theorem T_D0_A4_05_ProjectionAndSubjectKeyPreservation
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    projValidSlice2348 sp.slice2348 = sp.base ∧
    projValidSlice56 sp.slice56 = sp.base ∧
    projValidSlice7 sp.slice7 = sp.base ∧
    subjectKeyOfB1Summary (extractSummary sp.sq2348) = sp.bundle7.subjectKey := by
  refine ⟨sp.fiber2348.2, sp.fiber56.2, sp.fiber7.2, ?_⟩
  have h1 := sp.slice2348.1.2
  unfold checkSlice2348Bool checkR2348AlignBool at h1
  simp only [Bool.and_eq_true, beq_iff_eq] at h1
  rcases h1.2 with ⟨⟨⟨⟨⟨⟨_, hrflx⟩, hpkey⟩, hcell⟩, hbase⟩, hdom⟩, hspec⟩
  have hb1 : sp.slice2348.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber2348.2
  have h7 := sp.slice7.1.2
  unfold checkSlice7Bool at h7
  simp only [Bool.and_eq_true, beq_iff_eq] at h7
  have hSub7 : sp.slice7.1.1.bundle.subjectKey = sp.slice7.1.1.claimedBase.toSubjectKey := h7.1.1.2
  have hb7 : sp.slice7.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber7.2
  show subjectKeyOfB1Summary (extractSummary sp.slice2348.1.1.sq) = sp.slice7.1.1.bundle.subjectKey
  rw [hSub7, hb7, ← hb1]
  unfold subjectKeyOfB1Summary B4CommonTransitionBase.toSubjectKey
  rw [hrflx, hpkey, hcell, hbase, hdom, hspec]

/-- **`T_D0_A4_02` — Lossless Reconstruction of `CoupledB1G7Qualification` (`P1B2AC`) & `G56QualifiedRecord` (`B3`)**. -/
theorem T_D0_A4_02_SpineReconstructionLossless
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx) :
    (∃ g56Rec : G56QualifiedRecord ctx.toG56Context,
       extractVerifiedG56 g56Rec.verifiedG56Slot = rec.spine.c56) ∧
    (∃ b1g7 : CoupledB1G7Qualification,
       extractB1G7Summary b1g7.spine = extractSummary rec.spine.sq2348 ∧
       extractB1G7Bundle b1g7.spine = rec.spine.bundle7) := by
  have h2348 : checkG2348SummaryBool (extractSummary rec.spine.sq2348) = true := by
    have hs := rec.spine.slice2348.1.2
    unfold checkSlice2348Bool at hs; simp only [Bool.and_eq_true] at hs; exact hs.1.2
  have h56 : isG56CouplingVerifiedBool ctx.toG56Context rec.spine.c56 = true := by
    have hs := rec.spine.slice56.1.2
    unfold checkSlice56Bool at hs; simp only [Bool.and_eq_true] at hs; exact hs.1.1.1.1
  have h7 : checkCertifiedG7BundleBool rec.spine.bundle7 = true := by
    have hs := rec.spine.slice7.1.2
    unfold checkSlice7Bool at hs; simp only [Bool.and_eq_true] at hs; exact hs.1.1.1.2
  refine ⟨⟨reifyVerifiedG56 ctx.toG56Context ⟨rec.spine.c56, h56⟩, rfl⟩, ?_⟩
  let sp17 : B1AndG7Spine := {
    slotG1    := .mkUnchecked
    slot2348  := .mkVerified ⟨extractSummary rec.spine.sq2348, h2348⟩
    slotG56   := .mkUnchecked
    slotG7    := .mkVerified ⟨rec.spine.bundle7, h7⟩
    grantFlag := .noGrantFromMathCheck
  }
  have hSubEq := (T_D0_A4_05_ProjectionAndSubjectKeyPreservation ctx rec.spine).2.2.2
  exact ⟨⟨sp17, hSubEq⟩, rfl, rfl⟩

/-- Unsealed contrast wrapper (`CE-B4-04`) showing unsealed `auditNote : String` breaks uniqueness. -/
structure UnsealedB4RecordContrast (ctx : B4SharedContext) where
  spine     : B4CanonicalSpine ctx
  auditNote : String

theorem ce04_unsealed_breaks_uniqueness {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) :
    let u1 : UnsealedB4RecordContrast ctx := ⟨sp, "note_A"⟩
    let u2 : UnsealedB4RecordContrast ctx := ⟨sp, "note_B"⟩
    u1.spine = u2.spine ∧ u1 ≠ u2 := by
  refine ⟨rfl, ?_⟩
  intro hEq
  have hN : "note_A" = "note_B" := congrArg UnsealedB4RecordContrast.auditNote hEq
  nomatch hN

/-- **`T_D0_A4_04` — Sealed `B4QualifiedRecord` Extensional Uniqueness (`r1 = r2 ↔ E_B4 r1 = E_B4 r2`)**. -/
theorem T_D0_A4_04_SpineUniqueness
    (ctx : B4SharedContext) (r1 r2 : B4QualifiedRecord ctx) :
    r1 = r2 ↔ extractB4Spine r1 = extractB4Spine r2 := by
  constructor
  · intro h; rw [h]
  · intro hSp
    unfold extractB4Spine at hSp
    rcases r1 with ⟨sp1, q1, cs1, g1_1, oa1, gf1, jd1, h2348_1, h56_1, h7_1, hcs1, hoa1, hgf1, hjd1⟩
    rcases r2 with ⟨sp2, q2, cs2, g1_2, oa2, gf2, jd2, h2348_2, h56_2, h7_2, hcs2, hoa2, hgf2, hjd2⟩
    dsimp only at hSp
    subst hSp
    have hq : q1 = q2 := by
      rcases q1 with ⟨qg1_1, qs2348_1, qg56_1, qg7_1, qgf1⟩
      rcases q2 with ⟨qg1_2, qs2348_2, qg56_2, qg7_2, qgf2⟩
      cases qg1_1; cases qg1_2
      cases qgf1; cases qgf2
      cases qs2348_1 with
      | mkVerified c1 =>
          cases qs2348_2 with
          | mkVerified c2 =>
              cases qg56_1 with
              | mkVerified d1 =>
                  cases qg56_2 with
                  | mkVerified d2 =>
                      cases qg7_1 with
                      | mkVerified e1 =>
                          cases qg7_2 with
                          | mkVerified e2 =>
                              dsimp [extractSlot2348Summary] at h2348_1 h2348_2
                              dsimp [extractSlot56Cert] at h56_1 h56_2
                              dsimp [extractSlot7Bundle] at h7_1 h7_2
                              have hc : c1 = c2 := Subtype.ext (h2348_1.trans h2348_2.symm)
                              have hd : d1 = d2 := Subtype.ext (h56_1.trans h56_2.symm)
                              have he : e1 = e2 := Subtype.ext (h7_1.trans h7_2.symm)
                              subst hc; subst hd; subst he
                              rfl
    have hcs : cs1 = cs2 := by
      cases cs1 with
      | mkVerified a1 =>
          cases cs2 with
          | mkVerified a2 =>
              dsimp only at hcs1 hcs2
              have ha : a1 = a2 := Subtype.ext (hcs1.trans hcs2.symm)
              subst ha; rfl
    have hg1 : g1_1 = g1_2 := slotUnchecked_unique _ _
    have hoa : oa1 = oa2 := hoa1.trans hoa2.symm
    have hgf : gf1 = gf2 := hgf1.trans hgf2.symm
    have hjd : jd1 = jd2 := hjd1.trans hjd2.symm
    subst hq; subst hcs; subst hg1; subst hoa; subst hgf; subst hjd
    rfl

/-- **`T_D0_A4_03` — Bidirectional Spine Reification Roundtrip (`E_B4 ∘ Q_B4 = id` & `Q_B4 ∘ E_B4 = id`)**. -/
theorem T_D0_A4_03_SpineRoundtrip (ctx : B4SharedContext) :
    (∀ sp : B4CanonicalSpine ctx, extractB4Spine (reifyB4Spine ctx sp) = sp) ∧
    (∀ rec : B4QualifiedRecord ctx, reifyB4Spine ctx (extractB4Spine rec) = rec) := by
  refine ⟨fun _ => rfl, ?_⟩
  intro rec
  exact (T_D0_A4_04_SpineUniqueness ctx _ _).mpr rfl

/-- **`T_D0_A4_06` — Declarative Semantic Equivalence Between Spine & 3-Tuple (`0` Checker Calls)**. -/
theorem T_D0_A4_06_SemanticPreservation
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    SemValidB4Spine ctx sp ↔
    SemValidB4ThreeTuple ctx sp.slice2348 sp.slice56 sp.slice7 := by
  unfold SemValidB4Spine SemValidB4ThreeTuple B4CanonicalSpine.toPayload
  have h12 : projValidSlice2348 sp.slice2348 = projValidSlice56 sp.slice56 :=
    sp.fiber2348.2.trans sp.fiber56.2.symm
  have h23 : projValidSlice56 sp.slice56 = projValidSlice7 sp.slice7 :=
    sp.fiber56.2.trans sp.fiber7.2.symm
  have hBase1 : sp.slice2348.1.1.claimedBase = sp.base.1 :=
    congrArg Subtype.val sp.fiber2348.2
  rw [hBase1]
  exact ⟨fun h => ⟨h12, h23, h⟩, fun h => h.2.2⟩

/-- Spine extensionality lemma: two spines with equal `base` and equal underlying valid slices are equal. -/
theorem spine_ext {ctx : B4SharedContext} {a b : B4CanonicalSpine ctx}
    (hBase : a.base = b.base)
    (hs1   : a.slice2348 = b.slice2348)
    (hs2   : a.slice56 = b.slice56)
    (hs3   : a.slice7 = b.slice7) :
    a = b := by
  rcases a with ⟨ba, ⟨f1a, p1a⟩, ⟨f2a, p2a⟩, ⟨f3a, p3a⟩⟩
  rcases b with ⟨bb, ⟨f1b, p1b⟩, ⟨f2b, p2b⟩, ⟨f3b, p3b⟩⟩
  dsimp [B4CanonicalSpine.slice2348, B4CanonicalSpine.slice56, B4CanonicalSpine.slice7] at hBase hs1 hs2 hs3
  subst hBase; subst hs1; subst hs2; subst hs3
  rfl

/-- Universal mediating map into `B4CanonicalSpine ctx` from any commuting 3-cone over `B4ValidBase`. -/
def liftThreeConeToSpine {X : Type} {ctx : B4SharedContext}
    (f0 : X → B4ValidBase)
    (f1 : X → ValidSlice2348 ctx)
    (f2 : X → ValidSlice56 ctx)
    (f3 : X → ValidSlice7 ctx)
    (h1 : ∀ x : X, projValidSlice2348 (f1 x) = f0 x)
    (h2 : ∀ x : X, projValidSlice56 (f2 x) = f0 x)
    (h3 : ∀ x : X, projValidSlice7 (f3 x) = f0 x) :
    X → B4CanonicalSpine ctx :=
  fun x => {
    base      := f0 x
    fiber2348 := ⟨f1 x, h1 x⟩
    fiber56   := ⟨f2 x, h2 x⟩
    fiber7    := ⟨f3 x, h3 x⟩
  }

/-- **`T_D0_A4_07` — Three-Slot Universal Property Over `B4ValidBase` (`T23 §Ⅳ.1` Projection-Preserving Uniqueness)**:
    For any type `X`, valid base map `f0 : X → B4ValidBase`, and commuting 3-cone `(f1, f2, f3)`,
    `u := liftThreeConeToSpine ...` factors `f0, f1, f2, f3` AND is the UNIQUE map `u' : X → B4CanonicalSpine ctx`
    preserving `(base, slice2348, slice56, slice7)` projections! -/
theorem T_D0_A4_07_ThreeSlotUniversalProperty
    {X : Type} (ctx : B4SharedContext)
    (f0 : X → B4ValidBase)
    (f1 : X → ValidSlice2348 ctx)
    (f2 : X → ValidSlice56 ctx)
    (f3 : X → ValidSlice7 ctx)
    (h1 : ∀ x : X, projValidSlice2348 (f1 x) = f0 x)
    (h2 : ∀ x : X, projValidSlice56 (f2 x) = f0 x)
    (h3 : ∀ x : X, projValidSlice7 (f3 x) = f0 x) :
    let u := liftThreeConeToSpine f0 f1 f2 f3 h1 h2 h3
    (∀ x : X,
       (u x).base = f0 x ∧
       (u x).slice2348 = f1 x ∧
       (u x).slice56 = f2 x ∧
       (u x).slice7 = f3 x) ∧
    (∀ u' : X → B4CanonicalSpine ctx,
       (∀ x : X,
          (u' x).base = f0 x ∧
          (u' x).slice2348 = f1 x ∧
          (u' x).slice56 = f2 x ∧
          (u' x).slice7 = f3 x) →
       ∀ x : X, u' x = u x) := by
  refine ⟨fun _ => ⟨rfl, rfl, rfl, rfl⟩, ?_⟩
  intro u' hu' x
  rcases hu' x with ⟨hb, hs1, hs2, hs3⟩
  exact spine_ext hb hs1 hs2 hs3

/-- Abstract `CE-B4-20` model proving unrestricted binary pullback is NON-bijective with valid spine
    when an invalid base `false` is inhabited (`F-B4-T22-01` necessity contrast). -/
def ce20_rawBaseValid : Bool → Prop := fun b => b = true
def ce20_rawLeftPullback : Type :=
  { p : { p12 : Bool × Bool // p12.1 = p12.2 } × Bool // p.1.1.2 = p.2 }
def ce20_validSpine : Type :=
  Σ (t : { b : Bool // ce20_rawBaseValid b }),
    { a : Bool // a = t.1 ∧ a = false }

theorem ce20_unrestrictedPullback_mismatch :
    Nonempty ce20_rawLeftPullback ∧ ¬ Nonempty ce20_validSpine := by
  refine ⟨⟨⟨(⟨(false, false), rfl⟩, false), rfl⟩⟩, ?_⟩
  rintro ⟨⟨⟨b, hb⟩, ⟨a, ha1, ha2⟩⟩⟩
  dsimp only at ha1
  dsimp [ce20_rawBaseValid] at hb
  rw [hb] at ha1
  rw [ha1] at ha2
  nomatch ha2

/-- **`T_D0_A5_01` — Exact Domain-Aligned Left / Spine / Right Associativity Bijections Over `B4ValidBase` (`F-B4-T22-01`)**. -/
theorem T_D0_A5_01_LeftRightSpineBijection (ctx : B4SharedContext) :
    (∀ pL : B4LeftPullback ctx, leftOfSpine (spineOfLeft pL) = pL) ∧
    (∀ sp : B4CanonicalSpine ctx, spineOfLeft (leftOfSpine sp) = sp) ∧
    (∀ pR : B4RightPullback ctx, rightOfSpine (spineOfRight pR) = pR) ∧
    (∀ sp : B4CanonicalSpine ctx, spineOfRight (rightOfSpine sp) = sp) ∧
    (∀ pL : B4LeftPullback ctx, assocRightToLeft (assocLeftToRight pL) = pL) ∧
    (∀ pR : B4RightPullback ctx, assocLeftToRight (assocRightToLeft pR) = pR) := by
  have hLS : ∀ pL : B4LeftPullback ctx, leftOfSpine (spineOfLeft pL) = pL := by
    rintro ⟨⟨⟨⟨s1, s2⟩, h12⟩, s3⟩, h23⟩
    rfl
  have hSL : ∀ sp : B4CanonicalSpine ctx, spineOfLeft (leftOfSpine sp) = sp := by
    intro sp
    exact spine_ext sp.fiber2348.2 rfl rfl rfl
  have hRS : ∀ pR : B4RightPullback ctx, rightOfSpine (spineOfRight pR) = pR := by
    rintro ⟨⟨s1, ⟨⟨s2, s3⟩, h23⟩⟩, h12⟩
    rfl
  have hSR : ∀ sp : B4CanonicalSpine ctx, spineOfRight (rightOfSpine sp) = sp := by
    intro sp
    exact spine_ext sp.fiber2348.2 rfl rfl rfl
  refine ⟨hLS, hSL, hRS, hSR, ?_, ?_⟩
  · intro pL
    unfold assocRightToLeft assocLeftToRight
    rw [hSR, hLS]
  · intro pR
    unfold assocLeftToRight assocRightToLeft
    rw [hSL, hRS]

/-- **`T_D0_A5_02` — Associator Semantic & Premise-Footprint Invariance (`CE-B4-05` Blocked)**. -/
theorem T_D0_A5_02_AssociatorSemanticAndDepsInvariance
    (ctx : B4SharedContext) (pL : B4LeftPullback ctx) :
    let spL := spineOfLeft pL
    let spR := spineOfRight (assocLeftToRight pL)
    spR = spL ∧
    (SemValidB4Spine ctx spL ↔ SemValidB4Spine ctx spR) ∧
    deriveSpineB4PrimDeps ctx spL = deriveSpineB4PrimDeps ctx spR := by
  dsimp only
  have hEq : spineOfRight (assocLeftToRight pL) = spineOfLeft pL :=
    (T_D0_A5_01_LeftRightSpineBijection ctx).2.2.2.1 (spineOfLeft pL)
  rw [hEq]
  exact ⟨rfl, Iff.rfl, rfl⟩

/-- **`T_D0_A5_03` — 4-Clause Spine Coherence Equality Decomposition (`SameBase ∧ SameSlots ∧ SameBinding ∧ SameDeps`)**. -/
theorem T_D0_A5_03_SpineCoherenceDecomposition
    (ctx : B4SharedContext) (a b : B4CanonicalSpine ctx) :
    a = b ↔
      (a.base = b.base ∧
       (a.ast = b.ast ∧ extractSummary a.sq2348 = extractSummary b.sq2348 ∧
        a.c56 = b.c56 ∧ a.bundle7 = b.bundle7 ∧ a.bridgeMode = b.bridgeMode) ∧
       a.base.1.toG56Binding = b.base.1.toG56Binding ∧
       deriveSpineB4PrimDeps ctx a = deriveSpineB4PrimDeps ctx b) := by
  constructor
  · intro h; subst h; exact ⟨rfl, ⟨rfl, rfl, rfl, rfl, rfl⟩, rfl, rfl⟩
  · rintro ⟨hBase, ⟨hAst, hSum, hC56, hBun, hMode⟩, _, _⟩
    have hBaseVal : a.base.1 = b.base.1 := congrArg Subtype.val hBase
    have hCb1 : a.slice2348.1.1.claimedBase = b.slice2348.1.1.claimedBase := by
      have ha := congrArg Subtype.val a.fiber2348.2
      have hb := congrArg Subtype.val b.fiber2348.2
      exact ha.trans (hBaseVal.trans hb.symm)
    have hCb2 : a.slice56.1.1.claimedBase = b.slice56.1.1.claimedBase := by
      have ha := congrArg Subtype.val a.fiber56.2
      have hb := congrArg Subtype.val b.fiber56.2
      exact ha.trans (hBaseVal.trans hb.symm)
    have hCb3 : a.slice7.1.1.claimedBase = b.slice7.1.1.claimedBase := by
      have ha := congrArg Subtype.val a.fiber7.2
      have hb := congrArg Subtype.val b.fiber7.2
      exact ha.trans (hBaseVal.trans hb.symm)
    have hs1Raw : a.slice2348.1.1 = b.slice2348.1.1 :=
      provenanceSlice2348_ext hAst hSum hCb1
    have hs2Raw : a.slice56.1.1 = b.slice56.1.1 := by
      rcases h1 : a.slice56.1.1 with ⟨c1, cb1⟩
      rcases h2 : b.slice56.1.1 with ⟨c2, cb2⟩
      have hcEq : c1 = c2 := by
        have x1 : a.c56 = c1 := by unfold B4CanonicalSpine.c56; rw [h1]
        have x2 : b.c56 = c2 := by unfold B4CanonicalSpine.c56; rw [h2]
        exact x1.symm.trans (hC56.trans x2)
      have hcbEq : cb1 = cb2 := by
        rw [h1, h2] at hCb2; exact hCb2
      subst hcEq; subst hcbEq; rfl
    have hs3Raw : a.slice7.1.1 = b.slice7.1.1 := by
      rcases h1 : a.slice7.1.1 with ⟨bn1, cb1, bm1⟩
      rcases h2 : b.slice7.1.1 with ⟨bn2, cb2, bm2⟩
      have hbnEq : bn1 = bn2 := by
        have x1 : a.bundle7 = bn1 := by unfold B4CanonicalSpine.bundle7; rw [h1]
        have x2 : b.bundle7 = bn2 := by unfold B4CanonicalSpine.bundle7; rw [h2]
        exact x1.symm.trans (hBun.trans x2)
      have hcbEq : cb1 = cb2 := by rw [h1, h2] at hCb3; exact hCb3
      have hbmEq : bm1 = bm2 := by
        have x1 : a.bridgeMode = bm1 := by unfold B4CanonicalSpine.bridgeMode; rw [h1]
        have x2 : b.bridgeMode = bm2 := by unfold B4CanonicalSpine.bridgeMode; rw [h2]
        exact x1.symm.trans (hMode.trans x2)
      subst hbnEq; subst hcbEq; subst hbmEq; rfl
    exact spine_ext hBase
      (Subtype.ext (Subtype.ext hs1Raw))
      (Subtype.ext (Subtype.ext hs2Raw))
      (Subtype.ext (Subtype.ext hs3Raw))

/-- Forged raw diagnostic observation (`CE-B4-13`) with all flags set to `true` and `firstError? = none`. -/
def spoofedB4DiagObs : B4DiagnosticObservation where
  sharedEnvAndDagOk   := true
  transitionAlignedOk := true
  validBaseOk         := true
  slice2348Ok         := true
  slice56Ok           := true
  slice7Ok            := true
  compositeDepsOk     := true
  firstError?         := none

/-- **`T_D0_A12_01` — Unbound Diagnostic Projection Spoofability Contrast (`CE-B4-13`)**. -/
theorem T_D0_A12_01_UnboundDiagnosticSpoofableContrast
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (hInvalid : checkB4CompositeBool ctx pkt = false) :
    projectUnboundB4DiagPassBool spoofedB4DiagObs = true ∧
    checkB4CompositeBool ctx pkt = false :=
  ⟨rfl, hInvalid⟩

/-- **`T_D0_A12_02` — Provenance-Bound `B4` Consumer Exactness (`consumeBoundB4Verdict = true ↔ isSome`)**. -/
theorem T_D0_A12_02_ProvenanceBoundB4ConsumerSoundness
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (d : ProvenanceBoundB4Diagnostic ctx pkt) :
    consumeBoundB4Verdict d = true ↔ (qualifyB4Composite? ctx pkt).isSome = true := by
  rw [(T_D0_A4_01_SpineExistence ctx pkt).1]
  unfold consumeBoundB4Verdict
  rw [d.hProv]
  unfold projectUnboundB4DiagPassBool evalB4Detailed checkB4CompositeBool
  dsimp only
  constructor
  · intro h
    simp only [Bool.and_eq_true] at h
    exact h.2
  · intro hNone
    have u := unpack_checkB4CompositeBool hNone
    have hvB : checkValidB4TransitionBaseBool pkt.s2348.claimedBase = true :=
      (checkValidB4TransitionBaseBool_iff _).mpr u.2.2.2.2.1
    have hvB7 : checkValidB4TransitionBaseBool pkt.s7.claimedBase = true := by
      rwa [u.2.2.1, u.2.2.2.1] at hvB
    simp [u.1, u.2.1, u.2.2.1, u.2.2.2.1, hvB7,
          u.2.2.2.2.2.1, u.2.2.2.2.2.2.1, u.2.2.2.2.2.2.2.1, u.2.2.2.2.2.2.2.2, hNone]

/-- **`T_D0_A14_01` — Authority Firewall Part 1: 3 Verified Slots with `G1` Unchecked & Registry Unauthenticated**. -/
theorem T_D0_A14_01_ThreeVerifiedSlotsWithG1Unchecked
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx) :
    rec.threeSlotQual.slotG1 = .mkUnchecked ∧
    rec.g1IntegritySlot = .mkUnchecked ∧
    rec.officialRegistryAuth = false ∧
    (∃ s2348, checkG2348SummaryBool s2348 = true) ∧
    (∃ c56, isG56CouplingVerifiedBool ctx.toG56Context c56 = true) ∧
    (∃ b7, checkCertifiedG7BundleBool b7 = true) := by
  refine ⟨slotUnchecked_unique _ _, slotUnchecked_unique _ _, rec.hOfficialAuth_eq_false,
          verified_slot_has_checked_cert rec.threeSlotQual.slot2348,
          verified_slot_has_checked_cert rec.threeSlotQual.slotG56,
          verified_slot_has_checked_cert rec.threeSlotQual.slotG7⟩

/-- **`T_D0_A14_02` — Authority Firewall Part 2: `FullReflexAdmitted` Remains Provably Empty in `B4`**. -/
theorem T_D0_A14_02_FullReflexAdmittedStillEmptyInB4 (ctx : B4SharedContext) :
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool
        (isG56CouplingVerifiedBool ctx.toG56Context)
        checkCertifiedG7BundleBool) :=
  (T_I0_A7_ZeroAuthorityAndNoFullReflex ctx.toG56Context).2

/-- Predicate restricting ledger events to epistemic events (`0` institutional grant minting/revocation). -/
def isEpistemicOnlyEventBool : StructuralLedgerEvent → Bool
  | .recordStructuralReflex _ => true
  | .retractPremise _         => true
  | .advanceEpoch _           => true
  | .issueGrantHeld _         => false
  | .revokeGrantHeld _        => false

private theorem foldl_grantLedger_epistemic_inv (st : StructuralLedgerState) :
    ∀ (ΔL : List StructuralLedgerEvent),
      (∀ ev ∈ ΔL, isEpistemicOnlyEventBool ev = true) →
      (ΔL.foldl stepStructuralLedger st).grantLedger = st.grantLedger
  | [], _ => rfl
  | ev :: tail, hAll => by
      have hHead := hAll ev (List.mem_cons_self ..)
      have hStep : (stepStructuralLedger st ev).grantLedger = st.grantLedger := by
        cases ev <;> simp [isEpistemicOnlyEventBool, stepStructuralLedger, stepGrantLedgerState] at hHead ⊢
      dsimp only [List.foldl]
      rw [foldl_grantLedger_epistemic_inv (stepStructuralLedger st ev) tail
            (fun x hx => hAll x (List.mem_cons_of_mem ev hx)),
          hStep]

/-- **`T_D0_A14_03` — Authority Firewall Part 3: Zero Institutional Grant Escalation Across All `B4` Commits**. -/
theorem T_D0_A14_03_ZeroGrantEscalationAcrossB4Commits
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx)
    (L ΔL_ep : List StructuralLedgerEvent)
    (hEpOnly : ∀ ev ∈ ΔL_ep, isEpistemicOnlyEventBool ev = true) :
    rec.grantFlag = .noGrantFromMathCheck ∧
    rec.threeSlotQual.grantFlag = .noGrantFromMathCheck ∧
    (foldStructuralLedger (L ++ ΔL_ep)).grantLedger = (foldStructuralLedger L).grantLedger := by
  have hQgf : rec.threeSlotQual.grantFlag = .noGrantFromMathCheck := by
    cases rec.threeSlotQual.grantFlag; rfl
  refine ⟨rec.hGrant_eq, hQgf, ?_⟩
  unfold foldStructuralLedger
  rw [List.foldl_append]
  exact foldl_grantLedger_epistemic_inv _ ΔL_ep hEpOnly

end OmegaCellC1P1B2BB4
