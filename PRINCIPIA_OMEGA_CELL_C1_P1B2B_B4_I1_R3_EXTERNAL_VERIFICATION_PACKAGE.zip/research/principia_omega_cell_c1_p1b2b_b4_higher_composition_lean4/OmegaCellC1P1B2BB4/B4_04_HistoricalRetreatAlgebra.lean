/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Certified Higher Composition & Historical Retreat Algebra (`ACT-I0`)
  Module: OmegaCellC1P1B2BB4.B4_04_HistoricalRetreatAlgebra

  Gates & Binding Conditions Covered:
    - `I0-A8` (`F-B4-T22-06`, `Q-B4-R1-03`, `F-B4-T23-04`):
      * Strict type separation between `P_env : PrimPremiseEnv` and step-varying guard list
        `G_k : List StrictForm` (`B4EffDomSpec`, `T_I0_T23_04`, `CE-B4-33`).
      * `CanonCutPair`, `CutPairEquivInEnv P_env`, `Equivalence`, `joinCanonCutPair` congruence
        (`T_D0_R1_04`), join-semilattice with least element `botCanonCutPair = ([], [])` (`T_D0_A7_01`).
      * Typed partial temporal step composition (`T_D0_A7_02`, `T_D0_A7_04`, `T_D0_A2_04`) and
        indelible append-only `E_historical` (`T_D0_A7_03`, `CE-B4-18`).
    - `I0-A9` (`F-B4-T22-07`):
      * Base-case `ValidInitialB4ChainState` (`E_0 = []`) + mandatory per-step `StepDomainAccountingWitness`
        (`SemSameEffDom` with `ΔΦ = []` OR `SemExactScopeLossPartition` with `ΔΦ = Φ_shared`).
      * Multi-step exact loss partition composition (`T_D0_A8_01`), No Silent Scope Resurrection
        (`T_D0_A8_02`), executable monotone chain gate (`T_D0_A8_03`, `CE-B4-07`), and unrecorded
        shrinkage refutation (`CE-B4-25`).
-/
import OmegaCellC1P1B2BB4.B4_03_JointClosureAndCoherentRebind

namespace OmegaCellC1P1B2BB4

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ### 1. Step Effective Domain `B4EffDomSpec` vs `P_env : PrimPremiseEnv` (`F-B4-T23-04`) -/

/-- Step-$k$ domain & guard specification `(D_k : G7DomTag, G_k : List StrictForm)`, strictly distinct
    at the type level from `P_env : PrimPremiseEnv` (`F-B4-T23-04`). -/
structure B4EffDomSpec where
  domTag : G7DomTag
  guards : List StrictForm
  deriving DecidableEq, Repr

/-- Point-set membership `X_k(ρ) := InEffDom D_k G_k ρ` on fixed reference space `Env2 = Rat × Rat`. -/
def InB4EffDom (d : B4EffDomSpec) (ρ : Env2) : Prop :=
  InEffDom d.domTag d.guards ρ

/-- **`T_I0_T23_04` — Orthogonality of `PrimPremiseEnv` (`P_env`) vs Step Guard Environment (`G_k`) (`F-B4-T23-04`, `CE-B4-33`)**:
    (1) Under fixed `P_env = []`, changing step guard list `[]` to `[.pos .varX]` strictly shrinks
        `InB4EffDom` at `(0, 0)` (`true` vs `false`);
    (2) Under fixed `G_k = []`, changing `P_env` from `0 = 0` to `0 > 0` flips `SemValidPrimId P_env "p"`
        while leaving `InB4EffDom ⟨.domQ, []⟩` completely unchanged across all `ρ : Env2`! -/
theorem T_I0_T23_04_PrimEnvVsGuardEnvOrthogonality :
    let d0 : B4EffDomSpec := ⟨.domQ, []⟩
    let d1 : B4EffDomSpec := ⟨.domQ, [.pos .varX]⟩
    let P_true  : PrimPremiseEnv := [⟨"p", .domQ, "s", .eqZero (.const 0), []⟩]
    let P_false : PrimPremiseEnv := [⟨"p", .domQ, "s", .pos (.const 0), []⟩]
    (InB4EffDom d0 (0, 0) ∧ ¬ InB4EffDom d1 (0, 0)) ∧
    (SemValidPrimId P_true "p" ∧ ¬ SemValidPrimId P_false "p" ∧
     ∀ ρ : Env2, InB4EffDom d0 ρ ↔ InEffDom .domQ [] ρ) := by
  dsimp only
  refine ⟨⟨⟨rfl, trivial, fun _ h => nomatch h⟩, ?_⟩, ⟨?_, ?_, fun _ => Iff.rfl⟩⟩
  · intro hEff
    have hm := hEff.2.2 (.pos .varX) (List.mem_cons_self ..)
    rcases hm.2 with ⟨v, hv, hPos⟩
    cases hv
    exact Rat.lt_irrefl hPos
  · intro e he ρ _
    unfold lookupPrimPrem? at he
    dsimp [List.find?] at he
    injection he with hEq; subst hEq
    exact ⟨⟨0, .const 0 ρ⟩, ⟨0, .const 0 ρ, rfl⟩⟩
  · intro hSem
    have hEntry : lookupPrimPrem? [⟨"p", .domQ, "s", .pos (.const 0), []⟩] "p" =
        some ⟨"p", .domQ, "s", .pos (.const 0), []⟩ := rfl
    have hm := hSem _ hEntry (0, 0) rfl
    rcases hm.2 with ⟨v, hv, hPos⟩
    cases hv
    exact Rat.lt_irrefl hPos

/-! ### 2. `CanonCutPair`, `CutPairEquivInEnv`, & Join-Semilattice Laws (`F-B4-T22-06`, `Q-B4-R1-03`) -/

/-- Canonical cut pair `(Φ : ExcisedLocus, P : List String)` with `isStrictCanonStrList P = true`. -/
abbrev CanonCutPair : Type :=
  { c : ExcisedLocus × List String // isStrictCanonStrList c.2 = true }

/-- Least element `⊥ = ([], [])` of `CanonCutPair`. -/
def botCanonCutPair : CanonCutPair :=
  ⟨([], []), rfl⟩

/-- Binary join `(Φ1, P1) ⊔ (Φ2, P2) := (Φ1 ++ Φ2, canonSortStrs (P1 ++ P2))`. -/
def joinCanonCutPair (c1 c2 : CanonCutPair) : CanonCutPair :=
  ⟨(c1.1.1 ++ c2.1.1, canonSortStrs (c1.1.2 ++ c2.1.2)),
   (canonSortStrs_canonical_laws _).2.1⟩

/-- Environment-indexed product cut equivalence `c1 ~_{P_env} c2` (`F-B4-T22-06`, `Q-B4-R1-03`). -/
def CutPairEquivInEnv (P_env : PrimPremiseEnv) (c1 c2 : CanonCutPair) : Prop :=
  (∀ ρ : Env2, ModelsExcised c1.1.1 ρ ↔ ModelsExcised c2.1.1 ρ) ∧
  c1.1.2 = c2.1.2 ∧
  c1.1.2.map (lookupPrimPrem? P_env) = c2.1.2.map (lookupPrimPrem? P_env)

theorem modelsExcised_append_iff (Φ1 Φ2 : ExcisedLocus) (ρ : Env2) :
    ModelsExcised (Φ1 ++ Φ2) ρ ↔ (ModelsExcised Φ1 ρ ∨ ModelsExcised Φ2 ρ) := by
  unfold ModelsExcised
  constructor
  · rintro ⟨E, hMem, hBr⟩
    rcases List.mem_append.mp hMem with h1 | h2
    · exact Or.inl ⟨E, h1, hBr⟩
    · exact Or.inr ⟨E, h2, hBr⟩
  · rintro (⟨E, h1, hBr⟩ | ⟨E, h2, hBr⟩)
    · exact ⟨E, List.mem_append_left _ h1, hBr⟩
    · exact ⟨E, List.mem_append_right _ h2, hBr⟩

/-- **`T_D0_R1_04` — `CutPairEquivInEnv` Equivalence & `⊔`-Congruence (`F-B4-T22-06`, `Q-B4-R1-03`)**:
    Fixes `P_env : PrimPremiseEnv`: `CutPairEquivInEnv P_env` is an `Equivalence` on `CanonCutPair`,
    and `joinCanonCutPair` (`⊔`) respects `CutPairEquivInEnv P_env`! -/
theorem T_D0_R1_04_CutEquivCongruenceAndEnvIndexing (P_env : PrimPremiseEnv) :
    Equivalence (CutPairEquivInEnv P_env) ∧
    (∀ (c1 c1' c2 c2' : CanonCutPair),
       CutPairEquivInEnv P_env c1 c1' →
       CutPairEquivInEnv P_env c2 c2' →
       CutPairEquivInEnv P_env (joinCanonCutPair c1 c2) (joinCanonCutPair c1' c2')) := by
  refine ⟨?_, ?_⟩
  · exact {
      refl  := fun _ => ⟨fun _ => Iff.rfl, rfl, rfl⟩
      symm  := fun h => ⟨fun ρ => (h.1 ρ).symm, h.2.1.symm, h.2.2.symm⟩
      trans := fun h1 h2 =>
        ⟨fun ρ => (h1.1 ρ).trans (h2.1 ρ), h1.2.1.trans h2.2.1, h1.2.2.trans h2.2.2⟩
    }
  · intro c1 c1' c2 c2' h1 h2
    have hP : canonSortStrs (c1.1.2 ++ c2.1.2) = canonSortStrs (c1'.1.2 ++ c2'.1.2) := by
      rw [h1.2.1, h2.2.1]
    refine ⟨?_, hP, ?_⟩
    · intro ρ
      unfold joinCanonCutPair
      dsimp only
      rw [modelsExcised_append_iff, modelsExcised_append_iff, h1.1 ρ, h2.1 ρ]
    · unfold joinCanonCutPair
      dsimp only
      rw [hP]

/-- **`T_D0_A7_01` — Cut Join-Semilattice with Least Element `⊥ = ([], [])` (`F-B4-T22-06`)**:
    Up to `CutPairEquivInEnv P_env`, `(CanonCutPair, joinCanonCutPair, botCanonCutPair)` satisfies
    idempotence, commutativity, associativity, and syntactic least-element identity (`⊥ ⊔ c = c` and `c ⊔ ⊥ = c`). -/
theorem T_D0_A7_01_CutJoinSemilatticeLaws (P_env : PrimPremiseEnv) :
    (∀ c : CanonCutPair, CutPairEquivInEnv P_env (joinCanonCutPair c c) c) ∧
    (∀ c1 c2 : CanonCutPair, CutPairEquivInEnv P_env (joinCanonCutPair c1 c2) (joinCanonCutPair c2 c1)) ∧
    (∀ c1 c2 c3 : CanonCutPair,
       CutPairEquivInEnv P_env
         (joinCanonCutPair (joinCanonCutPair c1 c2) c3)
         (joinCanonCutPair c1 (joinCanonCutPair c2 c3))) ∧
    (∀ c : CanonCutPair,
       joinCanonCutPair botCanonCutPair c = c ∧
       joinCanonCutPair c botCanonCutPair = c) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro c
    have hP : canonSortStrs (c.1.2 ++ c.1.2) = c.1.2 := by
      have h1 : canonSortStrs (c.1.2 ++ c.1.2) = canonSortStrs c.1.2 := by
        apply (canonSortStrs_eq_iff_mem _ _).mpr
        intro x; simp
      exact h1.trans (canonSortStrs_eq_of_isStrictCanon c.1.2 c.2)
    refine ⟨?_, hP, by unfold joinCanonCutPair; dsimp only; rw [hP]⟩
    intro ρ
    unfold joinCanonCutPair; dsimp only
    rw [modelsExcised_append_iff]
    exact ⟨fun h => h.elim id id, fun h => Or.inl h⟩
  · intro c1 c2
    have hP : canonSortStrs (c1.1.2 ++ c2.1.2) = canonSortStrs (c2.1.2 ++ c1.1.2) := by
      apply (canonSortStrs_eq_iff_mem _ _).mpr
      intro x; rw [List.mem_append, List.mem_append, or_comm]
    refine ⟨?_, hP, by unfold joinCanonCutPair; dsimp only; rw [hP]⟩
    intro ρ
    unfold joinCanonCutPair; dsimp only
    rw [modelsExcised_append_iff, modelsExcised_append_iff, or_comm]
  · intro c1 c2 c3
    have hP : canonSortStrs (canonSortStrs (c1.1.2 ++ c2.1.2) ++ c3.1.2) =
              canonSortStrs (c1.1.2 ++ canonSortStrs (c2.1.2 ++ c3.1.2)) := by
      apply (canonSortStrs_eq_iff_mem _ _).mpr
      intro x
      rw [List.mem_append, List.mem_append, mem_canonSortStrs, mem_canonSortStrs,
          List.mem_append, List.mem_append, or_assoc]
    refine ⟨?_, hP, by unfold joinCanonCutPair; dsimp only; rw [hP]⟩
    intro ρ
    unfold joinCanonCutPair; dsimp only
    rw [modelsExcised_append_iff, modelsExcised_append_iff,
        modelsExcised_append_iff, modelsExcised_append_iff, or_assoc]
  · intro ⟨⟨Φ, P⟩, hCanon⟩
    have hIdem : canonSortStrs P = P := canonSortStrs_eq_of_isStrictCanon P hCanon
    constructor
    · apply Subtype.ext
      unfold joinCanonCutPair botCanonCutPair
      dsimp only [List.nil_append]
      rw [hIdem]
    · apply Subtype.ext
      unfold joinCanonCutPair botCanonCutPair
      dsimp only
      rw [List.append_nil, List.append_nil, hIdem]

/-! ### 3. Typed Partial Temporal Composition & Step-vs-Cumulative Flag Coherence (`I0-A8`) -/

/-- Certified temporal step descriptor for partial path composition (`D0-A7`). -/
structure B4TemporalStep where
  base           : B4CommonTransitionBase
  stepCut        : CanonCutPair
  causalPrimDeps : List String
  hCanonDeps     : isStrictCanonStrList causalPrimDeps = true

/-- Accumulated multi-step temporal path summary. -/
structure B4TemporalComposite where
  baseId                : String
  startCellCid          : String
  endCellCid            : String
  startDom              : B4EffDomSpec
  endDom                : B4EffDomSpec
  startSpecId           : String
  endSpecId             : String
  startEpoch            : Nat
  endEpoch              : Nat
  endPathKey            : StructuralPathKey
  cumulativeHistRetreat : Bool
  accumulatedCut        : CanonCutPair
  causalPrimDeps        : List String
  deriving DecidableEq, Repr

def stepToComposite (s : B4TemporalStep) : B4TemporalComposite where
  baseId                := s.base.baseId
  startCellCid          := s.base.cellOldCid
  endCellCid            := s.base.cellNewCid
  startDom              := ⟨s.base.domOld, s.base.guardsOld⟩
  endDom                := ⟨s.base.domNew, s.base.guardsNew⟩
  startSpecId           := s.base.specOldId
  endSpecId             := s.base.specNewId
  startEpoch            := s.base.assignedEvalEpoch
  endEpoch              := s.base.assignedEvalEpoch
  endPathKey            := s.base.pathKey
  cumulativeHistRetreat := s.base.cumulativeHistRetreat
  accumulatedCut        := s.stepCut
  causalPrimDeps        := s.causalPrimDeps

/-- Executable composability guard between consecutive temporal steps `s1 ; s2`. -/
def checkStepComposableBool (s1 s2 : B4TemporalStep) : Bool :=
  (s1.base.baseId == "base_Q") &&
  (s2.base.baseId == "base_Q") &&
  (s1.base.baseId == s2.base.baseId) &&
  (s1.base.cellNewCid == s2.base.cellOldCid) &&
  (s1.base.domNew == s2.base.domOld) &&
  (s1.base.domNewId == s2.base.domOldId) &&
  (s1.base.guardsNew == s2.base.guardsOld) &&
  (s1.base.specNewId == s2.base.specOldId) &&
  (s2.base.parentPathKey? == some s1.base.pathKey) &&
  decide (s1.base.assignedEvalEpoch < s2.base.assignedEvalEpoch) &&
  (s2.base.cumulativeHistRetreat == (s1.base.cumulativeHistRetreat || s2.base.stepRequiresRetreat))

/-- Compose a `B4TemporalComposite` prefix with a composable next `B4TemporalStep`. -/
def checkCompositeStepComposableBool (c : B4TemporalComposite) (s : B4TemporalStep) : Bool :=
  (c.baseId == "base_Q") &&
  (s.base.baseId == "base_Q") &&
  (c.baseId == s.base.baseId) &&
  (c.endCellCid == s.base.cellOldCid) &&
  (c.endDom.domTag == s.base.domOld) &&
  (c.endDom.guards == s.base.guardsOld) &&
  (c.endSpecId == s.base.specOldId) &&
  (s.base.parentPathKey? == some c.endPathKey) &&
  decide (c.endEpoch < s.base.assignedEvalEpoch) &&
  (s.base.cumulativeHistRetreat == (c.cumulativeHistRetreat || s.base.stepRequiresRetreat))

def appendStepToComposite (c : B4TemporalComposite) (s : B4TemporalStep) : B4TemporalComposite where
  baseId                := c.baseId
  startCellCid          := c.startCellCid
  endCellCid            := s.base.cellNewCid
  startDom              := c.startDom
  endDom                := ⟨s.base.domNew, s.base.guardsNew⟩
  startSpecId           := c.startSpecId
  endSpecId             := s.base.specNewId
  startEpoch            := c.startEpoch
  endEpoch              := s.base.assignedEvalEpoch
  endPathKey            := s.base.pathKey
  cumulativeHistRetreat := s.base.cumulativeHistRetreat
  accumulatedCut        := joinCanonCutPair c.accumulatedCut s.stepCut
  causalPrimDeps        := canonSortStrs (c.causalPrimDeps ++ s.causalPrimDeps)

def prependStepToComposite (s : B4TemporalStep) (c : B4TemporalComposite) : B4TemporalComposite where
  baseId                := s.base.baseId
  startCellCid          := s.base.cellOldCid
  endCellCid            := c.endCellCid
  startDom              := ⟨s.base.domOld, s.base.guardsOld⟩
  endDom                := c.endDom
  startSpecId           := s.base.specOldId
  endSpecId             := c.endSpecId
  startEpoch            := s.base.assignedEvalEpoch
  endEpoch              := c.endEpoch
  endPathKey            := c.endPathKey
  cumulativeHistRetreat := c.cumulativeHistRetreat
  accumulatedCut        := joinCanonCutPair s.stepCut c.accumulatedCut
  causalPrimDeps        := canonSortStrs (s.causalPrimDeps ++ c.causalPrimDeps)

/-- **`T_D0_A7_02` — Typed Partial Temporal Composition Exact Associativity**:
    Whenever `checkStepComposableBool s1 s2 = true` and `checkStepComposableBool s2 s3 = true`,
    `((s1 ; s2) ; s3)` and `(s1 ; (s2 ; s3))` produce IDENTICAL `B4TemporalComposite` records
    (`=` on endpoints, epochs, cumulative retreat flag, accumulated `CanonCutPair`, and `D_causal`)! -/
theorem T_D0_A7_02_TypedPartialCompositionAssociativity
    (s1 s2 s3 : B4TemporalStep)
    (h12 : checkStepComposableBool s1 s2 = true)
    (h23 : checkStepComposableBool s2 s3 = true) :
    checkCompositeStepComposableBool (appendStepToComposite (stepToComposite s1) s2) s3 = true ∧
    appendStepToComposite (appendStepToComposite (stepToComposite s1) s2) s3 =
    prependStepToComposite s1 (appendStepToComposite (stepToComposite s2) s3) := by
  unfold checkStepComposableBool at h12 h23
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at h12 h23
  have hb1 : s1.base.baseId = "base_Q" := h12.1.1.1.1.1.1.1.1.1.1
  have hb2 : s2.base.baseId = "base_Q" := h12.1.1.1.1.1.1.1.1.1.2
  refine ⟨?_, ?_⟩
  · unfold checkCompositeStepComposableBool appendStepToComposite stepToComposite
    dsimp only
    rcases h23 with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨_, hb3⟩, _⟩, hc23⟩, hd23⟩, _⟩, hg23⟩, hsp23⟩, hp23⟩, hep23⟩, hcum23⟩
    have hexpB : decide (s2.base.assignedEvalEpoch < s3.base.assignedEvalEpoch) = true :=
      decide_eq_true hep23
    simp [hb1, hb3, hc23, hd23, hg23, hsp23, hp23, hexpB, hcum23]
  · unfold appendStepToComposite prependStepToComposite stepToComposite
    dsimp only
    have hBaseEq : s1.base.baseId = s2.base.baseId := hb1.trans hb2.symm
    have hCutEq : joinCanonCutPair (joinCanonCutPair s1.stepCut s2.stepCut) s3.stepCut =
                  joinCanonCutPair s1.stepCut (joinCanonCutPair s2.stepCut s3.stepCut) := by
      apply Subtype.ext
      unfold joinCanonCutPair
      dsimp only
      rw [List.append_assoc]
      congr 1
      apply (canonSortStrs_eq_iff_mem _ _).mpr
      intro x
      rw [List.mem_append, List.mem_append, mem_canonSortStrs, mem_canonSortStrs,
          List.mem_append, List.mem_append, or_assoc]
    have hDepsEq : canonSortStrs (canonSortStrs (s1.causalPrimDeps ++ s2.causalPrimDeps) ++ s3.causalPrimDeps) =
                   canonSortStrs (s1.causalPrimDeps ++ canonSortStrs (s2.causalPrimDeps ++ s3.causalPrimDeps)) := by
      apply (canonSortStrs_eq_iff_mem _ _).mpr
      intro x
      rw [List.mem_append, List.mem_append, mem_canonSortStrs, mem_canonSortStrs,
          List.mem_append, List.mem_append, or_assoc]
    rw [hBaseEq, hCutEq, hDepsEq]

/-- **`T_D0_A7_04` — Disjoint-Space, Cross-Lineage, & Backwards-Epoch Composition Rejection (`CE-B4-08`, `CE-B4-11`)**. -/
theorem T_D0_A7_04_DisjointSpaceUnionRejection
    (s1 s2 : B4TemporalStep) :
    (s1.base.baseId ≠ "base_Q" ∨ s2.base.baseId ≠ "base_Q" ∨ s1.base.baseId ≠ s2.base.baseId →
       checkStepComposableBool s1 s2 = false) ∧
    (¬ (s1.base.assignedEvalEpoch < s2.base.assignedEvalEpoch) →
       checkStepComposableBool s1 s2 = false) ∧
    (s2.base.parentPathKey? ≠ some s1.base.pathKey →
       checkStepComposableBool s1 s2 = false) := by
  refine ⟨?_, ?_, ?_⟩
  · intro hBad
    apply Bool.eq_false_iff.mpr
    intro hOk
    unfold checkStepComposableBool at hOk
    simp only [Bool.and_eq_true, beq_iff_eq] at hOk
    rcases hBad with h1 | h2 | h12
    · exact h1 hOk.1.1.1.1.1.1.1.1.1.1
    · exact h2 hOk.1.1.1.1.1.1.1.1.1.2
    · exact h12 hOk.1.1.1.1.1.1.1.1.2
  · intro hNotLt
    apply Bool.eq_false_iff.mpr
    intro hOk
    unfold checkStepComposableBool at hOk
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hOk
    exact hNotLt hOk.1.2
  · intro hBadPar
    apply Bool.eq_false_iff.mpr
    intro hOk
    unfold checkStepComposableBool at hOk
    simp only [Bool.and_eq_true, beq_iff_eq] at hOk
    exact hBadPar hOk.1.1.2

/-- **`T_D0_A2_04` — Step vs Cumulative Retreat Flag Coherence (`POS-B4-07`, `CE-B4-11`)**:
    Constructs a valid 2-step `Retreat → Repair` pair `(s1_retreat, s2_repairAfterRetreat)` proving
    that `s2` coherently satisfies `stepRequiresRetreat = false ∧ cumulativeHistRetreat = true`,
    `ValidB4TransitionBase s2.base`, and `checkStepComposableBool s1 s2 = true`! -/
def demoStep1RetreatBase : B4CommonTransitionBase where
  baseId                := "base_Q"
  rflxCid               := "rflx_step1_ret"
  pathKey               := .root "g0" "obst_s1" "g1" "rflx_step1_ret"
  parentPathKey?        := none
  cellOldCid            := "g0"
  obstCid               := "obst_s1"
  cellNewCid            := "g1"
  specOldId             := "spec_v1"
  specNewId             := "spec_v2"
  domOld                := .domQ
  domOldId              := "dom_Q"
  guardsOld             := []
  domNew                := .domQNonzero
  domNewId              := "dom_Q_nonzero"
  guardsNew             := []
  postGoal              := .neqZero .varX
  reflexKind            := .retreat
  stepRequiresRetreat   := true
  cumulativeHistRetreat := true
  assignedEvalEpoch     := 10

def demoStep2RepairAfterRetreatBase : B4CommonTransitionBase where
  baseId                := "base_Q"
  rflxCid               := "rflx_step2_rep"
  pathKey               := .step demoStep1RetreatBase.pathKey "g1" "obst_s2" "g2" "rflx_step2_rep"
  parentPathKey?        := some demoStep1RetreatBase.pathKey
  cellOldCid            := "g1"
  obstCid               := "obst_s2"
  cellNewCid            := "g2"
  specOldId             := "spec_v2"
  specNewId             := "spec_v2"
  domOld                := .domQNonzero
  domOldId              := "dom_Q_nonzero"
  guardsOld             := []
  domNew                := .domQNonzero
  domNewId              := "dom_Q_nonzero"
  guardsNew             := []
  postGoal              := .pos (.mul .varX .varX)
  reflexKind            := .repair
  stepRequiresRetreat   := false
  cumulativeHistRetreat := true
  assignedEvalEpoch     := 15

theorem T_D0_A2_04_StepVsCumulativeRetreatFlagCoherence :
    let s1 : B4TemporalStep := ⟨demoStep1RetreatBase, ⟨([[.eqZero .varX]], []), rfl⟩, [], rfl⟩
    let s2 : B4TemporalStep := ⟨demoStep2RepairAfterRetreatBase, botCanonCutPair, [], rfl⟩
    ValidB4TransitionBase s1.base ∧
    ValidB4TransitionBase s2.base ∧
    s2.base.stepRequiresRetreat = false ∧
    s2.base.cumulativeHistRetreat = true ∧
    (s2.base.toG56Binding).requiresRetreatHistory = false ∧
    checkStepComposableBool s1 s2 = true := by
  dsimp only
  refine ⟨?_, ?_, rfl, rfl, rfl, by decide⟩
  · exact (checkValidB4TransitionBaseBool_iff _).mp (by decide)
  · exact (checkValidB4TransitionBaseBool_iff _).mp (by decide)

/-! ### 4. Historical Excision Log, Per-Step Domain Accounting, & No Silent Resurrection (`I0-A9`, `F-B4-T22-07`) -/

/-- Indelible historical excision event recorded in `E_historical` whenever a retreat step excises `stepExcised`. -/
structure HistoricalExcisionEvent where
  stepRflxCid : String
  stepEpoch   : Nat
  fromDom     : B4EffDomSpec
  toDom       : B4EffDomSpec
  stepExcised : ExcisedLocus
  deriving DecidableEq, Repr

/-- State of a `B4` monotone historical research chain. -/
structure B4HistoricalChainState where
  initialDom          : B4EffDomSpec
  currentDom          : B4EffDomSpec
  currentEpoch        : Nat
  E_historical        : List HistoricalExcisionEvent
  E_currentlyExcluded : ExcisedLocus
  deriving DecidableEq, Repr

/-- Base-case chain invariant at $k = 0$ (`F-B4-T22-07`: `E_0 = []`). -/
def ValidInitialB4ChainState (st0 : B4HistoricalChainState) : Prop :=
  st0.currentDom = st0.initialDom ∧
  st0.E_historical = [] ∧
  st0.E_currentlyExcluded = []

/-- **Mandatory Per-Step Domain-Accounting Witness (`F-B4-T22-07`, blocks `CE-B4-25`!)**:
    Either a certified zero-loss step (`SemSameEffDom` with `ΔΦ = []`) OR a certified exact
    loss-partition step (`SemExactScopeLossPartition` with `ΔΦ = Φ_shared`). -/
def StepDomainAccountingWitness (d_cur d_next : B4EffDomSpec) (ΔΦ : ExcisedLocus) : Prop :=
  (ΔΦ = [] ∧ SemSameEffDom d_cur.domTag d_cur.guards d_next.domTag d_next.guards) ∨
  SemExactScopeLossPartition d_cur.domTag d_cur.guards d_next.domTag d_next.guards ΔΦ

/-- Pure algebraic composition of two consecutive `SemExactScopeLossPartition` steps! -/
theorem semExactScopeLossPartition_compose
    {D0 : G7DomTag} {G0 : List StrictForm}
    {D1 : G7DomTag} {G1 : List StrictForm}
    {D2 : G7DomTag} {G2 : List StrictForm}
    {Φ1 Φ2 : ExcisedLocus}
    (h01 : SemExactScopeLossPartition D0 G0 D1 G1 Φ1)
    (h12 : SemExactScopeLossPartition D1 G1 D2 G2 Φ2) :
    SemExactScopeLossPartition D0 G0 D2 G2 (Φ1 ++ Φ2) := by
  apply mkSemExactScopeLossPartition
  · intro ρ ⟨hIn2, hExc12⟩
    rw [modelsExcised_append_iff] at hExc12
    rcases hExc12 with hExc1 | hExc2
    · exact h01.disjoint_new_excised ρ ⟨h12.new_subset_old ρ hIn2, hExc1⟩
    · exact h12.disjoint_new_excised ρ ⟨hIn2, hExc2⟩
  · intro ρ hIn0
    rcases h01.old_covered_by_new_or_excised ρ hIn0 with hIn1 | hExc1
    · rcases h12.old_covered_by_new_or_excised ρ hIn1 with hIn2 | hExc2
      · exact Or.inl hIn2
      · exact Or.inr ((modelsExcised_append_iff Φ1 Φ2 ρ).mpr (Or.inr hExc2))
    · exact Or.inr ((modelsExcised_append_iff Φ1 Φ2 ρ).mpr (Or.inl hExc1))
  · intro ρ hIn2
    exact h01.new_subset_old ρ (h12.new_subset_old ρ hIn2)

/-- Right-composition of `SemExactScopeLossPartition` with `SemSameEffDom` (`ΔΦ = []`). -/
theorem semExactScopeLossPartition_compose_same
    {D0 : G7DomTag} {G0 : List StrictForm}
    {D1 : G7DomTag} {G1 : List StrictForm}
    {D2 : G7DomTag} {G2 : List StrictForm}
    {Φ1 : ExcisedLocus}
    (h01  : SemExactScopeLossPartition D0 G0 D1 G1 Φ1)
    (h12s : SemSameEffDom D1 G1 D2 G2) :
    SemExactScopeLossPartition D0 G0 D2 G2 Φ1 := by
  apply mkSemExactScopeLossPartition
  · intro ρ ⟨hIn2, hExc1⟩
    exact h01.disjoint_new_excised ρ ⟨(h12s ρ).mpr hIn2, hExc1⟩
  · intro ρ hIn0
    rcases h01.old_covered_by_new_or_excised ρ hIn0 with hIn1 | hExc1
    · exact Or.inl ((h12s ρ).mp hIn1)
    · exact Or.inr hExc1
  · intro ρ hIn2
    exact h01.new_subset_old ρ ((h12s ρ).mpr hIn2)

/-- Deterministic state update for an accounted historical step (`E_historical` strictly append-only!). -/
def applyAccountedChainStep (st : B4HistoricalChainState)
    (rflxCid : String) (nextEpoch : Nat) (nextDom : B4EffDomSpec) (ΔΦ : ExcisedLocus) :
    B4HistoricalChainState where
  initialDom          := st.initialDom
  currentDom          := nextDom
  currentEpoch        := nextEpoch
  E_historical        :=
    if ΔΦ.isEmpty then st.E_historical
    else st.E_historical ++ [⟨rflxCid, nextEpoch, st.currentDom, nextDom, ΔΦ⟩]
  E_currentlyExcluded := st.E_currentlyExcluded ++ ΔΦ

/-- Inductive derivation of a certified monotone historical chain (`k ≥ 0` steps from `st0`). -/
inductive ValidB4MonotoneChain : B4HistoricalChainState → B4HistoricalChainState → Prop where
  | refl {st0 : B4HistoricalChainState} :
      ValidInitialB4ChainState st0 →
      ValidB4MonotoneChain st0 st0
  | step {st0 st : B4HistoricalChainState}
      {rflxCid : String} {nextEpoch : Nat} {nextDom : B4EffDomSpec} {ΔΦ : ExcisedLocus} :
      ValidB4MonotoneChain st0 st →
      st.currentEpoch < nextEpoch →
      StepDomainAccountingWitness st.currentDom nextDom ΔΦ →
      ValidB4MonotoneChain st0 (applyAccountedChainStep st rflxCid nextEpoch nextDom ΔΦ)

/-- **`T_D0_A7_03` — Indelible Append-Only Historical Excision Log (`E_hist(j) <+: E_hist(k)`, `CE-B4-18`)**:
    Across every single step and every multi-step `ValidB4MonotoneChain`, `E_historical` is a prefix
    of its successor (`<+:`), so past excision events can NEVER be deleted or overwritten! -/
theorem T_D0_A7_03_HistoricalExcisionAppendOnly :
    (∀ (st : B4HistoricalChainState) (cid : String) (ep : Nat) (nd : B4EffDomSpec) (ΔΦ : ExcisedLocus),
       st.E_historical <+: (applyAccountedChainStep st cid ep nd ΔΦ).E_historical) ∧
    (∀ {st0 stk : B4HistoricalChainState},
       ValidB4MonotoneChain st0 stk →
       st0.E_historical <+: stk.E_historical) := by
  have hStep : ∀ (st : B4HistoricalChainState) (cid : String) (ep : Nat) (nd : B4EffDomSpec) (ΔΦ : ExcisedLocus),
      st.E_historical <+: (applyAccountedChainStep st cid ep nd ΔΦ).E_historical := by
    intro st cid ep nd ΔΦ
    unfold applyAccountedChainStep
    dsimp only
    split
    · exact ⟨[], List.append_nil _⟩
    · exact ⟨[_], rfl⟩
  refine ⟨hStep, ?_⟩
  intro st0 stk hChain
  induction hChain with
  | refl _ => exact ⟨[], List.append_nil _⟩
  | @step st cid ep nd ΔΦ _ _ _ ih =>
      rcases ih with ⟨t1, ht1⟩
      rcases hStep st cid ep nd ΔΦ with ⟨t2, ht2⟩
      refine ⟨t1 ++ t2, ?_⟩
      rw [← List.append_assoc, ht1, ht2]

/-- **`T_D0_A8_01` — Multi-Step `SemExactScopeLossPartition` Composition & Exact Cumulative Set-Difference (`F-B4-T22-07`, `F-B4-T23-04`)**:
    (1) Algebraic composition of two `SemExactScopeLossPartition` steps yields `SemExactScopeLossPartition`
        over `Φ1 ++ Φ2`;
    (2) Across ANY `k`-step `ValidB4MonotoneChain st0 stk` (`k ≥ 0`), `SemExactScopeLossPartition` holds
        from `st0.initialDom` to `stk.currentDom` with `stk.E_currentlyExcluded`, and
        `∀ ρ : Env2, InB4EffDom stk.currentDom ρ ↔ (InB4EffDom stk.initialDom ρ ∧ ¬ ModelsExcised stk.E_currentlyExcluded ρ)`! -/
theorem T_D0_A8_01_MultiStepExactLossPartitionComposition :
    (∀ {D0 D1 D2 : G7DomTag} {G0 G1 G2 : List StrictForm} {Φ1 Φ2 : ExcisedLocus},
       SemExactScopeLossPartition D0 G0 D1 G1 Φ1 →
       SemExactScopeLossPartition D1 G1 D2 G2 Φ2 →
       SemExactScopeLossPartition D0 G0 D2 G2 (Φ1 ++ Φ2)) ∧
    (∀ {st0 stk : B4HistoricalChainState},
       ValidB4MonotoneChain st0 stk →
       stk.initialDom = st0.initialDom ∧
       SemExactScopeLossPartition
         st0.initialDom.domTag st0.initialDom.guards
         stk.currentDom.domTag stk.currentDom.guards
         stk.E_currentlyExcluded ∧
       (∀ ρ : Env2,
          InB4EffDom stk.currentDom ρ ↔
          (InB4EffDom st0.initialDom ρ ∧ ¬ ModelsExcised stk.E_currentlyExcluded ρ))) := by
  refine ⟨fun h01 h12 => semExactScopeLossPartition_compose h01 h12, ?_⟩
  intro st0 stk hChain
  have hMain :
      stk.initialDom = st0.initialDom ∧
      SemExactScopeLossPartition
        st0.initialDom.domTag st0.initialDom.guards
        stk.currentDom.domTag stk.currentDom.guards
        stk.E_currentlyExcluded := by
    induction hChain with
    | refl hInit =>
        rcases hInit with ⟨hCurEq, _, hExcEmpty⟩
        refine ⟨rfl, ?_⟩
        rw [hCurEq, hExcEmpty]
        apply mkSemExactScopeLossPartition
        · intro ρ ⟨_, hExc⟩; rcases hExc with ⟨_, hMem, _⟩; nomatch hMem
        · intro ρ hIn; exact Or.inl hIn
        · intro ρ hIn; exact hIn
    | @step st cid ep nd ΔΦ _ _ hWit ih =>
        rcases ih with ⟨hInitEq, hPartPrev⟩
        unfold applyAccountedChainStep
        dsimp only
        refine ⟨hInitEq, ?_⟩
        rcases hWit with ⟨hNil, hSame⟩ | hLoss
        · rw [hNil, List.append_nil]
          exact semExactScopeLossPartition_compose_same hPartPrev hSame
        · exact semExactScopeLossPartition_compose hPartPrev hLoss
  refine ⟨hMain.1, hMain.2, ?_⟩
  intro ρ
  unfold InB4EffDom
  constructor
  · intro hInCur
    refine ⟨hMain.2.new_subset_old ρ hInCur, ?_⟩
    intro hExc
    exact hMain.2.disjoint_new_excised ρ ⟨hInCur, hExc⟩
  · rintro ⟨hIn0, hNotExc⟩
    rcases hMain.2.old_covered_by_new_or_excised ρ hIn0 with hInCur | hExc
    · exact hInCur
    · exact False.elim (hNotExc hExc)

/-- **`T_D0_A8_02` — No Silent Scope Resurrection Across All Historical Events (`CE-B4-07`)**:
    In any `ValidB4MonotoneChain st0 stk`, every point `ρ` satisfying `ModelsExcised ev.stepExcised ρ`
    for ANY historical excision event `ev ∈ stk.E_historical` is permanently excluded from `stk.currentDom`! -/
theorem T_D0_A8_02_NoSilentScopeResurrection
    {st0 stk : B4HistoricalChainState}
    (hChain : ValidB4MonotoneChain st0 stk) :
    ∀ ev ∈ stk.E_historical, ∀ ρ : Env2,
      ModelsExcised ev.stepExcised ρ →
      ¬ InB4EffDom stk.currentDom ρ := by
  have hSubLocus : ∀ ev ∈ stk.E_historical, ∀ ρ : Env2,
      ModelsExcised ev.stepExcised ρ → ModelsExcised stk.E_currentlyExcluded ρ := by
    induction hChain with
    | refl hInit =>
        intro ev hMem
        rw [hInit.2.1] at hMem
        nomatch hMem
    | @step st cid ep nd ΔΦ _ _ _ ih =>
        intro ev hMem ρ hModEv
        unfold applyAccountedChainStep at hMem ⊢
        dsimp only at hMem ⊢
        rw [modelsExcised_append_iff]
        by_cases hEmp : ΔΦ.isEmpty = true
        · rw [if_pos hEmp] at hMem
          exact Or.inl (ih ev hMem ρ hModEv)
        · rw [if_neg hEmp] at hMem
          rcases List.mem_append.mp hMem with hOld | hSingle
          · exact Or.inl (ih ev hOld ρ hModEv)
          · rcases List.mem_cons.mp hSingle with rfl | hNil
            · exact Or.inr hModEv
            · nomatch hNil
  have hPart := (T_D0_A8_01_MultiStepExactLossPartitionComposition.2 hChain).2.1
  intro ev hMem ρ hModEv hInCur
  exact hPart.disjoint_new_excised ρ ⟨hInCur, hSubLocus ev hMem ρ hModEv⟩

/-- Executable monotone chain step gate rejecting silent domain re-expansion (`CE-B4-07`). -/
inductive B4MonotoneChainError where
  | epochNotStrictlyIncreasing    : B4MonotoneChainError
  | silentScopeResurrectionBlocked : B4MonotoneChainError
  | uncertifiedRefinementExpansion : B4MonotoneChainError
  deriving DecidableEq, Repr

def evalMonotoneChainStepError? (st : B4HistoricalChainState)
    (stepBase : B4CommonTransitionBase) : Option B4MonotoneChainError :=
  if !(decide (st.currentEpoch < stepBase.assignedEvalEpoch)) then
    some .epochNotStrictlyIncreasing
  else if (st.currentDom.domTag == .domQNonzero) && (stepBase.domNew == .domQ) then
    some .silentScopeResurrectionBlocked
  else if !st.E_currentlyExcluded.isEmpty &&
          (stepBase.reflexKind == .refinement) &&
          (st.currentDom.guards != stepBase.guardsNew) &&
          stepBase.guardsNew.isEmpty then
    some .uncertifiedRefinementExpansion
  else
    none

def checkMonotoneChainStepBool (st : B4HistoricalChainState)
    (stepBase : B4CommonTransitionBase) : Bool :=
  (evalMonotoneChainStepError? st stepBase).isNone

/-- **`T_D0_A8_03` — Deterministic Rejection of Silent Scope Resurrection (`.domQNonzero → .domQ`, `CE-B4-07`) & Unrecorded Shrinkage Contrast (`CE-B4-25`)**:
    (1) Any step attempting `.domQNonzero → .domQ` at epoch `> st.currentEpoch` is rejected with
        `some .silentScopeResurrectionBlocked` (`checkMonotoneChainStepBool = false`);
    (2) `CE-B4-25`: Shrinking `⟨.domQ, [.neqZero .varX]⟩` to `⟨.domQ, [.neqZero .varX, .neqZero (.sub .varX (.const 1))]⟩`
        with unrecorded `ΔΦ = []` provably FAILS `StepDomainAccountingWitness` at `ρ = (1, 0)`! -/
theorem T_D0_A8_03_SilentResurrectionStepRejected :
    (∀ (st : B4HistoricalChainState) (stepBase : B4CommonTransitionBase),
       st.currentEpoch < stepBase.assignedEvalEpoch →
       st.currentDom.domTag = .domQNonzero →
       stepBase.domNew = .domQ →
       evalMonotoneChainStepError? st stepBase = some .silentScopeResurrectionBlocked ∧
       checkMonotoneChainStepBool st stepBase = false) ∧
    (let d1 : B4EffDomSpec := ⟨.domQ, [.neqZero .varX]⟩
     let d2 : B4EffDomSpec := ⟨.domQ, [.neqZero .varX, .neqZero (.sub .varX (.const 1))]⟩
     ¬ StepDomainAccountingWitness d1 d2 []) := by
  refine ⟨?_, ?_⟩
  · intro st stepBase hLt hCurNz hNewQ
    unfold checkMonotoneChainStepBool evalMonotoneChainStepError?
    have hLtB : decide (st.currentEpoch < stepBase.assignedEvalEpoch) = true := decide_eq_true hLt
    simp [hLtB, hCurNz, hNewQ]
  · dsimp only
    intro hWit
    have hIn1 : InEffDom .domQ [.neqZero .varX] (1, 0) := by
      refine ⟨rfl, ⟨⟨1, .varX (1, 0)⟩, fun _ => trivial⟩, ?_⟩
      intro γ hMem
      rcases List.mem_cons.mp hMem with rfl | hNil
      · exact ⟨⟨1, .varX (1, 0)⟩, ⟨1, .varX (1, 0), by decide⟩⟩
      · nomatch hNil
    have hNotIn2 : ¬ InEffDom .domQ [.neqZero .varX, .neqZero (.sub .varX (.const 1))] (1, 0) := by
      intro hIn2
      have hm := hIn2.2.2 (.neqZero (.sub .varX (.const 1)))
        (List.mem_cons_of_mem _ (List.mem_cons_self ..))
      rcases hm.2 with ⟨v, hv, hNe⟩
      cases hv with
      | sub hx hc =>
          cases hx; cases hc
          exact hNe Rat.sub_self
    rcases hWit with ⟨_, hSame⟩ | hPart
    · exact hNotIn2 ((hSame (1, 0)).mp hIn1)
    · rcases hPart.old_covered_by_new_or_excised (1, 0) hIn1 with hIn2 | ⟨_, hMem, _⟩
      · exact hNotIn2 hIn2
      · nomatch hMem

end OmegaCellC1P1B2BB4
