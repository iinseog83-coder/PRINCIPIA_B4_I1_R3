/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Certified Higher Composition & Historical Retreat Algebra (`ACT-I0`)
  Module: OmegaCellC1P1B2BB4.B4_05_RetractionInterchangeAndMaster

  Gates & Binding Conditions Covered:
    - `I0-A10` (`F-B4-T22-08`, `Q-B4-R1-04`, `F-B4-T23-05`):
      * Exact retracted-premise union under ledger append (`T_D0_R1_07`).
      * Sound targeted invalidation (`T_D0_A9_01`), complete-hypothesis dependency-sensitive
        preservation + `CE-B4-26` expiry contrast (`T_D0_A9_02`).
      * Causal chain suffix invalidation & prefix preservation (`T_D0_A9_03`), standalone non-chained
        record independence under full multi-retraction disjointness `D_B4(q_indep) ∩ ΔR = ∅`
        (`T_D0_R1_06`, `CE-B4-27`), and multi-retraction refutation of single-premise guard
        (`T_I0_T23_05`, `CE-B4-34`).
    - `I0-A11` (`F-B4-T22-09`, `F-B4-T23-06`):
      * Explicit `deriveSlice2348PrimDeps = []` & 4-way `depActiveBool` decomposition (`T_D0_A10_01`).
      * Subsumed interaction conditional survival + `CE-B4-28` (`T_D0_R1_05`).
      * Exact 5-way `checkActiveB4SpineBool` factorization including `jointStandingGuardBool`
        (`T_I0_T23_06`, `CE-B4-35`).
      * Restricted Spatio-Temporal Interchange (`T_D0_A10_02`), Zero/Subsumed-Interaction
        Interchange (`T_D0_A10_03`), Interaction-Retraction Counterexample (`T_D0_A10_04`, `CE-B4-12A`),
        and Creation-vs-Standing `PathKey` Distinction (`T_D0_A10_05`, `CE-B4-12B`).
    - `I0-A12` (`F-B4-T22-10`, `F-B4-T23-07`):
      * `B4` Master Conditional Soundness (`T_D0_A11_01`) & Declarative Semantics Anti-Circularity
        Witness (`T_D0_A11_03`).
      * Abstract duplicate-key JSON pair-stream parser contract (`T_D0_R1_08`, `CE-B4-29`) and
        explicit Lean-model vs CPython-runtime boundary (`T_I0_T23_07`, `CE-B4-36`).
-/
import OmegaCellC1P1B2BB4.B4_04_HistoricalRetreatAlgebra

namespace OmegaCellC1P1B2BB4

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ### 1. Exact Ledger Retraction Union (`T_D0_R1_07`) -/

/-- Retracted primitive premises recorded in folded ledger `L`. -/
def retractedOfLedger (L : List StructuralLedgerEvent) : List String :=
  (foldStructuralLedger L).epistemic.retractedPremises

/-- Current epoch recorded in folded ledger `L`. -/
def currentEpochOfLedger (L : List StructuralLedgerEvent) : Nat :=
  (foldStructuralLedger L).epistemic.currentEpoch

/-- Premise IDs retracted within a delta event suffix `ΔL`. -/
def retractedPremisesInEvents : List StructuralLedgerEvent → List String
  | []                        => []
  | .retractPremise p :: tail => p :: retractedPremisesInEvents tail
  | .recordStructuralReflex _ :: tail => retractedPremisesInEvents tail
  | .advanceEpoch _ :: tail   => retractedPremisesInEvents tail
  | .issueGrantHeld _ :: tail => retractedPremisesInEvents tail
  | .revokeGrantHeld _ :: tail => retractedPremisesInEvents tail

private theorem foldl_retractedPremises_append (st : StructuralLedgerState) :
    ∀ (ΔL : List StructuralLedgerEvent),
      (ΔL.foldl stepStructuralLedger st).epistemic.retractedPremises =
      st.epistemic.retractedPremises ++ retractedPremisesInEvents ΔL
  | [] => (List.append_nil _).symm
  | ev :: tail => by
      dsimp only [List.foldl]
      rw [foldl_retractedPremises_append (stepStructuralLedger st ev) tail]
      cases ev <;>
        simp [stepStructuralLedger, stepEpistemicState, retractedPremisesInEvents, List.append_assoc]

theorem retractedOfLedger_append_eq (L ΔL : List StructuralLedgerEvent) :
    retractedOfLedger (L ++ ΔL) = retractedOfLedger L ++ retractedPremisesInEvents ΔL := by
  unfold retractedOfLedger foldStructuralLedger
  rw [List.foldl_append]
  exact foldl_retractedPremises_append _ ΔL

/-- **`T_D0_R1_07` — Exact Retracted-Set Union Under Ledger Append (`Q-B4-R1-04`)**:
    `p ∈ retractedOfLedger (L ++ ΔL) ↔ (p ∈ retractedOfLedger L ∨ p ∈ retractedPremisesInEvents ΔL)`
    and `retractedOfLedger` is monotone under ledger append (`L ⊆ L ++ ΔL`). -/
theorem T_D0_R1_07_RetractedLedgerAppendExactUnion
    (L ΔL : List StructuralLedgerEvent) :
    retractedOfLedger (L ++ ΔL) = retractedOfLedger L ++ retractedPremisesInEvents ΔL ∧
    (∀ p : String,
       p ∈ retractedOfLedger (L ++ ΔL) ↔
       (p ∈ retractedOfLedger L ∨ p ∈ retractedPremisesInEvents ΔL)) ∧
    (∀ p : String, p ∈ retractedOfLedger L → p ∈ retractedOfLedger (L ++ ΔL)) := by
  refine ⟨retractedOfLedger_append_eq L ΔL, ?_, ?_⟩
  · intro p
    rw [retractedOfLedger_append_eq, List.mem_append]
  · intro p hp
    rw [retractedOfLedger_append_eq]
    exact List.mem_append_left _ hp

/-! ### 2. Standing Active Predicates & Exact 5-Way Guard Factorization (`F-B4-T23-06`) -/

/-- Executable check that NO premise in `deps` appears in retracted list `R`. -/
def depActiveBool (deps R : List String) : Bool :=
  deps.all (fun p => !R.contains p)

theorem depActiveBool_iff (deps R : List String) :
    depActiveBool deps R = true ↔ ∀ p ∈ deps, p ∉ R := by
  unfold depActiveBool
  rw [List.all_eq_true]
  constructor
  · intro h p hp hInR
    have hb := h p hp
    have hCont : R.contains p = true := List.contains_iff_mem.mpr hInR
    rw [hCont] at hb
    nomatch hb
  · intro h p hp
    cases hCont : R.contains p with
    | false => rfl
    | true  => exact False.elim (h p hp (List.contains_iff_mem.mp hCont))

theorem depActiveBool_append (d1 d2 R : List String) :
    depActiveBool (d1 ++ d2) R = (depActiveBool d1 R && depActiveBool d2 R) := by
  unfold depActiveBool
  exact List.all_append

theorem depActiveBool_canonSortStrs (deps R : List String) :
    depActiveBool (canonSortStrs deps) R = depActiveBool deps R := by
  cases hb : depActiveBool deps R with
  | true =>
      apply (depActiveBool_iff _ _).mpr
      intro p hp
      exact (depActiveBool_iff _ _).mp hb p ((mem_canonSortStrs deps p).mp hp)
  | false =>
      apply Bool.eq_false_iff.mpr
      intro hCan
      have hOrig : depActiveBool deps R = true := by
        apply (depActiveBool_iff _ _).mpr
        intro p hp
        exact (depActiveBool_iff _ _).mp hCan p ((mem_canonSortStrs deps p).mpr hp)
      rw [hb] at hOrig
      nomatch hOrig

/-- Explicit zero-premise lemma for Slot `s2348` (`F-B4-T23-06` item 1). -/
theorem deriveSlice2348PrimDeps_eq_nil (s : ProvenanceBoundG2348Slice) :
    deriveSlice2348PrimDeps s = [] := rfl

theorem depActiveBool_slice2348_true (s : ProvenanceBoundG2348Slice) (R : List String) :
    depActiveBool (deriveSlice2348PrimDeps s) R = true := rfl

/-- Standing check whether any descendant lineage committed in `L` silently re-expands `t`'s
    narrowed `.domQNonzero` post-domain back to `.domQ`. -/
def hasSilentResurrectionAfterBool (t : B4CommonTransitionBase)
    (L : List StructuralLedgerEvent) : Bool :=
  (t.domNewId == "dom_Q_nonzero") &&
  (foldStructuralLedger L).epistemic.committedLineages.any
    (fun e => (e.pathKey != t.pathKey) && (e.cellOldCid == t.cellNewCid) && (e.domNewId == "dom_Q"))

/-- Explicit joint standing guard `OtherGuards_joint(L, ctx, t)` (`F-B4-T23-06`):
    requires `ctx.ledgerSnap` to be a prefix of live ledger `L` AND zero silent scope resurrection after `t`. -/
def jointStandingGuardBool (L : List StructuralLedgerEvent)
    (ctx : B4SharedContext) (t : B4CommonTransitionBase) : Bool :=
  decide (ctx.ledgerSnap <+: L) && !hasSilentResurrectionAfterBool t L

/-- Per-slot standing active predicates at live ledger `L` (`CE-B4-12B`: standing validity checks
    premise survival & non-expiry without re-running creation `PathKey`-freshness!). -/
def activeSlice2348Bool (L : List StructuralLedgerEvent) {ctx : B4SharedContext}
    (s : ValidSlice2348 ctx) : Bool :=
  depActiveBool (deriveSlice2348PrimDeps s.1.1) (retractedOfLedger L)

def activeSlice56Bool (L : List StructuralLedgerEvent) {ctx : B4SharedContext}
    (s : ValidSlice56 ctx) : Bool :=
  depActiveBool (deriveSlice56PrimDeps s.1.1) (retractedOfLedger L)

def activeSlice7Bool (L : List StructuralLedgerEvent) {ctx : B4SharedContext}
    (s : ValidSlice7 ctx) : Bool :=
  depActiveBool (deriveSlice7PrimDeps s.1.1) (retractedOfLedger L) &&
  decide (currentEpochOfLedger L < s.1.1.bundle.expiresEpoch)

/-- Composite standing active predicate on `sp : B4CanonicalSpine ctx` at live ledger `L`. -/
def checkActiveB4SpineBool (L : List StructuralLedgerEvent) (ctx : B4SharedContext)
    (sp : B4CanonicalSpine ctx) : Bool :=
  depActiveBool (deriveSpineB4PrimDeps ctx sp) (retractedOfLedger L) &&
  decide (currentEpochOfLedger L < sp.bundle7.expiresEpoch) &&
  jointStandingGuardBool L ctx sp.base.1

/-- Composite standing active predicate on sealed `rec : B4QualifiedRecord ctx` at live ledger `L`. -/
def checkActiveB4RecordBool (L : List StructuralLedgerEvent) {ctx : B4SharedContext}
    (rec : B4QualifiedRecord ctx) : Bool :=
  checkActiveB4SpineBool L ctx (extractB4Spine rec)

/-! ### 3. `I0-A10`: Targeted Retraction, Complete Survival Guard, Causal Chains, & Multi-Retraction (`F-B4-T23-05`) -/

/-- **`T_D0_A9_01` — Sound Targeted Invalidation Under Retraction**:
    Once any premise `p ∈ D_B4(rec)` is retracted in `L`, `checkActiveB4RecordBool (L ++ ΔL) rec = false`
    permanently for ALL future ledger extensions `ΔL`! -/
theorem T_D0_A9_01_SoundTargetedInvalidation
    {ctx : B4SharedContext} (rec : B4QualifiedRecord ctx)
    (L ΔL : List StructuralLedgerEvent) (p : String)
    (hDep : p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec))
    (hRet : p ∈ retractedOfLedger L) :
    checkActiveB4RecordBool (L ++ ΔL) rec = false := by
  unfold checkActiveB4RecordBool checkActiveB4SpineBool
  have hRetLater : p ∈ retractedOfLedger (L ++ ΔL) :=
    (T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL).2.2 p hRet
  have hDepFalse : depActiveBool (deriveSpineB4PrimDeps ctx (extractB4Spine rec))
      (retractedOfLedger (L ++ ΔL)) = false := by
    apply Bool.eq_false_iff.mpr
    intro hAct
    exact (depActiveBool_iff _ _).mp hAct p hDep hRetLater
  simp [hDepFalse]

/-- **`T_D0_A9_02` — Dependency-Sensitive Preservation Under Complete Survival Hypotheses (`Q-B4-R1-04`, `CE-B4-26`)**:
    (1) If `checkActiveB4RecordBool L rec = true`, `D_B4(rec) ∩ ΔR = ∅`, `currentEpochOfLedger (L ++ ΔL) < expiresEpoch`,
        and `!hasSilentResurrectionAfterBool base (L ++ ΔL) = true`, then `checkActiveB4RecordBool (L ++ ΔL) rec = true`;
    (2) `CE-B4-26` Contrast: when `ΔL = [.advanceEpoch expiresEpoch]` (`ΔR = []`, so `D_B4(rec) ∩ ΔR = ∅`!),
        `checkActiveB4RecordBool (L ++ ΔL) rec = false`, proving necessity of the explicit non-expiry guard! -/
theorem T_D0_A9_02_DependencySensitivePreservation
    {ctx : B4SharedContext} (rec : B4QualifiedRecord ctx)
    (L : List StructuralLedgerEvent) :
    (∀ (ΔL : List StructuralLedgerEvent),
       checkActiveB4RecordBool L rec = true →
       (∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), p ∉ retractedPremisesInEvents ΔL) →
       currentEpochOfLedger (L ++ ΔL) < (extractB4Spine rec).bundle7.expiresEpoch →
       hasSilentResurrectionAfterBool (extractB4Spine rec).base.1 (L ++ ΔL) = false →
       checkActiveB4RecordBool (L ++ ΔL) rec = true) ∧
    (let exp := (extractB4Spine rec).bundle7.expiresEpoch
     let ΔL_exp : List StructuralLedgerEvent := [.advanceEpoch exp]
     (∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), p ∉ retractedPremisesInEvents ΔL_exp) ∧
     checkActiveB4RecordBool (L ++ ΔL_exp) rec = false) := by
  refine ⟨?_, ?_⟩
  · intro ΔL hActL hDisj hExpNext hNoResNext
    unfold checkActiveB4RecordBool checkActiveB4SpineBool jointStandingGuardBool at hActL ⊢
    simp only [Bool.and_eq_true, decide_eq_true_eq] at hActL
    rcases hActL with ⟨⟨hDepL, _⟩, ⟨hPrefL, _⟩⟩
    have hDepNext : depActiveBool (deriveSpineB4PrimDeps ctx (extractB4Spine rec))
        (retractedOfLedger (L ++ ΔL)) = true := by
      apply (depActiveBool_iff _ _).mpr
      intro p hp hInApp
      rcases (T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL).2.1 p |>.mp hInApp with hOld | hNew
      · exact (depActiveBool_iff _ _).mp hDepL p hp hOld
      · exact hDisj p hp hNew
    have hPrefNext : ctx.ledgerSnap <+: (L ++ ΔL) := by
      rcases hPrefL with ⟨t, ht⟩
      exact ⟨t ++ ΔL, by rw [← List.append_assoc, ht]⟩
    have hPrefB : decide (ctx.ledgerSnap <+: L ++ ΔL) = true := decide_eq_true hPrefNext
    have hExpB : decide (currentEpochOfLedger (L ++ ΔL) < (extractB4Spine rec).bundle7.expiresEpoch) = true :=
      decide_eq_true hExpNext
    rw [hDepNext, hExpB, hPrefB, hNoResNext]
    rfl
  · dsimp only
    refine ⟨(fun _ _ hMem => by dsimp [retractedPremisesInEvents] at hMem; nomatch hMem), ?_⟩
    unfold checkActiveB4RecordBool checkActiveB4SpineBool currentEpochOfLedger foldStructuralLedger
    rw [List.foldl_append]
    dsimp [List.foldl, stepStructuralLedger, stepEpistemicState]
    have hNotLt : ¬ ((extractB4Spine rec).bundle7.expiresEpoch < (extractB4Spine rec).bundle7.expiresEpoch) :=
      Nat.lt_irrefl _
    simp [hNotLt]

/-- Context-packaged qualified `B4` record for multi-step causal chains & standalone comparisons. -/
structure PackagedB4Record where
  ctx    : B4SharedContext
  record : B4QualifiedRecord ctx

def PackagedB4Record.primDeps (q : PackagedB4Record) : List String :=
  deriveSpineB4PrimDeps q.ctx (extractB4Spine q.record)

def PackagedB4Record.expiresEpoch (q : PackagedB4Record) : Nat :=
  (extractB4Spine q.record).bundle7.expiresEpoch

def PackagedB4Record.base (q : PackagedB4Record) : B4CommonTransitionBase :=
  (extractB4Spine q.record).base.1

def PackagedB4Record.activeAtBool (L : List StructuralLedgerEvent) (q : PackagedB4Record) : Bool :=
  checkActiveB4RecordBool L q.record

/-- Cumulative causal activity of chain node `j`: all causal ancestors `0 .. j` in `chain` are active at `L`. -/
def activeChainNodeAtBool (L : List StructuralLedgerEvent)
    (chain : List PackagedB4Record) (j : Nat) : Bool :=
  (chain.take (j + 1)).all (PackagedB4Record.activeAtBool L)

/-- Monotone causal dependency inheritance along a `chain` (`i ≤ j ⟹ D_B4(q_i) ⊆ D_B4(q_j)`). -/
def IsCausalDepsMonotoneChain (chain : List PackagedB4Record) : Prop :=
  ∀ (i j : Nat) (hi : i < chain.length) (hj : j < chain.length),
    i ≤ j → ∀ p ∈ (chain[i]).primDeps, p ∈ (chain[j]).primDeps

/-- **`T_D0_A9_03` — Causal Chain Suffix Invalidation & Prefix Preservation (`F-B4-T22-08`, `F-B4-T23-05`)**:
    In a causal chain `chain`, if `p ∈ (chain[k]).primDeps` is retracted in `ΔL` while every prefix
    node `i < k` satisfies `activeAtBool L`, FULL multi-retraction disjointness `D_B4(chain[i]) ∩ ΔR = ∅`
    (`F-B4-T23-05`), and standing non-expiry / non-resurrection at `L ++ ΔL`, then:
    (1) Every prefix node `i < k` remains individually and cumulatively active at `L ++ ΔL`;
    (2) Every suffix node `j ≥ k` (`j < chain.length`) becomes cumulatively INACTIVE at `L ++ ΔL`
        (and individually inactive under `IsCausalDepsMonotoneChain chain`)! -/
theorem T_D0_A9_03_CausalChainSuffixInvalidationPrefixPreservation
    (chain : List PackagedB4Record)
    (L ΔL : List StructuralLedgerEvent)
    (k : Nat) (hk : k < chain.length)
    (p : String)
    (hDepK : p ∈ (chain[k]).primDeps)
    (hRetP : p ∈ retractedPremisesInEvents ΔL)
    (hPrefAct : ∀ (i : Nat) (hi : i < k),
       (chain[i]'(Nat.lt_trans hi hk)).activeAtBool L = true)
    (hPrefDisj : ∀ (i : Nat) (hi : i < k),
       ∀ r ∈ (chain[i]'(Nat.lt_trans hi hk)).primDeps, r ∉ retractedPremisesInEvents ΔL)
    (hPrefExp : ∀ (i : Nat) (hi : i < k),
       currentEpochOfLedger (L ++ ΔL) < (chain[i]'(Nat.lt_trans hi hk)).expiresEpoch)
    (hPrefNoRes : ∀ (i : Nat) (hi : i < k),
       hasSilentResurrectionAfterBool (chain[i]'(Nat.lt_trans hi hk)).base (L ++ ΔL) = false) :
    (∀ (i : Nat) (hi : i < k),
       (chain[i]'(Nat.lt_trans hi hk)).activeAtBool (L ++ ΔL) = true ∧
       activeChainNodeAtBool (L ++ ΔL) chain i = true) ∧
    (∀ (j : Nat) (hj : j < chain.length),
       k ≤ j →
       activeChainNodeAtBool (L ++ ΔL) chain j = false ∧
       (IsCausalDepsMonotoneChain chain → (chain[j]).activeAtBool (L ++ ΔL) = false)) := by
  have hIndivPref : ∀ (i : Nat) (hi : i < k),
      (chain[i]'(Nat.lt_trans hi hk)).activeAtBool (L ++ ΔL) = true := by
    intro i hi
    exact (T_D0_A9_02_DependencySensitivePreservation (chain[i]'(Nat.lt_trans hi hk)).record L).1
      ΔL (hPrefAct i hi) (hPrefDisj i hi) (hPrefExp i hi) (hPrefNoRes i hi)
  refine ⟨?_, ?_⟩
  · intro i hi
    refine ⟨hIndivPref i hi, ?_⟩
    unfold activeChainNodeAtBool
    rw [List.all_eq_true]
    intro q hMemTake
    rcases List.mem_iff_getElem.mp hMemTake with ⟨m, hmTake, rfl⟩
    have hmLt : m < i + 1 := by
      have hLen : (chain.take (i + 1)).length = min (i + 1) chain.length := List.length_take
      omega
    have hmLtK : m < k := by omega
    rw [List.getElem_take]
    exact hIndivPref m hmLtK
  · intro j hj hkj
    have hKInact : (chain[k]).activeAtBool (L ++ ΔL) = false := by
      unfold PackagedB4Record.activeAtBool checkActiveB4RecordBool checkActiveB4SpineBool
      have hInApp : p ∈ retractedOfLedger (L ++ ΔL) :=
        (T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL).2.1 p |>.mpr (Or.inr hRetP)
      have hDepFalse : depActiveBool (chain[k]).primDeps (retractedOfLedger (L ++ ΔL)) = false := by
        apply Bool.eq_false_iff.mpr
        intro hOk
        exact (depActiveBool_iff _ _).mp hOk p hDepK hInApp
      exact by unfold PackagedB4Record.primDeps at hDepFalse; simp [hDepFalse]
    refine ⟨?_, ?_⟩
    · unfold activeChainNodeAtBool
      apply Bool.eq_false_iff.mpr
      intro hAll
      rw [List.all_eq_true] at hAll
      have hkTake : k < (chain.take (j + 1)).length := by
        rw [List.length_take]; omega
      have hMemK : chain[k] ∈ chain.take (j + 1) := by
        have hEq : (chain.take (j + 1))[k]'hkTake = chain[k] := List.getElem_take
        rw [← hEq]
        exact List.getElem_mem hkTake
      have hTrue := hAll (chain[k]) hMemK
      rw [hKInact] at hTrue
      nomatch hTrue
    · intro hMono
      have hDepJ : p ∈ (chain[j]).primDeps := hMono k j hk hj hkj p hDepK
      unfold PackagedB4Record.activeAtBool checkActiveB4RecordBool checkActiveB4SpineBool
      have hInApp : p ∈ retractedOfLedger (L ++ ΔL) :=
        (T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL).2.1 p |>.mpr (Or.inr hRetP)
      have hDepFalse : depActiveBool (chain[j]).primDeps (retractedOfLedger (L ++ ΔL)) = false := by
        apply Bool.eq_false_iff.mpr
        intro hOk
        exact (depActiveBool_iff _ _).mp hOk p hDepJ hInApp
      exact by unfold PackagedB4Record.primDeps at hDepFalse; simp [hDepFalse]

/-- **`T_D0_R1_06` — Standalone Non-Chained Record Independence Under Full Multi-Retraction Disjointness (`F-B4-T22-08`, `F-B4-T23-05`, `CE-B4-27`)**:
    Even if `q_indep` was created at a strictly later epoch (`q_k.ctx.assignedEvalEpoch < q_indep.ctx.assignedEvalEpoch`),
    retracting `p ∈ q_k.primDeps` in `ΔL` invalidates `q_k` while preserving `q_indep` whenever
    `D_B4(q_indep) ∩ ΔR = ∅` (`∀ r ∈ q_indep.primDeps, r ∉ retractedPremisesInEvents ΔL`) and
    `q_indep`'s standing guards hold at `L ++ ΔL`! -/
theorem T_D0_R1_06_StandaloneNonChainedRecordIndependence
    (q_k q_indep : PackagedB4Record)
    (L ΔL : List StructuralLedgerEvent)
    (p : String)
    (hDepK : p ∈ q_k.primDeps)
    (hRetP : p ∈ retractedPremisesInEvents ΔL)
    (hActIndep : q_indep.activeAtBool L = true)
    (hFullDisj : ∀ r ∈ q_indep.primDeps, r ∉ retractedPremisesInEvents ΔL)
    (hExpIndep : currentEpochOfLedger (L ++ ΔL) < q_indep.expiresEpoch)
    (hNoResIndep : hasSilentResurrectionAfterBool q_indep.base (L ++ ΔL) = false) :
    q_k.activeAtBool (L ++ ΔL) = false ∧
    q_indep.activeAtBool (L ++ ΔL) = true := by
  refine ⟨?_, ?_⟩
  · unfold PackagedB4Record.activeAtBool checkActiveB4RecordBool checkActiveB4SpineBool
    have hInApp : p ∈ retractedOfLedger (L ++ ΔL) :=
      (T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL).2.1 p |>.mpr (Or.inr hRetP)
    have hDepFalse : depActiveBool q_k.primDeps (retractedOfLedger (L ++ ΔL)) = false := by
      apply Bool.eq_false_iff.mpr
      intro hOk
      exact (depActiveBool_iff _ _).mp hOk p hDepK hInApp
    exact by unfold PackagedB4Record.primDeps at hDepFalse; simp [hDepFalse]
  · exact (T_D0_A9_02_DependencySensitivePreservation q_indep.record L).1
      ΔL hActIndep hFullDisj hExpIndep hNoResIndep

/-- **`T_I0_T23_05` — Multi-Premise Retraction Refutes Single-Premise Disjointness Guard (`F-B4-T23-05`, `CE-B4-34`)**:
    Constructs `ΔL_two = [.retractPremise "prem_p", .retractPremise "prem_r"]`:
    (1) `"prem_p" ∉ ["prem_r"]` holds (the naive single-premise hypothesis `p ∉ D(q_indep)` is TRUE!),
    (2) `depActiveBool ["prem_r"] (retractedOfLedger []) = true` prior to `ΔL_two`,
    (3) YET `depActiveBool ["prem_r"] (retractedOfLedger ([] ++ ΔL_two)) = false` (and any `q_indep`
        with `"prem_r" ∈ q_indep.primDeps` satisfies `q_indep.activeAtBool ([] ++ ΔL_two) = false`),
        proving full `D_B4(q_indep) ∩ ΔR = ∅` is strictly necessary! -/
theorem T_I0_T23_05_MultiRetractionRefutesSinglePremiseGuard :
    let ΔL_two : List StructuralLedgerEvent := [.retractPremise "prem_p", .retractPremise "prem_r"]
    ("prem_p" ∉ (["prem_r"] : List String)) ∧
    depActiveBool ["prem_r"] (retractedOfLedger []) = true ∧
    depActiveBool ["prem_r"] (retractedOfLedger ([] ++ ΔL_two)) = false ∧
    (∀ q_indep : PackagedB4Record,
       "prem_r" ∈ q_indep.primDeps →
       q_indep.activeAtBool ([] ++ ΔL_two) = false) := by
  dsimp only
  refine ⟨by decide, rfl, rfl, ?_⟩
  intro q_indep hMemR
  unfold PackagedB4Record.activeAtBool checkActiveB4RecordBool checkActiveB4SpineBool
  have hInR : "prem_r" ∈ retractedOfLedger [.retractPremise "prem_p", .retractPremise "prem_r"] := by
    decide
  have hFalse : depActiveBool q_indep.primDeps
      (retractedOfLedger [.retractPremise "prem_p", .retractPremise "prem_r"]) = false := by
    apply Bool.eq_false_iff.mpr
    intro hOk
    exact (depActiveBool_iff _ _).mp hOk "prem_r" hMemR hInR
  exact by unfold PackagedB4Record.primDeps at hFalse; simp [hFalse]

/-! ### 4. `I0-A11`: Exact Guard Factorization & Restricted Spatio-Temporal Interchange (`F-B4-T22-09`, `F-B4-T23-06`) -/

/-- **`T_D0_A10_01` — Exact 4-Term Premise-Survival Decomposition Using `deriveSlice2348PrimDeps = []` (`F-B4-T23-06`)**:
    For every `sp : B4CanonicalSpine ctx` and any retracted list `R`,
    `depActiveBool (deriveSpineB4PrimDeps ctx sp) R` equals the exact 4-way Boolean conjunction
    over `deriveSlice2348PrimDeps` (`= []`), `deriveSlice56PrimDeps`, `deriveSlice7PrimDeps`, and
    `deriveB4InteractionPrimDeps`! -/
theorem T_D0_A10_01_DepActiveExactDecomposition
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) (R : List String) :
    deriveSlice2348PrimDeps sp.slice2348.1.1 = [] ∧
    depActiveBool (deriveSpineB4PrimDeps ctx sp) R =
      (depActiveBool (deriveSlice2348PrimDeps sp.slice2348.1.1) R &&
       depActiveBool (deriveSlice56PrimDeps sp.slice56.1.1) R &&
       depActiveBool (deriveSlice7PrimDeps sp.slice7.1.1) R &&
       depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode) R) := by
  refine ⟨deriveSlice2348PrimDeps_eq_nil _, ?_⟩
  rw [depActiveBool_slice2348_true, Bool.true_and]
  unfold deriveSpineB4PrimDeps deriveB4JointPrimDeps
    deriveSlice56PrimDeps deriveSlice7PrimDeps
    B4CanonicalSpine.c56 B4CanonicalSpine.bundle7 B4CanonicalSpine.bridgeMode
  rw [depActiveBool_canonSortStrs, depActiveBool_append, depActiveBool_append]

/-- **`T_D0_R1_05` — Subsumed Interaction Conditional Survival & Unsubsumed Refutation (`F-B4-T22-09`, `CE-B4-28`)**:
    (1) Whenever `∀ p ∈ D_inter, p ∈ D_56 ∨ p ∈ D_7` (`D_inter ⊆ D_56 ∪ D_7`), slot survival
        `(depActiveBool D_56 R && depActiveBool D_7 R) = true` automatically entails
        `depActiveBool D_inter R = true` (and `depActiveBool D_B4 R = true`);
    (2) `CE-B4-28` Contrast: when `D_56 = ["prem_5"]`, `D_7 = ["prem_7"]`, `D_inter = ["prem_bridge_only"]`,
        and `R = ["prem_bridge_only"]`, `(depActiveBool D_56 R && depActiveBool D_7 R) = true`
        whereas `depActiveBool D_inter R = false`, refuting unconditional survival! -/
theorem T_D0_R1_05_SubsumedInteractionConditionalSurvival :
    (∀ (D56 D7 Dinter R : List String),
       (∀ p ∈ Dinter, p ∈ D56 ∨ p ∈ D7) →
       depActiveBool D56 R = true →
       depActiveBool D7 R = true →
       depActiveBool Dinter R = true) ∧
    (let D56 := ["prem_5"]
     let D7  := ["prem_7"]
     let Dinter := ["prem_bridge_only"]
     let R := ["prem_bridge_only"]
     depActiveBool D56 R = true ∧
     depActiveBool D7 R = true ∧
     depActiveBool Dinter R = false) := by
  refine ⟨?_, ⟨rfl, rfl, rfl⟩⟩
  intro D56 D7 Dinter R hSub h56 h7
  apply (depActiveBool_iff _ _).mpr
  intro p hp
  rcases hSub p hp with hp56 | hp7
  · exact (depActiveBool_iff _ _).mp h56 p hp56
  · exact (depActiveBool_iff _ _).mp h7 p hp7

/-- **`T_I0_T23_06` — Exact 5-Way Factorization of `checkActiveB4SpineBool` & `CE-B4-35` Contrast (`F-B4-T23-06`)**:
    (1) `checkActiveB4SpineBool L ctx sp` is identically equal (`=`) as a `Bool` to the 5-term
        conjunction `activeSlice2348Bool ∧ activeSlice56Bool ∧ activeSlice7Bool ∧ depActiveBool D_inter ∧ jointStandingGuardBool`;
    (2) `CE-B4-35`: When `ctx.ledgerSnap = [.advanceEpoch 5]` and `L = []`, `jointStandingGuardBool L ctx sp.base.1 = false`,
        so `checkActiveB4SpineBool L ctx sp = false` EVEN IF all 3 slot active flags and `depActiveBool D_inter` are `true`! -/
theorem T_I0_T23_06_ExactActiveB4JointGuardFactorization :
    (∀ (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       checkActiveB4SpineBool L ctx sp =
         (activeSlice2348Bool L sp.slice2348 &&
          activeSlice56Bool L sp.slice56 &&
          activeSlice7Bool L sp.slice7 &&
          depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode) (retractedOfLedger L) &&
          jointStandingGuardBool L ctx sp.base.1)) ∧
    (∀ (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       ctx.ledgerSnap = [.advanceEpoch 5] →
       jointStandingGuardBool [] ctx sp.base.1 = false ∧
       checkActiveB4SpineBool [] ctx sp = false) := by
  refine ⟨?_, ?_⟩
  · intro L ctx sp
    unfold checkActiveB4SpineBool activeSlice2348Bool activeSlice56Bool activeSlice7Bool
    rw [(T_D0_A10_01_DepActiveExactDecomposition ctx sp (retractedOfLedger L)).2]
    unfold B4CanonicalSpine.bundle7
    cases a : depActiveBool (deriveSlice2348PrimDeps sp.slice2348.1.1) (retractedOfLedger L) <;>
    cases b : depActiveBool (deriveSlice56PrimDeps sp.slice56.1.1) (retractedOfLedger L) <;>
    cases c : depActiveBool (deriveSlice7PrimDeps sp.slice7.1.1) (retractedOfLedger L) <;>
    cases d : depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode) (retractedOfLedger L) <;>
    cases e : decide (currentEpochOfLedger L < sp.slice7.1.1.bundle.expiresEpoch) <;>
    cases f : jointStandingGuardBool L ctx sp.base.1 <;>
    rfl
  · intro ctx sp hSnap
    have hNotPref : ¬ (ctx.ledgerSnap <+: ([] : List StructuralLedgerEvent)) := by
      rw [hSnap]
      rintro ⟨t, ht⟩
      nomatch ht
    have hJg : jointStandingGuardBool [] ctx sp.base.1 = false := by
      unfold jointStandingGuardBool
      have hd : decide (ctx.ledgerSnap <+: ([] : List StructuralLedgerEvent)) = false :=
        decide_eq_false hNotPref
      rw [hd]
      rfl
    refine ⟨hJg, ?_⟩
    unfold checkActiveB4SpineBool
    simp [hJg]

/-- **`T_D0_A10_02` — Restricted Spatio-Temporal Interchange Law (`F-B4-T22-09`, `F-B4-T23-06`)**:
    Given `jointStandingGuardBool L ctx sp.base.1 = true` and survival of interaction premises
    `depActiveBool D_inter (retractedOfLedger L) = true`, spatial reification (`reifyB4Spine`) and
    temporal standing filtration (`checkActiveB4RecordBool L`) commute biconditionally:
    `checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔ (activeSlice2348Bool = true ∧ activeSlice56Bool = true ∧ activeSlice7Bool = true)`! -/
theorem T_D0_A10_02_RestrictedSpatioTemporalInterchange
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (hJointGuard : jointStandingGuardBool L ctx sp.base.1 = true)
    (hInterSurv  : depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
                     (retractedOfLedger L) = true) :
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔
      (activeSlice2348Bool L sp.slice2348 = true ∧
       activeSlice56Bool L sp.slice56 = true ∧
       activeSlice7Bool L sp.slice7 = true) := by
  unfold checkActiveB4RecordBool
  rw [(T_D0_A4_03_SpineRoundtrip ctx).1 sp,
      (T_I0_T23_06_ExactActiveB4JointGuardFactorization.1 L ctx sp),
      hInterSurv, hJointGuard]
  simp only [Bool.and_true, Bool.and_eq_true, and_assoc]

/-- **`T_D0_A10_03` — Zero- or Subsumed-Interaction Spatio-Temporal Interchange (`F-B4-T22-09`, `F-B4-T23-06`)**:
    Whenever `sp.bridgeMode` has subsumed interaction premises (`D_inter ⊆ D_56 ∪ D_7` — in particular
    unconditionally for `.directUnguardedL0` and `.impNormalizedA0` where `D_inter = []`!) and
    `jointStandingGuardBool L ctx sp.base.1 = true`,
    `checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔ (activeSlice2348Bool = true ∧ activeSlice56Bool = true ∧ activeSlice7Bool = true)`
    WITHOUT any separate `D_inter` survival hypothesis! -/
theorem T_D0_A10_03_ZeroInteractionUnconditionalInterchange
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (hJointGuard : jointStandingGuardBool L ctx sp.base.1 = true)
    (hSubsumed :
       ∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode,
         p ∈ deriveSlice56PrimDeps sp.slice56.1.1 ∨ p ∈ deriveSlice7PrimDeps sp.slice7.1.1) :
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔
      (activeSlice2348Bool L sp.slice2348 = true ∧
       activeSlice56Bool L sp.slice56 = true ∧
       activeSlice7Bool L sp.slice7 = true) := by
  unfold checkActiveB4RecordBool
  rw [(T_D0_A4_03_SpineRoundtrip ctx).1 sp,
      (T_I0_T23_06_ExactActiveB4JointGuardFactorization.1 L ctx sp),
      hJointGuard, Bool.and_true]
  constructor
  · intro h
    simp only [Bool.and_eq_true] at h
    exact ⟨h.1.1.1, h.1.1.2, h.1.2⟩
  · rintro ⟨h1, h2, h3⟩
    have h7Dep : depActiveBool (deriveSlice7PrimDeps sp.slice7.1.1) (retractedOfLedger L) = true := by
      unfold activeSlice7Bool at h3
      simp only [Bool.and_eq_true] at h3
      exact h3.1
    have hInter : depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
        (retractedOfLedger L) = true :=
      T_D0_R1_05_SubsumedInteractionConditionalSurvival.1 _ _ _ _ hSubsumed h2 h7Dep
    simp [h1, h2, h3, hInter]

/-- **`T_D0_A10_04` — Interaction-Premise Retraction Refutes Naive Unconditional Interchange (`CE-B4-12A`)**:
    For any `sp : B4CanonicalSpine ctx` in `.certifiedBridgeL1` mode introducing an unsubsumed bridge
    premise `p_br ∈ D_inter \ (D_56 ∪ D_7)`, retracting ONLY `p_br` leaves `activeSlice2348Bool = true`,
    `activeSlice56Bool = true`, and `activeSlice7Bool = true` (assuming unexpired epoch), YET forces
    `checkActiveB4RecordBool L (reifyB4Spine ctx sp) = false`! -/
theorem T_D0_A10_04_InteractionPremiseRetractionBreaksNaiveInterchange
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (p_br : String)
    (hInInter : p_br ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
    (hRetOnlyBr : retractedOfLedger L = [p_br])
    (hNot56 : p_br ∉ deriveSlice56PrimDeps sp.slice56.1.1)
    (hNot7  : p_br ∉ deriveSlice7PrimDeps sp.slice7.1.1)
    (hExp   : currentEpochOfLedger L < sp.bundle7.expiresEpoch) :
    activeSlice2348Bool L sp.slice2348 = true ∧
    activeSlice56Bool L sp.slice56 = true ∧
    activeSlice7Bool L sp.slice7 = true ∧
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = false := by
  have hAct56 : activeSlice56Bool L sp.slice56 = true := by
    unfold activeSlice56Bool
    rw [hRetOnlyBr]
    apply (depActiveBool_iff _ _).mpr
    intro q hq hMem
    rcases List.mem_cons.mp hMem with rfl | hNil
    · exact hNot56 hq
    · nomatch hNil
  have hAct7 : activeSlice7Bool L sp.slice7 = true := by
    unfold activeSlice7Bool
    rw [hRetOnlyBr]
    have hd7 : depActiveBool (deriveSlice7PrimDeps sp.slice7.1.1) [p_br] = true := by
      apply (depActiveBool_iff _ _).mpr
      intro q hq hMem
      rcases List.mem_cons.mp hMem with rfl | hNil
      · exact hNot7 hq
      · nomatch hNil
    have he7 : decide (currentEpochOfLedger L < sp.slice7.1.1.bundle.expiresEpoch) = true :=
      decide_eq_true hExp
    simp [hd7, he7]
  have hInterFalse : depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
      (retractedOfLedger L) = false := by
    rw [hRetOnlyBr]
    apply Bool.eq_false_iff.mpr
    intro hOk
    exact (depActiveBool_iff _ _).mp hOk p_br hInInter (List.mem_cons_self ..)
  refine ⟨rfl, hAct56, hAct7, ?_⟩
  unfold checkActiveB4RecordBool
  rw [(T_D0_A4_03_SpineRoundtrip ctx).1 sp,
      (T_I0_T23_06_ExactActiveB4JointGuardFactorization.1 L ctx sp),
      hInterFalse]
  simp

/-- Canonical `CommittedLineageEntry` corresponding to `sp : B4CanonicalSpine ctx`. -/
def committedEntryOfSpine {ctx : B4SharedContext} (sp : B4CanonicalSpine ctx) : CommittedLineageEntry where
  pathKey           := derivePathKey sp.ast
  rflxCid           := sp.ast.rflxCid
  cellOldCid        := sp.ast.cellOldCid
  obstCid           := sp.ast.obstCid
  cellNewCid        := sp.ast.cellNewCid
  baseId            := sp.ast.baseId
  domOldId          := sp.ast.domOldId
  domNewId          := sp.ast.domNewId
  specOldId         := sp.ast.specOldId
  specNewId         := sp.ast.specNewId
  stepKind          := sp.ast.reflexKind
  historicalRetreat := sp.base.1.cumulativeHistRetreat

/-- **`T_D0_A10_05` — Creation `PathKey`-Freshness vs Standing Active Validity Distinction (`CE-B4-12B`)**:
    Once `sp : B4CanonicalSpine ctx` is committed into `L' := ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]`:
    (1) Re-running **creation** `checkStructuralReflex` on `sp.ast` against `L'` deterministically REJECTS
        with `.rejectInvalid .G8 .duplicatePathKey` (`checkSlice2348Bool { ctx with ledgerSnap := L' } = false`);
    (2) Meanwhile, **standing** `checkActiveB4SpineBool L' ctx sp` equals `checkActiveB4SpineBool ctx.ledgerSnap ctx sp`
        (staying `true` whenever `sp` was active at `ctx.ledgerSnap`)! -/
private theorem checkStructuralReflex_append_self_duplicate
    (fuel : Nat) (regId : String) (store : StructuralStore)
    (L : List StructuralLedgerEvent) (ast : StructuralReflexAST)
    (e : CommittedLineageEntry) (sq : StructuralQualification)
    (hAcc : checkStructuralReflex fuel regId store L ast = .structuralAccept sq)
    (hPk  : e.pathKey = derivePathKey ast) :
    checkStructuralReflex fuel regId store (L ++ [.recordStructuralReflex e]) ast =
      .rejectInvalid .G8 .duplicatePathKey := by
  cases fuel with
  | zero => unfold checkStructuralReflex at hAcc; nomatch hAcc
  | succ f' =>
      unfold checkStructuralReflex at hAcc ⊢
      by_cases hCid : (ast.rflxCid == "") = true
      · rw [dif_pos hCid] at hAcc; nomatch hAcc
      · rw [dif_neg hCid] at hAcc ⊢
        cases hc1 : store.lookupCell? ast.cellOldCid with
        | none => rw [hc1] at hAcc; nomatch hAcc
        | some cOld =>
            rw [hc1] at hAcc; dsimp only
            cases hc2 : store.lookupCell? ast.cellNewCid with
            | none => rw [hc2] at hAcc; nomatch hAcc
            | some cNew =>
                rw [hc2] at hAcc; dsimp only
                cases ho : store.lookupObst? ast.obstCid with
                | none => rw [ho] at hAcc; nomatch hAcc
                | some obst =>
                    rw [ho] at hAcc; dsimp only at hAcc ⊢
                    by_cases hg2 : (!(cOld.baseId == ast.baseId &&
                          cNew.baseId == ast.baseId &&
                          cOld.domId == ast.domOldId &&
                          cNew.domId == ast.domNewId &&
                          cOld.specId == ast.specOldId &&
                          cNew.specId == ast.specNewId &&
                          obst.cellCid == ast.cellOldCid &&
                          obst.specId == ast.specOldId)) = true
                    · rw [if_pos hg2] at hAcc; nomatch hAcc
                    · rw [if_neg hg2] at hAcc ⊢
                      cases hg3 : checkG3Matrix obst.inpKind ast.reflexKind with
                      | error err => rw [hg3] at hAcc; cases err <;> nomatch hAcc
                      | ok _ =>
                          rw [hg3] at hAcc; dsimp only at hAcc ⊢
                          cases hg4 : reifyTransportCode (f' + 1) regId ast.baseId
                              ast.domOldId ast.domNewId
                              ast.specOldId ast.specNewId
                              cOld.prov cNew.prov ast.reflexKind
                              ast.transportCode with
                          | error err => rw [hg4] at hAcc; cases err <;> nomatch hAcc
                          | ok _ =>
                              dsimp only
                              have hContains : (((foldStructuralLedger (L ++ [.recordStructuralReflex e])).epistemic.committedLineages.map
                                  (·.pathKey)).contains (derivePathKey ast)) = true := by
                                apply List.contains_iff_mem.mpr
                                unfold foldStructuralLedger
                                rw [List.foldl_append]
                                dsimp [List.foldl, stepStructuralLedger, stepEpistemicState]
                                rw [List.map_append, ← hPk]
                                exact List.mem_append_right _ (List.mem_cons_self ..)
                              rw [if_pos hContains]

/-- **`T_D0_A10_05` — Creation `PathKey`-Freshness vs Standing Active Validity Distinction (`CE-B4-12B`)**:
    Once `sp : B4CanonicalSpine ctx` is committed into `L' := ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]`:
    (1) Re-running **creation** `checkStructuralReflex` on `sp.ast` against `L'` deterministically REJECTS
        with `.rejectInvalid .G8 .duplicatePathKey` (`checkSlice2348Bool { ctx with ledgerSnap := L' } = false`);
    (2) Meanwhile, **standing** `checkActiveB4SpineBool L' ctx sp` equals `checkActiveB4SpineBool ctx.ledgerSnap ctx sp`
        (staying `true` whenever `sp` was active at `ctx.ledgerSnap`)! -/
theorem T_D0_A10_05_CreationVsStandingPathKeyDistinction
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    let e_sp := committedEntryOfSpine sp
    let L' := ctx.ledgerSnap ++ [.recordStructuralReflex e_sp]
    checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore L' sp.ast =
      .rejectInvalid .G8 .duplicatePathKey ∧
    checkSlice2348Bool { ctx with ledgerSnap := L' } sp.slice2348.1.1 = false ∧
    checkActiveB4SpineBool L' ctx sp = checkActiveB4SpineBool ctx.ledgerSnap ctx sp := by
  dsimp only
  have hs1 := sp.slice2348.1.2
  unfold checkSlice2348Bool at hs1
  simp only [Bool.and_eq_true] at hs1
  have hRefOrig := hs1.1.1
  have hAlign := hs1.2
  unfold checkR2348AlignBool at hAlign
  simp only [Bool.and_eq_true, beq_iff_eq] at hAlign
  have hPathKeyEq : derivePathKey sp.ast = sp.base.1.pathKey := by
    have hp : derivePathKey sp.slice2348.1.1.ast = sp.slice2348.1.1.claimedBase.pathKey :=
      hAlign.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.1.2
    have hb : sp.slice2348.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber2348.2
    rwa [hb] at hp
  have hExSq : ∃ sq, checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap sp.ast =
      .structuralAccept sq := by
    unfold B4CanonicalSpine.ast
    cases hChk : checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap sp.slice2348.1.1.ast with
    | structuralAccept sq' => exact ⟨sq', rfl⟩
    | rejectInvalid _ _  => rw [hChk] at hRefOrig; nomatch hRefOrig
    | rejectRefuted _    => rw [hChk] at hRefOrig; nomatch hRefOrig
    | unsupportedHeld _  => rw [hChk] at hRefOrig; nomatch hRefOrig
    | unavailableHeld _  => rw [hChk] at hRefOrig; nomatch hRefOrig
    | resourceHeld _     => rw [hChk] at hRefOrig; nomatch hRefOrig
  rcases hExSq with ⟨sq, hAcc⟩
  have hDupRej : checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore
      (ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) sp.ast =
      .rejectInvalid .G8 .duplicatePathKey :=
    checkStructuralReflex_append_self_duplicate _ _ _ _ _ _ sq hAcc rfl
  have hSliceFalse : checkSlice2348Bool
      { ctx with ledgerSnap := ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)] }
      sp.slice2348.1.1 = false := by
    unfold checkSlice2348Bool
    dsimp only
    have hDupRaw : checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore
        (ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) sp.slice2348.1.1.ast =
        .rejectInvalid .G8 .duplicatePathKey := hDupRej
    rw [hDupRaw]
    rfl
  refine ⟨hDupRej, hSliceFalse, ?_⟩
  unfold checkActiveB4SpineBool jointStandingGuardBool
  have hRetEq : retractedOfLedger (ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) =
      retractedOfLedger ctx.ledgerSnap := by
    rw [retractedOfLedger_append_eq]
    dsimp [retractedPremisesInEvents]
    exact List.append_nil _
  have hEpEq : currentEpochOfLedger (ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) =
      currentEpochOfLedger ctx.ledgerSnap := by
    unfold currentEpochOfLedger foldStructuralLedger
    rw [List.foldl_append]
    rfl
  have hPref1 : decide (ctx.ledgerSnap <+: ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) = true :=
    decide_eq_true ⟨[.recordStructuralReflex (committedEntryOfSpine sp)], rfl⟩
  have hPref0 : decide (ctx.ledgerSnap <+: ctx.ledgerSnap) = true :=
    decide_eq_true ⟨[], List.append_nil _⟩
  have hResEq : hasSilentResurrectionAfterBool sp.base.1
      (ctx.ledgerSnap ++ [.recordStructuralReflex (committedEntryOfSpine sp)]) =
      hasSilentResurrectionAfterBool sp.base.1 ctx.ledgerSnap := by
    unfold hasSilentResurrectionAfterBool foldStructuralLedger
    rw [List.foldl_append]
    dsimp [List.foldl, stepStructuralLedger, stepEpistemicState]
    rw [List.any_append]
    have hSelfFalse : ((committedEntryOfSpine sp).pathKey != sp.base.1.pathKey &&
        (committedEntryOfSpine sp).cellOldCid == sp.base.1.cellNewCid &&
        (committedEntryOfSpine sp).domNewId == "dom_Q") = false := by
      have hpEq : (committedEntryOfSpine sp).pathKey = sp.base.1.pathKey := hPathKeyEq
      simp [hpEq]
    dsimp [List.any]
    rw [hSelfFalse, Bool.or_false, Bool.or_false]
  rw [hRetEq, hEpEq, hPref1, hPref0, hResEq]

/-! ### 5. `I0-A12`: `B4` Master Conditional Soundness & Anti-Circularity (`T_D0_A11_01`, `T_D0_A11_03`) -/

/-- **`T_D0_A11_01` — `B4` Master Conditional Soundness**:
    For every context `ctx : B4SharedContext` satisfying `B4SyntacticContextValid ctx` and every
    sealed `rec : B4QualifiedRecord ctx`, if every premise `p ∈ D_B4(rec)` satisfies `SemValidPrimId ctx.primEnv p`,
    then the extracted canonical spine `extractB4Spine rec` satisfies full declarative semantics
    `SemValidB4Spine ctx (extractB4Spine rec)` (`0` checker calls in `SemValidB4Spine`)! -/
theorem T_D0_A11_01_B4_MasterConditionalSoundness
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx)
    (hCtx  : B4SyntacticContextValid ctx)
    (hPrem : ∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), SemValidPrimId ctx.primEnv p) :
    SemValidB4Spine ctx (extractB4Spine rec) := by
  let sp := extractB4Spine rec
  have hPrem56 : ∀ p ∈ deriveSlice56PrimDeps sp.slice56.1.1, SemValidPrimId ctx.primEnv p := by
    intro p hp
    apply hPrem p
    unfold deriveSpineB4PrimDeps
    rw [mem_deriveB4JointPrimDeps_iff]
    exact Or.inl hp
  have hPrem7 : ∀ p ∈ deriveSlice7PrimDeps sp.slice7.1.1, SemValidPrimId ctx.primEnv p := by
    intro p hp
    apply hPrem p
    unfold deriveSpineB4PrimDeps
    rw [mem_deriveB4JointPrimDeps_iff]
    exact Or.inr (Or.inl hp)
  have hPremInter : ∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode,
      SemValidPrimId ctx.primEnv p := by
    intro p hp
    apply hPrem p
    unfold deriveSpineB4PrimDeps
    rw [mem_deriveB4JointPrimDeps_iff]
    exact Or.inr (Or.inr hp)
  have hS1 := T_D0_A1_01_Slice2348ProvenanceSound ctx sp.slice2348.1 hCtx
  have hS2 := T_D0_A1_03_Slice56ProjectionAndSoundness ctx sp.slice56.1 hPrem56
  have hS3 := T_D0_A1_04_Slice7SharedEnvAndGoalBridgeSound ctx sp.slice7.1 hPrem7 hPremInter
  have hEp := T_D0_R1_01_SpineCommonEpochBinding ctx sp
  -- Extract payload alignment facts
  have hb1 : sp.slice2348.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber2348.2
  have hb2 : sp.slice56.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber56.2
  have hb3 : sp.slice7.1.1.claimedBase = sp.base.1 := congrArg Subtype.val sp.fiber7.2
  have hc1 := sp.slice2348.1.2
  unfold checkSlice2348Bool checkR2348AlignBool at hc1
  simp only [Bool.and_eq_true, beq_iff_eq] at hc1
  rcases hc1.2 with ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨ha_b, ha_r⟩, ha_pk⟩, ha_par⟩, ha_co⟩, ha_ob⟩, ha_cn⟩, ha_so⟩, ha_sn⟩, ha_do⟩, ha_dn⟩, ha_rk⟩, ha_hr⟩,
    _⟩, _⟩, _⟩, _⟩, _⟩, _⟩
  have hc2 := sp.slice56.1.2
  unfold checkSlice56Bool at hc2
  simp only [Bool.and_eq_true, beq_iff_eq] at hc2
  rcases hc2 with ⟨⟨⟨⟨_, _⟩, h56_tb⟩, h56_ob⟩, h56_gn⟩
  have hc3 := sp.slice7.1.2
  unfold checkSlice7Bool checkGoalBridgeModeBool at hc3
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hc3
  rcases hc3 with ⟨⟨⟨⟨⟨hEnv7, _⟩, hBun7Ok⟩, hSub7⟩, hExp7⟩, ⟨hDom7, _⟩⟩
  have hSub2348 : subjectKeyOfB1Summary (extractSummary sp.sq2348) = sp.base.1.toSubjectKey := by
    have hEqSub := (T_D0_A4_05_ProjectionAndSubjectKeyPreservation ctx sp).2.2.2
    rw [hEqSub]
    unfold B4CanonicalSpine.bundle7
    rwa [hb3] at hSub7
  have hPremSnap7 : ∀ p ∈ sp.bundle7.claimedPrimDeps, SemValidPrimId sp.bundle7.primEnvSnapshot p := by
    unfold B4CanonicalSpine.bundle7
    rw [hEnv7]
    exact hPrem7
  have hBunSound := certifiedG7Bundle_whitebox_sound sp.bundle7 hBun7Ok hPremSnap7
  have hPostGoal : ∀ ρ : Env2, InEffDom sp.base.1.domNew sp.base.1.guardsNew ρ →
      ModelsStrictForm sp.base.1.postGoal ρ := by
    have hp := hS3.2.2.2
    rwa [hb3] at hp
  refine {
    alignedPayload := ?_
    structuralValid := hS1.1
    g56CouplingValid := hS2.2.2
    g7BundleGoalValid := hBunSound
    postStateGoalValid := hPostGoal
  }
  unfold SemB4PayloadAligned B4CanonicalSpine.toPayload
    B4CanonicalSpine.ast B4CanonicalSpine.sq2348 B4CanonicalSpine.c56 B4CanonicalSpine.bundle7
  dsimp only
  have hEp1 : sp.base.1.assignedEvalEpoch = ctx.assignedEvalEpoch := hEp.1
  rw [← hb1] at hEp1 hSub2348 ⊢
  refine ⟨sp.slice2348.2, hEp1,
    ha_b, ha_r, ha_pk, ha_par, ha_co, ha_ob, ha_cn, ha_so, ha_sn, ha_do, ha_dn, ha_rk,
    ha_hr, hSub2348, ?_, ?_, ?_, ?_, ?_, hExp7⟩
  · rw [hb1, ← hb2]; exact h56_tb
  · rw [hb1, ← hb2]; exact h56_ob
  · rw [hb1, ← hb2]; exact h56_gn
  · rw [hb1, ← hb3]; exact hSub7
  · rw [hb1, ← hb3]; exact hDom7

/-- **`T_D0_A11_03` — Declarative Semantics Independence from Checker Outcomes (`0` Checker Calls)**:
    Demonstrates structurally that `SemB4PayloadValid` is a pure mathematical model predicate
    whose truth value is completely invariant (`↔`) under zeroing all checker fuels (`fuelStruct := 0`,
    `fuelG5 := 0`, `fuelG6 := 0`), whereas executable `checkSlice2348Bool` deterministically evaluates
    to `false` at `fuelStruct = 0` — paired with live `Lean.Environment` transitive-cone verification
    `Cone*(SemValidB4Spine) ∩ K_exec_all = ∅` in `AuditB4AxiomsAndDag.lean`! -/
theorem T_D0_A11_03_DeclarativeSemanticsCheckerDisjoint
    (ctx : B4SharedContext) (s : ProvenanceBoundG2348Slice) (payload : B4RawPayload) :
    let ctxZeroFuel := { ctx with fuelStruct := 0, fuelG5 := 0, fuelG6 := 0 }
    checkSlice2348Bool ctxZeroFuel s = false ∧
    (SemB4PayloadValid ctx.regId ctx.structStore ctx.ledgerSnap ctx.assignedEvalEpoch ctx.primEnv payload ↔
     SemB4PayloadValid ctxZeroFuel.regId ctxZeroFuel.structStore ctxZeroFuel.ledgerSnap
       ctxZeroFuel.assignedEvalEpoch ctxZeroFuel.primEnv payload) := by
  refine ⟨?_, Iff.rfl⟩
  unfold checkSlice2348Bool checkStructuralReflex
  rfl

/-! ### 6. Abstract Duplicate-Key JSON Parser Contract & Runtime Boundary (`T_D0_R1_08`, `T_I0_T23_07`) -/

/-- Check whether an association-list key-value stream contains any duplicate key (`F-B4-T22-10`, `F-B4-T23-07`). -/
def hasDuplicateJsonKeyBool {V : Type} : List (String × V) → Bool
  | []            => false
  | (k, _) :: kvs => (kvs.map Prod.fst).contains k || hasDuplicateJsonKeyBool kvs

/-- Strict duplicate-key-rejecting JSON pair-stream parser model (`parseJsonPairsStrict`). -/
def parseJsonPairsStrict {V : Type} (kvs : List (String × V)) : Option (List (String × V)) :=
  if hasDuplicateJsonKeyBool kvs then none else some kvs

/-- Naive last-key-wins lookup (`dict(kvs)` semantics in standard Python `json.loads` without `object_pairs_hook`). -/
def lookupJsonLastWins? {V : Type} (kvs : List (String × V)) (key : String) : Option V :=
  match kvs.reverse.find? (fun kv => kv.1 == key) with
  | some (_, v) => some v
  | none        => none

theorem hasDuplicateJsonKeyBool_false_iff_nodup {V : Type} :
    ∀ (kvs : List (String × V)),
      hasDuplicateJsonKeyBool kvs = false ↔ (kvs.map Prod.fst).Nodup
  | [] => by simp [hasDuplicateJsonKeyBool]
  | (k, v) :: tail => by
      unfold hasDuplicateJsonKeyBool
      dsimp [List.map]
      rw [Bool.or_eq_false_iff, List.nodup_cons, ← hasDuplicateJsonKeyBool_false_iff_nodup tail]
      constructor
      · rintro ⟨hContF, hTail⟩
        refine ⟨?_, hTail⟩
        intro hMem
        have hc : (tail.map Prod.fst).contains k = true := List.contains_iff_mem.mpr hMem
        rw [hc] at hContF
        nomatch hContF
      · rintro ⟨hNotMem, hTail⟩
        refine ⟨?_, hTail⟩
        cases hc : (tail.map Prod.fst).contains k with
        | false => rfl
        | true  => exact False.elim (hNotMem (List.contains_iff_mem.mp hc))

/-- Duplicate-key JSON attack payload (`CE-B4-29`). -/
def ce29_dupVerdictJson : List (String × String) :=
  [("verdict", "REJECT"), ("verdict", "FORGED_PASS")]

/-- **`T_D0_R1_08` — Abstract Duplicate-Key JSON Pair-Stream Parser Contract (`F-B4-T22-10`, `F-B4-T23-07`, `CE-B4-29`)**:
    (1) `parseJsonPairsStrict kvs = some out ↔ (kvs.map Prod.fst).Nodup ∧ out = kvs`;
    (2) Any duplicate-key stream (`¬ (kvs.map Prod.fst).Nodup`) is deterministically rejected (`= none`);
    (3) On `ce29_dupVerdictJson`, `parseJsonPairsStrict = none` while naive `lookupJsonLastWins?`
        silently returns `some "FORGED_PASS"`!
    (Paired with Python runtime execution contract `EXEC-B4-R1-08` / `CAL-B4-08` per `F-B4-T23-07`.) -/
theorem T_D0_R1_08_VerifyKitStrictJsonParseContract :
    (∀ {V : Type} (kvs out : List (String × V)),
       parseJsonPairsStrict kvs = some out ↔ ((kvs.map Prod.fst).Nodup ∧ out = kvs)) ∧
    (∀ {V : Type} (kvs : List (String × V)),
       ¬ (kvs.map Prod.fst).Nodup → parseJsonPairsStrict kvs = none) ∧
    (parseJsonPairsStrict ce29_dupVerdictJson = none ∧
     lookupJsonLastWins? ce29_dupVerdictJson "verdict" = some "FORGED_PASS") := by
  refine ⟨?_, ?_, ⟨rfl, rfl⟩⟩
  · intro V kvs out
    unfold parseJsonPairsStrict
    cases hd : hasDuplicateJsonKeyBool kvs with
    | true =>
        simp only [ite_true, reduceCtorEq, false_iff, not_and]
        intro hNodup _
        have hf := (hasDuplicateJsonKeyBool_false_iff_nodup kvs).mpr hNodup
        rw [hd] at hf
        nomatch hf
    | false =>
        simp only [Bool.false_eq_true, ite_false, Option.some.injEq]
        exact ⟨fun hEq => ⟨(hasDuplicateJsonKeyBool_false_iff_nodup kvs).mp hd, hEq.symm⟩,
               fun ⟨_, hEq⟩ => hEq.symm⟩
  · intro V kvs hNotNodup
    unfold parseJsonPairsStrict
    cases hd : hasDuplicateJsonKeyBool kvs with
    | true  => rfl
    | false => exact False.elim (hNotNodup ((hasDuplicateJsonKeyBool_false_iff_nodup kvs).mp hd))

/-- **`T_I0_T23_07` — Explicit Epistemic Boundary Between Lean Pair-Stream Model & Raw Unicode-Escape Lexing (`F-B4-T23-07`, `CE-B4-36`)**:
    Pre-unescaped raw key tokens `[("verdict", "REJECT"), ("verdict\\u0074_raw", "PASS")]` pass
    `parseJsonPairsStrict` (`some ...`), whereas post-unescaped `[("verdict", "REJECT"), ("verdict", "PASS")]`
    is rejected (`none`). Thus raw character/escape lexing inside CPython's C `json` module is NOT claimed
    as a Lean theorem (`Refinement_CPythonJsonLoads = HELD`) and is tested separately by `EXEC-B4-R1-08`! -/
theorem T_I0_T23_07_AbstractModelVsRuntimeBoundary :
    let rawPreLexTokens  : List (String × String) := [("verdict", "REJECT"), ("verdict_raw_escape", "PASS")]
    let postUnescapePairs : List (String × String) := [("verdict", "REJECT"), ("verdict", "PASS")]
    (parseJsonPairsStrict rawPreLexTokens).isSome = true ∧
    parseJsonPairsStrict postUnescapePairs = none :=
  ⟨rfl, rfl⟩

end OmegaCellC1P1B2BB4
