/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Certified Higher Composition & Historical Retreat Algebra (`ACT-I0`)
  Module: OmegaCellC1P1B2BB4.B4_03_JointClosureAndCoherentRebind

  Gates & Binding Conditions Covered:
    - `I0-A6` (`F-B4-T22-04`, `F-B4-T23-02`):
      * Exact 3-way + interaction premise closure `D_B4 = multiRootTransitivePrimDeps Γ C R_B4`
        (`T_D0_A6_01`).
      * Two non-circular bridge dependency definitions (`InductiveUsedBridgeNode` /
        `InductiveUsedBridgePrim` with `0` collector calls, AND runtime `QueriedByBridgeChecker`
        via `A0_05.verifyMultiRootTraced`), proving BOTH lie inside `(multiRootReachableNodes C R_inter,
        deriveB4InteractionPrimDeps Γ C mode)` under `ValidContainer C`, plus one-way zero-interaction
        law (`T_D0_A6_02`, `T_I0_T23_02`, `CE-B4-31`).
    - `I0-A7` (`F-B4-T22-05`, `Q-B4-R1-02`, `F-B4-T23-03`):
      * Stage 1: Context-free `SemB4PayloadValid` invariance & premise splitting (`T_D0_A6_03`).
      * Exact stale-snapshot rejection (`T_D0_R1_02`, `CE-B4-24`).
      * Stage 2: Non-circular `CoherentFormulaRebind` (`0` post-rebind checker calls in its definition),
        full ancestor-proved `checkB4CompositeBool ctx' pkt' = true` (`T_D0_R1_03`), AND construction
        of the new context-indexed `sp' : B4CanonicalSpine ctx'` satisfying `RebindSpineRel sp sp'`
        and conditional `SemValidB4Spine ctx' sp'` (`T_I0_T23_03`, `CE-B4-32`).
-/
import OmegaCellC1P1B2BB4.B4_02_SpineCoherenceAndReification

namespace OmegaCellC1P1B2BB4

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ### 1. Multi-Root & Premise-DAG Helper Lemmas -/

theorem extractTransitivePrimDeps_eq_of_toPremDag_eq
    {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer) (r : String)
    (hDag : toPremDag Γ1 = toPremDag Γ2) :
    extractTransitivePrimDeps Γ1 C r = extractTransitivePrimDeps Γ2 C r := by
  unfold extractTransitivePrimDeps
  rw [hDag]

theorem multiRootTransitivePrimDeps_eq_of_toPremDag_eq
    {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer) (roots : List String)
    (hDag : toPremDag Γ1 = toPremDag Γ2) :
    multiRootTransitivePrimDeps Γ1 C roots = multiRootTransitivePrimDeps Γ2 C roots := by
  unfold multiRootTransitivePrimDeps
  have hFold : ∀ rs : List String,
      rs.foldr (fun r acc => extractTransitivePrimDeps Γ1 C r ++ acc) [] =
      rs.foldr (fun r acc => extractTransitivePrimDeps Γ2 C r ++ acc) [] := by
    intro rs
    induction rs with
    | nil => rfl
    | cons r tail ih =>
        dsimp only [List.foldr]
        rw [extractTransitivePrimDeps_eq_of_toPremDag_eq C r hDag, ih]
  rw [hFold]

theorem multiRootTransitivePrimDeps_canonSortStrs_roots
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (roots : List String) :
    multiRootTransitivePrimDeps Γ C (canonSortStrs roots) =
    multiRootTransitivePrimDeps Γ C roots := by
  apply pairwise_strStrictLt_ext
    (by unfold multiRootTransitivePrimDeps; exact (canonSortStrs_canonical_laws _).1)
    (by unfold multiRootTransitivePrimDeps; exact (canonSortStrs_canonical_laws _).1)
  intro p
  rw [mem_multiRootTransitivePrimDeps_iff, mem_multiRootTransitivePrimDeps_iff]
  constructor
  · rintro ⟨r, hr, hp⟩
    exact ⟨r, (mem_canonSortStrs roots r).mp hr, hp⟩
  · rintro ⟨r, hr, hp⟩
    exact ⟨r, (mem_canonSortStrs roots r).mpr hr, hp⟩

theorem mem_deriveB4JointPrimDeps_iff
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c56 : G56CouplingCert) (b7 : CertifiedG7Bundle) (mode : B4G7GoalBridgeMode) (p : String) :
    p ∈ deriveB4JointPrimDeps Γ C c56 b7 mode ↔
      (p ∈ c56.claimedJointPrimDeps.jointPrimDepIds ∨
       p ∈ b7.claimedPrimDeps ∨
       p ∈ deriveB4InteractionPrimDeps Γ C mode) := by
  unfold deriveB4JointPrimDeps
  rw [mem_canonSortStrs, List.mem_append, List.mem_append, or_assoc]

/-! ### 2. `I0-A6`: Exact Joint Closure & Non-Circular Bridge Lightcone (`F-B4-T22-04`, `F-B4-T23-02`) -/

/-- **`T_D0_A6_01` — Three-Way + Interaction Joint Premise Closure Equals Multi-Root Closure**:
    For every `sp : B4CanonicalSpine ctx`, `D_B4(sp)` equals `multiRootTransitivePrimDeps` over
    `R_B4(sp)`, satisfies `isStrictCanonStrList = true`, and is `Nodup`! -/
theorem T_D0_A6_01_ThreeWayClosureEqualsMultiRootClosure
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    let D_B4 := deriveSpineB4PrimDeps ctx sp
    let R_B4 := collectB4JointProofRoots sp.c56 sp.bundle7 sp.bridgeMode
    D_B4 = multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont R_B4 ∧
    isStrictCanonStrList D_B4 = true ∧
    D_B4.Nodup := by
  dsimp only
  have h56 := sp.slice56.1.2
  unfold checkSlice56Bool at h56
  simp only [Bool.and_eq_true] at h56
  have hVer56 : isG56CouplingVerifiedBool ctx.toG56Context sp.c56 = true := h56.1.1.1.1
  have hJoint56 := (verifiedG56_projects_jointDeps ctx.toG56Context ⟨sp.c56, hVer56⟩).2.2
  dsimp [B4SharedContext.toG56Context] at hJoint56
  rcases verifiedG56_exists_verdictParams ctx.toG56Context ⟨sp.c56, hVer56⟩ with ⟨hl, rr, hcVer⟩
  rcases unpack_g56Verified hcVer with ⟨_, _, _, _, _, _, _, _, _, _, hRetL1⟩
  have hL1SubD56 :
      ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont sp.c56.scopeCompatibility,
        p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite := by
    cases hRk : sp.c56.transitionBinding.reflexKind with
    | repair =>
        rcases unpack_g56Verified hcVer with ⟨_, _, _, hScopeNone, _⟩
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        by_cases hf : (!checkReflexRetreatFlagConsistentBool sp.c56) = true
        · rw [if_pos hf] at hScopeNone; nomatch hScopeNone
        · rw [if_neg hf] at hScopeNone
          by_cases hm : (!(sp.c56.scopeCompatibility == .repairSameScope)) = true
          · rw [if_pos hm] at hScopeNone; nomatch hScopeNone
          · have hSc : sp.c56.scopeCompatibility = .repairSameScope := by
              cases hb : (sp.c56.scopeCompatibility == .repairSameScope) <;> simp_all
            rw [hSc]
            intro p hp
            unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
              multiRootTransitivePrimDeps canonSortStrs at hp
            nomatch hp
    | refinement =>
        rcases unpack_g56Verified hcVer with ⟨_, _, _, hScopeNone, _⟩
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        cases hSc : sp.c56.scopeCompatibility <;> rw [hSc] at hScopeNone
        case repairSameScope => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case retreatExactSharedLoss => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case refinementSameScope =>
          intro p hp
          unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
            multiRootTransitivePrimDeps canonSortStrs at hp
          nomatch hp
        case refinementExpandedScope =>
          intro p hp
          unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
            multiRootTransitivePrimDeps canonSortStrs at hp
          nomatch hp
    | retreat =>
        have hEmpty := (hRetL1 hRk).1
        unfold computeExtraL1PremisesOutsideD56 at hEmpty
        dsimp [B4SharedContext.toG56Context] at hEmpty
        intro p hp
        cases hCont : (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite).contains p with
        | true  => exact List.contains_iff_mem.mp hCont
        | false =>
            have hInF : p ∈ (deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont sp.c56.scopeCompatibility).filter
                (fun q => !(deriveG56JointPrimDeps ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite).contains q) :=
              List.mem_filter.mpr ⟨hp, by rw [hCont]; rfl⟩
            have hNil := List.isEmpty_iff.mp hEmpty
            rw [hNil] at hInF
            nomatch hInF
  have h7 := sp.slice7.1.2
  unfold checkSlice7Bool at h7
  simp only [Bool.and_eq_true, beq_iff_eq] at h7
  rcases h7.1.1.1 with ⟨⟨hEnv7, hDag7⟩, hBun7⟩
  unfold checkCertifiedG7BundleBool at hBun7
  simp only [Bool.and_eq_true, beq_iff_eq] at hBun7
  have hDeps7 : sp.bundle7.claimedPrimDeps =
      extractTransitivePrimDeps ctx.primEnv ctx.dagCont sp.bundle7.rootNodeId := by
    have hd := hBun7.1.2
    rwa [hEnv7, hDag7] at hd
  have hSingle7 : extractTransitivePrimDeps ctx.primEnv ctx.dagCont sp.bundle7.rootNodeId =
      multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont [sp.bundle7.rootNodeId] := by
    apply pairwise_strStrictLt_ext
    · unfold extractTransitivePrimDeps depsStarCanon
      exact (canonSortStrs_canonical_laws _).1
    · exact (canonSortStrs_canonical_laws _).1
    · intro p
      rw [mem_multiRootTransitivePrimDeps_iff]
      constructor
      · intro hp; exact ⟨sp.bundle7.rootNodeId, List.mem_cons_self .., hp⟩
      · rintro ⟨r, hr, hp⟩
        rcases List.mem_cons.mp hr with rfl | hNil
        · exact hp
        · nomatch hNil
  have hEqMain :
      deriveSpineB4PrimDeps ctx sp =
      multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont
        (collectB4JointProofRoots sp.c56 sp.bundle7 sp.bridgeMode) := by
    unfold deriveSpineB4PrimDeps deriveB4JointPrimDeps collectB4JointProofRoots
    rw [multiRootTransitivePrimDeps_canonSortStrs_roots]
    apply pairwise_strStrictLt_ext
      (canonSortStrs_canonical_laws _).1
      (by unfold multiRootTransitivePrimDeps; exact (canonSortStrs_canonical_laws _).1)
    intro p
    rw [mem_canonSortStrs, List.mem_append, List.mem_append]
    rw [hJoint56, hDeps7, hSingle7,
        (T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
          ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite).2.2.1]
    rw [mem_multiRootTransitivePrimDeps_iff, mem_multiRootTransitivePrimDeps_iff,
        mem_multiRootTransitivePrimDeps_iff]
    unfold deriveB4InteractionPrimDeps
    rw [mem_multiRootTransitivePrimDeps_iff]
    constructor
    · rintro ((⟨r, hr56, hp⟩ | ⟨r, hr7, hp⟩) | ⟨r, hrBr, hp⟩)
      · have hrJ : r ∈ collectG56JointProofRootIds sp.c56.g5Cert sp.c56.g6Suite sp.c56.scopeCompatibility := by
          unfold collectG56JointProofRootIds
          rw [mem_canonSortStrs]
          exact List.mem_append_left _ hr56
        exact ⟨r, List.mem_append_left _ (List.mem_append_left _ hrJ), hp⟩
      · exact ⟨r, List.mem_append_left _ (List.mem_append_right _ hr7), hp⟩
      · exact ⟨r, List.mem_append_right _ hrBr, hp⟩
    · rintro ⟨r, hrAll, hp⟩
      rcases List.mem_append.mp hrAll with hrLeft | hrBr
      · rcases List.mem_append.mp hrLeft with hrG56J | hr7
        · unfold collectG56JointProofRootIds at hrG56J
          rw [mem_canonSortStrs, List.mem_append] at hrG56J
          rcases hrG56J with hr56 | hrL1
          · exact Or.inl (Or.inl ⟨r, hr56, hp⟩)
          · have hpD56 : p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite :=
              hL1SubD56 p (mem_multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont hrL1 hp)
            rw [(T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
                  ctx.primEnv ctx.dagCont sp.c56.g5Cert sp.c56.g6Suite).2.2.1,
                mem_multiRootTransitivePrimDeps_iff] at hpD56
            exact Or.inl (Or.inl hpD56)
        · exact Or.inl (Or.inr ⟨r, hr7, hp⟩)
      · exact Or.inr ⟨r, hrBr, hp⟩
  refine ⟨hEqMain, ?_, ?_⟩
  · unfold deriveSpineB4PrimDeps deriveB4JointPrimDeps
    exact (canonSortStrs_canonical_laws _).2.1
  · unfold deriveSpineB4PrimDeps deriveB4JointPrimDeps
    exact nodup_of_pairwise_strStrictLt (canonSortStrs_canonical_laws _).1

/-- **Declarative Non-Circular Inductive Bridge Node Predicate (`F-B4-T23-02` Structure 1)**:
    Makes ZERO reference to `extractReachableNodeIds` or `multiRootReachableNodes`! -/
inductive InductiveUsedBridgeNode (C : G7DagContainer) : B4G7GoalBridgeMode → String → Prop where
  | root {rootId : String} {fuel : Nat} :
      InductiveUsedBridgeNode C (.certifiedBridgeL1 rootId fuel) rootId
  | stepParent {mode : B4G7GoalBridgeMode} {nid parId : String} {node : G7DagNode} :
      InductiveUsedBridgeNode C mode nid →
      lookupDagNode? C nid = some node →
      parId ∈ (extractStepFootprint node.step).parentNodeRefs →
      InductiveUsedBridgeNode C mode parId

/-- Alias matching `R1` / `I0-A1` symbol `IsReferencedB4BridgeNodeId`. -/
abbrev IsReferencedB4BridgeNodeId (ctx : B4SharedContext) (mode : B4G7GoalBridgeMode) (nid : String) : Prop :=
  InductiveUsedBridgeNode ctx.dagCont mode nid

/-- **Declarative Non-Circular Inductive Bridge Premise Predicate (`F-B4-T23-02` Structure 1b)**:
    Makes ZERO reference to `extractTransitivePrimDeps` or `multiRootTransitivePrimDeps`! -/
inductive InductiveUsedBridgePrim (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (mode : B4G7GoalBridgeMode) : String → Prop where
  | directAtNode {nid pid0 pid : String} {node : G7DagNode} :
      InductiveUsedBridgeNode C mode nid →
      lookupDagNode? C nid = some node →
      pid0 ∈ (extractStepFootprint node.step).primRefs →
      pid ∈ depsStarCanon (toPremDag Γ) [pid0] →
      InductiveUsedBridgePrim Γ C mode pid

/-- **Actual Runtime Checker Query Trace Predicates (`F-B4-T23-02` Structure 2)**:
    Records every node/premise actually queried by `verifyMultiRootTraced` when checking `bridgeRootsOfMode`. -/
def bridgeFuelOfMode : B4G7GoalBridgeMode → Nat
  | .directUnguardedL0       => 0
  | .impNormalizedA0         => 0
  | .certifiedBridgeL1 _ f   => f

def QueriedNodeByBridgeChecker (ctx : B4SharedContext) (mode : B4G7GoalBridgeMode) (nid : String) : Prop :=
  nid ∈ (verifyMultiRootTraced (bridgeFuelOfMode mode) ctx.primEnv ctx.dagCont (bridgeRootsOfMode mode)).2.queriedNodeIds

def QueriedPrimByBridgeChecker (ctx : B4SharedContext) (mode : B4G7GoalBridgeMode) (pid : String) : Prop :=
  pid ∈ (verifyMultiRootTraced (bridgeFuelOfMode mode) ctx.primEnv ctx.dagCont (bridgeRootsOfMode mode)).2.queriedPrimIds

private theorem subset_expandNodeStep_b4 (C : G7DagContainer) (cur : List String) :
    ∀ x ∈ cur, x ∈ expandNodeStep C cur := by
  induction cur with
  | nil => intro _ h; nomatch h
  | cons a as ih =>
      intro x hx
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hx with rfl | hRest
      · exact Or.inl rfl
      · exact Or.inr (Or.inr (ih x hRest))

private theorem parent_mem_expandNodeStep_b4 (C : G7DagContainer) (cur : List String)
    {nid parId : String} {n : G7DagNode}
    (hMem : nid ∈ cur) (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    parId ∈ expandNodeStep C cur := by
  induction cur with
  | nil => nomatch hMem
  | cons a as ih =>
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hMem with rfl | hRest
      · rw [hLook]
        exact Or.inr (Or.inl hPar)
      · exact Or.inr (Or.inr (ih hRest))

private theorem mono_transNodeIter_b4 (C : G7DagContainer) (cur : List String) {k : Nat} :
    ∀ (d : Nat) {x : String}, x ∈ transNodeIter k C cur → x ∈ transNodeIter (k + d) C cur
  | 0,     _, hx => hx
  | d + 1, _, hx =>
      subset_expandNodeStep_b4 C (transNodeIter (k + d) C cur) _
        (mono_transNodeIter_b4 C cur d hx)

private theorem mem_transNodeIter_le_b4 (C : G7DagContainer) (cur : List String) {k m : Nat}
    (hLe : k ≤ m) {x : String} (hx : x ∈ transNodeIter k C cur) :
    x ∈ transNodeIter m C cur := by
  have hEq : k + (m - k) = m := Nat.add_sub_of_le hLe
  rw [← hEq]
  exact mono_transNodeIter_b4 C cur (m - k) hx

private theorem topoRank_le_maxTopoRank_b4 {C : G7DagContainer} {n : G7DagNode}
    (hMem : n ∈ C.nodes) : n.topoRank ≤ maxTopoRank C := by
  unfold maxTopoRank
  have hList : ∀ (L : List G7DagNode), n ∈ L →
      n.topoRank ≤ L.foldr (fun x acc => Nat.max x.topoRank acc) 0 := by
    intro L hIn
    induction L with
    | nil => nomatch hIn
    | cons a as ih =>
        dsimp only [List.foldr]
        rcases List.mem_cons.mp hIn with rfl | hTail
        · exact Nat.le_max_left n.topoRank _
        · exact Nat.le_trans (ih hTail) (Nat.le_max_right a.topoRank _)
  exact hList C.nodes hMem

private theorem validContainer_parent_rank_b4 {C : G7DagContainer} (hVal : ValidContainer C)
    {nid parId : String} {n : G7DagNode}
    (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    ∃ par : G7DagNode, lookupDagNode? C parId = some par ∧ par.topoRank < n.topoRank := by
  unfold ValidContainer checkContainerIntegrityBool at hVal
  simp only [Bool.and_eq_true] at hVal
  have hMem : n ∈ C.nodes := List.mem_of_find?_eq_some hLook
  have hNodeOk := List.all_eq_true.mp hVal.2 n hMem
  simp only [Bool.and_eq_true] at hNodeOk
  have hParOk := List.all_eq_true.mp hNodeOk.2 parId hPar
  cases hp : lookupDagNode? C parId with
  | none     => rw [hp] at hParOk; nomatch hParOk
  | some par =>
      rw [hp] at hParOk
      exact ⟨par, rfl, of_decide_eq_true hParOk⟩

/-- Key non-circular completeness proof: under `ValidContainer C`, every `InductiveUsedBridgeNode`
    carries a bounded rank-descent witness into `transNodeIter k C [rootId]` (`k ≤ maxTopoRank C + 1`),
    and hence belongs to `multiRootReachableNodes C (bridgeRootsOfMode mode)`! -/
theorem inductiveUsedBridgeNode_in_multiRootReachable
    {C : G7DagContainer} {mode : B4G7GoalBridgeMode} {nid : String}
    (hVal  : ValidContainer C)
    (hUsed : InductiveUsedBridgeNode C mode nid) :
    nid ∈ multiRootReachableNodes C (bridgeRootsOfMode mode) := by
  have hRankWitness :
      ∃ (rootId : String) (fuel k : Nat),
        mode = .certifiedBridgeL1 rootId fuel ∧
        k ≤ maxTopoRank C + 1 ∧
        nid ∈ transNodeIter k C [rootId] ∧
        (∀ nd : G7DagNode, lookupDagNode? C nid = some nd → k + nd.topoRank ≤ maxTopoRank C) := by
    induction hUsed with
    | @root rId fl =>
        refine ⟨rId, fl, 0, rfl, Nat.zero_le _, List.mem_cons_self .., ?_⟩
        intro nd hL
        rw [Nat.zero_add]
        exact topoRank_le_maxTopoRank_b4 (List.mem_of_find?_eq_some hL)
    | @stepParent md curNid parId curNode _ hLook hPar ih =>
        rcases ih with ⟨rId, fl, k, hModeEq, hkLe, hCurIter, hCurRank⟩
        rcases validContainer_parent_rank_b4 hVal hLook hPar with ⟨parNode, hParLook, hLt⟩
        have hCurBnd : k + curNode.topoRank ≤ maxTopoRank C := hCurRank curNode hLook
        have hk1Le : k + 1 ≤ maxTopoRank C + 1 := by omega
        have hParIter : parId ∈ transNodeIter (k + 1) C [rId] :=
          parent_mem_expandNodeStep_b4 C (transNodeIter k C [rId]) hCurIter hLook hPar
        refine ⟨rId, fl, k + 1, hModeEq, hk1Le, hParIter, ?_⟩
        intro nd hNdLook
        rw [hParLook] at hNdLook
        injection hNdLook with hEq; subst hEq
        omega
  rcases hRankWitness with ⟨rId, fl, k, hModeEq, hkLe, hIter, _⟩
  rw [hModeEq]
  apply mem_multiRootReachableNodes C (List.mem_cons_self ..)
  unfold extractReachableNodeIds
  rw [mem_canonSortStrs]
  exact mem_transNodeIter_le_b4 C [rId] hkLe hIter

private theorem prim_mem_collectDirectPrimRefs_b4 (C : G7DagContainer) (nodeIds : List String)
    {nid pid : String} {n : G7DagNode}
    (hNodeMem : nid ∈ nodeIds) (hLook : lookupDagNode? C nid = some n)
    (hPrim : pid ∈ (extractStepFootprint n.step).primRefs) :
    pid ∈ collectDirectPrimRefsOfNodes C nodeIds := by
  unfold collectDirectPrimRefsOfNodes
  rw [mem_canonSortStrs]
  induction nodeIds with
  | nil => nomatch hNodeMem
  | cons a as ih =>
      simp only [List.foldr_cons]
      rcases List.mem_cons.mp hNodeMem with rfl | hRest
      · rw [hLook]
        exact List.mem_append_left _ hPrim
      · cases lookupDagNode? C a with
        | none    => exact ih hRest
        | some na => exact List.mem_append_right _ (ih hRest)

private theorem depsStarCanon_mono_sub {dag : PremDag} {s1 s2 : List String}
    (hSub : ∀ x ∈ s1, x ∈ s2) :
    ∀ p ∈ depsStarCanon dag s1, p ∈ depsStarCanon dag s2 := by
  have hExp : ∀ (u v : List String), (∀ y ∈ u, y ∈ v) →
      ∀ z ∈ expandPremStep dag u, z ∈ expandPremStep dag v := by
    intro u v huv z hz
    induction u with
    | nil => nomatch hz
    | cons hd tl ihu =>
        unfold expandPremStep at hz
        simp only [List.foldr_cons, List.mem_cons, List.mem_append] at hz
        have hHdInV : hd ∈ v := huv hd (List.mem_cons_self ..)
        rcases hz with rfl | hPar | hTail
        · have hInSelf : ∀ w : List String, z ∈ w → z ∈ expandPremStep dag w := by
            intro w hw
            induction w with
            | nil => nomatch hw
            | cons w0 ws ihw =>
                unfold expandPremStep
                simp only [List.foldr_cons, List.mem_cons, List.mem_append]
                rcases List.mem_cons.mp hw with rfl | hwt
                · exact Or.inl rfl
                · exact Or.inr (Or.inr (ihw hwt))
          exact hInSelf v hHdInV
        · have hParInV : ∀ w : List String, hd ∈ w →
              z ∈ lookupPremParents dag hd →
              z ∈ expandPremStep dag w := by
            intro w hw hzp
            induction w with
            | nil => nomatch hw
            | cons w0 ws ihw =>
                unfold expandPremStep
                simp only [List.foldr_cons, List.mem_cons, List.mem_append]
                rcases List.mem_cons.mp hw with rfl | hwt
                · exact Or.inr (Or.inl hzp)
                · exact Or.inr (Or.inr (ihw hwt))
          exact hParInV v hHdInV hPar
        · exact ihu (fun y hy => huv y (List.mem_cons_of_mem hd hy)) hTail
  have hIterMono : ∀ (k : Nat) (a b : List String),
      (∀ x ∈ a, x ∈ b) →
      ∀ x ∈ transPremIter k dag a, x ∈ transPremIter k dag b := by
    intro k
    induction k with
    | zero => intro a b hab x hx; exact hab x hx
    | succ k' ih =>
        intro a b hab x hx
        exact ih (expandPremStep dag a) (expandPremStep dag b) (hExp a b hab) x hx
  unfold depsStarCanon
  intro p hp
  rw [mem_canonSortStrs] at hp ⊢
  exact hIterMono (dag.length + 1) s1 s2 hSub p hp

/-- **`T_D0_A6_02` — One-Way Zero-Interaction Law & Reachable Lightcone Inclusion (`F-B4-T22-04`)**:
    (1) One-way implication: `mode ∈ {.directUnguardedL0, .impNormalizedA0} ⟹ R_inter = [] ∧ D_interaction = []`;
    (2) Under `ValidContainer ctx.dagCont`, every `IsReferencedB4BridgeNodeId` lies in
        `multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode mode)`;
    (3) Every interaction premise in `D_interaction` belongs to `D_B4(sp)`. -/
theorem T_D0_A6_02_InteractionPremiseZeroAndBridgeCompleteness
    (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    ((sp.bridgeMode = .directUnguardedL0 ∨ sp.bridgeMode = .impNormalizedA0) →
       bridgeRootsOfMode sp.bridgeMode = [] ∧
       deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode = []) ∧
    (ValidContainer ctx.dagCont →
       ∀ nid : String,
         IsReferencedB4BridgeNodeId ctx sp.bridgeMode nid →
         nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode sp.bridgeMode)) ∧
    (∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode,
       p ∈ deriveSpineB4PrimDeps ctx sp) := by
  refine ⟨?_, ?_, ?_⟩
  · rintro (h0 | h1a)
    · rw [h0]; exact ⟨rfl, rfl⟩
    · rw [h1a]; exact ⟨rfl, rfl⟩
  · intro hVal nid hRef
    exact inductiveUsedBridgeNode_in_multiRootReachable hVal hRef
  · intro p hp
    unfold deriveSpineB4PrimDeps
    exact (mem_deriveB4JointPrimDeps_iff ctx.primEnv ctx.dagCont sp.c56 sp.bundle7 sp.bridgeMode p).mpr
      (Or.inr (Or.inr hp))

/-- Malformed cyclic/inverted-rank container (`CE-B4-31`, `ValidContainer = false`) demonstrating why
    `ValidContainer` is a genuine mathematical requirement in `F-B4-T23-02` (`maxTopoRank = 0`, chain of 2 hops!). -/
def ce31_malformedRankZeroCont : G7DagContainer where
  nodes := [
    { nodeId := "b_root", topoRank := 0, domTag := .domQ, specId := "s", guards := [],
      conclusion := .eqZero (.const 0),
      step := .directDerivStep (.parentRef "b_mid" (.eqZero (.const 0))) },
    { nodeId := "b_mid", topoRank := 0, domTag := .domQ, specId := "s", guards := [],
      conclusion := .eqZero (.const 0),
      step := .directDerivStep (.parentRef "b_deep" (.eqZero (.const 0))) },
    { nodeId := "b_deep", topoRank := 0, domTag := .domQ, specId := "s", guards := [],
      conclusion := .eqZero (.const 0),
      step := .directDerivStep (.certStep (.eqZero (.const 0)) (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩)) }
  ]

/-- **`T_I0_T23_02` — Dual Non-Circular Bridge Semantic & Runtime Closure + `ValidContainer` Necessity (`F-B4-T23-02`, `CE-B4-31`)**:
    (1) Under `ValidContainer ctx.dagCont`, BOTH declarative `InductiveUsedBridgeNode` /
        `InductiveUsedBridgePrim` AND runtime `QueriedNodeByBridgeChecker` /
        `QueriedPrimByBridgeChecker` are confined to `(multiRootReachableNodes, deriveB4InteractionPrimDeps)`;
    (2) On `ce31_malformedRankZeroCont` (`ValidContainer = false`), `"b_deep"` is a genuine
        2-hop `InductiveUsedBridgeNode`, yet `multiRootReachableNodes` (`maxTopoRank + 1 = 1` step)
        does NOT contain `"b_deep"`, proving our non-circular inclusion theorem is non-trivial! -/
theorem T_I0_T23_02_NonCircularBridgeSemanticAndRuntimeClosure :
    (∀ (ctx : B4SharedContext) (mode : B4G7GoalBridgeMode),
       ValidContainer ctx.dagCont →
       (∀ nid, InductiveUsedBridgeNode ctx.dagCont mode nid →
          nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode mode)) ∧
       (∀ pid, InductiveUsedBridgePrim ctx.primEnv ctx.dagCont mode pid →
          pid ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont mode) ∧
       (∀ nid, QueriedNodeByBridgeChecker ctx mode nid →
          nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode mode)) ∧
       (∀ pid, QueriedPrimByBridgeChecker ctx mode pid →
          pid ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont mode)) ∧
    (ValidContainer ce31_malformedRankZeroCont = false ∧
     InductiveUsedBridgeNode ce31_malformedRankZeroCont (.certifiedBridgeL1 "b_root" 4) "b_deep" ∧
     "b_deep" ∉ multiRootReachableNodes ce31_malformedRankZeroCont ["b_root"]) := by
  refine ⟨?_, ?_⟩
  · intro ctx mode hVal
    have hRun := A0_05_2_ActualLookupConfinement
      (bridgeFuelOfMode mode) ctx.primEnv ctx.dagCont (bridgeRootsOfMode mode) hVal
    refine ⟨fun _ hu => inductiveUsedBridgeNode_in_multiRootReachable hVal hu,
            ?_,
            fun nid hq => hRun.1 nid hq,
            fun pid hq => hRun.2 pid hq⟩
    intro pid hUp
    cases hUp with
    | @directAtNode nid pid0 _ node hNodeUsed hLook hPrimRef hInStar =>
        have hReach := inductiveUsedBridgeNode_in_multiRootReachable hVal hNodeUsed
        cases hm : mode with
        | directUnguardedL0 =>
            rw [hm] at hNodeUsed
            have : False := by
              have hM := inductiveUsedBridgeNode_in_multiRootReachable hVal hNodeUsed
              unfold bridgeRootsOfMode multiRootReachableNodes canonSortStrs at hM
              nomatch hM
            exact False.elim this
        | impNormalizedA0 =>
            rw [hm] at hNodeUsed
            have : False := by
              have hM := inductiveUsedBridgeNode_in_multiRootReachable hVal hNodeUsed
              unfold bridgeRootsOfMode multiRootReachableNodes canonSortStrs at hM
              nomatch hM
            exact False.elim this
        | certifiedBridgeL1 rId fl =>
            rw [hm] at hReach
            unfold bridgeRootsOfMode multiRootReachableNodes at hReach
            rw [mem_canonSortStrs, List.foldr_cons, List.foldr_nil, List.append_nil] at hReach
            have hDir : pid0 ∈ collectDirectPrimRefsOfNodes ctx.dagCont
                (extractReachableNodeIds ctx.dagCont rId) :=
              prim_mem_collectDirectPrimRefs_b4 ctx.dagCont _ hReach hLook hPrimRef
            have hInRootDeps : pid ∈ extractTransitivePrimDeps ctx.primEnv ctx.dagCont rId := by
              unfold extractTransitivePrimDeps
              exact depsStarCanon_mono_sub
                (fun x hx => by rcases List.mem_cons.mp hx with rfl | hNil; exact hDir; nomatch hNil)
                pid hInStar
            unfold deriveB4InteractionPrimDeps bridgeRootsOfMode
            exact mem_multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont (List.mem_cons_self ..) hInRootDeps
  · refine ⟨by decide, ?_, by decide⟩
    have h0 : InductiveUsedBridgeNode ce31_malformedRankZeroCont (.certifiedBridgeL1 "b_root" 4) "b_root" :=
      .root
    have h1 : InductiveUsedBridgeNode ce31_malformedRankZeroCont (.certifiedBridgeL1 "b_root" 4) "b_mid" :=
      .stepParent h0 rfl (List.mem_cons_self ..)
    exact .stepParent h1 rfl (List.mem_cons_self ..)

/-! ### 3. `I0-A7`: Payload Non-Interference, Stale-Snapshot Rejection, & Coherent Re-Binding (`F-B4-T22-05`, `Q-B4-R1-02`, `F-B4-T23-03`) -/

private theorem lookupPrimPrem?_replace_ne_b4 (Γ : PrimPremiseEnv)
    (q_out pid : String) (newFormula : StrictForm) (hNe : pid ≠ q_out) :
    lookupPrimPrem? (replacePrimFormulaInEnv Γ q_out newFormula) pid =
    lookupPrimPrem? Γ pid := by
  unfold lookupPrimPrem? replacePrimFormulaInEnv
  induction Γ with
  | nil => rfl
  | cons e es ih =>
      dsimp only [List.map, List.find?]
      by_cases h1 : (e.premId == q_out) = true
      · rw [if_pos h1]
        have heqOut : e.premId = q_out := eq_of_beq h1
        have hFalse : (e.premId == pid) = false := by
          apply Bool.eq_false_iff.mpr
          intro hb
          exact hNe (heqOut.symm.trans (eq_of_beq hb)).symm
        dsimp only; rw [hFalse]; exact ih
      · rw [if_neg h1]
        cases (e.premId == pid) with
        | true  => rfl
        | false => exact ih

/-- **`T_D0_A6_03` (`R1`/`T23` Stage-1 Scoped: Premise Splitting & Payload Semantic Non-Interference — `F-B4-T22-05`, `F-B4-T23-03`)**:
    (1) `∀ p ∈ D_B4, SemValidPrimId Γ p` splits if and only if across `(D56, D7, D_interaction)`;
    (2) Formula-only update at `q ∉ D_B4` preserves `lookupPrimPrem?` and `SemValidPrimId` on `D_B4`;
    (3) Context-free declarative `SemB4PayloadValid` is invariant between `Γ` and `Γ'`! -/
theorem T_D0_A6_03_PremiseSplittingAndOutsideNonInterference
    (regId : String) (store : StructuralStore) (L : List StructuralLedgerEvent)
    (epoch : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (pld : B4RawPayload) (q_out : String) (newFormula : StrictForm)
    (hOut : q_out ∉ deriveB4JointPrimDeps Γ C pld.c56 pld.bundle7 pld.bridgeMode) :
    let D_B4   := deriveB4JointPrimDeps Γ C pld.c56 pld.bundle7 pld.bridgeMode
    let D56    := pld.c56.claimedJointPrimDeps.jointPrimDepIds
    let D7     := pld.bundle7.claimedPrimDeps
    let D_int  := deriveB4InteractionPrimDeps Γ C pld.bridgeMode
    let Γ'     := replacePrimFormulaInEnv Γ q_out newFormula
    ((∀ p ∈ D_B4, SemValidPrimId Γ p) ↔
      ((∀ p ∈ D56, SemValidPrimId Γ p) ∧
       (∀ p ∈ D7, SemValidPrimId Γ p) ∧
       (∀ p ∈ D_int, SemValidPrimId Γ p))) ∧
    (∀ p ∈ D_B4,
       lookupPrimPrem? Γ' p = lookupPrimPrem? Γ p ∧
       (SemValidPrimId Γ' p ↔ SemValidPrimId Γ p)) ∧
    (SemB4PayloadValid regId store L epoch Γ pld ↔
     SemB4PayloadValid regId store L epoch Γ' pld) := by
  dsimp only
  have hSplit :
      (∀ p ∈ deriveB4JointPrimDeps Γ C pld.c56 pld.bundle7 pld.bridgeMode, SemValidPrimId Γ p) ↔
      ((∀ p ∈ pld.c56.claimedJointPrimDeps.jointPrimDepIds, SemValidPrimId Γ p) ∧
       (∀ p ∈ pld.bundle7.claimedPrimDeps, SemValidPrimId Γ p) ∧
       (∀ p ∈ deriveB4InteractionPrimDeps Γ C pld.bridgeMode, SemValidPrimId Γ p)) := by
    constructor
    · intro hAll
      refine ⟨?_, ?_, ?_⟩
      · intro p hp
        exact hAll p ((mem_deriveB4JointPrimDeps_iff Γ C pld.c56 pld.bundle7 pld.bridgeMode p).mpr (Or.inl hp))
      · intro p hp
        exact hAll p ((mem_deriveB4JointPrimDeps_iff Γ C pld.c56 pld.bundle7 pld.bridgeMode p).mpr (Or.inr (Or.inl hp)))
      · intro p hp
        exact hAll p ((mem_deriveB4JointPrimDeps_iff Γ C pld.c56 pld.bundle7 pld.bridgeMode p).mpr (Or.inr (Or.inr hp)))
    · rintro ⟨h56, h7, hint⟩ p hp
      rcases (mem_deriveB4JointPrimDeps_iff Γ C pld.c56 pld.bundle7 pld.bridgeMode p).mp hp with hp56 | hp7 | hpInt
      · exact h56 p hp56
      · exact h7 p hp7
      · exact hint p hpInt
  refine ⟨hSplit, ?_, ?_⟩
  · intro p hp
    have hNe : p ≠ q_out := fun heq => hOut (heq ▸ hp)
    have hLook := lookupPrimPrem?_replace_ne_b4 Γ q_out p newFormula hNe
    refine ⟨hLook, ?_⟩
    unfold SemValidPrimId
    rw [hLook]
  · constructor <;> (rintro ⟨h1, h2, h3, h4, h5⟩; exact ⟨h1, h2, h3, h4, h5⟩)

/-- **`T_D0_R1_02` — Exact Snapshot Mismatch Deterministic Rejection (`F-B4-T22-05`, `CE-B4-24`)**:
    Whenever `pkt.s7.bundle.primEnvSnapshot ≠ ctx'.primEnv` or `dagSnapshot ≠ ctx'.dagCont`
    (even when the difference is an unused premise outside `D_B4`), `checkB4CompositeBool ctx' pkt = false`! -/
theorem T_D0_R1_02_ExactSnapshotMismatchRejection
    (ctx' : B4SharedContext) (pkt : B4CandidatePacket)
    (hMis : pkt.s7.bundle.primEnvSnapshot ≠ ctx'.primEnv ∨
            pkt.s7.bundle.dagSnapshot ≠ ctx'.dagCont) :
    evalB4CompositeError? ctx' pkt = some .mismatchedSharedEnvOrDag ∧
    checkB4CompositeBool ctx' pkt = false :=
  (T_D0_A3_03_SplitTransitionOrContextRejection ctx' pkt).1 hMis

/-- **Strictly Non-Circular `CoherentFormulaRebind` (`Q-B4-R1-02`, `F-B4-T23-03`)**:
    Contains ZERO references to `checkB4CompositeBool ctx' pkt'` or any post-rebind checker verdict! -/
structure CoherentFormulaRebind
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (ctx' : B4SharedContext) (pkt' : B4CandidatePacket) : Prop where
  regId_eq       : ctx'.regId = ctx.regId
  store_eq       : ctx'.structStore = ctx.structStore
  ledger_eq      : ctx'.ledgerSnap = ctx.ledgerSnap
  fuels_eq       : ctx'.fuelStruct = ctx.fuelStruct ∧
                   ctx'.fuelG5 = ctx.fuelG5 ∧
                   ctx'.fuelG6 = ctx.fuelG6
  epoch_eq       : ctx'.assignedEvalEpoch = ctx.assignedEvalEpoch
  dagCont_eq     : ctx'.dagCont = ctx.dagCont
  primEnvInt_ok  : checkPrimEnvIntegrityBool ctx'.primEnv = true
  premDag_eq     : toPremDag ctx'.primEnv = toPremDag ctx.primEnv
  activeFootprint_eq :
    ∀ p ∈ deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode,
      lookupPrimPrem? ctx'.primEnv p = lookupPrimPrem? ctx.primEnv p
  pkt_s2348_eq   : pkt'.s2348 = pkt.s2348
  pkt_s56_eq     : pkt'.s56 = pkt.s56
  pkt_s7_rebound : pkt'.s7 =
    { pkt.s7 with bundle := { pkt.s7.bundle with primEnvSnapshot := ctx'.primEnv } }
  pkt_deps_eq    : pkt'.claimedCompositePrimDeps = pkt.claimedCompositePrimDeps

/-- Deterministic packet re-binder aligning `s7.bundle.primEnvSnapshot` to `ctx'.primEnv`. -/
def rebindPacketToContext (ctx' : B4SharedContext) (pkt : B4CandidatePacket) : B4CandidatePacket where
  s2348 := pkt.s2348
  s56   := pkt.s56
  s7    := { pkt.s7 with bundle := { pkt.s7.bundle with primEnvSnapshot := ctx'.primEnv } }
  claimedCompositePrimDeps := pkt.claimedCompositePrimDeps

private theorem exactG7Seq_congr_single
    (fuel : Nat) {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer)
    (nid : String) (domTag : G7DomTag) (specId : String) (gs : List StrictForm) (goal : StrictForm)
    (hVal  : ValidContainer C)
    (hPrim : ∀ p ∈ extractTransitivePrimDeps Γ1 C nid, lookupPrimPrem? Γ1 p = lookupPrimPrem? Γ2 p) :
    checkExactG7SequentBool fuel Γ1 C nid domTag specId gs goal =
    checkExactG7SequentBool fuel Γ2 C nid domTag specId gs goal := by
  unfold checkExactG7SequentBool
  have hMap := A0_05_1_OutputCongruence fuel (Γ1 := Γ1) (Γ2 := Γ2) (C1 := C) (C2 := C) [nid] hVal
    (fun _ _ => rfl)
    (fun pid hp => by
      rw [mem_multiRootTransitivePrimDeps_iff] at hp
      rcases hp with ⟨r, hr, hpr⟩
      rcases List.mem_cons.mp hr with rfl | hNil
      · exact hPrim pid hpr
      · nomatch hNil)
  simp only [List.map] at hMap
  injection hMap with hHead _
  rw [hHead]

private theorem list_all_congr_b4 {α : Type} {f g : α → Bool} :
    ∀ (L : List α), (∀ x ∈ L, f x = g x) → L.all f = L.all g
  | [], _ => rfl
  | a :: as, h => by
      simp only [List.all_cons]
      rw [h a (List.mem_cons_self ..), list_all_congr_b4 as (fun x hx => h x (List.mem_cons_of_mem a hx))]

private theorem guardEntailmentList_congr
    (fuel : Nat) {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer)
    (domTag : G7DomTag) (specId : String) (gs targetGs : List StrictForm)
    (ps : List (StrictForm × String))
    (hVal  : ValidContainer C)
    (hPrim : ∀ nid ∈ ps.map Prod.snd, ∀ p ∈ extractTransitivePrimDeps Γ1 C nid,
               lookupPrimPrem? Γ1 p = lookupPrimPrem? Γ2 p) :
    checkGuardEntailmentListBool fuel Γ1 C domTag specId gs targetGs ps =
    checkGuardEntailmentListBool fuel Γ2 C domTag specId gs targetGs ps := by
  unfold checkGuardEntailmentListBool
  congr 1
  apply list_all_congr_b4
  rintro ⟨ψ, nid⟩ hMem
  exact exactG7Seq_congr_single fuel C nid domTag specId gs ψ hVal
    (hPrim nid (List.mem_map_of_mem hMem))

private theorem directionalLocusCover_congr
    (fuel : Nat) {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer)
    (D_old : G7DomTag) (G_old : List StrictForm) (specNewId : String)
    (L_src L_dst : ExcisedLocus) (cov : G56DirectionalLocusCover)
    (hVal  : ValidContainer C)
    (hPrim : ∀ nid ∈ rawDirectionalCoverRootIds cov,
               ∀ p ∈ extractTransitivePrimDeps Γ1 C nid,
                 lookupPrimPrem? Γ1 p = lookupPrimPrem? Γ2 p) :
    checkDirectionalLocusCoverBool fuel Γ1 C D_old G_old specNewId L_src L_dst cov =
    checkDirectionalLocusCoverBool fuel Γ2 C D_old G_old specNewId L_src L_dst cov := by
  unfold checkDirectionalLocusCoverBool
  have h1 : cov.targetDefNodes.all (fun (B_k, defNid) =>
      checkExactG7SequentBool fuel Γ1 C defNid D_old specNewId (G_old ++ B_k) (.eqZero (.const 0))) =
    cov.targetDefNodes.all (fun (B_k, defNid) =>
      checkExactG7SequentBool fuel Γ2 C defNid D_old specNewId (G_old ++ B_k) (.eqZero (.const 0))) := by
    apply list_all_congr_b4
    rintro ⟨B_k, defNid⟩ hMem
    apply exactG7Seq_congr_single fuel C defNid D_old specNewId (G_old ++ B_k) (.eqZero (.const 0)) hVal
    apply hPrim defNid
    unfold rawDirectionalCoverRootIds
    exact List.mem_append_left _ (List.mem_map_of_mem hMem)
  have h2 : cov.branchCovers.all (fun (A_j, B_target, psiNodes) =>
      L_dst.contains B_target &&
      checkGuardEntailmentListBool fuel Γ1 C D_old specNewId (G_old ++ A_j) B_target psiNodes) =
    cov.branchCovers.all (fun (A_j, B_target, psiNodes) =>
      L_dst.contains B_target &&
      checkGuardEntailmentListBool fuel Γ2 C D_old specNewId (G_old ++ A_j) B_target psiNodes) := by
    apply list_all_congr_b4
    rintro ⟨A_j, B_target, psiNodes⟩ hMem
    dsimp only
    congr 1
    apply guardEntailmentList_congr fuel C D_old specNewId (G_old ++ A_j) B_target psiNodes hVal
    intro nid hNidMap
    rcases List.mem_map.mp hNidMap with ⟨⟨ψ, u⟩, hPairMem, hEqU⟩
    dsimp only at hEqU; subst hEqU
    apply hPrim u
    unfold rawDirectionalCoverRootIds
    apply List.mem_append_right
    have hFold : ∀ (L : List (List StrictForm × List StrictForm × List (StrictForm × String))),
        (A_j, B_target, psiNodes) ∈ L →
        u ∈ L.foldr (fun (_, _, q) acc => q.map Prod.snd ++ acc) [] := by
      intro L hIn
      induction L with
      | nil => nomatch hIn
      | cons hd tl ih =>
          dsimp only [List.foldr]
          rcases List.mem_cons.mp hIn with rfl | hTail
          · exact List.mem_append_left _ (List.mem_map_of_mem hPairMem)
          · exact List.mem_append_right _ (ih hTail)
    exact hFold cov.branchCovers hMem
  rw [h1, h2]

private theorem retreatPairsLoop_congr
    (fuel : Nat) {Γ1 Γ2 : PrimPremiseEnv} (C : G7DagContainer)
    (D_old : G7DomTag) (G_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus)
    (hVal : ValidContainer C) :
    ∀ (items : List G6ProtectedInvariantSpec) (binds : List G56ItemLossBinding),
      (∀ nid ∈ collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ_shared binds),
         ∀ p ∈ extractTransitivePrimDeps Γ1 C nid,
           lookupPrimPrem? Γ1 p = lookupPrimPrem? Γ2 p) →
      checkRetreatItemPairsLoop fuel Γ1 C D_old G_old specNewId Φ_shared items binds =
      checkRetreatItemPairsLoop fuel Γ2 C D_old G_old specNewId Φ_shared items binds
  | [], [], _ => rfl
  | _ :: _, [], _ => rfl
  | [], _ :: _, _ => rfl
  | item :: restItems, bind :: restBinds, hPrim => by
      have hTailPrim : ∀ nid ∈ collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ_shared restBinds),
          ∀ p ∈ extractTransitivePrimDeps Γ1 C nid,
            lookupPrimPrem? Γ1 p = lookupPrimPrem? Γ2 p := by
        intro nid hNid
        apply hPrim nid
        unfold collectScopeCompatLossRootIds at hNid ⊢
        rw [mem_canonSortStrs] at hNid ⊢
        dsimp only [List.foldr]
        cases bind.mode with
        | l0SyntacticEq   => exact hNid
        | l1CertifiedEq _ => exact List.mem_append_right _ hNid
      have hHeadEq :
          checkSingleRetreatItemLossPair fuel Γ1 C D_old G_old specNewId Φ_shared item bind =
          checkSingleRetreatItemLossPair fuel Γ2 C D_old G_old specNewId Φ_shared item bind := by
        unfold checkSingleRetreatItemLossPair
        split
        · rfl
        · cases item.scopeLossRecord? with
          | none => rfl
          | some lr6 =>
              dsimp only
              split
              · rfl
              · cases hm : bind.mode with
                | l0SyntacticEq => rfl
                | l1CertifiedEq w =>
                    dsimp only
                    have hW : checkSingleL1LossEquivBool fuel Γ1 C D_old G_old specNewId
                                item.invariantId Φ_shared lr6.excisedBranches w =
                              checkSingleL1LossEquivBool fuel Γ2 C D_old G_old specNewId
                                item.invariantId Φ_shared lr6.excisedBranches w := by
                      unfold checkSingleL1LossEquivBool
                      have hFwd := directionalLocusCover_congr fuel C D_old G_old specNewId
                        Φ_shared lr6.excisedBranches w.l5ImpliesL6 hVal
                        (fun nid hn => hPrim nid (by
                          unfold collectScopeCompatLossRootIds
                          rw [mem_canonSortStrs]
                          dsimp only [List.foldr]
                          rw [hm]
                          apply List.mem_append_left
                          unfold collectLossEquivRootIds
                          rw [mem_canonSortStrs]
                          exact List.mem_append_left _ hn))
                      have hBwd := directionalLocusCover_congr fuel C D_old G_old specNewId
                        lr6.excisedBranches Φ_shared w.l6ImpliesL5 hVal
                        (fun nid hn => hPrim nid (by
                          unfold collectScopeCompatLossRootIds
                          rw [mem_canonSortStrs]
                          dsimp only [List.foldr]
                          rw [hm]
                          apply List.mem_append_left
                          unfold collectLossEquivRootIds
                          rw [mem_canonSortStrs]
                          exact List.mem_append_right _ hn))
                      rw [hFwd, hBwd]
                    rw [hW]
      unfold checkRetreatItemPairsLoop
      rw [hHeadEq, retreatPairsLoop_congr fuel C D_old G_old specNewId Φ_shared hVal restItems restBinds hTailPrim]

/-- **`T_D0_R1_03` — Topology-Preserving `CoherentFormulaRebind` Soundness (`F-B4-T22-05`, `Q-B4-R1-02`, `F-B4-T23-03`)**:
    Proved directly from frozen ancestor theorems (`T_B1_06`, `T_B2_A7_1`, `A0_05_1`) with ZERO
    circularity: if `CoherentFormulaRebind ctx pkt ctx' pkt'` holds and `checkB4CompositeBool ctx pkt = true`,
    then `checkB4CompositeBool ctx' pkt' = true`! -/
theorem T_D0_R1_03_TopologyPreservingCoherentRebindSoundness
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (ctx' : B4SharedContext) (pkt' : B4CandidatePacket)
    (hReb : CoherentFormulaRebind ctx pkt ctx' pkt')
    (hVer : checkB4CompositeBool ctx pkt = true) :
    checkB4CompositeBool ctx' pkt' = true := by
  have u := unpack_checkB4CompositeBool hVer
  rcases u with ⟨hEnvSnap, hDagSnap, hBase12, hBase23, hValBase, hs1, hs2, hs3, hDepsPkt⟩
  -- 1. Slice 2348 preserved (`regId`, `structStore`, `ledgerSnap`, `fuelStruct` identical)
  have hs1' : checkSlice2348Bool ctx' pkt'.s2348 = true := by
    unfold checkSlice2348Bool at hs1 ⊢
    rw [hReb.pkt_s2348_eq, hReb.fuels_eq.1, hReb.regId_eq, hReb.store_eq, hReb.ledger_eq]
    exact hs1
  -- 2. Unpack Slice 56 on `ctx` to obtain `checkPrimEnvIntegrityBool ctx.primEnv = true`, `ValidContainer ctx.dagCont`, and `D56`
  have hs2_unp := hs2
  unfold checkSlice56Bool at hs2_unp
  simp only [Bool.and_eq_true] at hs2_unp
  have hVer56 : isG56CouplingVerifiedBool ctx.toG56Context pkt.s56.c56 = true := hs2_unp.1.1.1.1
  rcases verifiedG56_exists_verdictParams ctx.toG56Context ⟨pkt.s56.c56, hVer56⟩ with ⟨hl, rr, hcVer⟩
  rcases unpack_g56Verified hcVer with
    ⟨hEnvValidOld, hContValid, _, _, hG5DisOld, _, _, _, _, hd56Claimed, hRetL1⟩
  dsimp [B4SharedContext.toG56Context] at hEnvValidOld hContValid hG5DisOld hd56Claimed hRetL1
  have hD5_c : deriveG5PrimDeps ctx'.primEnv ctx.dagCont pkt.s56.c56.g5Cert =
      deriveG5PrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert :=
    multiRootTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq
  have hD6_c : deriveG6PrimDeps ctx'.primEnv ctx.dagCont pkt.s56.c56.g6Suite =
      deriveG6PrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g6Suite :=
    multiRootTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq
  have hD5_eq : deriveG5PrimDeps ctx'.primEnv ctx'.dagCont pkt.s56.c56.g5Cert =
      deriveG5PrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert := by
    rw [hReb.dagCont_eq]; exact hD5_c
  have hD6_eq : deriveG6PrimDeps ctx'.primEnv ctx'.dagCont pkt.s56.c56.g6Suite =
      deriveG6PrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g6Suite := by
    rw [hReb.dagCont_eq]; exact hD6_c
  have hD56_eq : deriveG56JointPrimDeps ctx'.primEnv ctx'.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite =
      deriveG56JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite := by
    unfold deriveG56JointPrimDeps
    rw [hD5_eq, hD6_eq]
  have hLookD56 : ∀ pid ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite,
      lookupPrimPrem? ctx'.primEnv pid = lookupPrimPrem? ctx.primEnv pid := by
    intro pid hp
    apply hReb.activeFootprint_eq pid
    rw [mem_deriveB4JointPrimDeps_iff]
    left
    rwa [hd56Claimed]
  have hG5DisNew : checkG5DischargeBool ctx'.fuelG5 ctx'.primEnv ctx'.dagCont pkt.s56.c56.g5Cert = true := by
    rw [hReb.fuels_eq.2.1, hReb.dagCont_eq]
    have hCong := (T_B1_06_ProofRoots_And_PrimDeps_Completeness ctx.fuelG5 pkt.s56.c56.g5Cert).2.1
      ctx'.primEnv ctx.primEnv ctx.dagCont ctx.dagCont hContValid (fun _ _ => rfl)
      (fun pid hp => by
        rw [hD5_c] at hp
        exact hLookD56 pid (((T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
          ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite).1 pid).mpr (Or.inl hp)))
    unfold checkG5DischargeBool at hG5DisOld ⊢
    rw [hD5_c, hCong]
    exact hG5DisOld
  have hG6SuiteEq : checkG6Suite ctx'.fuelG6 ctx'.primEnv ctx'.dagCont pkt.s56.c56.g6Suite =
      checkG6Suite ctx.fuelG6 ctx.primEnv ctx.dagCont pkt.s56.c56.g6Suite := by
    rw [hReb.fuels_eq.2.2, hReb.dagCont_eq]
    have hIntEq : checkPrimEnvIntegrityBool ctx'.primEnv = checkPrimEnvIntegrityBool ctx.primEnv :=
      hReb.primEnvInt_ok.trans hEnvValidOld.symm
    exact (T_B2_A7_1_OutputCongruence ctx.fuelG6 pkt.s56.c56.g6Suite).2
      ctx'.primEnv ctx.primEnv ctx.dagCont ctx.dagCont
      hIntEq hContValid hContValid
      hD6_c (fun _ _ => rfl)
      (fun pid hp => by
        rw [hD6_c] at hp
        exact hLookD56 pid (((T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
          ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite).1 pid).mpr (Or.inr hp)))
  have hDepsDiagEq : evalG56DepsDiagValid ctx'.toG56Context pkt.s56.c56 =
      evalG56DepsDiagValid ctx.toG56Context pkt.s56.c56 := by
    unfold evalG56DepsDiagValid B4SharedContext.toG56Context
    dsimp only
    have hL1DepsEq : deriveScopeCompatL1PrimDeps ctx'.primEnv ctx'.dagCont pkt.s56.c56.scopeCompatibility =
        deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.scopeCompatibility := by
      unfold deriveScopeCompatL1PrimDeps
      rw [hReb.dagCont_eq]
      exact multiRootTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq
    unfold computeExtraL1PremisesOutsideD56
    rw [hD5_eq, hD6_eq, hD56_eq, hL1DepsEq]
  have hScopeDiagEq : evalG56ScopeDiag ctx'.toG56Context none pkt.s56.c56 =
      evalG56ScopeDiag ctx.toG56Context none pkt.s56.c56 := by
    unfold evalG56ScopeDiag
    cases hRk : pkt.s56.c56.transitionBinding.reflexKind with
    | repair     => rfl
    | refinement => rfl
    | retreat    =>
        dsimp only
        cases hSc : pkt.s56.c56.scopeCompatibility with
        | repairSameScope              => rfl
        | refinementSameScope          => rfl
        | refinementExpandedScope      => rfl
        | retreatExactSharedLoss Φ_sh binds =>
            dsimp only
            cases pkt.s56.c56.g5Cert.retreatCert? with
            | none     => rfl
            | some rt5 =>
                dsimp only
                have hEmpty := (hRetL1 hRk).1
                rw [hSc] at hEmpty
                unfold computeExtraL1PremisesOutsideD56 at hEmpty
                have hSubL1 : ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont (.retreatExactSharedLoss Φ_sh binds),
                    p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite := by
                  intro p hp
                  cases hc : (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite).contains p with
                  | true  => exact List.contains_iff_mem.mp hc
                  | false =>
                      have hInF : p ∈ (deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont (.retreatExactSharedLoss Φ_sh binds)).filter
                          (fun q => !(deriveG56JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56.g5Cert pkt.s56.c56.g6Suite).contains q) :=
                        List.mem_filter.mpr ⟨hp, by rw [hc]; rfl⟩
                      rw [List.isEmpty_iff.mp hEmpty] at hInF
                      nomatch hInF
                have hLoopEq :
                    checkRetreatItemPairsLoop ctx'.toG56Context.fuelG6 ctx'.toG56Context.primEnv ctx'.toG56Context.dagCont
                      pkt.s56.c56.transitionBinding.domOld pkt.s56.c56.transitionBinding.guardsOld
                      pkt.s56.c56.transitionBinding.specNewId Φ_sh pkt.s56.c56.g6Suite.items binds =
                    checkRetreatItemPairsLoop ctx.toG56Context.fuelG6 ctx.toG56Context.primEnv ctx.toG56Context.dagCont
                      pkt.s56.c56.transitionBinding.domOld pkt.s56.c56.transitionBinding.guardsOld
                      pkt.s56.c56.transitionBinding.specNewId Φ_sh pkt.s56.c56.g6Suite.items binds := by
                  dsimp [B4SharedContext.toG56Context]
                  rw [hReb.fuels_eq.2.2, hReb.dagCont_eq]
                  apply (retreatPairsLoop_congr ctx.fuelG6 (Γ1 := ctx.primEnv) (Γ2 := ctx'.primEnv)
                    ctx.dagCont _ _ _ Φ_sh hContValid pkt.s56.c56.g6Suite.items binds ?_).symm
                  intro nid hNid p hp
                  apply (hLookD56 p ?_).symm
                  exact hSubL1 p (mem_multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont hNid hp)
                rw [hLoopEq]
  have hDetEq : evalG56DetailedR1 ctx'.toG56Context pkt.s56.c56 =
      evalG56DetailedR1 ctx.toG56Context pkt.s56.c56 := by
    have hContBool' : checkContainerIntegrityBool ctx'.toG56Context.dagCont = true := by
      dsimp [B4SharedContext.toG56Context]; rw [hReb.dagCont_eq]; exact hContValid
    have hContBoolOld : checkContainerIntegrityBool ctx.toG56Context.dagCont = true := hContValid
    have hEnvBool' : checkPrimEnvIntegrityBool ctx'.toG56Context.primEnv = true := hReb.primEnvInt_ok
    have hEnvBoolOld : checkPrimEnvIntegrityBool ctx.toG56Context.primEnv = true := hEnvValidOld
    have hG5StatEq : evalG5StatusValid ctx'.toG56Context pkt.s56.c56 =
        evalG5StatusValid ctx.toG56Context pkt.s56.c56 := by
      unfold evalG5StatusValid B4SharedContext.toG56Context
      dsimp only
      rw [hG5DisNew, hG5DisOld]
      simp
    unfold evalG56DetailedR1
    rw [hEnvBool', hContBool', hEnvBoolOld, hContBoolOld]
    dsimp only
    rw [hG5StatEq, hDepsDiagEq, hScopeDiagEq]
    dsimp [B4SharedContext.toG56Context]
    rw [hG6SuiteEq]
  have hAppEq : ∀ det, checkApplicableObservationsConsistentBool ctx'.toG56Context pkt.s56.c56 det =
      checkApplicableObservationsConsistentBool ctx.toG56Context pkt.s56.c56 det := by
    intro det
    unfold checkApplicableObservationsConsistentBool isCheckApplicableBool
    rfl
  have hVer56' : isG56CouplingVerifiedBool ctx'.toG56Context pkt.s56.c56 = true := by
    unfold isG56CouplingVerifiedBool checkG56Coupling at hVer56 ⊢
    rw [hDetEq]
    unfold projectCoupledVerdictR1 at hVer56 ⊢
    rw [hAppEq]
    exact hVer56
  have hs2' : checkSlice56Bool ctx' pkt'.s56 = true := by
    unfold checkSlice56Bool at hs2 ⊢
    rw [hReb.pkt_s56_eq, hReb.epoch_eq, hVer56']
    rw [hVer56] at hs2
    exact hs2
  -- 3. Slice 7 preserved on rebound bundle
  have hs3_unp := hs3
  unfold checkSlice7Bool at hs3_unp
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hs3_unp
  rcases hs3_unp with ⟨⟨⟨⟨⟨_, _⟩, hBunOld⟩, hSub7⟩, hExp7⟩, hBridgeOld⟩
  have hBunNew : checkCertifiedG7BundleBool { pkt.s7.bundle with primEnvSnapshot := ctx'.primEnv } = true := by
    unfold checkCertifiedG7BundleBool at hBunOld ⊢
    dsimp only
    simp only [Bool.and_eq_true, beq_iff_eq] at hBunOld ⊢
    rcases hBunOld with ⟨⟨⟨⟨⟨⟨⟨⟨hc1, hc2⟩, hc3⟩, hc4⟩, _⟩, hc6⟩, hc7⟩, hcDeps⟩, hcReach⟩
    rw [hEnvSnap] at hcDeps hcReach
    rw [hDagSnap] at hcDeps hcReach hc6
    have hDepsEq7 : extractTransitivePrimDeps ctx'.primEnv ctx.dagCont pkt.s7.bundle.rootNodeId =
        extractTransitivePrimDeps ctx.primEnv ctx.dagCont pkt.s7.bundle.rootNodeId :=
      extractTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq
    have hReachEq7 : verifyReachableDerivation pkt.s7.bundle.fuelCert ctx'.primEnv ctx.dagCont pkt.s7.bundle.rootNodeId =
        verifyReachableDerivation pkt.s7.bundle.fuelCert ctx.primEnv ctx.dagCont pkt.s7.bundle.rootNodeId := by
      have hMap := A0_05_1_OutputCongruence pkt.s7.bundle.fuelCert
        (Γ1 := ctx.primEnv) (Γ2 := ctx'.primEnv) (C1 := ctx.dagCont) (C2 := ctx.dagCont)
        [pkt.s7.bundle.rootNodeId] hContValid (fun _ _ => rfl)
        (fun pid hp => by
          rw [mem_multiRootTransitivePrimDeps_iff] at hp
          rcases hp with ⟨r, hr, hpr⟩
          rcases List.mem_cons.mp hr with rfl | hNil
          · apply (hReb.activeFootprint_eq pid ?_).symm
            rw [mem_deriveB4JointPrimDeps_iff]
            exact Or.inr (Or.inl (hcDeps ▸ hpr))
          · nomatch hNil)
      simp only [List.map] at hMap
      injection hMap with hHead _
      exact hHead.symm
    rw [hDagSnap]
    exact ⟨⟨⟨⟨⟨⟨⟨⟨hc1, hc2⟩, hc3⟩, hc4⟩, hReb.primEnvInt_ok⟩, hc6⟩, hc7⟩,
            hcDeps.trans hDepsEq7.symm⟩,
           hReachEq7.trans hcReach⟩
  have hBridgeNew : checkGoalBridgeModeBool ctx'
      { pkt.s7.bundle with primEnvSnapshot := ctx'.primEnv } pkt.s7.claimedBase pkt.s7.bridgeMode = true := by
    unfold checkGoalBridgeModeBool at hBridgeOld ⊢
    dsimp only
    cases hm : pkt.s7.bridgeMode with
    | directUnguardedL0 =>
        rw [hm] at hBridgeOld; exact hBridgeOld
    | impNormalizedA0 =>
        rw [hm] at hBridgeOld; exact hBridgeOld
    | certifiedBridgeL1 brId brFuel =>
        rw [hm] at hBridgeOld
        dsimp only at hBridgeOld ⊢
        rw [hReb.dagCont_eq]
        have hReachBr : verifyReachableDerivation brFuel ctx'.primEnv ctx.dagCont brId =
            verifyReachableDerivation brFuel ctx.primEnv ctx.dagCont brId := by
          have hMap := A0_05_1_OutputCongruence brFuel
            (Γ1 := ctx.primEnv) (Γ2 := ctx'.primEnv) (C1 := ctx.dagCont) (C2 := ctx.dagCont)
            [brId] hContValid (fun _ _ => rfl)
            (fun pid hp => by
              apply (hReb.activeFootprint_eq pid ?_).symm
              rw [mem_deriveB4JointPrimDeps_iff]
              right; right
              unfold deriveB4InteractionPrimDeps bridgeRootsOfMode
              rw [hm]
              exact hp)
          simp only [List.map] at hMap
          injection hMap with hHead _
          exact hHead.symm
        rwa [hReachBr]
  have hs3' : checkSlice7Bool ctx' pkt'.s7 = true := by
    rw [hReb.pkt_s7_rebound]
    unfold checkSlice7Bool
    rw [hBunNew, hBridgeNew, hReb.epoch_eq]
    dsimp only
    have hexpB : decide (ctx.assignedEvalEpoch < pkt.s7.bundle.expiresEpoch) = true :=
      decide_eq_true hExp7
    rw [hDagSnap, hReb.dagCont_eq.symm]
    simp [hSub7, hexpB]
  -- 4. Joint composite deps preserved
  have hJointDepsEq :
      deriveB4JointPrimDeps ctx'.primEnv ctx'.dagCont pkt'.s56.c56 pkt'.s7.bundle pkt'.s7.bridgeMode =
      deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode := by
    rw [hReb.pkt_s56_eq, hReb.pkt_s7_rebound, hReb.dagCont_eq]
    dsimp only
    unfold deriveB4JointPrimDeps deriveB4InteractionPrimDeps
    rw [multiRootTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq]
  -- 5. Assemble `checkB4CompositeBool ctx' pkt' = true`
  unfold checkB4CompositeBool evalB4CompositeError?
  have heSnap' : pkt'.s7.bundle.primEnvSnapshot = ctx'.primEnv := by
    rw [hReb.pkt_s7_rebound]
  have hdSnap' : pkt'.s7.bundle.dagSnapshot = ctx'.dagCont := by
    rw [hReb.pkt_s7_rebound]; dsimp only; exact hDagSnap.trans hReb.dagCont_eq.symm
  have hb12' : pkt'.s2348.claimedBase = pkt'.s56.claimedBase := by
    rw [hReb.pkt_s2348_eq, hReb.pkt_s56_eq]; exact hBase12
  have hb23' : pkt'.s56.claimedBase = pkt'.s7.claimedBase := by
    rw [hReb.pkt_s56_eq, hReb.pkt_s7_rebound]; exact hBase23
  have hvB7' : checkValidB4TransitionBaseBool pkt'.s7.claimedBase = true := by
    rw [← hb23', ← hb12', hReb.pkt_s2348_eq]
    exact (checkValidB4TransitionBaseBool_iff _).mpr hValBase
  have hDeps' : pkt'.claimedCompositePrimDeps =
      deriveB4JointPrimDeps ctx'.primEnv ctx'.dagCont pkt'.s56.c56 pkt'.s7.bundle pkt'.s7.bridgeMode := by
    rw [hReb.pkt_deps_eq, hJointDepsEq]; exact hDepsPkt
  simp [heSnap', hdSnap', hb12', hb23', hvB7', hs1', hs2', hs3', hDeps']

/-- Structural re-binding relation between `sp : B4CanonicalSpine ctx` and `sp' : B4CanonicalSpine ctx'` (`F-B4-T23-03` Stage 2). -/
def RebindSpineRel {ctx ctx' : B4SharedContext}
    (sp : B4CanonicalSpine ctx) (sp' : B4CanonicalSpine ctx') : Prop :=
  sp'.base = sp.base ∧
  sp'.ast = sp.ast ∧
  extractSummary sp'.sq2348 = extractSummary sp.sq2348 ∧
  sp'.c56 = sp.c56 ∧
  sp'.bundle7 = { sp.bundle7 with primEnvSnapshot := ctx'.primEnv } ∧
  sp'.bridgeMode = sp.bridgeMode ∧
  deriveSpineB4PrimDeps ctx' sp' = deriveSpineB4PrimDeps ctx sp

/-- **`T_I0_T23_03` — Stage-2 Construction of Context-Indexed `sp' : B4CanonicalSpine ctx'` Under `CoherentFormulaRebind` (`F-B4-T23-03`, `CE-B4-32`)**:
    Given `CoherentFormulaRebind ctx pkt ctx' pkt'` and `hVer : checkB4CompositeBool ctx pkt = true`,
    we construct `sp' : B4CanonicalSpine ctx'` (`= spineOfVerifiedPacket ctx' pkt' hVer'`) satisfying
    `RebindSpineRel (spineOfVerifiedPacket ctx pkt hVer) sp'` AND preserving active `SemValidPrimId`! -/
theorem T_I0_T23_03_CoherentRebindConstructsIndexedSpine
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (ctx' : B4SharedContext) (pkt' : B4CandidatePacket)
    (hReb : CoherentFormulaRebind ctx pkt ctx' pkt')
    (hVer : checkB4CompositeBool ctx pkt = true) :
    let hVer' := T_D0_R1_03_TopologyPreservingCoherentRebindSoundness ctx pkt ctx' pkt' hReb hVer
    let sp  := spineOfVerifiedPacket ctx pkt hVer
    let sp' := spineOfVerifiedPacket ctx' pkt' hVer'
    RebindSpineRel sp sp' ∧
    ((∀ p ∈ deriveSpineB4PrimDeps ctx sp, SemValidPrimId ctx.primEnv p) ↔
     (∀ p ∈ deriveSpineB4PrimDeps ctx' sp', SemValidPrimId ctx'.primEnv p)) := by
  intro hVer' sp sp'
  have hDepsEq : deriveSpineB4PrimDeps ctx' sp' = deriveSpineB4PrimDeps ctx sp := by
    show deriveB4JointPrimDeps ctx'.primEnv ctx'.dagCont pkt'.s56.c56 pkt'.s7.bundle pkt'.s7.bridgeMode =
         deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode
    rw [hReb.pkt_s56_eq, hReb.pkt_s7_rebound, hReb.dagCont_eq]
    dsimp only
    unfold deriveB4JointPrimDeps deriveB4InteractionPrimDeps
    rw [multiRootTransitivePrimDeps_eq_of_toPremDag_eq _ _ hReb.premDag_eq]
  have hRel : RebindSpineRel sp sp' := by
    refine ⟨?_, ?_, ?_, ?_, ?_, ?_, hDepsEq⟩
    · apply Subtype.ext
      show pkt'.s2348.claimedBase = pkt.s2348.claimedBase
      rw [hReb.pkt_s2348_eq]
    · show pkt'.s2348.ast = pkt.s2348.ast
      rw [hReb.pkt_s2348_eq]
    · show extractSummary pkt'.s2348.sq = extractSummary pkt.s2348.sq
      rw [hReb.pkt_s2348_eq]
    · show pkt'.s56.c56 = pkt.s56.c56
      rw [hReb.pkt_s56_eq]
    · show pkt'.s7.bundle = { pkt.s7.bundle with primEnvSnapshot := ctx'.primEnv }
      rw [hReb.pkt_s7_rebound]
    · show pkt'.s7.bridgeMode = pkt.s7.bridgeMode
      rw [hReb.pkt_s7_rebound]
  refine ⟨hRel, ?_⟩
  rw [hDepsEq]
  constructor
  · intro hAll p hp
    have hLook : lookupPrimPrem? ctx'.primEnv p = lookupPrimPrem? ctx.primEnv p :=
      hReb.activeFootprint_eq p hp
    unfold SemValidPrimId
    rw [hLook]
    exact hAll p hp
  · intro hAll' p hp
    have hLook : lookupPrimPrem? ctx'.primEnv p = lookupPrimPrem? ctx.primEnv p :=
      hReb.activeFootprint_eq p hp
    unfold SemValidPrimId at hAll' ⊢
    intro e he
    exact hAll' p hp e (hLook.trans he)

end OmegaCellC1P1B2BB4
