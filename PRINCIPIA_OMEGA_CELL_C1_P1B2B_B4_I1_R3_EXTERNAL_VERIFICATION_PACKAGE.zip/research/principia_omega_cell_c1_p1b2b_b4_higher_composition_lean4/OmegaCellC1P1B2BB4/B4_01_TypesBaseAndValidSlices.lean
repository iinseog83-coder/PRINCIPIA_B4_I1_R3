/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Certified Higher Composition & Historical Retreat Algebra (`ACT-I0`)
  Module: OmegaCellC1P1B2BB4.B4_01_TypesBaseAndValidSlices

  Gates & Binding Conditions Covered:
    - `I0-A1` & `I0-A2` (`F-B4-T22-01..03`, `Q-B4-R1-01`, `F-B4-T23-01`):
      * `B4SharedContext` (zero environment merging), `B4SyntacticContextValid`.
      * 20-field `B4CommonTransitionBase`, 13-field `toG56Binding` (`stepRequiresRetreat` vs
        `cumulativeHistRetreat` strictly separated), `ValidB4TransitionBase`, `B4ValidBase`,
        and context-indexed `ValidB4TransitionBaseInCtx`.
      * Typed slices `ProvenanceBoundG2348Slice`, `BoundG56Slice`, `GoalAlignedG7Slice` (`Mode G0`,
        `Mode G1a`, `Mode G1b`), restricted valid slices `ValidSlice2348/56/7` with total projections
        `projValidSlice* : ValidSlice* ctx → B4ValidBase` (surjectivity NOT required and constructively
        refuted on `B4ValidBase`!).
      * Mechanically proved theorems `T_D0_A1_01 .. T_D0_A1_04`, `T_D0_A2_02`, `T_D0_A2_03`.
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1
import OmegaCellC1P1B2A
import OmegaCellC1P1B2BA0
import OmegaCellC1P1B2BB1
import OmegaCellC1P1B2BB2
import OmegaCellC1P1B2BB3

namespace OmegaCellC1P1B2BB4

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ### 1. Shared Ambient Context `B4SharedContext` (`0` Environment Merging) -/

/-- Single shared ambient verification context across `G2348`, `G56`, and `G7`. -/
structure B4SharedContext where
  regId             : String
  structStore       : StructuralStore
  ledgerSnap        : List StructuralLedgerEvent
  fuelStruct        : Nat
  fuelG5            : Nat
  fuelG6            : Nat
  assignedEvalEpoch : Nat
  primEnv           : PrimPremiseEnv
  dagCont           : G7DagContainer

/-- Canonical projection from `B4SharedContext` to frozen `B3`'s `G56SharedContext`. -/
def B4SharedContext.toG56Context (ctx : B4SharedContext) : G56SharedContext where
  fuelG5  := ctx.fuelG5
  fuelG6  := ctx.fuelG6
  primEnv := ctx.primEnv
  dagCont := ctx.dagCont

/-- Structural/syntactic validity of `B4SharedContext` (strictly distinct from `SemValidPrimId`!). -/
def B4SyntacticContextValid (ctx : B4SharedContext) : Prop :=
  RegistryContextValid ctx.regId ∧
  StoreLookupConsistent ctx.structStore ∧
  SyntacticValidPrimEnv ctx.primEnv ∧
  ValidContainer ctx.dagCont ∧
  (foldStructuralLedger ctx.ledgerSnap).epistemic.currentEpoch = ctx.assignedEvalEpoch

/-! ### 2. `B4CommonTransitionBase`, 13-Field `toG56Binding`, & `B4ValidBase` (`F-B4-T22-01..03`, `F-B4-T23-01`) -/

/-- Three-element index set `I_3 = {s2348, s56, s7}` for `B4` spatial composition. -/
inductive B4SlotIdx where
  | s2348 : B4SlotIdx
  | s56   : B4SlotIdx
  | s7    : B4SlotIdx
  deriving DecidableEq, Repr

/-- Common 20-field transition base `T_B4` synchronizing `G2348`, `G56`, and `G7`. -/
structure B4CommonTransitionBase where
  baseId                : String
  rflxCid               : String
  pathKey               : StructuralPathKey
  parentPathKey?        : Option StructuralPathKey
  cellOldCid            : String
  obstCid               : String
  cellNewCid            : String
  specOldId             : String
  specNewId             : String
  domOld                : G7DomTag
  domOldId              : String
  guardsOld             : List StrictForm
  domNew                : G7DomTag
  domNewId              : String
  guardsNew             : List StrictForm
  postGoal              : StrictForm
  reflexKind            : ReflexKind
  stepRequiresRetreat   : Bool
  cumulativeHistRetreat : Bool
  assignedEvalEpoch     : Nat
  deriving DecidableEq, Repr

/-- Complete 13-field projection `B4CommonTransitionBase → G56TransitionBinding` (`F-B4-T22-03`):
    maps `t.stepRequiresRetreat ↦ requiresRetreatHistory` (NEVER `t.cumulativeHistRetreat`!). -/
def B4CommonTransitionBase.toG56Binding (t : B4CommonTransitionBase) : G56TransitionBinding where
  baseId                 := t.baseId
  rflxCid                := t.rflxCid
  cellOldCid             := t.cellOldCid
  cellNewCid             := t.cellNewCid
  specOldId              := t.specOldId
  specNewId              := t.specNewId
  assignedEvalEpoch      := t.assignedEvalEpoch
  domOld                 := t.domOld
  guardsOld              := t.guardsOld
  domNew                 := t.domNew
  guardsNew              := t.guardsNew
  reflexKind             := t.reflexKind
  requiresRetreatHistory := t.stepRequiresRetreat

/-- Projection from `B4CommonTransitionBase` to `P1B2AC`'s `ReflexSubjectKey`. -/
def B4CommonTransitionBase.toSubjectKey (t : B4CommonTransitionBase) : ReflexSubjectKey where
  rflxCid       := t.rflxCid
  pathKey       := t.pathKey
  targetCellCid := t.cellNewCid
  baseId        := t.baseId
  targetDomId   := t.domNewId
  targetSpecId  := t.specNewId

/-- Expected structural `PathKey` derived from `(parentPathKey?, cellOldCid, obstCid, cellNewCid, rflxCid)`. -/
def expectedPathKeyOfBase (t : B4CommonTransitionBase) : StructuralPathKey :=
  match t.parentPathKey? with
  | none     => .root t.cellOldCid t.obstCid t.cellNewCid t.rflxCid
  | some par => .step par t.cellOldCid t.obstCid t.cellNewCid t.rflxCid

/-- Pure declarative intrinsic well-formedness `ValidB4TransitionBase` (`0` executable checker calls). -/
def ValidB4TransitionBase (t : B4CommonTransitionBase) : Prop :=
  t.baseId = "base_Q" ∧
  t.rflxCid ≠ "" ∧
  g7DomTagToId? t.domOld = some t.domOldId ∧
  g7DomTagToId? t.domNew = some t.domNewId ∧
  t.pathKey = expectedPathKeyOfBase t ∧
  t.stepRequiresRetreat = (t.reflexKind == .retreat) ∧
  (t.stepRequiresRetreat = true → t.cumulativeHistRetreat = true)

/-- Computable boolean counterpart of `ValidB4TransitionBase`. -/
def checkValidB4TransitionBaseBool (t : B4CommonTransitionBase) : Bool :=
  (t.baseId == "base_Q") &&
  (t.rflxCid != "") &&
  (g7DomTagToId? t.domOld == some t.domOldId) &&
  (g7DomTagToId? t.domNew == some t.domNewId) &&
  (t.pathKey == expectedPathKeyOfBase t) &&
  (t.stepRequiresRetreat == (t.reflexKind == .retreat)) &&
  (!t.stepRequiresRetreat || t.cumulativeHistRetreat)

theorem checkValidB4TransitionBaseBool_iff (t : B4CommonTransitionBase) :
    checkValidB4TransitionBaseBool t = true ↔ ValidB4TransitionBase t := by
  unfold checkValidB4TransitionBaseBool ValidB4TransitionBase
  simp only [Bool.and_eq_true, Bool.or_eq_true, Bool.not_eq_true', beq_iff_eq, bne_iff_ne]
  constructor
  · rintro ⟨⟨⟨⟨⟨⟨h1, h2⟩, h3⟩, h4⟩, h5⟩, h6⟩, h7⟩
    refine ⟨h1, h2, h3, h4, h5, h6, ?_⟩
    intro hStep
    rcases h7 with hF | hCum
    · rw [hStep] at hF; nomatch hF
    · exact hCum
  · rintro ⟨h1, h2, h3, h4, h5, h6, h7⟩
    refine ⟨⟨⟨⟨⟨⟨h1, h2⟩, h3⟩, h4⟩, h5⟩, h6⟩, ?_⟩
    cases hs : t.stepRequiresRetreat with
    | false => exact Or.inl rfl
    | true  => exact Or.inr (h7 hs)

/-- Unified Valid Transition Base subtype `T_valid` (`F-B4-T22-01`, `Q-B4-R1-01`). -/
abbrev B4ValidBase : Type :=
  { t : B4CommonTransitionBase // ValidB4TransitionBase t }

/-- Context-indexed base validity (`F-B4-T23-01`), adding context epoch alignment to `ValidB4TransitionBase`. -/
def ValidB4TransitionBaseInCtx (ctx : B4SharedContext) (t : B4CommonTransitionBase) : Prop :=
  ValidB4TransitionBase t ∧ t.assignedEvalEpoch = ctx.assignedEvalEpoch

/-! ### 3. Typed Slot Slices `S_i(ctx)` & Validity-Restricted Slices `S_i^valid(ctx)` (`D0-A1`, `Q-B4-R1-01`) -/

/-- Raw candidate data for Slot `s2348` (`ProvenanceBoundG2348Slice` — prevents raw summary forgery `CE-B4-19`). -/
structure ProvenanceBoundG2348Slice where
  ast         : StructuralReflexAST
  sq          : StructuralQualification
  claimedBase : B4CommonTransitionBase

/-- Alignment check between `(ast, extractSummary sq)` and `claimedBase`. -/
def checkR2348AlignBool (ast : StructuralReflexAST) (s : CheckedG2348Summary)
    (t : B4CommonTransitionBase) : Bool :=
  (ast.baseId == t.baseId) &&
  (ast.rflxCid == t.rflxCid) &&
  (derivePathKey ast == t.pathKey) &&
  (ast.parentPathKey? == t.parentPathKey?) &&
  (ast.cellOldCid == t.cellOldCid) &&
  (ast.obstCid == t.obstCid) &&
  (ast.cellNewCid == t.cellNewCid) &&
  (ast.specOldId == t.specOldId) &&
  (ast.specNewId == t.specNewId) &&
  (ast.domOldId == t.domOldId) &&
  (ast.domNewId == t.domNewId) &&
  (ast.reflexKind == t.reflexKind) &&
  (s.historicalRetreat == t.cumulativeHistRetreat) &&
  (s.rflxCid == t.rflxCid) &&
  (s.pathKey == t.pathKey) &&
  (s.cellNewCid == t.cellNewCid) &&
  (s.baseId == t.baseId) &&
  (s.domNewId == t.domNewId) &&
  (s.specNewId == t.specNewId)

/-- Executable verification predicate for Slot `s2348` in `ctx`. -/
def checkSlice2348Bool (ctx : B4SharedContext) (s : ProvenanceBoundG2348Slice) : Bool :=
  (match checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap s.ast with
   | .structuralAccept sq' =>
       (extractSummary sq' == extractSummary s.sq) && (sq'.grantFlag == s.sq.grantFlag)
   | _ => false) &&
  checkG2348SummaryBool (extractSummary s.sq) &&
  checkR2348AlignBool s.ast (extractSummary s.sq) s.claimedBase

/-- Verified raw slice `S_2348(ctx)`. -/
abbrev VerifiedSlice2348 (ctx : B4SharedContext) : Type :=
  { s : ProvenanceBoundG2348Slice // checkSlice2348Bool ctx s = true }

/-- Validity-restricted slice `S_2348^valid(ctx)` (`Q-B4-R1-01`). -/
abbrev ValidSlice2348 (ctx : B4SharedContext) : Type :=
  { s : VerifiedSlice2348 ctx // ValidB4TransitionBase s.1.claimedBase }

/-- Total projection `π̂_2348 : S_2348^valid(ctx) → T_valid` (surjectivity NOT claimed). -/
def projValidSlice2348 {ctx : B4SharedContext} (s : ValidSlice2348 ctx) : B4ValidBase :=
  ⟨s.1.1.claimedBase, s.2⟩

/-- Premise footprint of Slot `s2348` is identically empty (`F-B4-T23-06`). -/
def deriveSlice2348PrimDeps (_ : ProvenanceBoundG2348Slice) : List String := []

/-- Raw candidate data for Slot `s56` (`BoundG56Slice`). -/
structure BoundG56Slice where
  c56         : G56CouplingCert
  claimedBase : B4CommonTransitionBase
  deriving DecidableEq, Repr

/-- Executable verification predicate for Slot `s56` in `ctx`. -/
def checkSlice56Bool (ctx : B4SharedContext) (s : BoundG56Slice) : Bool :=
  isG56CouplingVerifiedBool ctx.toG56Context s.c56 &&
  (projectG5Transition ⟨s.c56.g5Cert, ctx.assignedEvalEpoch⟩ == s.claimedBase.toG56Binding) &&
  (s.c56.transitionBinding == s.claimedBase.toG56Binding) &&
  (s.c56.g5Cert.obstCid == s.claimedBase.obstCid) &&
  (s.c56.g5Cert.goalNew == s.claimedBase.postGoal)

/-- Verified raw slice `S_56(ctx)`. -/
abbrev VerifiedSlice56 (ctx : B4SharedContext) : Type :=
  { s : BoundG56Slice // checkSlice56Bool ctx s = true }

/-- Validity-restricted slice `S_56^valid(ctx)`. -/
abbrev ValidSlice56 (ctx : B4SharedContext) : Type :=
  { s : VerifiedSlice56 ctx // ValidB4TransitionBase s.1.claimedBase }

/-- Total projection `π̂_56 : S_56^valid(ctx) → T_valid`. -/
def projValidSlice56 {ctx : B4SharedContext} (s : ValidSlice56 ctx) : B4ValidBase :=
  ⟨s.1.1.claimedBase, s.2⟩

/-- Premise footprint `D_56` of Slot `s56`. -/
def deriveSlice56PrimDeps (s : BoundG56Slice) : List String :=
  s.c56.claimedJointPrimDeps.jointPrimDepIds

/-- Three Goal-Bridge alignment modes for Slot `s7` (`Mode G0`, `Mode G1a`, `Mode G1b`). -/
inductive B4G7GoalBridgeMode where
  | directUnguardedL0 : B4G7GoalBridgeMode
  | impNormalizedA0   : B4G7GoalBridgeMode
  | certifiedBridgeL1 : (bridgeRootId : String) → (bridgeFuel : Nat) → B4G7GoalBridgeMode
  deriving DecidableEq, Repr

/-- Proof roots introduced specifically by the cross-slot Goal-Bridge (`R_inter`). -/
def bridgeRootsOfMode : B4G7GoalBridgeMode → List String
  | .directUnguardedL0         => []
  | .impNormalizedA0           => []
  | .certifiedBridgeL1 rId _   => [rId]

/-- Interaction primitive premise closure `D_interaction(Γ, C, mode)`. -/
def deriveB4InteractionPrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (mode : B4G7GoalBridgeMode) : List String :=
  multiRootTransitivePrimDeps Γ C (bridgeRootsOfMode mode)

/-- Executable Goal-Bridge check aligning `b.claimedGoal` with `(t.domNew, t.guardsNew, t.postGoal)`. -/
def checkGoalBridgeModeBool (ctx : B4SharedContext) (b : CertifiedG7Bundle)
    (t : B4CommonTransitionBase) (mode : B4G7GoalBridgeMode) : Bool :=
  (b.claimedDomTag == t.domNew) &&
  match mode with
  | .directUnguardedL0 =>
      (t.guardsNew == []) && (b.claimedGoal == t.postGoal)
  | .impNormalizedA0 =>
      (!t.guardsNew.isEmpty) &&
      checkGuardsAndGoalDomDefBool t.domNew t.guardsNew t.postGoal &&
      (b.claimedGoal == foldStrictImp t.guardsNew t.postGoal)
  | .certifiedBridgeL1 bridgeRootId bridgeFuel =>
      verifyReachableDerivation bridgeFuel ctx.primEnv ctx.dagCont bridgeRootId ==
        .accept ⟨t.domNew, t.specNewId, t.guardsNew, .impStrict b.claimedGoal t.postGoal⟩

/-- Raw candidate data for Slot `s7` (`GoalAlignedG7Slice`). -/
structure GoalAlignedG7Slice where
  bundle      : CertifiedG7Bundle
  claimedBase : B4CommonTransitionBase
  bridgeMode  : B4G7GoalBridgeMode
  deriving DecidableEq, Repr

/-- Executable verification predicate for Slot `s7` in `ctx`. -/
def checkSlice7Bool (ctx : B4SharedContext) (s : GoalAlignedG7Slice) : Bool :=
  (s.bundle.primEnvSnapshot == ctx.primEnv) &&
  (s.bundle.dagSnapshot == ctx.dagCont) &&
  checkCertifiedG7BundleBool s.bundle &&
  (s.bundle.subjectKey == s.claimedBase.toSubjectKey) &&
  decide (ctx.assignedEvalEpoch < s.bundle.expiresEpoch) &&
  checkGoalBridgeModeBool ctx s.bundle s.claimedBase s.bridgeMode

/-- Verified raw slice `S_7(ctx)`. -/
abbrev VerifiedSlice7 (ctx : B4SharedContext) : Type :=
  { s : GoalAlignedG7Slice // checkSlice7Bool ctx s = true }

/-- Validity-restricted slice `S_7^valid(ctx)`. -/
abbrev ValidSlice7 (ctx : B4SharedContext) : Type :=
  { s : VerifiedSlice7 ctx // ValidB4TransitionBase s.1.claimedBase }

/-- Total projection `π̂_7 : S_7^valid(ctx) → T_valid`. -/
def projValidSlice7 {ctx : B4SharedContext} (s : ValidSlice7 ctx) : B4ValidBase :=
  ⟨s.1.1.claimedBase, s.2⟩

/-- Premise footprint `D_7` of Slot `s7`'s `CertifiedG7Bundle`. -/
def deriveSlice7PrimDeps (s : GoalAlignedG7Slice) : List String :=
  s.bundle.claimedPrimDeps

/-- Dependent fiber family `F_i^valid(ctx, t̂)` over `t̂ : B4ValidBase`. -/
def B4ValidSlotFiber (ctx : B4SharedContext) : B4SlotIdx → B4ValidBase → Type
  | .s2348, t => { s : ValidSlice2348 ctx // projValidSlice2348 s = t }
  | .s56,   t => { s : ValidSlice56 ctx   // projValidSlice56 s = t }
  | .s7,    t => { s : ValidSlice7 ctx    // projValidSlice7 s = t }

/-! ### 4. Theorems `T_D0_A1_01 .. 04` & `T_D0_A2_02 .. 03` -/

/-- **`T_D0_A1_01` — Slot `s2348` Provenance Soundness**:
    Under `B4SyntacticContextValid ctx`, any `s : VerifiedSlice2348 ctx` yields
    `SemStructuralValid ctx.regId ctx.structStore ctx.ledgerSnap s.1.ast` AND
    `checkG2348SummaryBool (extractSummary s.1.sq) = true`. -/
theorem T_D0_A1_01_Slice2348ProvenanceSound
    (ctx : B4SharedContext) (s : VerifiedSlice2348 ctx)
    (hCtx : B4SyntacticContextValid ctx) :
    SemStructuralValid ctx.regId ctx.structStore ctx.ledgerSnap s.1.ast ∧
    checkG2348SummaryBool (extractSummary s.1.sq) = true := by
  have hs := s.2
  unfold checkSlice2348Bool at hs
  simp only [Bool.and_eq_true] at hs
  rcases hs with ⟨⟨hRef, hSum⟩, _⟩
  cases hChk : checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap s.1.ast with
  | structuralAccept sq' =>
      have hSem := (T_B1_05_structural_master_soundness_and_consistency.2
        ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap s.1.ast sq'
        hCtx.1 hCtx.2.1 hChk).1
      exact ⟨hSem, hSum⟩
  | rejectInvalid _ _  => rw [hChk] at hRef; nomatch hRef
  | rejectRefuted _    => rw [hChk] at hRef; nomatch hRef
  | unsupportedHeld _  => rw [hChk] at hRef; nomatch hRef
  | unavailableHeld _  => rw [hChk] at hRef; nomatch hRef
  | resourceHeld _     => rw [hChk] at hRef; nomatch hRef

/-- Forged raw `CheckedG2348Summary` (`CE-B4-19`) claiming bogus domain `"dom_BOGUS_FORGED"`. -/
def forgedRawG2348Summary : CheckedG2348Summary where
  rflxCid              := "forged_rflx_ce19"
  pathKey              := .root "g0" "obst_nogo_xor" "g2" "forged_rflx_ce19"
  cellOldCid           := "g0"
  obstCid              := "obst_nogo_xor"
  cellNewCid           := "g2"
  baseId               := "base_BOGUS_FORGED"
  domOldId             := "dom_BOGUS_FORGED"
  domNewId             := "dom_BOGUS_FORGED"
  specOldId            := "spec_v1"
  specNewId            := "spec_v2"
  historicalRetreat    := false
  checkedHistoryIds    := []
  nonEmptyRflxCidCheck := true

/-- **`T_D0_A1_02` — Raw `CheckedG2348Summary` Forgery Contrast (`CE-B4-19`)**:
    `forgedRawG2348Summary` passes bare `checkG2348SummaryBool = true`, yet NO `(fuel, store, L, ast, sq)`
    under `"reg_Q_v1"` and `StoreLookupConsistent store` can ever produce `extractSummary sq = forgedRawG2348Summary`! -/
theorem T_D0_A1_02_RawG2348SummaryForgeryContrast :
    checkG2348SummaryBool forgedRawG2348Summary = true ∧
    ∀ (fuel : Nat) (store : StructuralStore) (L : List StructuralLedgerEvent)
      (ast : StructuralReflexAST) (sq : StructuralQualification),
      StoreLookupConsistent store →
      checkStructuralReflex fuel "reg_Q_v1" store L ast = .structuralAccept sq →
      extractSummary sq ≠ forgedRawG2348Summary := by
  refine ⟨rfl, ?_⟩
  intro fuel store L ast sq hStore hAcc hEq
  have hSem := (T_B1_05_structural_master_soundness_and_consistency.2
    fuel "reg_Q_v1" store L ast sq rfl hStore hAcc).1
  have hBaseQ : ast.baseId = "base_Q" := hSem.2.1
  have hSumBase : (extractSummary sq).baseId = ast.baseId := by
    cases fuel with
    | zero => unfold checkStructuralReflex at hAcc; nomatch hAcc
    | succ f' =>
        unfold checkStructuralReflex at hAcc
        by_cases h1 : (ast.rflxCid == "") = true
        · rw [dif_pos h1] at hAcc; nomatch hAcc
        · rw [dif_neg h1] at hAcc
          cases h2 : store.lookupCell? ast.cellOldCid with
          | none => rw [h2] at hAcc; nomatch hAcc
          | some cOld =>
              rw [h2] at hAcc
              cases h3 : store.lookupCell? ast.cellNewCid with
              | none => rw [h3] at hAcc; nomatch hAcc
              | some cNew =>
                  rw [h3] at hAcc
                  cases h4 : store.lookupObst? ast.obstCid with
                  | none => rw [h4] at hAcc; nomatch hAcc
                  | some obst =>
                      rw [h4] at hAcc
                      dsimp only at hAcc
                      split at hAcc
                      · nomatch hAcc
                      · cases h5 : checkG3Matrix obst.inpKind ast.reflexKind with
                        | error err => rw [h5] at hAcc; cases err <;> nomatch hAcc
                        | ok _ =>
                            rw [h5] at hAcc; dsimp only at hAcc
                            cases h6 : reifyTransportCode (f' + 1) "reg_Q_v1" ast.baseId ast.domOldId ast.domNewId
                                ast.specOldId ast.specNewId cOld.prov cNew.prov ast.reflexKind ast.transportCode with
                            | error err => rw [h6] at hAcc; cases err <;> nomatch hAcc
                            | ok _ =>
                                rw [h6] at hAcc; dsimp only at hAcc
                                split at hAcc
                                · nomatch hAcc
                                · cases hp : ast.parentPathKey? with
                                  | none =>
                                      rw [hp] at hAcc; dsimp only at hAcc
                                      split at hAcc
                                      · nomatch hAcc
                                      · injection hAcc with hSq; subst hSq; rfl
                                  | some par =>
                                      rw [hp] at hAcc; dsimp only at hAcc
                                      cases hf : ((foldStructuralLedger L).epistemic.committedLineages.find?
                                          (fun e => e.pathKey == par)) with
                                      | none => rw [hf] at hAcc; nomatch hAcc
                                      | some pe =>
                                          rw [hf] at hAcc; dsimp only at hAcc
                                          split at hAcc
                                          · nomatch hAcc
                                          · split at hAcc
                                            · nomatch hAcc
                                            · injection hAcc with hSq; subst hSq; rfl
  rw [hEq] at hSumBase
  dsimp [forgedRawG2348Summary] at hSumBase
  rw [← hSumBase] at hBaseQ
  nomatch hBaseQ

/-- **`T_D0_A1_03` — Slot `s56` Projection & Conditional Soundness**:
    For any `s : VerifiedSlice56 ctx`, `(qualifyG56Coupled? ctx.toG56Context s.1.c56).isSome = true`
    holds unconditionally, and assuming `SemValidPrimId` on `deriveSlice56PrimDeps s.1`,
    `SemValidG56Coupling s.1.c56` holds! -/
theorem T_D0_A1_03_Slice56ProjectionAndSoundness
    (ctx : B4SharedContext) (s : VerifiedSlice56 ctx)
    (hPrem : ∀ p ∈ deriveSlice56PrimDeps s.1, SemValidPrimId ctx.primEnv p) :
    (qualifyG56Coupled? ctx.toG56Context s.1.c56).isSome = true ∧
    s.1.claimedBase.assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    SemValidG56Coupling s.1.c56 := by
  have hs := s.2
  unfold checkSlice56Bool at hs
  simp only [Bool.and_eq_true, beq_iff_eq] at hs
  rcases hs with ⟨⟨⟨⟨hVerBool, hProjEq⟩, _⟩, _⟩, _⟩
  have hQual : (qualifyG56Coupled? ctx.toG56Context s.1.c56).isSome = true :=
    (T_I0_A7_TOTALITY ctx.toG56Context s.1.c56).1.mpr hVerBool
  have hEpEq : s.1.claimedBase.assignedEvalEpoch = ctx.assignedEvalEpoch :=
    (congrArg G56TransitionBinding.assignedEvalEpoch hProjEq).symm
  let vObj : VerifiedG56Object ctx.toG56Context := ⟨s.1.c56, hVerBool⟩
  have hDepsEq := (verifiedG56_projects_jointDeps ctx.toG56Context vObj).2.2
  rcases verifiedG56_exists_verdictParams ctx.toG56Context vObj with ⟨hl, rr, hVer⟩
  have hPremDerived : ∀ p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont s.1.c56.g5Cert s.1.c56.g6Suite,
      SemValidPrimId ctx.primEnv p := by
    intro p hp
    apply hPrem p
    unfold deriveSlice56PrimDeps
    rw [hDepsEq]
    exact hp
  have hMaster := T_I0_A6_G56_MasterConditionalSoundness ctx.toG56Context s.1.c56 hl rr hVer hPremDerived
  exact ⟨hQual, hEpEq, hMaster.2.2.2.2.2.2.2.2.2.2⟩

/-- **`T_D0_A1_04` — Slot `s7` Shared Context & Goal-Bridge Conditional Soundness**:
    Across all 3 `B4G7GoalBridgeMode`s (`Mode G0`, `Mode G1a`, `Mode G1b`), any `s : VerifiedSlice7 ctx`
    enforces `s.1.bundle.primEnvSnapshot = ctx.primEnv` and `s.1.bundle.dagSnapshot = ctx.dagCont`,
    and under `SemValidPrimId` on `D_7(s)` and `D_interaction(s)`, entails
    `∀ ρ : Env2, InEffDom s.1.claimedBase.domNew s.1.claimedBase.guardsNew ρ →
      ModelsStrictForm s.1.claimedBase.postGoal ρ`! -/
theorem T_D0_A1_04_Slice7SharedEnvAndGoalBridgeSound
    (ctx : B4SharedContext) (s : VerifiedSlice7 ctx)
    (hPrem7     : ∀ p ∈ deriveSlice7PrimDeps s.1, SemValidPrimId ctx.primEnv p)
    (hPremInter : ∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont s.1.bridgeMode,
                    SemValidPrimId ctx.primEnv p) :
    s.1.bundle.primEnvSnapshot = ctx.primEnv ∧
    s.1.bundle.dagSnapshot = ctx.dagCont ∧
    ctx.assignedEvalEpoch < s.1.bundle.expiresEpoch ∧
    (∀ ρ : Env2,
       InEffDom s.1.claimedBase.domNew s.1.claimedBase.guardsNew ρ →
       ModelsStrictForm s.1.claimedBase.postGoal ρ) := by
  have hs := s.2
  unfold checkSlice7Bool at hs
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hs
  rcases hs with ⟨⟨⟨⟨⟨hEnvEq, hDagEq⟩, hBunOk⟩, _⟩, hExpLt⟩, hBridgeOk⟩
  have hPremSnap : ∀ p ∈ s.1.bundle.claimedPrimDeps, SemValidPrimId s.1.bundle.primEnvSnapshot p := by
    rw [hEnvEq]
    exact hPrem7
  have hBunSound := certifiedG7Bundle_whitebox_sound s.1.bundle hBunOk hPremSnap
  have hCont : ValidContainer ctx.dagCont := by
    unfold checkCertifiedG7BundleBool at hBunOk
    simp only [Bool.and_eq_true] at hBunOk
    have hc := hBunOk.1.1.1.2
    rwa [hDagEq] at hc
  refine ⟨hEnvEq, hDagEq, hExpLt, ?_⟩
  intro ρ hEff
  unfold checkGoalBridgeModeBool at hBridgeOk
  simp only [Bool.and_eq_true, beq_iff_eq] at hBridgeOk
  rcases hBridgeOk with ⟨hDomEq, hModeChk⟩
  have hClaimedAtRho : ModelsStrictForm s.1.bundle.claimedGoal ρ :=
    hBunSound ρ (by rw [hDomEq]; exact hEff.1)
  cases hm : s.1.bridgeMode with
  | directUnguardedL0 =>
      rw [hm] at hModeChk; dsimp only at hModeChk
      simp only [Bool.and_eq_true, beq_iff_eq] at hModeChk
      rwa [← hModeChk.2]
  | impNormalizedA0 =>
      rw [hm] at hModeChk; dsimp only at hModeChk
      simp only [Bool.and_eq_true, beq_iff_eq] at hModeChk
      rcases hModeChk with ⟨⟨_, hDefOk⟩, hGoalFold⟩
      rw [hGoalFold] at hClaimedAtRho
      exact ((L_B2B_ImpNorm hDefOk ρ hEff.1).2.mp hClaimedAtRho) hEff
  | certifiedBridgeL1 bridgeRootId bridgeFuel =>
      rw [hm] at hModeChk; dsimp only at hModeChk
      have hAcc : verifyReachableDerivation bridgeFuel ctx.primEnv ctx.dagCont bridgeRootId =
          .accept ⟨s.1.claimedBase.domNew, s.1.claimedBase.specNewId,
                   s.1.claimedBase.guardsNew,
                   .impStrict s.1.bundle.claimedGoal s.1.claimedBase.postGoal⟩ :=
        eq_of_beq hModeChk
      have hPremBr : ∀ pid ∈ multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont [bridgeRootId],
          SemValidPrimId ctx.primEnv pid := by
        intro pid hp
        apply hPremInter pid
        unfold deriveB4InteractionPrimDeps bridgeRootsOfMode
        rw [hm]
        exact hp
      have hSeq := A0_05_4_SemanticDependencyClosure bridgeFuel ctx.primEnv ctx.dagCont
        [bridgeRootId] hCont hPremBr bridgeRootId (List.mem_cons_self ..) _ hAcc
      have hImpAtRho := hSeq.2 ρ hEff.1 hEff.2.2
      exact strictMPStep_sound hClaimedAtRho hImpAtRho

/-- Tier-1 syntactic domain-tag support predicates (`F-B4-T22-02` `R1` §2.2). -/
def isV1SupportedDomTagBool (d : G7DomTag) : Bool :=
  match g7DomTagToId? d with
  | some s => (parseDomTagV1? s).isSome
  | none   => false

def isG7IdSupportedDomTagBool (d : G7DomTag) : Bool :=
  (g7DomTagToId? d).isSome

/-- **`T_D0_A2_02` (`R1`-Scoped Tier-1 Raw Domain Support Strict Hierarchy — `F-B4-T22-02`)**:
    Proves strict proper inclusions on syntactic domain-tag support:
    (1) `isV1SupportedDomTagBool d = true ⟹ isG7IdSupportedDomTagBool d = true`;
    (2) `.domQ2` separates Tier-1 `G7` ID support from `P1B1` V1 support (`false` vs `true`);
    (3) `.domFiniteGrid [(1, 0)]` separates full `G7DomTag` from `g7DomTagToId?` support (`none`). -/
theorem T_D0_A2_02_ProperInclusionOfSlotTransitionImages :
    (∀ d : G7DomTag, isV1SupportedDomTagBool d = true → isG7IdSupportedDomTagBool d = true) ∧
    (isV1SupportedDomTagBool .domQ2 = false ∧ isG7IdSupportedDomTagBool .domQ2 = true) ∧
    (isG7IdSupportedDomTagBool (.domFiniteGrid [(1, 0)]) = false) := by
  refine ⟨?_, ⟨rfl, rfl⟩, rfl⟩
  intro d hd
  cases d <;> simp [isV1SupportedDomTagBool, isG7IdSupportedDomTagBool, g7DomTagToId?, parseDomTagV1?] at hd ⊢

/-- Concrete valid base `t_nonSurjValidBase : B4ValidBase` whose `cellOldCid = ""` makes it
    provably outside `Im(projValidSlice56)` for EVERY `ctx`, proving `projValidSlice56` is total
    yet NOT surjective onto `B4ValidBase` (`Q-B4-R1-01`, `§Ⅰ.1`)! -/
def t_nonSurjValidBase : B4ValidBase :=
  ⟨{ baseId                := "base_Q"
     rflxCid               := "rflx_nonsurj"
     pathKey               := .root "" "obst_ns" "cell_ns_new" "rflx_nonsurj"
     parentPathKey?        := none
     cellOldCid            := ""
     obstCid               := "obst_ns"
     cellNewCid            := "cell_ns_new"
     specOldId             := "spec_v1"
     specNewId             := "spec_v2"
     domOld                := .domQ
     domOldId              := "dom_Q"
     guardsOld             := []
     domNew                := .domQ
     domNewId              := "dom_Q"
     guardsNew             := []
     postGoal              := .eqZero (.const 0)
     reflexKind            := .repair
     stepRequiresRetreat   := false
     cumulativeHistRetreat := false
     assignedEvalEpoch     := 10 },
   by
     refine ⟨rfl, ?_, rfl, rfl, rfl, rfl, fun h => nomatch h⟩
     intro h; nomatch h⟩

/-- **`T_D0_A2_03` — Common Valid Fiber Domain Characterization & Non-Surjectivity (`F-B4-T22-02`, `Q-B4-R1-01`)**:
    (1) Under `B4SyntacticContextValid ctx`, any `t̂ : B4ValidBase` in the image of `projValidSlice2348`
        (hence any `t̂` in the 3-slot joint fiber image) satisfies `t̂.1.baseId = "base_Q"`,
        `t̂.1.domOld ∈ [.domQ, .domQNonzero]`, and `t̂.1.domNew ∈ [.domQ, .domQNonzero]`;
    (2) `projValidSlice56` is total on `ValidSlice56 ctx` yet NOT surjective onto `B4ValidBase`
        (`t_nonSurjValidBase` has empty fiber in `ValidSlice56 ctx` for ALL `ctx`!). -/
theorem T_D0_A2_03_CommonBaseCompatibilityCharacterization :
    (∀ (ctx : B4SharedContext) (s1 : ValidSlice2348 ctx),
       B4SyntacticContextValid ctx →
       let t := (projValidSlice2348 s1).1
       t.baseId = "base_Q" ∧
       (t.domOld = .domQ ∨ t.domOld = .domQNonzero) ∧
       (t.domNew = .domQ ∨ t.domNew = .domQNonzero)) ∧
    (∀ (ctx : B4SharedContext) (s2 : ValidSlice56 ctx),
       projValidSlice56 s2 ≠ t_nonSurjValidBase) := by
  refine ⟨?_, ?_⟩
  · intro ctx s1 hCtx
    dsimp only
    have hSem := (T_D0_A1_01_Slice2348ProvenanceSound ctx s1.1 hCtx).1
    rcases hSem.2.2.2.2.1 with ⟨tOld, tNew, _, hOldId, hNewId, _⟩
    have hs := s1.1.2
    unfold checkSlice2348Bool checkR2348AlignBool at hs
    simp only [Bool.and_eq_true, beq_iff_eq] at hs
    have hDomOldAlign : s1.1.1.ast.domOldId = s1.1.1.claimedBase.domOldId :=
      hs.2.1.1.1.1.1.1.1.1.1.2
    have hDomNewAlign : s1.1.1.ast.domNewId = s1.1.1.claimedBase.domNewId :=
      hs.2.1.1.1.1.1.1.1.1.2
    have hVal := s1.2
    rcases hVal with ⟨hBaseQ, _, hG7Old, hG7New, _⟩
    have hOldV1 : domTagToId tOld = s1.1.1.claimedBase.domOldId := hOldId.trans hDomOldAlign
    have hNewV1 : domTagToId tNew = s1.1.1.claimedBase.domNewId := hNewId.trans hDomNewAlign
    dsimp only [projValidSlice2348]
    refine ⟨hBaseQ, ?_, ?_⟩
    · cases tOld <;> cases hd : s1.1.1.claimedBase.domOld <;>
        simp [domTagToId, g7DomTagToId?, hd] at hOldV1 hG7Old ⊢ <;>
        (rw [← hOldV1] at hG7Old; nomatch hG7Old)
    · cases tNew <;> cases hd : s1.1.1.claimedBase.domNew <;>
        simp [domTagToId, g7DomTagToId?, hd] at hNewV1 hG7New ⊢ <;>
        (rw [← hNewV1] at hG7New; nomatch hG7New)
  · intro ctx s2 hEq
    have hs := s2.1.2
    unfold checkSlice56Bool at hs
    simp only [Bool.and_eq_true, beq_iff_eq] at hs
    rcases hs with ⟨⟨⟨⟨hVer, _⟩, hTbEq⟩, _⟩, _⟩
    rcases verifiedG56_exists_verdictParams ctx.toG56Context ⟨s2.1.1.c56, hVer⟩ with ⟨hl, rr, hc⟩
    rcases unpack_g56Verified hc with ⟨_, _, hBindNone, _⟩
    rcases bindingDiag_none_implies_components hBindNone with ⟨hHdr, _⟩
    unfold checkG56CouplingHeaderBasicBool at hHdr
    simp only [Bool.and_eq_true, bne_iff_ne] at hHdr
    have hCellOldNe : s2.1.1.c56.transitionBinding.cellOldCid ≠ "" := hHdr.1.1.1.2
    rw [hTbEq] at hCellOldNe
    have hBaseEq : s2.1.1.claimedBase = t_nonSurjValidBase.1 := congrArg Subtype.val hEq
    have hEmpty : (s2.1.1.claimedBase.toG56Binding).cellOldCid = "" := by
      rw [hBaseEq]; rfl
    exact hCellOldNe hEmpty

end OmegaCellC1P1B2BB4
