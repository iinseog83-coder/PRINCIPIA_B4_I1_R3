/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Detached `Born-T21` Independent VerifyKit (`KitB4I1-R3`)
  File: ExternalSpecPinB4I1R3.lean
  Scope: Strictly Detached External Verification Module (`0` bytes modified in `B4` or 7 Ancestors)

  Implements:
    1. Exact Kernel `isDefEq` Type-Signature Pins (`Pin_01 .. Pin_63`) for all `63/63` `B4`
       headline theorems (`48` `D0` + `8` `R1` + `7` `T23` companions).
    2. Independent Layer-2 Mathematical Semantics `Layer2_SemB4PayloadValid` (`0` references to
       `SemB4PayloadValid` / `SemValidB4Spine` in its definition) + mechanical biconditional
       equivalence `T_KitI1_Layer2DualSemanticBiconditional`.
    3. `M_end_to_end`: `10` isolated single-fault full-pipeline mutants (`E2E-B4-01 .. E2E-B4-10`),
       proving universal zero-fault identity (`T_Kit_ZeroFaultExactIdentity`) and `10/10`
       positive-preservation + adversarial-kill (`T_KitI1_All10EndToEndMutantsPreservePosAndKilled`).
    4. Provenance-bound consumer gate verification (`T_KitI1_ProvenanceBoundConsumerBlocksSpoof`).
-/
import OmegaCellC1P1B2BB4

namespace ExternalSpecPinB4I1R3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3
open OmegaCellC1P1B2BB4

/-! ## Section 1: Exact `63/63` Headline Theorem Type-Signature Pins (`isDefEq`) -/

-- D0-A1 (4)
theorem Pin_01_T_D0_A1_01 (ctx : B4SharedContext) (s : VerifiedSlice2348 ctx)
    (hCtx : B4SyntacticContextValid ctx) :
    SemStructuralValid ctx.regId ctx.structStore ctx.ledgerSnap s.1.ast ∧
    checkG2348SummaryBool (extractSummary s.1.sq) = true :=
  OmegaCellC1P1B2BB4.T_D0_A1_01_Slice2348ProvenanceSound ctx s hCtx

theorem Pin_02_T_D0_A1_02 :
    checkG2348SummaryBool forgedRawG2348Summary = true ∧
    ∀ (fuel : Nat) (store : StructuralStore) (L : List StructuralLedgerEvent)
      (ast : StructuralReflexAST) (sq : StructuralQualification),
      StoreLookupConsistent store →
      checkStructuralReflex fuel "reg_Q_v1" store L ast = .structuralAccept sq →
      extractSummary sq ≠ forgedRawG2348Summary :=
  OmegaCellC1P1B2BB4.T_D0_A1_02_RawG2348SummaryForgeryContrast

theorem Pin_03_T_D0_A1_03 (ctx : B4SharedContext) (s : VerifiedSlice56 ctx)
    (hPrem : ∀ p ∈ deriveSlice56PrimDeps s.1, SemValidPrimId ctx.primEnv p) :
    (qualifyG56Coupled? ctx.toG56Context s.1.c56).isSome = true ∧
    s.1.claimedBase.assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    SemValidG56Coupling s.1.c56 :=
  OmegaCellC1P1B2BB4.T_D0_A1_03_Slice56ProjectionAndSoundness ctx s hPrem

theorem Pin_04_T_D0_A1_04 (ctx : B4SharedContext) (s : VerifiedSlice7 ctx)
    (hPrem7     : ∀ p ∈ deriveSlice7PrimDeps s.1, SemValidPrimId ctx.primEnv p)
    (hPremInter : ∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont s.1.bridgeMode,
                    SemValidPrimId ctx.primEnv p) :
    s.1.bundle.primEnvSnapshot = ctx.primEnv ∧
    s.1.bundle.dagSnapshot = ctx.dagCont ∧
    ctx.assignedEvalEpoch < s.1.bundle.expiresEpoch ∧
    (∀ ρ : Env2,
       InEffDom s.1.claimedBase.domNew s.1.claimedBase.guardsNew ρ →
       ModelsStrictForm s.1.claimedBase.postGoal ρ) :=
  OmegaCellC1P1B2BB4.T_D0_A1_04_Slice7SharedEnvAndGoalBridgeSound ctx s hPrem7 hPremInter

-- D0-A2 (4)
theorem Pin_05_T_D0_A2_01 :
    Nonempty (ValidSlice2348 ctx_posB4_01) ∧
    Nonempty (ValidSlice56 ctx_posB4_01) ∧
    Nonempty (ValidSlice7 ctx_posB4_01) :=
  OmegaCellC1P1B2BB4.T_D0_A2_01_IndividualSlotNonemptiness

theorem Pin_06_T_D0_A2_02 :
    (∀ d : G7DomTag, isV1SupportedDomTagBool d = true → isG7IdSupportedDomTagBool d = true) ∧
    (isV1SupportedDomTagBool .domQ2 = false ∧ isG7IdSupportedDomTagBool .domQ2 = true) ∧
    (isG7IdSupportedDomTagBool (.domFiniteGrid [(1, 0)]) = false) :=
  OmegaCellC1P1B2BB4.T_D0_A2_02_ProperInclusionOfSlotTransitionImages

theorem Pin_07_T_D0_A2_03 :
    (∀ (ctx : B4SharedContext) (s1 : ValidSlice2348 ctx),
       B4SyntacticContextValid ctx →
       let t := (projValidSlice2348 s1).1
       t.baseId = "base_Q" ∧
       (t.domOld = .domQ ∨ t.domOld = .domQNonzero) ∧
       (t.domNew = .domQ ∨ t.domNew = .domQNonzero)) ∧
    (∀ (ctx : B4SharedContext) (s2 : ValidSlice56 ctx),
       projValidSlice56 s2 ≠ t_nonSurjValidBase) :=
  OmegaCellC1P1B2BB4.T_D0_A2_03_CommonBaseCompatibilityCharacterization

theorem Pin_08_T_D0_A2_04 :
    let s1 : B4TemporalStep := ⟨demoStep1RetreatBase, ⟨([[.eqZero .varX]], []), rfl⟩, [], rfl⟩
    let s2 : B4TemporalStep := ⟨demoStep2RepairAfterRetreatBase, botCanonCutPair, [], rfl⟩
    ValidB4TransitionBase s1.base ∧
    ValidB4TransitionBase s2.base ∧
    s2.base.stepRequiresRetreat = false ∧
    s2.base.cumulativeHistRetreat = true ∧
    (s2.base.toG56Binding).requiresRetreatHistory = false ∧
    checkStepComposableBool s1 s2 = true :=
  OmegaCellC1P1B2BB4.T_D0_A2_04_StepVsCumulativeRetreatFlagCoherence

-- D0-A3 (3)
theorem Pin_09_T_D0_A3_01 (ctx : B4SharedContext) :
    (∀ sp : B4CanonicalSpine ctx, ofIndexedSigma (toIndexedSigma sp) = sp) ∧
    (∀ sig : B4IndexedSigma ctx, toIndexedSigma (ofIndexedSigma sig) = sig) :=
  OmegaCellC1P1B2BB4.T_D0_A3_01_IndexedProductRecordEquivalence ctx

theorem Pin_10_T_D0_A3_02 :
    sp_posB4_01.base.1.reflexKind = .repair ∧
    sp_posB4_02.base.1.reflexKind = .retreat ∧
    sp_posB4_03.base.1.reflexKind = .refinement ∧
    (qualifyB4Composite? ctx_posB4_01 pkt_posB4_01).isSome = true ∧
    (qualifyB4Composite? ctx_posB4_02 pkt_posB4_02).isSome = true ∧
    (qualifyB4Composite? ctx_posB4_03 pkt_posB4_03).isSome = true :=
  OmegaCellC1P1B2BB4.T_D0_A3_02_ThreeSlotSpineNonemptinessAllKinds

theorem Pin_11_T_D0_A3_03 (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    ((pkt.s7.bundle.primEnvSnapshot ≠ ctx.primEnv ∨ pkt.s7.bundle.dagSnapshot ≠ ctx.dagCont) →
       evalB4CompositeError? ctx pkt = some .mismatchedSharedEnvOrDag ∧
       checkB4CompositeBool ctx pkt = false) ∧
    ((pkt.s7.bundle.primEnvSnapshot = ctx.primEnv ∧ pkt.s7.bundle.dagSnapshot = ctx.dagCont) →
     (pkt.s2348.claimedBase ≠ pkt.s56.claimedBase ∨ pkt.s56.claimedBase ≠ pkt.s7.claimedBase) →
       evalB4CompositeError? ctx pkt = some .mismatchedTransitionBase ∧
       checkB4CompositeBool ctx pkt = false) :=
  OmegaCellC1P1B2BB4.T_D0_A3_03_SplitTransitionOrContextRejection ctx pkt

-- D0-A4 (7)
theorem Pin_12_T_D0_A4_01 (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    ((qualifyB4Composite? ctx pkt).isSome = true ↔ checkB4CompositeBool ctx pkt = true) ∧
    (∀ hVer : checkB4CompositeBool ctx pkt = true,
       qualifyB4Composite? ctx pkt = some (reifyB4Spine ctx (spineOfVerifiedPacket ctx pkt hVer))) :=
  OmegaCellC1P1B2BB4.T_D0_A4_01_SpineExistence ctx pkt

theorem Pin_13_T_D0_A4_02 (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx) :
    (∃ g56Rec : G56QualifiedRecord ctx.toG56Context,
       extractVerifiedG56 g56Rec.verifiedG56Slot = rec.spine.c56) ∧
    (∃ b1g7 : CoupledB1G7Qualification,
       extractB1G7Summary b1g7.spine = extractSummary rec.spine.sq2348 ∧
       extractB1G7Bundle b1g7.spine = rec.spine.bundle7) :=
  OmegaCellC1P1B2BB4.T_D0_A4_02_SpineReconstructionLossless ctx rec

theorem Pin_14_T_D0_A4_03 (ctx : B4SharedContext) :
    (∀ sp : B4CanonicalSpine ctx, extractB4Spine (reifyB4Spine ctx sp) = sp) ∧
    (∀ rec : B4QualifiedRecord ctx, reifyB4Spine ctx (extractB4Spine rec) = rec) :=
  OmegaCellC1P1B2BB4.T_D0_A4_03_SpineRoundtrip ctx

theorem Pin_15_T_D0_A4_04 (ctx : B4SharedContext) (r1 r2 : B4QualifiedRecord ctx) :
    r1 = r2 ↔ extractB4Spine r1 = extractB4Spine r2 :=
  OmegaCellC1P1B2BB4.T_D0_A4_04_SpineUniqueness ctx r1 r2

theorem Pin_16_T_D0_A4_05 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    projValidSlice2348 sp.slice2348 = sp.base ∧
    projValidSlice56 sp.slice56 = sp.base ∧
    projValidSlice7 sp.slice7 = sp.base ∧
    subjectKeyOfB1Summary (extractSummary sp.sq2348) = sp.bundle7.subjectKey :=
  OmegaCellC1P1B2BB4.T_D0_A4_05_ProjectionAndSubjectKeyPreservation ctx sp

theorem Pin_17_T_D0_A4_06 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    SemValidB4Spine ctx sp ↔
    SemValidB4ThreeTuple ctx sp.slice2348 sp.slice56 sp.slice7 :=
  OmegaCellC1P1B2BB4.T_D0_A4_06_SemanticPreservation ctx sp

theorem Pin_18_T_D0_A4_07 {X : Type} (ctx : B4SharedContext)
    (f0 : X → B4ValidBase)
    (f1 : X → ValidSlice2348 ctx)
    (f2 : X → ValidSlice56 ctx)
    (f3 : X → ValidSlice7 ctx)
    (h1 : ∀ x : X, projValidSlice2348 (f1 x) = f0 x)
    (h2 : ∀ x : X, projValidSlice56 (f2 x) = f0 x)
    (h3 : ∀ x : X, projValidSlice7 (f3 x) = f0 x) :
    let u := liftThreeConeToSpine f0 f1 f2 f3 h1 h2 h3
    (∀ x : X,
       (u x).base = f0 x ∧
       (u x).slice2348 = f1 x ∧
       (u x).slice56 = f2 x ∧
       (u x).slice7 = f3 x) ∧
    (∀ u' : X → B4CanonicalSpine ctx,
       (∀ x : X,
          (u' x).base = f0 x ∧
          (u' x).slice2348 = f1 x ∧
          (u' x).slice56 = f2 x ∧
          (u' x).slice7 = f3 x) →
       ∀ x : X, u' x = u x) :=
  OmegaCellC1P1B2BB4.T_D0_A4_07_ThreeSlotUniversalProperty ctx f0 f1 f2 f3 h1 h2 h3

-- D0-A5 (4)
theorem Pin_19_T_D0_A5_01 (ctx : B4SharedContext) :
    (∀ pL : B4LeftPullback ctx, leftOfSpine (spineOfLeft pL) = pL) ∧
    (∀ sp : B4CanonicalSpine ctx, spineOfLeft (leftOfSpine sp) = sp) ∧
    (∀ pR : B4RightPullback ctx, rightOfSpine (spineOfRight pR) = pR) ∧
    (∀ sp : B4CanonicalSpine ctx, spineOfRight (rightOfSpine sp) = sp) ∧
    (∀ pL : B4LeftPullback ctx, assocRightToLeft (assocLeftToRight pL) = pL) ∧
    (∀ pR : B4RightPullback ctx, assocLeftToRight (assocRightToLeft pR) = pR) :=
  OmegaCellC1P1B2BB4.T_D0_A5_01_LeftRightSpineBijection ctx

theorem Pin_20_T_D0_A5_02 (ctx : B4SharedContext) (pL : B4LeftPullback ctx) :
    let spL := spineOfLeft pL
    let spR := spineOfRight (assocLeftToRight pL)
    spR = spL ∧
    (SemValidB4Spine ctx spL ↔ SemValidB4Spine ctx spR) ∧
    deriveSpineB4PrimDeps ctx spL = deriveSpineB4PrimDeps ctx spR :=
  OmegaCellC1P1B2BB4.T_D0_A5_02_AssociatorSemanticAndDepsInvariance ctx pL

theorem Pin_21_T_D0_A5_03 (ctx : B4SharedContext) (a b : B4CanonicalSpine ctx) :
    a = b ↔
      (a.base = b.base ∧
       (a.ast = b.ast ∧ extractSummary a.sq2348 = extractSummary b.sq2348 ∧
        a.c56 = b.c56 ∧ a.bundle7 = b.bundle7 ∧ a.bridgeMode = b.bridgeMode) ∧
       a.base.1.toG56Binding = b.base.1.toG56Binding ∧
       deriveSpineB4PrimDeps ctx a = deriveSpineB4PrimDeps ctx b) :=
  OmegaCellC1P1B2BB4.T_D0_A5_03_SpineCoherenceDecomposition ctx a b

theorem Pin_22_T_D0_A5_04 :
    deriveSpineB4PrimDeps ctx_posB4_01 sp_posB4_01 =
      deriveSpineB4PrimDeps ctx_posB4_01 sp_posB4_01_alt ∧
    sp_posB4_01 ≠ sp_posB4_01_alt :=
  OmegaCellC1P1B2BB4.T_D0_A5_04_DepsEqDoesNotImplySpineEq

-- D0-A6 (3)
theorem Pin_23_T_D0_A6_01 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    let D_B4 := deriveSpineB4PrimDeps ctx sp
    let R_B4 := collectB4JointProofRoots sp.c56 sp.bundle7 sp.bridgeMode
    D_B4 = multiRootTransitivePrimDeps ctx.primEnv ctx.dagCont R_B4 ∧
    isStrictCanonStrList D_B4 = true ∧
    D_B4.Nodup :=
  OmegaCellC1P1B2BB4.T_D0_A6_01_ThreeWayClosureEqualsMultiRootClosure ctx sp

theorem Pin_24_T_D0_A6_02 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    ((sp.bridgeMode = .directUnguardedL0 ∨ sp.bridgeMode = .impNormalizedA0) →
       bridgeRootsOfMode sp.bridgeMode = [] ∧
       deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode = []) ∧
    (ValidContainer ctx.dagCont →
       ∀ nid : String,
         IsReferencedB4BridgeNodeId ctx sp.bridgeMode nid →
         nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode sp.bridgeMode)) ∧
    (∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode,
       p ∈ deriveSpineB4PrimDeps ctx sp) :=
  OmegaCellC1P1B2BB4.T_D0_A6_02_InteractionPremiseZeroAndBridgeCompleteness ctx sp

theorem Pin_25_T_D0_A6_03
    (regId : String) (store : StructuralStore) (L : List StructuralLedgerEvent)
    (epoch : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (pld : B4RawPayload) (q_out : String) (newFormula : StrictForm)
    (hOut : q_out ∉ deriveB4JointPrimDeps Γ C pld.c56 pld.bundle7 pld.bridgeMode) :
    let D_B4   := deriveB4JointPrimDeps Γ C pld.c56 pld.bundle7 pld.bridgeMode
    let D56    := pld.c56.claimedJointPrimDeps.jointPrimDepIds
    let D7     := pld.bundle7.claimedPrimDeps
    let D_int  := deriveB4InteractionPrimDeps Γ C pld.bridgeMode
    let Γ'     := replacePrimFormulaInEnv Γ q_out newFormula
    ((∀ p ∈ D_B4, SemValidPrimId Γ p) ↔
      ((∀ p ∈ D56, SemValidPrimId Γ p) ∧
       (∀ p ∈ D7, SemValidPrimId Γ p) ∧
       (∀ p ∈ D_int, SemValidPrimId Γ p))) ∧
    (∀ p ∈ D_B4,
       lookupPrimPrem? Γ' p = lookupPrimPrem? Γ p ∧
       (SemValidPrimId Γ' p ↔ SemValidPrimId Γ p)) ∧
    (SemB4PayloadValid regId store L epoch Γ pld ↔
     SemB4PayloadValid regId store L epoch Γ' pld) :=
  OmegaCellC1P1B2BB4.T_D0_A6_03_PremiseSplittingAndOutsideNonInterference
    regId store L epoch Γ C pld q_out newFormula hOut

-- D0-A7 (4)
theorem Pin_26_T_D0_A7_01 (P_env : PrimPremiseEnv) :
    (∀ c : CanonCutPair, CutPairEquivInEnv P_env (joinCanonCutPair c c) c) ∧
    (∀ c1 c2 : CanonCutPair, CutPairEquivInEnv P_env (joinCanonCutPair c1 c2) (joinCanonCutPair c2 c1)) ∧
    (∀ c1 c2 c3 : CanonCutPair,
       CutPairEquivInEnv P_env
         (joinCanonCutPair (joinCanonCutPair c1 c2) c3)
         (joinCanonCutPair c1 (joinCanonCutPair c2 c3))) ∧
    (∀ c : CanonCutPair,
       joinCanonCutPair botCanonCutPair c = c ∧
       joinCanonCutPair c botCanonCutPair = c) :=
  OmegaCellC1P1B2BB4.T_D0_A7_01_CutJoinSemilatticeLaws P_env

theorem Pin_27_T_D0_A7_02 (s1 s2 s3 : B4TemporalStep)
    (h12 : checkStepComposableBool s1 s2 = true)
    (h23 : checkStepComposableBool s2 s3 = true) :
    checkCompositeStepComposableBool (appendStepToComposite (stepToComposite s1) s2) s3 = true ∧
    appendStepToComposite (appendStepToComposite (stepToComposite s1) s2) s3 =
    prependStepToComposite s1 (appendStepToComposite (stepToComposite s2) s3) :=
  OmegaCellC1P1B2BB4.T_D0_A7_02_TypedPartialCompositionAssociativity s1 s2 s3 h12 h23

theorem Pin_28_T_D0_A7_03 :
    (∀ (st : B4HistoricalChainState) (cid : String) (ep : Nat) (nd : B4EffDomSpec) (ΔΦ : ExcisedLocus),
       st.E_historical <+: (applyAccountedChainStep st cid ep nd ΔΦ).E_historical) ∧
    (∀ {st0 stk : B4HistoricalChainState},
       ValidB4MonotoneChain st0 stk →
       st0.E_historical <+: stk.E_historical) :=
  OmegaCellC1P1B2BB4.T_D0_A7_03_HistoricalExcisionAppendOnly

theorem Pin_29_T_D0_A7_04 (s1 s2 : B4TemporalStep) :
    (s1.base.baseId ≠ "base_Q" ∨ s2.base.baseId ≠ "base_Q" ∨ s1.base.baseId ≠ s2.base.baseId →
       checkStepComposableBool s1 s2 = false) ∧
    (¬ (s1.base.assignedEvalEpoch < s2.base.assignedEvalEpoch) →
       checkStepComposableBool s1 s2 = false) ∧
    (s2.base.parentPathKey? ≠ some s1.base.pathKey →
       checkStepComposableBool s1 s2 = false) :=
  OmegaCellC1P1B2BB4.T_D0_A7_04_DisjointSpaceUnionRejection s1 s2

-- D0-A8 (3)
theorem Pin_30_T_D0_A8_01 :
    (∀ {D0 D1 D2 : G7DomTag} {G0 G1 G2 : List StrictForm} {Φ1 Φ2 : ExcisedLocus},
       SemExactScopeLossPartition D0 G0 D1 G1 Φ1 →
       SemExactScopeLossPartition D1 G1 D2 G2 Φ2 →
       SemExactScopeLossPartition D0 G0 D2 G2 (Φ1 ++ Φ2)) ∧
    (∀ {st0 stk : B4HistoricalChainState},
       ValidB4MonotoneChain st0 stk →
       stk.initialDom = st0.initialDom ∧
       SemExactScopeLossPartition
         st0.initialDom.domTag st0.initialDom.guards
         stk.currentDom.domTag stk.currentDom.guards
         stk.E_currentlyExcluded ∧
       (∀ ρ : Env2,
          InB4EffDom stk.currentDom ρ ↔
          (InB4EffDom st0.initialDom ρ ∧ ¬ ModelsExcised stk.E_currentlyExcluded ρ))) :=
  OmegaCellC1P1B2BB4.T_D0_A8_01_MultiStepExactLossPartitionComposition

theorem Pin_31_T_D0_A8_02 {st0 stk : B4HistoricalChainState}
    (hChain : ValidB4MonotoneChain st0 stk) :
    ∀ ev ∈ stk.E_historical, ∀ ρ : Env2,
      ModelsExcised ev.stepExcised ρ →
      ¬ InB4EffDom stk.currentDom ρ :=
  OmegaCellC1P1B2BB4.T_D0_A8_02_NoSilentScopeResurrection hChain

theorem Pin_32_T_D0_A8_03 :
    (∀ (st : B4HistoricalChainState) (stepBase : B4CommonTransitionBase),
       st.currentEpoch < stepBase.assignedEvalEpoch →
       st.currentDom.domTag = .domQNonzero →
       stepBase.domNew = .domQ →
       evalMonotoneChainStepError? st stepBase = some .silentScopeResurrectionBlocked ∧
       checkMonotoneChainStepBool st stepBase = false) ∧
    (let d1 : B4EffDomSpec := ⟨.domQ, [.neqZero .varX]⟩
     let d2 : B4EffDomSpec := ⟨.domQ, [.neqZero .varX, .neqZero (.sub .varX (.const 1))]⟩
     ¬ StepDomainAccountingWitness d1 d2 []) :=
  OmegaCellC1P1B2BB4.T_D0_A8_03_SilentResurrectionStepRejected

-- D0-A9 (3)
theorem Pin_33_T_D0_A9_01 {ctx : B4SharedContext} (rec : B4QualifiedRecord ctx)
    (L ΔL : List StructuralLedgerEvent) (p : String)
    (hDep : p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec))
    (hRet : p ∈ OmegaCellC1P1B2BB4.retractedOfLedger L) :
    checkActiveB4RecordBool (L ++ ΔL) rec = false :=
  OmegaCellC1P1B2BB4.T_D0_A9_01_SoundTargetedInvalidation rec L ΔL p hDep hRet

theorem Pin_34_T_D0_A9_02 {ctx : B4SharedContext} (rec : B4QualifiedRecord ctx)
    (L : List StructuralLedgerEvent) :
    (∀ (ΔL : List StructuralLedgerEvent),
       checkActiveB4RecordBool L rec = true →
       (∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), p ∉ retractedPremisesInEvents ΔL) →
       currentEpochOfLedger (L ++ ΔL) < (extractB4Spine rec).bundle7.expiresEpoch →
       hasSilentResurrectionAfterBool (extractB4Spine rec).base.1 (L ++ ΔL) = false →
       checkActiveB4RecordBool (L ++ ΔL) rec = true) ∧
    (let exp := (extractB4Spine rec).bundle7.expiresEpoch
     let ΔL_exp : List StructuralLedgerEvent := [.advanceEpoch exp]
     (∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), p ∉ retractedPremisesInEvents ΔL_exp) ∧
     checkActiveB4RecordBool (L ++ ΔL_exp) rec = false) :=
  OmegaCellC1P1B2BB4.T_D0_A9_02_DependencySensitivePreservation rec L

theorem Pin_35_T_D0_A9_03
    (chain : List PackagedB4Record)
    (L ΔL : List StructuralLedgerEvent)
    (k : Nat) (hk : k < chain.length)
    (p : String)
    (hDepK : p ∈ (chain[k]).primDeps)
    (hRetP : p ∈ retractedPremisesInEvents ΔL)
    (hPrefAct : ∀ (i : Nat) (hi : i < k),
       (chain[i]'(Nat.lt_trans hi hk)).activeAtBool L = true)
    (hPrefDisj : ∀ (i : Nat) (hi : i < k),
       ∀ r ∈ (chain[i]'(Nat.lt_trans hi hk)).primDeps, r ∉ retractedPremisesInEvents ΔL)
    (hPrefExp : ∀ (i : Nat) (hi : i < k),
       currentEpochOfLedger (L ++ ΔL) < (chain[i]'(Nat.lt_trans hi hk)).expiresEpoch)
    (hPrefNoRes : ∀ (i : Nat) (hi : i < k),
       hasSilentResurrectionAfterBool (chain[i]'(Nat.lt_trans hi hk)).base (L ++ ΔL) = false) :
    (∀ (i : Nat) (hi : i < k),
       (chain[i]'(Nat.lt_trans hi hk)).activeAtBool (L ++ ΔL) = true ∧
       activeChainNodeAtBool (L ++ ΔL) chain i = true) ∧
    (∀ (j : Nat) (hj : j < chain.length),
       k ≤ j →
       activeChainNodeAtBool (L ++ ΔL) chain j = false ∧
       (IsCausalDepsMonotoneChain chain → (chain[j]).activeAtBool (L ++ ΔL) = false)) :=
  OmegaCellC1P1B2BB4.T_D0_A9_03_CausalChainSuffixInvalidationPrefixPreservation
    chain L ΔL k hk p hDepK hRetP hPrefAct hPrefDisj hPrefExp hPrefNoRes

-- D0-A10 (5)
theorem Pin_36_T_D0_A10_01 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) (R : List String) :
    deriveSlice2348PrimDeps sp.slice2348.1.1 = [] ∧
    depActiveBool (deriveSpineB4PrimDeps ctx sp) R =
      (depActiveBool (deriveSlice2348PrimDeps sp.slice2348.1.1) R &&
       depActiveBool (deriveSlice56PrimDeps sp.slice56.1.1) R &&
       depActiveBool (deriveSlice7PrimDeps sp.slice7.1.1) R &&
       depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode) R) :=
  OmegaCellC1P1B2BB4.T_D0_A10_01_DepActiveExactDecomposition ctx sp R

theorem Pin_37_T_D0_A10_02
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (hJointGuard : jointStandingGuardBool L ctx sp.base.1 = true)
    (hInterSurv  : depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
                     (OmegaCellC1P1B2BB4.retractedOfLedger L) = true) :
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔
      (activeSlice2348Bool L sp.slice2348 = true ∧
       activeSlice56Bool L sp.slice56 = true ∧
       activeSlice7Bool L sp.slice7 = true) :=
  OmegaCellC1P1B2BB4.T_D0_A10_02_RestrictedSpatioTemporalInterchange L ctx sp hJointGuard hInterSurv

theorem Pin_38_T_D0_A10_03
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (hJointGuard : jointStandingGuardBool L ctx sp.base.1 = true)
    (hSubsumed :
       ∀ p ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode,
         p ∈ deriveSlice56PrimDeps sp.slice56.1.1 ∨ p ∈ deriveSlice7PrimDeps sp.slice7.1.1) :
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = true ↔
      (activeSlice2348Bool L sp.slice2348 = true ∧
       activeSlice56Bool L sp.slice56 = true ∧
       activeSlice7Bool L sp.slice7 = true) :=
  OmegaCellC1P1B2BB4.T_D0_A10_03_ZeroInteractionUnconditionalInterchange L ctx sp hJointGuard hSubsumed

theorem Pin_39_T_D0_A10_04
    (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx)
    (p_br : String)
    (hInInter : p_br ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
    (hRetOnlyBr : OmegaCellC1P1B2BB4.retractedOfLedger L = [p_br])
    (hNot56 : p_br ∉ deriveSlice56PrimDeps sp.slice56.1.1)
    (hNot7  : p_br ∉ deriveSlice7PrimDeps sp.slice7.1.1)
    (hExp   : currentEpochOfLedger L < sp.bundle7.expiresEpoch) :
    activeSlice2348Bool L sp.slice2348 = true ∧
    activeSlice56Bool L sp.slice56 = true ∧
    activeSlice7Bool L sp.slice7 = true ∧
    checkActiveB4RecordBool L (reifyB4Spine ctx sp) = false :=
  OmegaCellC1P1B2BB4.T_D0_A10_04_InteractionPremiseRetractionBreaksNaiveInterchange
    L ctx sp p_br hInInter hRetOnlyBr hNot56 hNot7 hExp

theorem Pin_40_T_D0_A10_05 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    let e_sp := committedEntryOfSpine sp
    let L' := ctx.ledgerSnap ++ [.recordStructuralReflex e_sp]
    checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore L' sp.ast =
      .rejectInvalid .G8 .duplicatePathKey ∧
    checkSlice2348Bool { ctx with ledgerSnap := L' } sp.slice2348.1.1 = false ∧
    checkActiveB4SpineBool L' ctx sp = checkActiveB4SpineBool ctx.ledgerSnap ctx sp :=
  OmegaCellC1P1B2BB4.T_D0_A10_05_CreationVsStandingPathKeyDistinction ctx sp

-- D0-A11 (3)
theorem Pin_41_T_D0_A11_01
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx)
    (hCtx  : B4SyntacticContextValid ctx)
    (hPrem : ∀ p ∈ deriveSpineB4PrimDeps ctx (extractB4Spine rec), SemValidPrimId ctx.primEnv p) :
    SemValidB4Spine ctx (extractB4Spine rec) :=
  OmegaCellC1P1B2BB4.T_D0_A11_01_B4_MasterConditionalSoundness ctx rec hCtx hPrem

theorem Pin_42_T_D0_A11_02 :
    deriveSpineB4PrimDeps ctx_posB4_06 (extractB4Spine rec_posB4_06) =
      ["p_br_ax", "p_g5_ax", "p_g6_ax", "p_g7_ax"] ∧
    B4SyntacticContextValid ctx_posB4_06 ∧
    (∀ p ∈ deriveSpineB4PrimDeps ctx_posB4_06 (extractB4Spine rec_posB4_06),
       SemValidPrimId ctx_posB4_06.primEnv p) ∧
    SemValidB4Spine ctx_posB4_06 (extractB4Spine rec_posB4_06) :=
  OmegaCellC1P1B2BB4.T_D0_A11_02_NonVacuousMasterSoundnessWitness

theorem Pin_43_T_D0_A11_03
    (ctx : B4SharedContext) (s : ProvenanceBoundG2348Slice) (payload : B4RawPayload) :
    let ctxZeroFuel := { ctx with fuelStruct := 0, fuelG5 := 0, fuelG6 := 0 }
    checkSlice2348Bool ctxZeroFuel s = false ∧
    (SemB4PayloadValid ctx.regId ctx.structStore ctx.ledgerSnap ctx.assignedEvalEpoch ctx.primEnv payload ↔
     SemB4PayloadValid ctxZeroFuel.regId ctxZeroFuel.structStore ctxZeroFuel.ledgerSnap
       ctxZeroFuel.assignedEvalEpoch ctxZeroFuel.primEnv payload) :=
  OmegaCellC1P1B2BB4.T_D0_A11_03_DeclarativeSemanticsCheckerDisjoint ctx s payload

-- D0-A12 (2)
theorem Pin_44_T_D0_A12_01
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (hInvalid : checkB4CompositeBool ctx pkt = false) :
    projectUnboundB4DiagPassBool spoofedB4DiagObs = true ∧
    checkB4CompositeBool ctx pkt = false :=
  OmegaCellC1P1B2BB4.T_D0_A12_01_UnboundDiagnosticSpoofableContrast ctx pkt hInvalid

theorem Pin_45_T_D0_A12_02
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (d : ProvenanceBoundB4Diagnostic ctx pkt) :
    consumeBoundB4Verdict d = true ↔ (qualifyB4Composite? ctx pkt).isSome = true :=
  OmegaCellC1P1B2BB4.T_D0_A12_02_ProvenanceBoundB4ConsumerSoundness ctx pkt d

-- D0-A14 (3)
theorem Pin_46_T_D0_A14_01 (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx) :
    rec.threeSlotQual.slotG1 = .mkUnchecked ∧
    rec.g1IntegritySlot = .mkUnchecked ∧
    rec.officialRegistryAuth = false ∧
    (∃ s2348, checkG2348SummaryBool s2348 = true) ∧
    (∃ c56, isG56CouplingVerifiedBool ctx.toG56Context c56 = true) ∧
    (∃ b7, checkCertifiedG7BundleBool b7 = true) :=
  OmegaCellC1P1B2BB4.T_D0_A14_01_ThreeVerifiedSlotsWithG1Unchecked ctx rec

theorem Pin_47_T_D0_A14_02 (ctx : B4SharedContext) :
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool
        (isG56CouplingVerifiedBool ctx.toG56Context)
        checkCertifiedG7BundleBool) :=
  OmegaCellC1P1B2BB4.T_D0_A14_02_FullReflexAdmittedStillEmptyInB4 ctx

theorem Pin_48_T_D0_A14_03
    (ctx : B4SharedContext) (rec : B4QualifiedRecord ctx)
    (L ΔL_ep : List StructuralLedgerEvent)
    (hEpOnly : ∀ ev ∈ ΔL_ep, isEpistemicOnlyEventBool ev = true) :
    rec.grantFlag = .noGrantFromMathCheck ∧
    rec.threeSlotQual.grantFlag = .noGrantFromMathCheck ∧
    (foldStructuralLedger (L ++ ΔL_ep)).grantLedger = (foldStructuralLedger L).grantLedger :=
  OmegaCellC1P1B2BB4.T_D0_A14_03_ZeroGrantEscalationAcrossB4Commits ctx rec L ΔL_ep hEpOnly

-- R1 Corrigendum (8)
theorem Pin_49_T_D0_R1_01 (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx) :
    sp.base.1.assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    (sp.base.1.toG56Binding).assignedEvalEpoch = ctx.assignedEvalEpoch ∧
    sp.c56.g6Suite.evaluationEpoch = ctx.assignedEvalEpoch ∧
    sp.base.1.assignedEvalEpoch < sp.bundle7.expiresEpoch :=
  OmegaCellC1P1B2BB4.T_D0_R1_01_SpineCommonEpochBinding ctx sp

theorem Pin_50_T_D0_R1_02
    (ctx' : B4SharedContext) (pkt : B4CandidatePacket)
    (hMis : pkt.s7.bundle.primEnvSnapshot ≠ ctx'.primEnv ∨
            pkt.s7.bundle.dagSnapshot ≠ ctx'.dagCont) :
    evalB4CompositeError? ctx' pkt = some .mismatchedSharedEnvOrDag ∧
    checkB4CompositeBool ctx' pkt = false :=
  OmegaCellC1P1B2BB4.T_D0_R1_02_ExactSnapshotMismatchRejection ctx' pkt hMis

theorem Pin_51_T_D0_R1_03
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (ctx' : B4SharedContext) (pkt' : B4CandidatePacket)
    (hReb : CoherentFormulaRebind ctx pkt ctx' pkt')
    (hVer : checkB4CompositeBool ctx pkt = true) :
    checkB4CompositeBool ctx' pkt' = true :=
  OmegaCellC1P1B2BB4.T_D0_R1_03_TopologyPreservingCoherentRebindSoundness ctx pkt ctx' pkt' hReb hVer

theorem Pin_52_T_D0_R1_04 (P_env : PrimPremiseEnv) :
    Equivalence (CutPairEquivInEnv P_env) ∧
    (∀ (c1 c1' c2 c2' : CanonCutPair),
       CutPairEquivInEnv P_env c1 c1' →
       CutPairEquivInEnv P_env c2 c2' →
       CutPairEquivInEnv P_env (joinCanonCutPair c1 c2) (joinCanonCutPair c1' c2')) :=
  OmegaCellC1P1B2BB4.T_D0_R1_04_CutEquivCongruenceAndEnvIndexing P_env

theorem Pin_53_T_D0_R1_05 :
    (∀ (D56 D7 Dinter R : List String),
       (∀ p ∈ Dinter, p ∈ D56 ∨ p ∈ D7) →
       depActiveBool D56 R = true →
       depActiveBool D7 R = true →
       depActiveBool Dinter R = true) ∧
    (let D56 := ["prem_5"]
     let D7  := ["prem_7"]
     let Dinter := ["prem_bridge_only"]
     let R := ["prem_bridge_only"]
     depActiveBool D56 R = true ∧
     depActiveBool D7 R = true ∧
     depActiveBool Dinter R = false) :=
  OmegaCellC1P1B2BB4.T_D0_R1_05_SubsumedInteractionConditionalSurvival

theorem Pin_54_T_D0_R1_06
    (q_k q_indep : PackagedB4Record)
    (L ΔL : List StructuralLedgerEvent)
    (p : String)
    (hDepK : p ∈ q_k.primDeps)
    (hRetP : p ∈ retractedPremisesInEvents ΔL)
    (hActIndep : q_indep.activeAtBool L = true)
    (hFullDisj : ∀ r ∈ q_indep.primDeps, r ∉ retractedPremisesInEvents ΔL)
    (hExpIndep : currentEpochOfLedger (L ++ ΔL) < q_indep.expiresEpoch)
    (hNoResIndep : hasSilentResurrectionAfterBool q_indep.base (L ++ ΔL) = false) :
    q_k.activeAtBool (L ++ ΔL) = false ∧
    q_indep.activeAtBool (L ++ ΔL) = true :=
  OmegaCellC1P1B2BB4.T_D0_R1_06_StandaloneNonChainedRecordIndependence
    q_k q_indep L ΔL p hDepK hRetP hActIndep hFullDisj hExpIndep hNoResIndep

theorem Pin_55_T_D0_R1_07 (L ΔL : List StructuralLedgerEvent) :
    OmegaCellC1P1B2BB4.retractedOfLedger (L ++ ΔL) =
      OmegaCellC1P1B2BB4.retractedOfLedger L ++ retractedPremisesInEvents ΔL ∧
    (∀ p : String,
       p ∈ OmegaCellC1P1B2BB4.retractedOfLedger (L ++ ΔL) ↔
       (p ∈ OmegaCellC1P1B2BB4.retractedOfLedger L ∨ p ∈ retractedPremisesInEvents ΔL)) ∧
    (∀ p : String, p ∈ OmegaCellC1P1B2BB4.retractedOfLedger L →
       p ∈ OmegaCellC1P1B2BB4.retractedOfLedger (L ++ ΔL)) :=
  OmegaCellC1P1B2BB4.T_D0_R1_07_RetractedLedgerAppendExactUnion L ΔL

theorem Pin_56_T_D0_R1_08 :
    (∀ {V : Type} (kvs out : List (String × V)),
       parseJsonPairsStrict kvs = some out ↔ ((kvs.map Prod.fst).Nodup ∧ out = kvs)) ∧
    (∀ {V : Type} (kvs : List (String × V)),
       ¬ (kvs.map Prod.fst).Nodup → parseJsonPairsStrict kvs = none) ∧
    (parseJsonPairsStrict ce29_dupVerdictJson = none ∧
     lookupJsonLastWins? ce29_dupVerdictJson "verdict" = some "FORGED_PASS") :=
  OmegaCellC1P1B2BB4.T_D0_R1_08_VerifyKitStrictJsonParseContract

-- T23 Companion Theorems (7)
theorem Pin_57_T_I0_T23_01 :
    (∀ (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       ValidB4TransitionBaseInCtx ctx sp.base.1) ∧
    (∀ (ctx : B4SharedContext),
       ctx.assignedEvalEpoch = 99 →
       ValidB4TransitionBase t_nonSurjValidBase.1 ∧
       ¬ ValidB4TransitionBaseInCtx ctx t_nonSurjValidBase.1) :=
  OmegaCellC1P1B2BB4.T_I0_T23_01_ValidBaseInCtxDerivedFromSpine

theorem Pin_58_T_I0_T23_02 :
    (∀ (ctx : B4SharedContext) (mode : B4G7GoalBridgeMode),
       ValidContainer ctx.dagCont →
       (∀ nid, InductiveUsedBridgeNode ctx.dagCont mode nid →
          nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode mode)) ∧
       (∀ pid, InductiveUsedBridgePrim ctx.primEnv ctx.dagCont mode pid →
          pid ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont mode) ∧
       (∀ nid, QueriedNodeByBridgeChecker ctx mode nid →
          nid ∈ multiRootReachableNodes ctx.dagCont (bridgeRootsOfMode mode)) ∧
       (∀ pid, QueriedPrimByBridgeChecker ctx mode pid →
          pid ∈ deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont mode)) ∧
    (ValidContainer ce31_malformedRankZeroCont = false ∧
     InductiveUsedBridgeNode ce31_malformedRankZeroCont (.certifiedBridgeL1 "b_root" 4) "b_deep" ∧
     "b_deep" ∉ multiRootReachableNodes ce31_malformedRankZeroCont ["b_root"]) :=
  OmegaCellC1P1B2BB4.T_I0_T23_02_NonCircularBridgeSemanticAndRuntimeClosure

theorem Pin_59_T_I0_T23_03
    (ctx : B4SharedContext) (pkt : B4CandidatePacket)
    (ctx' : B4SharedContext) (pkt' : B4CandidatePacket)
    (hReb : CoherentFormulaRebind ctx pkt ctx' pkt')
    (hVer : checkB4CompositeBool ctx pkt = true) :
    let hVer' := T_D0_R1_03_TopologyPreservingCoherentRebindSoundness ctx pkt ctx' pkt' hReb hVer
    let sp  := spineOfVerifiedPacket ctx pkt hVer
    let sp' := spineOfVerifiedPacket ctx' pkt' hVer'
    RebindSpineRel sp sp' ∧
    ((∀ p ∈ deriveSpineB4PrimDeps ctx sp, SemValidPrimId ctx.primEnv p) ↔
     (∀ p ∈ deriveSpineB4PrimDeps ctx' sp', SemValidPrimId ctx'.primEnv p)) :=
  OmegaCellC1P1B2BB4.T_I0_T23_03_CoherentRebindConstructsIndexedSpine ctx pkt ctx' pkt' hReb hVer

theorem Pin_60_T_I0_T23_04 :
    let d0 : B4EffDomSpec := ⟨.domQ, []⟩
    let d1 : B4EffDomSpec := ⟨.domQ, [.pos .varX]⟩
    let P_true  : PrimPremiseEnv := [⟨"p", .domQ, "s", .eqZero (.const 0), []⟩]
    let P_false : PrimPremiseEnv := [⟨"p", .domQ, "s", .pos (.const 0), []⟩]
    (InB4EffDom d0 (0, 0) ∧ ¬ InB4EffDom d1 (0, 0)) ∧
    (SemValidPrimId P_true "p" ∧ ¬ SemValidPrimId P_false "p" ∧
     ∀ ρ : Env2, InB4EffDom d0 ρ ↔ InEffDom .domQ [] ρ) :=
  OmegaCellC1P1B2BB4.T_I0_T23_04_PrimEnvVsGuardEnvOrthogonality

theorem Pin_61_T_I0_T23_05 :
    let ΔL_two : List StructuralLedgerEvent := [.retractPremise "prem_p", .retractPremise "prem_r"]
    ("prem_p" ∉ (["prem_r"] : List String)) ∧
    depActiveBool ["prem_r"] (OmegaCellC1P1B2BB4.retractedOfLedger []) = true ∧
    depActiveBool ["prem_r"] (OmegaCellC1P1B2BB4.retractedOfLedger ([] ++ ΔL_two)) = false ∧
    (∀ q_indep : PackagedB4Record,
       "prem_r" ∈ q_indep.primDeps →
       q_indep.activeAtBool ([] ++ ΔL_two) = false) :=
  OmegaCellC1P1B2BB4.T_I0_T23_05_MultiRetractionRefutesSinglePremiseGuard

theorem Pin_62_T_I0_T23_06 :
    (∀ (L : List StructuralLedgerEvent) (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       checkActiveB4SpineBool L ctx sp =
         (activeSlice2348Bool L sp.slice2348 &&
          activeSlice56Bool L sp.slice56 &&
          activeSlice7Bool L sp.slice7 &&
          depActiveBool (deriveB4InteractionPrimDeps ctx.primEnv ctx.dagCont sp.bridgeMode)
            (OmegaCellC1P1B2BB4.retractedOfLedger L) &&
          jointStandingGuardBool L ctx sp.base.1)) ∧
    (∀ (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       ctx.ledgerSnap = [.advanceEpoch 5] →
       jointStandingGuardBool [] ctx sp.base.1 = false ∧
       checkActiveB4SpineBool [] ctx sp = false) :=
  OmegaCellC1P1B2BB4.T_I0_T23_06_ExactActiveB4JointGuardFactorization

theorem Pin_63_T_I0_T23_07 :
    let rawPreLexTokens   : List (String × String) := [("verdict", "REJECT"), ("verdict_raw_escape", "PASS")]
    let postUnescapePairs : List (String × String) := [("verdict", "REJECT"), ("verdict", "PASS")]
    (parseJsonPairsStrict rawPreLexTokens).isSome = true ∧
    parseJsonPairsStrict postUnescapePairs = none :=
  OmegaCellC1P1B2BB4.T_I0_T23_07_AbstractModelVsRuntimeBoundary

def all63PinnedTheoremPairs : List (Lean.Name × Lean.Name) := [
  (`OmegaCellC1P1B2BB4.T_D0_A1_01_Slice2348ProvenanceSound, `ExternalSpecPinB4I1R3.Pin_01_T_D0_A1_01),
  (`OmegaCellC1P1B2BB4.T_D0_A1_02_RawG2348SummaryForgeryContrast, `ExternalSpecPinB4I1R3.Pin_02_T_D0_A1_02),
  (`OmegaCellC1P1B2BB4.T_D0_A1_03_Slice56ProjectionAndSoundness, `ExternalSpecPinB4I1R3.Pin_03_T_D0_A1_03),
  (`OmegaCellC1P1B2BB4.T_D0_A1_04_Slice7SharedEnvAndGoalBridgeSound, `ExternalSpecPinB4I1R3.Pin_04_T_D0_A1_04),
  (`OmegaCellC1P1B2BB4.T_D0_A2_01_IndividualSlotNonemptiness, `ExternalSpecPinB4I1R3.Pin_05_T_D0_A2_01),
  (`OmegaCellC1P1B2BB4.T_D0_A2_02_ProperInclusionOfSlotTransitionImages, `ExternalSpecPinB4I1R3.Pin_06_T_D0_A2_02),
  (`OmegaCellC1P1B2BB4.T_D0_A2_03_CommonBaseCompatibilityCharacterization, `ExternalSpecPinB4I1R3.Pin_07_T_D0_A2_03),
  (`OmegaCellC1P1B2BB4.T_D0_A2_04_StepVsCumulativeRetreatFlagCoherence, `ExternalSpecPinB4I1R3.Pin_08_T_D0_A2_04),
  (`OmegaCellC1P1B2BB4.T_D0_A3_01_IndexedProductRecordEquivalence, `ExternalSpecPinB4I1R3.Pin_09_T_D0_A3_01),
  (`OmegaCellC1P1B2BB4.T_D0_A3_02_ThreeSlotSpineNonemptinessAllKinds, `ExternalSpecPinB4I1R3.Pin_10_T_D0_A3_02),
  (`OmegaCellC1P1B2BB4.T_D0_A3_03_SplitTransitionOrContextRejection, `ExternalSpecPinB4I1R3.Pin_11_T_D0_A3_03),
  (`OmegaCellC1P1B2BB4.T_D0_A4_01_SpineExistence, `ExternalSpecPinB4I1R3.Pin_12_T_D0_A4_01),
  (`OmegaCellC1P1B2BB4.T_D0_A4_02_SpineReconstructionLossless, `ExternalSpecPinB4I1R3.Pin_13_T_D0_A4_02),
  (`OmegaCellC1P1B2BB4.T_D0_A4_03_SpineRoundtrip, `ExternalSpecPinB4I1R3.Pin_14_T_D0_A4_03),
  (`OmegaCellC1P1B2BB4.T_D0_A4_04_SpineUniqueness, `ExternalSpecPinB4I1R3.Pin_15_T_D0_A4_04),
  (`OmegaCellC1P1B2BB4.T_D0_A4_05_ProjectionAndSubjectKeyPreservation, `ExternalSpecPinB4I1R3.Pin_16_T_D0_A4_05),
  (`OmegaCellC1P1B2BB4.T_D0_A4_06_SemanticPreservation, `ExternalSpecPinB4I1R3.Pin_17_T_D0_A4_06),
  (`OmegaCellC1P1B2BB4.T_D0_A4_07_ThreeSlotUniversalProperty, `ExternalSpecPinB4I1R3.Pin_18_T_D0_A4_07),
  (`OmegaCellC1P1B2BB4.T_D0_A5_01_LeftRightSpineBijection, `ExternalSpecPinB4I1R3.Pin_19_T_D0_A5_01),
  (`OmegaCellC1P1B2BB4.T_D0_A5_02_AssociatorSemanticAndDepsInvariance, `ExternalSpecPinB4I1R3.Pin_20_T_D0_A5_02),
  (`OmegaCellC1P1B2BB4.T_D0_A5_03_SpineCoherenceDecomposition, `ExternalSpecPinB4I1R3.Pin_21_T_D0_A5_03),
  (`OmegaCellC1P1B2BB4.T_D0_A5_04_DepsEqDoesNotImplySpineEq, `ExternalSpecPinB4I1R3.Pin_22_T_D0_A5_04),
  (`OmegaCellC1P1B2BB4.T_D0_A6_01_ThreeWayClosureEqualsMultiRootClosure, `ExternalSpecPinB4I1R3.Pin_23_T_D0_A6_01),
  (`OmegaCellC1P1B2BB4.T_D0_A6_02_InteractionPremiseZeroAndBridgeCompleteness, `ExternalSpecPinB4I1R3.Pin_24_T_D0_A6_02),
  (`OmegaCellC1P1B2BB4.T_D0_A6_03_PremiseSplittingAndOutsideNonInterference, `ExternalSpecPinB4I1R3.Pin_25_T_D0_A6_03),
  (`OmegaCellC1P1B2BB4.T_D0_A7_01_CutJoinSemilatticeLaws, `ExternalSpecPinB4I1R3.Pin_26_T_D0_A7_01),
  (`OmegaCellC1P1B2BB4.T_D0_A7_02_TypedPartialCompositionAssociativity, `ExternalSpecPinB4I1R3.Pin_27_T_D0_A7_02),
  (`OmegaCellC1P1B2BB4.T_D0_A7_03_HistoricalExcisionAppendOnly, `ExternalSpecPinB4I1R3.Pin_28_T_D0_A7_03),
  (`OmegaCellC1P1B2BB4.T_D0_A7_04_DisjointSpaceUnionRejection, `ExternalSpecPinB4I1R3.Pin_29_T_D0_A7_04),
  (`OmegaCellC1P1B2BB4.T_D0_A8_01_MultiStepExactLossPartitionComposition, `ExternalSpecPinB4I1R3.Pin_30_T_D0_A8_01),
  (`OmegaCellC1P1B2BB4.T_D0_A8_02_NoSilentScopeResurrection, `ExternalSpecPinB4I1R3.Pin_31_T_D0_A8_02),
  (`OmegaCellC1P1B2BB4.T_D0_A8_03_SilentResurrectionStepRejected, `ExternalSpecPinB4I1R3.Pin_32_T_D0_A8_03),
  (`OmegaCellC1P1B2BB4.T_D0_A9_01_SoundTargetedInvalidation, `ExternalSpecPinB4I1R3.Pin_33_T_D0_A9_01),
  (`OmegaCellC1P1B2BB4.T_D0_A9_02_DependencySensitivePreservation, `ExternalSpecPinB4I1R3.Pin_34_T_D0_A9_02),
  (`OmegaCellC1P1B2BB4.T_D0_A9_03_CausalChainSuffixInvalidationPrefixPreservation, `ExternalSpecPinB4I1R3.Pin_35_T_D0_A9_03),
  (`OmegaCellC1P1B2BB4.T_D0_A10_01_DepActiveExactDecomposition, `ExternalSpecPinB4I1R3.Pin_36_T_D0_A10_01),
  (`OmegaCellC1P1B2BB4.T_D0_A10_02_RestrictedSpatioTemporalInterchange, `ExternalSpecPinB4I1R3.Pin_37_T_D0_A10_02),
  (`OmegaCellC1P1B2BB4.T_D0_A10_03_ZeroInteractionUnconditionalInterchange, `ExternalSpecPinB4I1R3.Pin_38_T_D0_A10_03),
  (`OmegaCellC1P1B2BB4.T_D0_A10_04_InteractionPremiseRetractionBreaksNaiveInterchange, `ExternalSpecPinB4I1R3.Pin_39_T_D0_A10_04),
  (`OmegaCellC1P1B2BB4.T_D0_A10_05_CreationVsStandingPathKeyDistinction, `ExternalSpecPinB4I1R3.Pin_40_T_D0_A10_05),
  (`OmegaCellC1P1B2BB4.T_D0_A11_01_B4_MasterConditionalSoundness, `ExternalSpecPinB4I1R3.Pin_41_T_D0_A11_01),
  (`OmegaCellC1P1B2BB4.T_D0_A11_02_NonVacuousMasterSoundnessWitness, `ExternalSpecPinB4I1R3.Pin_42_T_D0_A11_02),
  (`OmegaCellC1P1B2BB4.T_D0_A11_03_DeclarativeSemanticsCheckerDisjoint, `ExternalSpecPinB4I1R3.Pin_43_T_D0_A11_03),
  (`OmegaCellC1P1B2BB4.T_D0_A12_01_UnboundDiagnosticSpoofableContrast, `ExternalSpecPinB4I1R3.Pin_44_T_D0_A12_01),
  (`OmegaCellC1P1B2BB4.T_D0_A12_02_ProvenanceBoundB4ConsumerSoundness, `ExternalSpecPinB4I1R3.Pin_45_T_D0_A12_02),
  (`OmegaCellC1P1B2BB4.T_D0_A14_01_ThreeVerifiedSlotsWithG1Unchecked, `ExternalSpecPinB4I1R3.Pin_46_T_D0_A14_01),
  (`OmegaCellC1P1B2BB4.T_D0_A14_02_FullReflexAdmittedStillEmptyInB4, `ExternalSpecPinB4I1R3.Pin_47_T_D0_A14_02),
  (`OmegaCellC1P1B2BB4.T_D0_A14_03_ZeroGrantEscalationAcrossB4Commits, `ExternalSpecPinB4I1R3.Pin_48_T_D0_A14_03),
  (`OmegaCellC1P1B2BB4.T_D0_R1_01_SpineCommonEpochBinding, `ExternalSpecPinB4I1R3.Pin_49_T_D0_R1_01),
  (`OmegaCellC1P1B2BB4.T_D0_R1_02_ExactSnapshotMismatchRejection, `ExternalSpecPinB4I1R3.Pin_50_T_D0_R1_02),
  (`OmegaCellC1P1B2BB4.T_D0_R1_03_TopologyPreservingCoherentRebindSoundness, `ExternalSpecPinB4I1R3.Pin_51_T_D0_R1_03),
  (`OmegaCellC1P1B2BB4.T_D0_R1_04_CutEquivCongruenceAndEnvIndexing, `ExternalSpecPinB4I1R3.Pin_52_T_D0_R1_04),
  (`OmegaCellC1P1B2BB4.T_D0_R1_05_SubsumedInteractionConditionalSurvival, `ExternalSpecPinB4I1R3.Pin_53_T_D0_R1_05),
  (`OmegaCellC1P1B2BB4.T_D0_R1_06_StandaloneNonChainedRecordIndependence, `ExternalSpecPinB4I1R3.Pin_54_T_D0_R1_06),
  (`OmegaCellC1P1B2BB4.T_D0_R1_07_RetractedLedgerAppendExactUnion, `ExternalSpecPinB4I1R3.Pin_55_T_D0_R1_07),
  (`OmegaCellC1P1B2BB4.T_D0_R1_08_VerifyKitStrictJsonParseContract, `ExternalSpecPinB4I1R3.Pin_56_T_D0_R1_08),
  (`OmegaCellC1P1B2BB4.T_I0_T23_01_ValidBaseInCtxDerivedFromSpine, `ExternalSpecPinB4I1R3.Pin_57_T_I0_T23_01),
  (`OmegaCellC1P1B2BB4.T_I0_T23_02_NonCircularBridgeSemanticAndRuntimeClosure, `ExternalSpecPinB4I1R3.Pin_58_T_I0_T23_02),
  (`OmegaCellC1P1B2BB4.T_I0_T23_03_CoherentRebindConstructsIndexedSpine, `ExternalSpecPinB4I1R3.Pin_59_T_I0_T23_03),
  (`OmegaCellC1P1B2BB4.T_I0_T23_04_PrimEnvVsGuardEnvOrthogonality, `ExternalSpecPinB4I1R3.Pin_60_T_I0_T23_04),
  (`OmegaCellC1P1B2BB4.T_I0_T23_05_MultiRetractionRefutesSinglePremiseGuard, `ExternalSpecPinB4I1R3.Pin_61_T_I0_T23_05),
  (`OmegaCellC1P1B2BB4.T_I0_T23_06_ExactActiveB4JointGuardFactorization, `ExternalSpecPinB4I1R3.Pin_62_T_I0_T23_06),
  (`OmegaCellC1P1B2BB4.T_I0_T23_07_AbstractModelVsRuntimeBoundary, `ExternalSpecPinB4I1R3.Pin_63_T_I0_T23_07)
]

/-! ## Section 2: Independent Layer-2 Declarative Semantics & Biconditional (`Born-T21` Dual Interpretation) -/

/-- Independently authored Layer-2 mathematical semantics for a `B4RawPayload` (`0` references to
    `SemB4PayloadValid` or `SemValidB4Spine` in its definition!). -/
def Layer2_SemB4PayloadValid
    (regId : String) (store : StructuralStore) (L : List StructuralLedgerEvent)
    (epoch : Nat) (_P_env : PrimPremiseEnv) (p : B4RawPayload) : Prop :=
  (p.base.baseId = "base_Q" ∧
   p.base.rflxCid ≠ "" ∧
   g7DomTagToId? p.base.domOld = some p.base.domOldId ∧
   g7DomTagToId? p.base.domNew = some p.base.domNewId ∧
   p.base.pathKey = (match p.base.parentPathKey? with
                     | none     => .root p.base.cellOldCid p.base.obstCid p.base.cellNewCid p.base.rflxCid
                     | some par => .step par p.base.cellOldCid p.base.obstCid p.base.cellNewCid p.base.rflxCid) ∧
   p.base.stepRequiresRetreat = (p.base.reflexKind == .retreat) ∧
   (p.base.stepRequiresRetreat = true → p.base.cumulativeHistRetreat = true)) ∧
  p.base.assignedEvalEpoch = epoch ∧
  p.ast.baseId = p.base.baseId ∧
  p.ast.rflxCid = p.base.rflxCid ∧
  derivePathKey p.ast = p.base.pathKey ∧
  p.ast.parentPathKey? = p.base.parentPathKey? ∧
  p.ast.cellOldCid = p.base.cellOldCid ∧
  p.ast.obstCid = p.base.obstCid ∧
  p.ast.cellNewCid = p.base.cellNewCid ∧
  p.ast.specOldId = p.base.specOldId ∧
  p.ast.specNewId = p.base.specNewId ∧
  p.ast.domOldId = p.base.domOldId ∧
  p.ast.domNewId = p.base.domNewId ∧
  p.ast.reflexKind = p.base.reflexKind ∧
  p.summary2348.historicalRetreat = p.base.cumulativeHistRetreat ∧
  subjectKeyOfB1Summary p.summary2348 = p.base.toSubjectKey ∧
  p.c56.transitionBinding = p.base.toG56Binding ∧
  p.c56.g5Cert.obstCid = p.base.obstCid ∧
  p.c56.g5Cert.goalNew = p.base.postGoal ∧
  p.bundle7.subjectKey = p.base.toSubjectKey ∧
  p.bundle7.claimedDomTag = p.base.domNew ∧
  epoch < p.bundle7.expiresEpoch ∧
  SemStructuralValid regId store L p.ast ∧
  SemValidG56Coupling p.c56 ∧
  (∀ ρ : Env2, inG7Dom p.bundle7.claimedDomTag ρ → ModelsStrictForm p.bundle7.claimedGoal ρ) ∧
  (∀ ρ : Env2, InEffDom p.base.domNew p.base.guardsNew ρ → ModelsStrictForm p.base.postGoal ρ)

theorem T_KitI1_Layer2DualSemanticBiconditional :
    (∀ regId store L epoch Γ pld,
       Layer2_SemB4PayloadValid regId store L epoch Γ pld ↔
       SemB4PayloadValid regId store L epoch Γ pld) ∧
    (∀ (ctx : B4SharedContext) (sp : B4CanonicalSpine ctx),
       Layer2_SemB4PayloadValid ctx.regId ctx.structStore ctx.ledgerSnap ctx.assignedEvalEpoch ctx.primEnv sp.toPayload ↔
       SemValidB4Spine ctx sp) := by
  have hPayload : ∀ regId store L epoch Γ pld,
      Layer2_SemB4PayloadValid regId store L epoch Γ pld ↔
      SemB4PayloadValid regId store L epoch Γ pld := by
    intro regId store L epoch Γ pld
    constructor
    · rintro ⟨hValB, hep, hb, hr, hpk, hpar, hco, hob, hcn, hso, hsn, hdo, hdn, hrk, hhr, hsub1, htb, hob5, hgn5, hsub7, hdom7, hexp7, hStr, hG56, hG7, hPost⟩
      exact {
        alignedPayload := ⟨hValB, hep, hb, hr, hpk, hpar, hco, hob, hcn, hso, hsn, hdo, hdn, hrk, hhr, hsub1, htb, hob5, hgn5, hsub7, hdom7, hexp7⟩
        structuralValid := hStr
        g56CouplingValid := hG56
        g7BundleGoalValid := hG7
        postStateGoalValid := hPost
      }
    · rintro ⟨⟨hValB, hep, hb, hr, hpk, hpar, hco, hob, hcn, hso, hsn, hdo, hdn, hrk, hhr, hsub1, htb, hob5, hgn5, hsub7, hdom7, hexp7⟩, hStr, hG56, hG7, hPost⟩
      exact ⟨hValB, hep, hb, hr, hpk, hpar, hco, hob, hcn, hso, hsn, hdo, hdn, hrk, hhr, hsub1, htb, hob5, hgn5, hsub7, hdom7, hexp7, hStr, hG56, hG7, hPost⟩
  exact ⟨hPayload, fun ctx sp => hPayload _ _ _ _ _ _⟩

/-! ## Section 3: `M_end_to_end` — `10` Isolated Single-Fault Full-Pipeline Mutants (`E2E-B4-01 .. E2E-B4-10`) -/

def pkt_e2e01_envOnly : B4CandidatePacket :=
  let b7' := { bundle7_posB4_01 with primEnvSnapshot := [⟨"p_unused", .domQ, "spec_f05_new", .eqZero (.const 0), []⟩] }
  { pkt_posB4_01 with s7 := ⟨b7', base_posB4_01, .directUnguardedL0⟩ }

def pkt_e2e02_dagOnly : B4CandidatePacket :=
  { pkt_posB4_01 with s7 := ⟨{ bundle7_posB4_01 with dagSnapshot := cont_posB4_05 }, base_posB4_01, .directUnguardedL0⟩ }

def pkt_e2e03_base12Only : B4CandidatePacket :=
  let bAlt := { base_posB4_01 with assignedEvalEpoch := 10, obstCid := "obst_f05_x1" }
  let s1Mis := ⟨ast_posB4_01, sq_posB4_01, { bAlt with postGoal := .eqZero (.const 0) }⟩
  { pkt_posB4_01 with s2348 := s1Mis }

def pkt_e2e04_base23Only : B4CandidatePacket :=
  let b7Mis := { base_posB4_01 with obstCid := "obst_ALT_7" }
  { pkt_posB4_01 with s7 := ⟨bundle7_posB4_01, b7Mis, .directUnguardedL0⟩ }

def evalCleanE2EPipeline (faultId : Nat) (ctx : B4SharedContext) (pkt : B4CandidatePacket) : Bool :=
  let envOk := (faultId == 1) || (pkt.s7.bundle.primEnvSnapshot == ctx.primEnv)
  let dagOk := (faultId == 2) || (pkt.s7.bundle.dagSnapshot == ctx.dagCont)
  let b12Ok := (faultId == 3) || (pkt.s2348.claimedBase == pkt.s56.claimedBase)
  let b23Ok := (faultId == 4) || (pkt.s56.claimedBase == pkt.s7.claimedBase)
  let vbOk  := checkValidB4TransitionBaseBool pkt.s2348.claimedBase
  let s1Ok  := if faultId == 5 then
                 (match checkStructuralReflex ctx.fuelStruct ctx.regId ctx.structStore ctx.ledgerSnap pkt.s2348.ast with
                  | .structuralAccept _ => true | _ => false) &&
                 checkG2348SummaryBool (extractSummary pkt.s2348.sq)
               else
                 checkSlice2348Bool ctx pkt.s2348
  let s2Ok  := if faultId == 6 then
                 isG56CouplingVerifiedBool ctx.toG56Context pkt.s56.c56
               else if faultId == 7 then
                 isG56CouplingVerifiedBool ctx.toG56Context pkt.s56.c56 &&
                 (pkt.s56.c56.transitionBinding == pkt.s56.claimedBase.toG56Binding)
               else
                 checkSlice56Bool ctx pkt.s56
  let s3Ok  := if faultId == 8 then
                 (pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) &&
                 (pkt.s7.bundle.dagSnapshot == ctx.dagCont) &&
                 checkCertifiedG7BundleBool pkt.s7.bundle &&
                 (pkt.s7.bundle.subjectKey == pkt.s7.claimedBase.toSubjectKey) &&
                 decide (ctx.assignedEvalEpoch < pkt.s7.bundle.expiresEpoch)
               else if faultId == 9 then
                 (pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) &&
                 (pkt.s7.bundle.dagSnapshot == ctx.dagCont) &&
                 checkCertifiedG7BundleBool pkt.s7.bundle &&
                 (pkt.s7.bundle.subjectKey == pkt.s7.claimedBase.toSubjectKey) &&
                 checkGoalBridgeModeBool ctx pkt.s7.bundle pkt.s7.claimedBase pkt.s7.bridgeMode
               else if faultId == 1 || faultId == 2 then
                 checkCertifiedG7BundleBool pkt.s7.bundle &&
                 (pkt.s7.bundle.subjectKey == pkt.s7.claimedBase.toSubjectKey) &&
                 decide (ctx.assignedEvalEpoch < pkt.s7.bundle.expiresEpoch) &&
                 checkGoalBridgeModeBool ctx pkt.s7.bundle pkt.s7.claimedBase pkt.s7.bridgeMode
               else
                 checkSlice7Bool ctx pkt.s7
  let depsOk := (faultId == 10) ||
                (pkt.claimedCompositePrimDeps ==
                  deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode)
  envOk && dagOk && b12Ok && b23Ok && vbOk && s1Ok && s2Ok && s3Ok && depsOk

private theorem bool_nine_iff_ite_none (b1 b2 b3 b4 b5 b6 b7 b8 b9 : Bool) :
    (b1 && b2 && b3 && b4 && b5 && b6 && b7 && b8 && b9) =
    (if (!b1 || !b2) then some B4CompositeError.mismatchedSharedEnvOrDag
     else if (!b3 || !b4) then some B4CompositeError.mismatchedTransitionBase
     else if !b5 then some B4CompositeError.invalidTransitionBase
     else if !b6 then some B4CompositeError.invalidSlice2348
     else if !b7 then some B4CompositeError.invalidSlice56
     else if !b8 then some B4CompositeError.invalidSlice7
     else if !b9 then some B4CompositeError.incompleteInteractionPremises
     else none).isNone := by
  cases b1 <;> cases b2 <;> cases b3 <;> cases b4 <;> cases b5 <;>
  cases b6 <;> cases b7 <;> cases b8 <;> cases b9 <;> rfl

theorem T_KitI1_CleanE2EZeroFaultExact (ctx : B4SharedContext) (pkt : B4CandidatePacket) :
    evalCleanE2EPipeline 0 ctx pkt = checkB4CompositeBool ctx pkt := by
  unfold evalCleanE2EPipeline checkB4CompositeBool evalB4CompositeError?
  change
    ((pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) &&
     (pkt.s7.bundle.dagSnapshot == ctx.dagCont) &&
     (pkt.s2348.claimedBase == pkt.s56.claimedBase) &&
     (pkt.s56.claimedBase == pkt.s7.claimedBase) &&
     checkValidB4TransitionBaseBool pkt.s2348.claimedBase &&
     checkSlice2348Bool ctx pkt.s2348 &&
     checkSlice56Bool ctx pkt.s56 &&
     checkSlice7Bool ctx pkt.s7 &&
     (pkt.claimedCompositePrimDeps ==
       deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode)) =
    (if (!(pkt.s7.bundle.primEnvSnapshot == ctx.primEnv) ||
         !(pkt.s7.bundle.dagSnapshot == ctx.dagCont)) then
       some B4CompositeError.mismatchedSharedEnvOrDag
     else if (!(pkt.s2348.claimedBase == pkt.s56.claimedBase) ||
              !(pkt.s56.claimedBase == pkt.s7.claimedBase)) then
       some B4CompositeError.mismatchedTransitionBase
     else if !checkValidB4TransitionBaseBool pkt.s2348.claimedBase then
       some B4CompositeError.invalidTransitionBase
     else if !checkSlice2348Bool ctx pkt.s2348 then
       some B4CompositeError.invalidSlice2348
     else if !checkSlice56Bool ctx pkt.s56 then
       some B4CompositeError.invalidSlice56
     else if !checkSlice7Bool ctx pkt.s7 then
       some B4CompositeError.invalidSlice7
     else if !(pkt.claimedCompositePrimDeps ==
               deriveB4JointPrimDeps ctx.primEnv ctx.dagCont pkt.s56.c56 pkt.s7.bundle pkt.s7.bridgeMode) then
       some B4CompositeError.incompleteInteractionPremises
     else none).isNone
  exact bool_nine_iff_ite_none _ _ _ _ _ _ _ _ _

def pkt_e2e05_dropR2348Align : B4CandidatePacket :=
  -- `ast_posB4_02` (`Retreat`) passes `checkStructuralReflex` while `s56`/`s7` use `base_posB4_01` (`Repair`)!
  { pkt_posB4_01 with s2348 := ⟨ast_posB4_02, sq_posB4_02, base_posB4_01⟩ }

def pkt_e2e06_dropSlice56Bind : B4CandidatePacket :=
  -- `cert_posG56_03` (`Retreat`) passes `isG56CouplingVerifiedBool` (over `ctx_posB4_02`'s container if shared,
  -- or `cert_posG56_04` on `cont_posG56_04`); simplest: `pkt_ce22_epochMismatch56` on `ctx` with epoch 11?
  -- Even simpler: `cert_posG56_01` has `evaluationEpoch = 10`; at `ctx11 := { ctx_posB4_01 with assignedEvalEpoch := 11 }`,
  -- `isG56CouplingVerifiedBool ctx11.toG56Context cert_posG56_01 = true`!
  pkt_ce22_epochMismatch56

def ctx_e2e06_epoch11 : B4SharedContext :=
  { ctx_posB4_01 with assignedEvalEpoch := 11 }

def pkt_e2e07_dropGoalNewEq56 : B4CandidatePacket :=
  -- `transitionBinding` does NOT contain `goalNew`! So changing `base.postGoal` while keeping `bundle7` matching `postGoal`:
  let bWeak := { base_posB4_01 with postGoal := formXSqPlusConstPos 2 }
  let sq1 := sq_posB4_01
  { s2348 := ⟨ast_posB4_01, sq1, bWeak⟩
    s56   := ⟨cert_posB4_05, bWeak⟩
    s7    := ⟨bundle7_posB4_05, bWeak, .directUnguardedL0⟩
    claimedCompositePrimDeps := ["p_br05_imp"] }

def e2e10Targets : List (Nat × String × B4SharedContext × B4CandidatePacket) := [
  (1,  "E2E-B4-01", ctx_posB4_01,      pkt_e2e01_envOnly),
  (2,  "E2E-B4-02", ctx_posB4_01,      pkt_e2e02_dagOnly),
  (3,  "E2E-B4-03", ctx_posB4_01,      pkt_e2e03_base12Only),
  (4,  "E2E-B4-04", ctx_posB4_01,      pkt_e2e04_base23Only),
  (5,  "E2E-B4-05", ctx_posB4_01,      pkt_e2e05_dropR2348Align),
  (6,  "E2E-B4-06", ctx_e2e06_epoch11, pkt_e2e06_dropSlice56Bind),
  (7,  "E2E-B4-07", ctx_posB4_05,      pkt_e2e07_dropGoalNewEq56),
  (8,  "E2E-B4-08", ctx_posB4_05,      pkt_ce03_splitGoal),
  (9,  "E2E-B4-09", ctx_posB4_01,      pkt_ce14_expiredBundle),
  (10, "E2E-B4-10", ctx_posB4_06,      pkt_ce23_omittedBridgePrem)
]

/-- **`T_KitI1_All10EndToEndMutantsPreservePosAndKilled`**:
    Every single one of `E2E-B4-01 .. E2E-B4-10`:
    (1) Preserves positive acceptance (`= true`) on canonical `POS-B4-01`, AND
    (2) Accepts (`= true`) its adversarial target while canonical `checkB4CompositeBool` rejects (`= false`)! -/
theorem T_KitI1_All10EndToEndMutantsPreservePosAndKilled :
    (List.range 10).all (fun k => evalCleanE2EPipeline (k + 1) ctx_posB4_01 pkt_posB4_01) = true ∧
    e2e10Targets.all (fun (fid, _, ctx, pkt) =>
      evalCleanE2EPipeline fid ctx pkt == true &&
      checkB4CompositeBool ctx pkt == false) = true :=
  ⟨by decide, by decide⟩

/-- **`T_KitI1_ProvenanceBoundConsumerBlocksSpoof`**:
    Unbound `projectUnboundB4DiagPassBool spoofedB4DiagObs = true`, whereas provenance-bound
    `consumeBoundB4Verdict` on invalid `pkt_ce01_splitBase` evaluates to `false`! -/
theorem T_KitI1_ProvenanceBoundConsumerBlocksSpoof :
    projectUnboundB4DiagPassBool spoofedB4DiagObs = true ∧
    consumeBoundB4Verdict
      (⟨evalB4Detailed ctx_posB4_01 pkt_ce01_splitBase, rfl⟩ :
        ProvenanceBoundB4Diagnostic ctx_posB4_01 pkt_ce01_splitBase) = false :=
  ⟨rfl, by decide⟩

/-- **`T_KitI1_StaleStateInvalidationSixWay` (`ACT-I1` Gate `A9`)**:
    Mechanically unites all six stale-state invalidation dimensions:
    (1) Stale env/DAG snapshot rejection vs coherent rebind acceptance;
    (2) Tampered active premise rejection under rebind;
    (3) Multi-premise retraction invalidation vs disjoint survival;
    (4) Creation-time bundle epoch expiry & post-commit record epoch expiry;
    (5) Joint standing ledger-snapshot prefix guard invalidation;
    (6) Monotone chain silent scope resurrection rejection. -/
theorem T_KitI1_StaleStateInvalidationSixWay :
    (evalB4CompositeError? ctx_posB4_14_rebound pkt_posB4_06 = some .mismatchedSharedEnvOrDag ∧
     (qualifyB4Composite? ctx_posB4_14_rebound pkt_posB4_14_rebound).isSome = true) ∧
    (checkB4CompositeBool ctx_ce32_tamperedActivePrem pkt_ce32_tamperedActivePrem = false) ∧
    (checkActiveB4RecordBool [.advanceEpoch 10, .retractPremise "p_br_ax"] rec_posB4_06 = false ∧
     checkActiveB4RecordBool [.advanceEpoch 10, .retractPremise "p_br_ax"] rec_posB4_01 = true ∧
     depActiveBool ["prem_r"] (OmegaCellC1P1B2BB4.retractedOfLedger [.retractPremise "prem_p", .retractPremise "prem_r"]) = false) ∧
    (evalB4CompositeError? ctx_posB4_01 pkt_ce14_expiredBundle = some .invalidSlice7 ∧
     checkActiveB4RecordBool [.advanceEpoch 100] rec_posB4_01 = false) ∧
    (jointStandingGuardBool [] { ctx_posB4_01 with ledgerSnap := [.advanceEpoch 5] } base_posB4_01 = false) ∧
    (evalMonotoneChainStepError? posB4_09_st1 { demoStep2RepairAfterRetreatBase with domNew := .domQ, domNewId := "dom_Q" } =
      some .silentScopeResurrectionBlocked) :=
  ⟨⟨by decide, by decide⟩, by decide, ⟨by decide, by decide, by decide⟩, ⟨by decide, by decide⟩, by decide, by decide⟩

/-! ## Section 1B: Compile-Time Kernel Reference Pins for 5 Shared Lower Semantic Anchors (`Article 3` / `F-I1-R0-03`) -/

def AnchorPin_01_SemStructuralValid :
    String → OmegaCellC1P1B1.StructuralStore → List OmegaCellC1P1B1.StructuralLedgerEvent → OmegaCellC1P1B1.StructuralReflexAST → Prop :=
  OmegaCellC1P1B1.SemStructuralValid

def AnchorPin_02_ModelsStrictForm :
    OmegaCellC1P1B2A.StrictForm → OmegaCellC1P1B2A.Env2 → Prop :=
  OmegaCellC1P1B2A.ModelsStrictForm

def AnchorPin_03_inG7Dom :
    OmegaCellC1P1B2A.G7DomTag → OmegaCellC1P1B2A.Env2 → Prop :=
  OmegaCellC1P1B2A.inG7Dom

def AnchorPin_04_InEffDom :
    OmegaCellC1P1B2A.G7DomTag → List OmegaCellC1P1B2A.StrictForm → OmegaCellC1P1B2A.Env2 → Prop :=
  OmegaCellC1P1B2BA0.InEffDom

def AnchorPin_05_SemValidG56Coupling :
    OmegaCellC1P1B2BB3.G56CouplingCert → Prop :=
  OmegaCellC1P1B2BB3.SemValidG56Coupling

def all5SharedAnchorPinPairs : List (Lean.Name × Lean.Name) := [
  (`OmegaCellC1P1B1.SemStructuralValid, `ExternalSpecPinB4I1R3.AnchorPin_01_SemStructuralValid),
  (`OmegaCellC1P1B2A.ModelsStrictForm, `ExternalSpecPinB4I1R3.AnchorPin_02_ModelsStrictForm),
  (`OmegaCellC1P1B2A.inG7Dom, `ExternalSpecPinB4I1R3.AnchorPin_03_inG7Dom),
  (`OmegaCellC1P1B2BA0.InEffDom, `ExternalSpecPinB4I1R3.AnchorPin_04_InEffDom),
  (`OmegaCellC1P1B2BB3.SemValidG56Coupling, `ExternalSpecPinB4I1R3.AnchorPin_05_SemValidG56Coupling)
]

end ExternalSpecPinB4I1R3
