/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B4 — Detached `Born-T21` Independent VerifyKit (`KitB4I1-R3`)
  Executable: ExternalObsB4I1R3.lean

  Implements:
    1. Pure FIPS-180-4 SHA-256 (`sha256HexUtf8`, self-tested against NIST `"abc"` vector at startup)
       for deterministic in-Lean `H_direct(c)` and `H_transitive(c)` computation.
    2. Gate A1 / A5: 63/63 B4 headline `isDefEq` pins, pretty signatures & axiom closures +
       5/5 `KitB4I1-R3` whitebox theorems (`0 sorryAx`, `0 native_decide`, `0` custom axioms).
    3. Gate A6 (`Article 3` / `F-I1-R0-03` / `F-T24-04`): Type-indexed Declaration Provenance 5-Tuple
       `Bind(c) = (N(c), T(c), M(c), H_direct(c), H_transitive(c))` with separate `isDefEq` vs
       pretty-type SHA-256 verification against compile-time `AnchorPin_01 .. AnchorPin_05`.
    4. Rule-based exhaustive classification of all `1,347` B4-owned constants (`|U_rule| = 0`).
    5. Gate A7 (`14` POS + `37` CE subcases), Gate A8 (`12` `M_reg` + `10` `M_e2e` + `EQ-01` + `NC-01`),
       and Gate A9 (`6` Stale State Invalidation probes).
-/
import Lean
import OmegaCellC1P1B2BB4
import ExternalSpecPinB4I1R3

open Lean
open Lean.Meta
open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3
open OmegaCellC1P1B2BB4
open ExternalSpecPinB4I1R3

/-! ## Pure FIPS-180-4 SHA-256 (for Deterministic In-Lean `H_direct` & `H_transitive`) -/

private def sha256K : Array UInt32 := #[
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
]

@[inline] private def rotr32 (x n : UInt32) : UInt32 :=
  (x >>> n) ||| (x <<< (32 - n))

private def hexDigitUpper (n : UInt32) : Char :=
  let v := (n &&& 0xf).toNat
  if v < 10 then Char.ofNat ('0'.toNat + v) else Char.ofNat ('A'.toNat + (v - 10))

private def uint32ToHexUpper (w : UInt32) : String :=
  String.ofList [
    hexDigitUpper (w >>> 28), hexDigitUpper (w >>> 24),
    hexDigitUpper (w >>> 20), hexDigitUpper (w >>> 16),
    hexDigitUpper (w >>> 12), hexDigitUpper (w >>> 8),
    hexDigitUpper (w >>> 4),  hexDigitUpper w
  ]

def sha256BytesUpper (msg : ByteArray) : String := Id.run do
  let bitLen : UInt64 := msg.size.toUInt64 * 8
  let mut padded := msg.push 0x80
  while padded.size % 64 != 56 do
    padded := padded.push 0x00
  for shift in [56, 48, 40, 32, 24, 16, 8, 0] do
    padded := padded.push ((bitLen >>> shift.toUInt64) &&& 0xff).toUInt8

  let mut h0 : UInt32 := 0x6a09e667
  let mut h1 : UInt32 := 0xbb67ae85
  let mut h2 : UInt32 := 0x3c6ef372
  let mut h3 : UInt32 := 0xa54ff53a
  let mut h4 : UInt32 := 0x510e527f
  let mut h5 : UInt32 := 0x9b05688c
  let mut h6 : UInt32 := 0x1f83d9ab
  let mut h7 : UInt32 := 0x5be0cd19

  let numBlocks := padded.size / 64
  for blk in [:numBlocks] do
    let base := blk * 64
    let mut w : Array UInt32 := Array.mkEmpty 64
    for i in [:16] do
      let j := base + i * 4
      let b0 := padded.get! j |>.toUInt32
      let b1 := padded.get! (j + 1) |>.toUInt32
      let b2 := padded.get! (j + 2) |>.toUInt32
      let b3 := padded.get! (j + 3) |>.toUInt32
      w := w.push ((b0 <<< 24) ||| (b1 <<< 16) ||| (b2 <<< 8) ||| b3)
    for i in [16:64] do
      let w15 := w[i - 15]!
      let w2  := w[i - 2]!
      let s0 := rotr32 w15 7 ^^^ rotr32 w15 18 ^^^ (w15 >>> 3)
      let s1 := rotr32 w2 17 ^^^ rotr32 w2 19 ^^^ (w2 >>> 10)
      w := w.push (w[i - 16]! + s0 + w[i - 7]! + s1)

    let mut a := h0; let mut b := h1; let mut c := h2; let mut d := h3
    let mut e := h4; let mut f := h5; let mut g := h6; let mut h := h7
    for i in [:64] do
      let S1 := rotr32 e 6 ^^^ rotr32 e 11 ^^^ rotr32 e 25
      let ch := (e &&& f) ^^^ ((~~~e) &&& g)
      let temp1 := h + S1 + ch + sha256K[i]! + w[i]!
      let S0 := rotr32 a 2 ^^^ rotr32 a 13 ^^^ rotr32 a 22
      let maj := (a &&& b) ^^^ (a &&& c) ^^^ (b &&& c)
      let temp2 := S0 + maj
      h := g; g := f; f := e; e := d + temp1
      d := c; c := b; b := a; a := temp1 + temp2

    h0 := h0 + a; h1 := h1 + b; h2 := h2 + c; h3 := h3 + d
    h4 := h4 + e; h5 := h5 + f; h6 := h6 + g; h7 := h7 + h

  return uint32ToHexUpper h0 ++ uint32ToHexUpper h1 ++ uint32ToHexUpper h2 ++ uint32ToHexUpper h3 ++
         uint32ToHexUpper h4 ++ uint32ToHexUpper h5 ++ uint32ToHexUpper h6 ++ uint32ToHexUpper h7

def sha256HexUtf8 (s : String) : String :=
  sha256BytesUpper s.toUTF8

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def b4Modules7 : List Name := [
  `OmegaCellC1P1B2BB4.B4_01_TypesBaseAndValidSlices,
  `OmegaCellC1P1B2BB4.B4_02_SpineCoherenceAndReification,
  `OmegaCellC1P1B2BB4.B4_03_JointClosureAndCoherentRebind,
  `OmegaCellC1P1B2BB4.B4_04_HistoricalRetreatAlgebra,
  `OmegaCellC1P1B2BB4.B4_05_RetractionInterchangeAndMaster,
  `OmegaCellC1P1B2BB4.B4_06_WitnessesCounterexamplesAndMutants,
  `OmegaCellC1P1B2BB4
]

def kitTheorems5 : List Name := [
  `ExternalSpecPinB4I1R3.T_KitI1_Layer2DualSemanticBiconditional,
  `ExternalSpecPinB4I1R3.T_KitI1_CleanE2EZeroFaultExact,
  `ExternalSpecPinB4I1R3.T_KitI1_All10EndToEndMutantsPreservePosAndKilled,
  `ExternalSpecPinB4I1R3.T_KitI1_ProvenanceBoundConsumerBlocksSpoof,
  `ExternalSpecPinB4I1R3.T_KitI1_StaleStateInvalidationSixWay
]

def b4CoreSemanticAnchors12 : List Name := [
  `OmegaCellC1P1B2BB4.ValidB4TransitionBase,
  `OmegaCellC1P1B2BB4.ValidB4TransitionBaseInCtx,
  `OmegaCellC1P1B2BB4.SemB4PayloadAligned,
  `OmegaCellC1P1B2BB4.SemB4PayloadValid,
  `OmegaCellC1P1B2BB4.IsReferencedB4BridgeNodeId,
  `OmegaCellC1P1B2BB4.InductiveUsedBridgeNode,
  `OmegaCellC1P1B2BB4.InductiveUsedBridgePrim,
  `OmegaCellC1P1B2BB4.InB4EffDom,
  `OmegaCellC1P1B2BB4.CutPairEquivInEnv,
  `OmegaCellC1P1B2BB4.ValidInitialB4ChainState,
  `OmegaCellC1P1B2BB4.StepDomainAccountingWitness,
  `OmegaCellC1P1B2BB4.ValidB4MonotoneChain
]

def allExecutableCheckers : List Name := [
  `OmegaCellC1P1B1.checkStructuralReflex,
  `OmegaCellC1P1B1.checkG3Matrix,
  `OmegaCellC1P1B1.reifyTransportCode,
  `OmegaCellC1P1B2A.evalPartExprFuel,
  `OmegaCellC1P1B2A.evalStrictFormFuel,
  `OmegaCellC1P1B2A.checkAlgDomCertBool,
  `OmegaCellC1P1B2A.verifyReachableDerivation,
  `OmegaCellC1P1B2A.checkCertifiedG7BundleBool,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced,
  `OmegaCellC1P1B2BB1.checkG5DischargeBool,
  `OmegaCellC1P1B2BB2.checkG6Suite,
  `OmegaCellC1P1B2BB2.isG6SuiteVerifiedBool,
  `OmegaCellC1P1B2BB3.checkG56Coupling,
  `OmegaCellC1P1B2BB3.isG56CouplingVerifiedBool,
  `OmegaCellC1P1B2BB3.qualifyG56Coupled?,
  `OmegaCellC1P1B2BB4.checkValidB4TransitionBaseBool,
  `OmegaCellC1P1B2BB4.checkR2348AlignBool,
  `OmegaCellC1P1B2BB4.checkSlice2348Bool,
  `OmegaCellC1P1B2BB4.checkSlice56Bool,
  `OmegaCellC1P1B2BB4.checkGoalBridgeModeBool,
  `OmegaCellC1P1B2BB4.checkSlice7Bool,
  `OmegaCellC1P1B2BB4.evalB4CompositeError?,
  `OmegaCellC1P1B2BB4.checkB4CompositeBool,
  `OmegaCellC1P1B2BB4.evalB4Detailed,
  `OmegaCellC1P1B2BB4.qualifyB4Composite?,
  `OmegaCellC1P1B2BB4.checkStepComposableBool,
  `OmegaCellC1P1B2BB4.checkMonotoneChainStepBool,
  `OmegaCellC1P1B2BB4.checkActiveB4SpineBool,
  `OmegaCellC1P1B2BB4.checkActiveB4RecordBool
]

def hasSubstr (s sub : String) : Bool :=
  (s.splitOn sub).length > 1

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def sortUniqueStrs (xs : List String) : List String :=
  (xs.mergeSort (· < ·)).eraseDups

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

partial def stripForalls : Expr → Expr
  | .forallE _ _ body _ => stripForalls body
  | .mdata _ e          => stripForalls e
  | e                   => e

def isPropReturningType (t : Expr) : Bool :=
  match stripForalls t with
  | .sort .zero => true
  | _           => false

def isTypeReturningDef (t : Expr) : Bool :=
  match stripForalls t with
  | .sort (.succ _) => true
  | .sort (.param _) => true
  | .sort (.max _ _) => true
  | .sort (.imax _ _) => true
  | _ => false

def isCompilerOrElabAuxName (c : Name) : Bool :=
  let s := c.toString
  isPrivateName c ||
  hasSubstr s "._cstage" || hasSubstr s "._eq_" || hasSubstr s "._sunfold" ||
  hasSubstr s ".match_" || hasSubstr s "._proof_" || hasSubstr s "._simp_" ||
  hasSubstr s "._unsafe_rec" || hasSubstr s "._sparseCasesOn_" || hasSubstr s "._sizeOf_inst" ||
  hasSubstr s "._flat_ctor" || hasSubstr s ".instDecidableEq" || hasSubstr s ".instRepr" ||
  s.endsWith "._f" || s.endsWith ".ctorElim" || s.endsWith ".ctorElimType" ||
  s.endsWith ".elim" || s.endsWith ".ofNat" ||
  s.endsWith ".rec" || s.endsWith ".recOn" || s.endsWith ".casesOn" ||
  s.endsWith ".brecOn" || s.endsWith ".below" || s.endsWith ".ibelow" ||
  s.endsWith ".noConfusion" || s.endsWith ".noConfusionType" ||
  s.endsWith ".inj" || s.endsWith ".injEq" || s.endsWith ".sizeOf_spec" ||
  s.endsWith ".ctorIdx" || s.endsWith ".toCtorIdx"

def isWitnessOrContrastFixtureName (c : Name) : Bool :=
  let s := c.toString
  hasSubstr s ".posB4_" || hasSubstr s "_posB4_" || hasSubstr s ".ce" || hasSubstr s "_ce" ||
  hasSubstr s ".mut" || hasSubstr s ".eqMut" || hasSubstr s ".demoStep" ||
  hasSubstr s ".forgedRawG2348Summary" || hasSubstr s ".spoofedB4DiagObs" ||
  hasSubstr s ".t_nonSurjValidBase" || hasSubstr s ".b4Witness" || hasSubstr s ".guardAlwaysPos" ||
  hasSubstr s ".formG1aImpGoal"

def isStructCtorPrivate (env : Environment) (indName : Name) : Bool :=
  match env.find? indName with
  | some (.inductInfo v) => (!v.ctors.isEmpty) && v.ctors.all isPrivateName
  | _ => false

def checkPinAndPrettyType (env : Environment) (origName pinName : Name) :
    IO (Bool × String) := do
  match env.find? origName, env.find? pinName with
  | some ciOrig, some ciPin =>
      let ctxCore : Core.Context := { fileName := "<KitB4I1R3>", fileMap := default }
      let stCore  : Core.State   := { env := env }
      let act : MetaM (Bool × String) := do
        let eqOk ← isDefEq ciOrig.type ciPin.type
        let fmt ← ppExpr ciOrig.type
        let flat := String.intercalate " " ((fmt.pretty.splitOn "\n").map (fun s => s.trimAscii.toString) |>.filter (· != ""))
        return (eqOk, flat)
      let ((res, _), _) ← (act.run {}).toIO ctxCore stCore
      return res
  | _, _ => return (false, "<MISSING_CONSTANT>")

def inspectSharedAnchorBind5 (env : Environment) (coneLayer2 coneWorkerSem : Std.HashSet Name)
    (origName pinName : Name) : IO (Bool × Json) := do
  match env.find? origName, env.find? pinName with
  | some _ciOrig, some ciPin =>
      let modName := match env.getModuleIdxFor? origName with
        | some midx => (env.header.moduleNames[midx.toNat]!).toString
        | none      => "<UNKNOWN_MODULE>"
      let pinRefsOrig := match ciPin with
        | .defnInfo vp => vp.value.getUsedConstants.contains origName
        | _            => false
      let (defEqOk, ppType) ← checkPinAndPrettyType env origName pinName
      let ppSha := sha256HexUtf8 ppType
      let dList := sortUniqueStrs ((directDeps env origName).toList.map Name.toString)
      let tList := sortUniqueStrs ((transitiveCone env [origName]).toList.map Name.toString)
      let hDirect := sha256HexUtf8 (String.intercalate "\n" dList)
      let hTrans  := sha256HexUtf8 (String.intercalate "\n" tList)
      let inBothCones := coneLayer2.contains origName && coneWorkerSem.contains origName
      let rowOk := defEqOk && pinRefsOrig && inBothCones && (modName != "<UNKNOWN_MODULE>")
      let j := Json.mkObj [
        ("canonicalName", Json.str origName.toString),
        ("anchorPinName", Json.str pinName.toString),
        ("existsInEnvironment", Json.bool true),
        ("definingModule", Json.str modName),
        ("kernelIsDefEqAnchorPinVerified", Json.bool (defEqOk && pinRefsOrig)),
        ("kernelPrettyType", Json.str ppType),
        ("kernelPrettyTypeSha256", Json.str ppSha),
        ("directDepCount", Json.num dList.length),
        ("directDepSetSha256_H_direct", Json.str hDirect),
        ("transitiveConeCount", Json.num tList.length),
        ("transitiveDepConeSha256_H_transitive", Json.str hTrans),
        ("presentInBothLayer2AndWorkerCones", Json.bool inBothCones)
      ]
      return (rowOk, j)
  | _, _ =>
      let j := Json.mkObj [
        ("canonicalName", Json.str origName.toString),
        ("anchorPinName", Json.str pinName.toString),
        ("existsInEnvironment", Json.bool false),
        ("definingModule", Json.str "<MISSING>"),
        ("kernelIsDefEqAnchorPinVerified", Json.bool false),
        ("kernelPrettyType", Json.str "<MISSING_CONSTANT>"),
        ("kernelPrettyTypeSha256", Json.str ""),
        ("directDepCount", Json.num 0),
        ("directDepSetSha256_H_direct", Json.str ""),
        ("transitiveConeCount", Json.num 0),
        ("transitiveDepConeSha256_H_transitive", Json.str ""),
        ("presentInBothLayer2AndWorkerCones", Json.bool false)
      ]
      return (false, j)

structure CliOpts where
  replayId       : String := "RL1_R3"
  hSourcesSha    : String := ""
  t24OracleSha   : String := ""
  r0FailedOrcSha : String := ""
  oracleSha      : String := ""
  oracleMatch    : Bool   := true
  outPath        : String := "b4_i1_r3_live_observation.json"

def parseArgs : List String → CliOpts → CliOpts
  | "--replay-id" :: v :: rest, o         => parseArgs rest { o with replayId := v }
  | "--h-sources-sha" :: v :: rest, o     => parseArgs rest { o with hSourcesSha := v }
  | "--t24-oracle-sha" :: v :: rest, o    => parseArgs rest { o with t24OracleSha := v }
  | "--r0-failed-orc-sha" :: v :: rest, o => parseArgs rest { o with r0FailedOrcSha := v }
  | "--oracle-sha" :: v :: rest, o        => parseArgs rest { o with oracleSha := v }
  | "--oracle-match" :: v :: rest, o      => parseArgs rest { o with oracleMatch := (v == "true") }
  | "--out-json" :: v :: rest, o          => parseArgs rest { o with outPath := v }
  | _ :: rest, o                          => parseArgs rest o
  | [], o                                 => o

def main (args : List String) : IO UInt32 := do
  let opts := parseArgs args {}

  -- FIPS-180-4 SHA-256 self-test against NIST vectors ("abc" & "")
  let shaSelfTestOk :=
    (sha256HexUtf8 "abc" == "BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD") &&
    (sha256HexUtf8 "" == "E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855")

  initSearchPath (← findSysroot)
  let rawEnv ← importModules #[
    { module := `OmegaCellC1P1B2BB4, importAll := true },
    { module := `ExternalSpecPinB4I1R3, importAll := true }
  ] {}
  let env := rawEnv.setExporting false
  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]

  -- 1. Gate A1 / A5: Verify all 63 B4 headline theorem `isDefEq` pins, pretty signatures & axiom closures
  let mut pinFailures : List String := []
  let mut badAxiomRefs : List String := []
  let mut sorryRefs : List String := []
  let mut nativeDecideRefs : List String := []
  let mut pinClosureRows : Array Json := #[]

  for (origThm, pinThm) in all63PinnedTheoremPairs do
    let (defEqOk, ppSig) ← checkPinAndPrettyType env origThm pinThm
    if !defEqOk then
      pinFailures := s!"{origThm} != {pinThm}" :: pinFailures
    let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) origThm) env
    let axStrs := (axs.toList.map Name.toString).mergeSort (· < ·)
    for a in axs do
      if a == `sorryAx then sorryRefs := origThm.toString :: sorryRefs
      if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
        nativeDecideRefs := s!"{origThm}->{a}" :: nativeDecideRefs
      if !allowedAx.contains a then
        badAxiomRefs := s!"{origThm}->{a}" :: badAxiomRefs
    let isThm := match env.find? origThm with | some (.thmInfo _) => true | _ => false
    if !isThm then pinFailures := s!"NOT_THM:{origThm}" :: pinFailures
    pinClosureRows := pinClosureRows.push (Json.mkObj [
      ("theoremName", Json.str origThm.toString),
      ("pinTheoremName", Json.str pinThm.toString),
      ("kernelIsDefEqVerified", Json.bool defEqOk),
      ("isTheoremInfo", Json.bool isThm),
      ("kernelPrettySignature", Json.str ppSig),
      ("transitiveAxioms", toJsonStrArr axStrs)
    ])

  -- Verify 5 KitB4I1R1 whitebox theorems
  let mut kitClosureRows : Array Json := #[]
  for kth in kitTheorems5 do
    let isKThm := match env.find? kth with | some (.thmInfo _) => true | _ => false
    if !isKThm then pinFailures := s!"NOT_KIT_THM:{kth}" :: pinFailures
    let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) kth) env
    let kAxStrs := (axs.toList.map Name.toString).mergeSort (· < ·)
    for a in axs do
      if a == `sorryAx then sorryRefs := kth.toString :: sorryRefs
      if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
        nativeDecideRefs := s!"{kth}->{a}" :: nativeDecideRefs
      if !allowedAx.contains a then
        badAxiomRefs := s!"{kth}->{a}" :: badAxiomRefs
    kitClosureRows := kitClosureRows.push (Json.mkObj [
      ("theoremName", Json.str kth.toString),
      ("isTheoremInfo", Json.bool isKThm),
      ("transitiveAxioms", toJsonStrArr kAxStrs)
    ])

  -- 2. Gate A6 (`Article 3` / `F-I1-R0-03` / `F-T24-04`): Layer-2 DAG + 5-Tuple `Bind(c)` Provenance
  let (layer2DisjointTopOk, layer2DirectConsts) :=
    match env.find? `ExternalSpecPinB4I1R3.Layer2_SemB4PayloadValid with
    | some (.defnInfo v) =>
        let used := v.value.getUsedConstants
        let disjOk :=
          !(used.contains `OmegaCellC1P1B2BB4.SemB4PayloadValid) &&
          !(used.contains `OmegaCellC1P1B2BB4.SemValidB4Spine) &&
          !(used.contains `OmegaCellC1P1B2BB4.SemB4PayloadAligned)
        let sortedUsed := sortUniqueStrs (used.toList.map Name.toString)
        (disjOk, sortedUsed)
    | _ => (false, [])

  let coneLayer2 := transitiveCone env [`ExternalSpecPinB4I1R3.Layer2_SemB4PayloadValid]
  let coneWorkerSem := transitiveCone env [`OmegaCellC1P1B2BB4.SemB4PayloadValid]
  let mut layer2CheckerHits : List String := []
  for k in allExecutableCheckers do
    if coneLayer2.contains k then
      layer2CheckerHits := k.toString :: layer2CheckerHits

  let mut sharedConeCount : Nat := 0
  for c in coneLayer2.toList do
    if coneWorkerSem.contains c then
      sharedConeCount := sharedConeCount + 1

  let mut anchorBindRows : Array Json := #[]
  let mut allAnchorsBoundOk : Bool := true
  for (origAnc, pinAnc) in all5SharedAnchorPinPairs do
    let (ancOk, ancJson) ← inspectSharedAnchorBind5 env coneLayer2 coneWorkerSem origAnc pinAnc
    if !ancOk then allAnchorsBoundOk := false
    anchorBindRows := anchorBindRows.push ancJson

  let r0MisboundAbsentOk := (env.find? `OmegaCellC1P1B2BB1.InEffDom).isNone

  -- 3. Rule-Based Exhaustive Constant Partition across all 7 B4 modules (`|U_rule| = 0`)
  let mut totalB4Owned : Nat := 0
  let mut cntS : Nat := 0
  let mut cntK : Nat := 0
  let mut cntD : Nat := 0
  let mut cntT : Nat := 0
  let mut cntF : Nat := 0
  let mut cntA : Nat := 0
  let mut unclassified : List String := []

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if b4Modules7.contains m then
      let md := env.header.moduleData[i]!
      totalB4Owned := totalB4Owned + md.constNames.size
      for c in md.constNames do
        if isCompilerOrElabAuxName c then
          cntA := cntA + 1
        else
          match env.find? c with
          | none => unclassified := s!"MISSING:{c}" :: unclassified
          | some (.thmInfo _) => cntT := cntT + 1
          | some (.ctorInfo _) => cntD := cntD + 1
          | some (.inductInfo ci) =>
              if isPropReturningType ci.type then cntS := cntS + 1 else cntD := cntD + 1
          | some (.defnInfo v) =>
              if isWitnessOrContrastFixtureName c then
                cntF := cntF + 1
              else if isPropReturningType v.type then
                cntS := cntS + 1
              else if isTypeReturningDef v.type then
                cntD := cntD + 1
              else
                cntK := cntK + 1
          | some _ => unclassified := c.toString :: unclassified

  -- 4. Anti-circularity check on core semantic anchors
  let semCone := transitiveCone env b4CoreSemanticAnchors12
  let mut semCircHits : List String := []
  for k in allExecutableCheckers do
    if semCone.contains k then
      semCircHits := k.toString :: semCircHits

  -- 5. Gate A7 (Soundness), A8 (Mutation), and A9 (Stale State Invalidation)
  let s2_launder : B4TemporalStep := ⟨{ demoStep2RepairAfterRetreatBase with cumulativeHistRetreat := false }, botCanonCutPair, [], rfl⟩
  let s2_badBase : B4TemporalStep := ⟨{ demoStep2RepairAfterRetreatBase with baseId := "base_R_unauth" }, botCanonCutPair, [], rfl⟩
  let s2_badEpoch : B4TemporalStep := ⟨{ demoStep2RepairAfterRetreatBase with assignedEvalEpoch := 10 }, botCanonCutPair, [], rfl⟩
  let s2_badPar : B4TemporalStep := ⟨{ demoStep2RepairAfterRetreatBase with parentPathKey? := none }, botCanonCutPair, [], rfl⟩
  let stepRes : B4CommonTransitionBase := { demoStep2RepairAfterRetreatBase with domNew := .domQ, domNewId := "dom_Q" }
  let L_ce12a : List StructuralLedgerEvent := [.advanceEpoch 10, .retractPremise "p_br_ax"]
  let L_ce12b : List StructuralLedgerEvent := [.recordStructuralReflex (committedEntryOfSpine sp_posB4_01)]
  let ΔL_two : List StructuralLedgerEvent := [.retractPremise "prem_p", .retractPremise "prem_r"]
  let ctx_ce35 := { ctx_posB4_01 with ledgerSnap := [.advanceEpoch 5] }
  let sq_ce35 := extractSqOrFallback 6 "reg_Q_v1" b4WitnessStore [.advanceEpoch 5] ast_posB4_01 (by decide)
  let pkt_ce35 : B4CandidatePacket := { pkt_posB4_01 with s2348 := ⟨ast_posB4_01, sq_ce35, base_posB4_01⟩ }
  let sp_ce35 := spineOfVerifiedPacket ctx_ce35 pkt_ce35 (by decide)

  let posPairs : List (String × Bool) := [
    ("POS-B4-01", (qualifyB4Composite? ctx_posB4_01 pkt_posB4_01).isSome),
    ("POS-B4-02", (qualifyB4Composite? ctx_posB4_02 pkt_posB4_02).isSome),
    ("POS-B4-03", (qualifyB4Composite? ctx_posB4_03 pkt_posB4_03).isSome),
    ("POS-B4-04", (qualifyB4Composite? ctx_posB4_04_g1a pkt_posB4_04_g1a).isSome),
    ("POS-B4-05", (qualifyB4Composite? ctx_posB4_05 pkt_posB4_05).isSome),
    ("POS-B4-06", (qualifyB4Composite? ctx_posB4_06 pkt_posB4_06).isSome &&
                  deriveSpineB4PrimDeps ctx_posB4_06 sp_posB4_06 == ["p_br_ax", "p_g5_ax", "p_g6_ax", "p_g7_ax"]),
    ("POS-B4-07", checkStepComposableBool posB4_08_s1 posB4_08_s2),
    ("POS-B4-08", appendStepToComposite (appendStepToComposite (stepToComposite posB4_08_s1) posB4_08_s2) posB4_08_s3 ==
                  prependStepToComposite posB4_08_s1 (appendStepToComposite (stepToComposite posB4_08_s2) posB4_08_s3)),
    ("POS-B4-09", posB4_09_st2.E_historical.length == 1 && posB4_09_st2.E_currentlyExcluded == [[.eqZero .varX]]),
    ("POS-B4-10", !checkActiveB4RecordBool L_ce12a rec_posB4_06 && checkActiveB4RecordBool L_ce12a rec_posB4_01),
    ("POS-B4-11", checkActiveB4RecordBool [.advanceEpoch 10] rec_posB4_06 &&
                  activeSlice2348Bool [.advanceEpoch 10] sp_posB4_06.slice2348 &&
                  activeSlice56Bool [.advanceEpoch 10] sp_posB4_06.slice56 &&
                  activeSlice7Bool [.advanceEpoch 10] sp_posB4_06.slice7),
    ("POS-B4-12", checkActiveB4RecordBool [] rec_posB4_01),
    ("POS-B4-13", consumeBoundB4Verdict (⟨evalB4Detailed ctx_posB4_01 pkt_posB4_01, rfl⟩ : ProvenanceBoundB4Diagnostic ctx_posB4_01 pkt_posB4_01)),
    ("POS-B4-14", (qualifyB4Composite? ctx_posB4_14_rebound pkt_posB4_14_rebound).isSome)
  ]

  let cePairs : List (String × Bool) := [
    ("CE-B4-01", evalB4CompositeError? ctx_posB4_01 pkt_ce01_splitBase == some .mismatchedTransitionBase),
    ("CE-B4-02", evalB4CompositeError? ctx_posB4_01 pkt_ce02_splitEnv == some .mismatchedSharedEnvOrDag),
    ("CE-B4-03", evalB4CompositeError? ctx_posB4_05 pkt_ce03_splitGoal == some .invalidSlice7),
    ("CE-B4-04", ("note_A" != "note_B")),
    ("CE-B4-05", evalB4CompositeError? ctx_posB4_06 pkt_ce05_spoofedEmptyDeps == some .incompleteInteractionPremises),
    ("CE-B4-06", evalB4CompositeError? ctx_posB4_01 pkt_ce06_splitDag == some .mismatchedSharedEnvOrDag),
    ("CE-B4-07", evalMonotoneChainStepError? posB4_09_st1 stepRes == some .silentScopeResurrectionBlocked),
    ("CE-B4-08", !checkStepComposableBool posB4_08_s1 s2_badBase),
    ("CE-B4-09", !checkStepComposableBool posB4_08_s1 s2_badEpoch),
    ("CE-B4-10", !checkStepComposableBool posB4_08_s1 s2_badPar),
    ("CE-B4-11", !checkStepComposableBool posB4_08_s1 s2_launder),
    ("CE-B4-12A", activeSlice2348Bool L_ce12a sp_posB4_06.slice2348 &&
                  activeSlice56Bool L_ce12a sp_posB4_06.slice56 &&
                  activeSlice7Bool L_ce12a sp_posB4_06.slice7 &&
                  !checkActiveB4RecordBool L_ce12a rec_posB4_06),
    ("CE-B4-12B", !checkSlice2348Bool { ctx_posB4_01 with ledgerSnap := L_ce12b } sp_posB4_01.slice2348.1.1 &&
                  checkActiveB4SpineBool L_ce12b ctx_posB4_01 sp_posB4_01),
    ("CE-B4-13", projectUnboundB4DiagPassBool spoofedB4DiagObs &&
                 !checkB4CompositeBool ctx_posB4_01 pkt_ce01_splitBase),
    ("CE-B4-14", evalB4CompositeError? ctx_posB4_01 pkt_ce14_expiredBundle == some .invalidSlice7),
    ("CE-B4-15", !rec_posB4_01.officialRegistryAuth &&
                 (foldStructuralLedger L_ce12b).grantLedger.isEmpty),
    ("CE-B4-16", checkCertifiedG7BundleBool bundle_ce16_domQ2 && !isV1SupportedDomTagBool .domQ2),
    ("CE-B4-17", deriveSpineB4PrimDeps ctx_posB4_01 sp_posB4_01 == deriveSpineB4PrimDeps ctx_posB4_01 sp_posB4_01_alt &&
                 sp_posB4_01.c56.couplingCid != sp_posB4_01_alt.c56.couplingCid),
    ("CE-B4-18", posB4_09_st1.E_historical.length == 1 && posB4_09_st2.E_historical.length == 1),
    ("CE-B4-19", checkG2348SummaryBool forgedRawG2348Summary && forgedRawG2348Summary.baseId == "base_BOGUS_FORGED"),
    ("CE-B4-20", !checkValidB4TransitionBaseBool base_ce_invalidBase),
    ("CE-B4-21", checkValidB4TransitionBaseBool t_nonSurjValidBase.1 && t_nonSurjValidBase.1.cellOldCid == ""),
    ("CE-B4-22", evalB4CompositeError? ctx_posB4_01 pkt_ce22_epochMismatch56 == some .invalidSlice56),
    ("CE-B4-23", evalB4CompositeError? ctx_posB4_06 pkt_ce23_omittedBridgePrem == some .incompleteInteractionPremises),
    ("CE-B4-24", evalB4CompositeError? ctx_posB4_14_rebound pkt_posB4_06 == some .mismatchedSharedEnvOrDag),
    ("CE-B4-25", !checkMonotoneChainStepBool
                    { posB4_09_st1 with E_currentlyExcluded := [[.eqZero .varX]], currentDom := ⟨.domQ, [.neqZero .varX]⟩ }
                    { demoStep2RepairAfterRetreatBase with reflexKind := .refinement, domNew := .domQ, guardsNew := [] }),
    ("CE-B4-26", !checkActiveB4RecordBool [.advanceEpoch 100] rec_posB4_01),
    ("CE-B4-27", !checkActiveB4RecordBool L_ce12a rec_posB4_06 && checkActiveB4RecordBool L_ce12a rec_posB4_01),
    ("CE-B4-28", depActiveBool ["prem_5"] ["prem_bridge_only"] &&
                 depActiveBool ["prem_7"] ["prem_bridge_only"] &&
                 !depActiveBool ["prem_bridge_only"] ["prem_bridge_only"]),
    ("CE-B4-29", (parseJsonPairsStrict ce29_dupVerdictJson).isNone &&
                 lookupJsonLastWins? ce29_dupVerdictJson "verdict" == some "FORGED_PASS"),
    ("CE-B4-30", checkValidB4TransitionBaseBool t_nonSurjValidBase.1 && t_nonSurjValidBase.1.assignedEvalEpoch != 99),
    ("CE-B4-31", !decide (ValidContainer ce31_malformedRankZeroCont) &&
                 !(multiRootReachableNodes ce31_malformedRankZeroCont ["b_root"]).contains "b_deep"),
    ("CE-B4-32", !checkB4CompositeBool ctx_ce32_tamperedActivePrem pkt_ce32_tamperedActivePrem),
    ("CE-B4-33", evalStrictFormFuel 4 (.pos .varX) (0, 0) == .satDefinedFalse),
    ("CE-B4-34", !(["prem_r"] : List String).contains "prem_p" &&
                 !depActiveBool ["prem_r"] (OmegaCellC1P1B2BB4.retractedOfLedger ΔL_two)),
    ("CE-B4-35", activeSlice2348Bool [] sp_ce35.slice2348 &&
                 activeSlice56Bool [] sp_ce35.slice56 &&
                 activeSlice7Bool [] sp_ce35.slice7 &&
                 !jointStandingGuardBool [] ctx_ce35 sp_ce35.base.1 &&
                 !checkActiveB4SpineBool [] ctx_ce35 sp_ce35),
    ("CE-B4-36", (parseJsonPairsStrict [("verdict", "REJECT"), ("verdict_raw_escape", "PASS")]).isSome &&
                 (parseJsonPairsStrict [("verdict", "REJECT"), ("verdict", "PASS")]).isNone)
  ]

  let regMutPairs : List (String × Bool) := [
    ("MUT-B4-01", mut01_dropPrimEnvSnap ctx_posB4_01 pkt_ce02_splitEnv != checkB4CompositeBool ctx_posB4_01 pkt_ce02_splitEnv),
    ("MUT-B4-02", mut02_dropDagSnap ctx_posB4_01 pkt_ce06_splitDag != checkB4CompositeBool ctx_posB4_01 pkt_ce06_splitDag),
    ("MUT-B4-03", mut03_dropBase12Eq ctx_posB4_01 pkt_ce01_splitBase != checkB4CompositeBool ctx_posB4_01 pkt_ce01_splitBase),
    ("MUT-B4-04", mut04_dropValidBase ctx_posB4_01 pkt_ce_invalidBase != checkB4CompositeBool ctx_posB4_01 pkt_ce_invalidBase),
    ("MUT-B4-05", mut05_dropGoalBridge ctx_posB4_05 pkt_ce03_splitGoal != checkB4CompositeBool ctx_posB4_05 pkt_ce03_splitGoal),
    ("MUT-B4-06", mut06_dropBundleExpiry ctx_posB4_01 pkt_ce14_expiredBundle != checkB4CompositeBool ctx_posB4_01 pkt_ce14_expiredBundle),
    ("MUT-B4-07", mut07_omitInteractionDeps ctx_posB4_06 pkt_ce23_omittedBridgePrem != checkB4CompositeBool ctx_posB4_06 pkt_ce23_omittedBridgePrem),
    ("MUT-B4-08", mut08_dropClaimedDepsEq ctx_posB4_06 pkt_ce05_spoofedEmptyDeps != checkB4CompositeBool ctx_posB4_06 pkt_ce05_spoofedEmptyDeps),
    ("MUT-B4-09", mut09_dropCumulativeRetreatProp posB4_08_s1 s2_launder != checkStepComposableBool posB4_08_s1 s2_launder),
    ("MUT-B4-10", mut10_dropSilentResurrectionBlock posB4_09_st1 stepRes != checkMonotoneChainStepBool posB4_09_st1 stepRes),
    ("MUT-B4-11", mut11_dropJointStandingGuard [] ctx_ce35 sp_ce35 != checkActiveB4SpineBool [] ctx_ce35 sp_ce35),
    ("MUT-B4-12", (mut12_allowDupJsonKeys ce29_dupVerdictJson).isSome != (parseJsonPairsStrict ce29_dupVerdictJson).isSome)
  ]

  let e2eMutRows : Array Json := (e2e10Targets.map (fun (fid, mid, ctx, pkt) =>
    let posOk := evalCleanE2EPipeline fid ctx_posB4_01 pkt_posB4_01
    let mutAcc := evalCleanE2EPipeline fid ctx pkt
    let canAcc := checkB4CompositeBool ctx pkt
    Json.mkObj [
      ("mutantId", Json.str mid),
      ("faultId", Json.num fid),
      ("preservesPosB4_01", Json.bool posOk),
      ("mutantAcceptedTarget", Json.bool mutAcc),
      ("canonicalAcceptedTarget", Json.bool canAcc),
      ("killed", Json.bool (posOk && mutAcc && !canAcc))
    ])).toArray

  let e2eAllKilled := e2e10Targets.all (fun (fid, _, ctx, pkt) =>
    evalCleanE2EPipeline fid ctx_posB4_01 pkt_posB4_01 &&
    evalCleanE2EPipeline fid ctx pkt &&
    !checkB4CompositeBool ctx pkt)

  let stalePairs : List (String × Bool) := [
    ("STALE-I1-01-SNAPSHOT-REBIND",
      evalB4CompositeError? ctx_posB4_14_rebound pkt_posB4_06 == some .mismatchedSharedEnvOrDag &&
      (qualifyB4Composite? ctx_posB4_14_rebound pkt_posB4_14_rebound).isSome),
    ("STALE-I1-02-TAMPERED-ACTIVE-PREM",
      !checkB4CompositeBool ctx_ce32_tamperedActivePrem pkt_ce32_tamperedActivePrem),
    ("STALE-I1-03-MULTI-RETRACTION-VS-DISJOINT",
      !checkActiveB4RecordBool L_ce12a rec_posB4_06 &&
      checkActiveB4RecordBool L_ce12a rec_posB4_01 &&
      !depActiveBool ["prem_r"] (OmegaCellC1P1B2BB4.retractedOfLedger ΔL_two)),
    ("STALE-I1-04-EPOCH-EXPIRY-CREATION-AND-POSTCOMMIT",
      evalB4CompositeError? ctx_posB4_01 pkt_ce14_expiredBundle == some .invalidSlice7 &&
      !checkActiveB4RecordBool [.advanceEpoch 100] rec_posB4_01),
    ("STALE-I1-05-JOINT-STANDING-LEDGER-PREFIX",
      activeSlice2348Bool [] sp_ce35.slice2348 &&
      activeSlice56Bool [] sp_ce35.slice56 &&
      activeSlice7Bool [] sp_ce35.slice7 &&
      !jointStandingGuardBool [] ctx_ce35 sp_ce35.base.1 &&
      !checkActiveB4SpineBool [] ctx_ce35 sp_ce35),
    ("STALE-I1-06-MONOTONE-SILENT-RESURRECTION",
      evalMonotoneChainStepError? posB4_09_st1 stepRes == some .silentScopeResurrectionBlocked)
  ]

  let eq01Ok :=
    eqMut01_deriveB4JointPrimDeps ctx_posB4_06.primEnv ctx_posB4_06.dagCont
      cert_posB4_06 bundle7_posB4_06 (.certifiedBridgeL1 "n06_br_imp" 8) ==
    deriveB4JointPrimDeps ctx_posB4_06.primEnv ctx_posB4_06.dagCont
      cert_posB4_06 bundle7_posB4_06 (.certifiedBridgeL1 "n06_br_imp" 8)

  let nc01Ok := isStructCtorPrivate env `OmegaCellC1P1B2BB4.B4QualifiedRecord

  let boundConsumerOk :=
    projectUnboundB4DiagPassBool spoofedB4DiagObs &&
    !consumeBoundB4Verdict
      (⟨evalB4Detailed ctx_posB4_01 pkt_ce01_splitBase, rfl⟩ :
        ProvenanceBoundB4Diagnostic ctx_posB4_01 pkt_ce01_splitBase) &&
    consumeBoundB4Verdict
      (⟨evalB4Detailed ctx_posB4_01 pkt_posB4_01, rfl⟩ :
        ProvenanceBoundB4Diagnostic ctx_posB4_01 pkt_posB4_01)

  let posAllOk := posPairs.all (·.2)
  let ceAllOk  := cePairs.all (·.2)
  let regMutAllOk := regMutPairs.all (·.2)
  let staleAllOk := stalePairs.all (·.2)
  let leanVerOk := (Lean.versionString == "4.33.1")
  let layer2AllOk :=
    shaSelfTestOk &&
    layer2DisjointTopOk &&
    layer2CheckerHits.isEmpty &&
    allAnchorsBoundOk &&
    r0MisboundAbsentOk

  let allOk :=
    leanVerOk &&
    opts.oracleMatch &&
    pinFailures.isEmpty &&
    sorryRefs.isEmpty &&
    nativeDecideRefs.isEmpty &&
    badAxiomRefs.isEmpty &&
    layer2AllOk &&
    unclassified.isEmpty &&
    semCircHits.isEmpty &&
    posAllOk &&
    ceAllOk &&
    regMutAllOk &&
    e2eAllKilled &&
    staleAllOk &&
    eq01Ok &&
    nc01Ok &&
    boundConsumerOk

  let outJson := Json.mkObj [
    ("replayId", Json.str opts.replayId),
    ("leanVersionExact", Json.str Lean.versionString),
    ("sha256Fips180SelfTestVerified", Json.bool shaSelfTestOk),
    ("sourceManifestSha256_H_S", Json.str opts.hSourcesSha),
    ("t24PrecedentOracleSha256", Json.str opts.t24OracleSha),
    ("preservedR0FailedOracleSha256", Json.str opts.r0FailedOrcSha),
    ("oraclePreRunSha256_H_O_I1_R3", Json.str opts.oracleSha),
    ("oraclePostRunSha256MatchesPreRun", Json.bool opts.oracleMatch),
    ("headline63TypePinsAllVerified", Json.bool (pinFailures.isEmpty && sorryRefs.isEmpty && nativeDecideRefs.isEmpty && badAxiomRefs.isEmpty)),
    ("headline63AxiomClosures", Json.arr pinClosureRows),
    ("kit5TheoremAxiomClosures", Json.arr kitClosureRows),
    ("layer2SemanticAudit", Json.mkObj [
      ("independenceScope", Json.str "B4_TOP_SPEC_STRUCTURAL_INDEPENDENCE_WITH_SHARED_LOWER_SEMANTICS"),
      ("fullStackSemanticIndependenceClaimed", Json.bool false),
      ("depSetNormalizationRule", Json.str "UTF8_LF_JOINED_SORTED_UNIQUE_LEAN_CONST_NAMES_SHA256"),
      ("disjointFromWorkerTopSpec", Json.bool layer2DisjointTopOk),
      ("disjointFromAllExecutableCheckers", Json.bool layer2CheckerHits.isEmpty),
      ("r0MisboundNameAbsentInEnv", Json.bool r0MisboundAbsentOk),
      ("all5SharedAnchorsTypedProvenanceVerified", Json.bool allAnchorsBoundOk),
      ("boundSharedLowerAnchors5", Json.arr anchorBindRows),
      ("layer2DirectBodyConstants", toJsonStrArr layer2DirectConsts),
      ("sharedTransitiveConeSize", Json.num sharedConeCount)
    ]),
    ("live14PositiveObservations", Json.arr ((posPairs.map (fun (k, v) => Json.mkObj [("id", Json.str k), ("passed", Json.bool v)])).toArray)),
    ("live37CounterexampleSubcaseObservations", Json.arr ((cePairs.map (fun (k, v) => Json.mkObj [("id", Json.str k), ("passed", Json.bool v)])).toArray)),
    ("registered12MutantObservations", Json.arr ((regMutPairs.map (fun (k, v) => Json.mkObj [("mutantId", Json.str k), ("killed", Json.bool v)])).toArray)),
    ("endToEnd10SingleFaultMutantObservations", Json.arr e2eMutRows),
    ("staleState6InvalidationObservations", Json.arr ((stalePairs.map (fun (k, v) => Json.mkObj [("probeId", Json.str k), ("passed", Json.bool v)])).toArray)),
    ("equivalentMutantEQ01Verified", Json.bool eq01Ok),
    ("privateConstructorSealNC01Verified", Json.bool nc01Ok),
    ("exhaustiveDeclarationClassificationCounts", Json.mkObj [
      ("totalB4OwnedConstants", Json.num totalB4Owned),
      ("S_semanticPredicates", Json.num cntS),
      ("K_executableFunctions", Json.num cntK),
      ("D_dataTypesAndCtors", Json.num cntD),
      ("T_theoremsAndLemmas", Json.num cntT),
      ("F_witnessAndMutantFixtures", Json.num cntF),
      ("A_compilerElabAuxiliaries", Json.num cntA)
    ]),
    ("unclassifiedRelevantDeclarationCount", Json.num unclassified.length),
    ("semanticConeDisjointFromExecutableCheckers", Json.bool semCircHits.isEmpty),
    ("provenanceBoundConsumerChecks", Json.mkObj [
      ("unboundSpoofPossible", Json.bool (projectUnboundB4DiagPassBool spoofedB4DiagObs)),
      ("provenanceBoundConsumerBlocksSpoofAndAcceptsValid", Json.bool boundConsumerOk)
    ]),
    ("allChecksPassed", Json.bool allOk)
  ]

  IO.FS.writeFile opts.outPath (outJson.pretty ++ "\n")
  IO.println s!"KIT_B4_I1_R3_REPLAY={opts.replayId} ALL_OK={allOk} PINS=63/{63 - pinFailures.length} ANCHORS5_OK={allAnchorsBoundOk} STALE_OK={staleAllOk} U_RULE={unclassified.length}"
  return (if allOk then 0 else 1)
