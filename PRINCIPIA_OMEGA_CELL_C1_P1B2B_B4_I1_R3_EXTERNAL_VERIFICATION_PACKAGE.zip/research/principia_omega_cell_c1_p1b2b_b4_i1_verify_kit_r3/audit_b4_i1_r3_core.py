#!/usr/bin/env python3
"""
PRINCIPIA Ω-CELL-C1-P1B2B-B4 — ACT-I1 R3 Detached External Replay & Authority Closure (`KitB4I1-R3`)
Module: audit_b4_i1_r3_core.py

Preserves all 77 binding conditions & 21 calibrations unchanged while integrating:
  - CMTO / R3-Q1..Q5:
      * Strict hash triple-binding `H_generated == H_audited == H_compiled` before & after compilation (`R3-Q3`)
      * Quadruple I1 oracle lineage `T24 -> R0 -> R1 -> R2 -> R3` (`Article 4`)
      * Explicit separation of `compileState` (`ExitCode=0, E=0`) vs `zeroWarningPolicyState` (`W=0`) (`S5`)
  - R2-α: Elaborated Core `Expr` De Bruijn equivalence under verified lineage map `rho` (`nu_alpha(e_R1) == nu_alpha_rho(e_R3)`)
  - R2-β: `Interventional Fault–Guard Response Matrix` (`21 x 9`, with `NOT_OBSERVED`, `C_detect`, `C_distinguish`, `rank_F2`)
  - R2-γ: Bowen–Lanford Directed Graph Zeta Inverse `det(I - uA) == 1` & integer nilpotency `A^9 == 0` cross-check
  - R2-δ: `Append-Only Historical Preservation` (`265 -> 283 -> 301 -> 321`) & `Frozen-State Noninterference Algebra` (`pi_F o V = pi_F`)
"""

from __future__ import annotations

import copy
import datetime
import hashlib
import json
import os
import platform
import shutil
import stat
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

KIT_I1_R3_LEAN_FILES = [
    "lean-toolchain",
    "lakefile.toml",
    "lake-manifest.json",
    "ExternalSpecPinB4I1R3.lean",
    "ExternalObsB4I1R3.lean",
]

FORBIDDEN_PREBUILD_DIR_NAMES = {".lake", "build"}
FORBIDDEN_PREBUILD_SUFFIXES = {
    ".olean",
    ".ilean",
    ".trace",
    ".hash",
    ".c",
    ".o",
    ".a",
    ".dll",
    ".so",
    ".dylib",
    ".exe",
}

GUARD_COLUMNS_9 = [
    "G1_StrictJsonParser",
    "G2_ZeroPrebuildCache",
    "G3_WriteIsolationAndReparse",
    "G4_OracleTemporalAndQuadrupleLineage",
    "G5_Exact63TheoremSetAndOrder",
    "G6_KernelTypePinAndAxiomClosure",
    "G7_TypedAnchor5TupleAndLayer2Scope",
    "G8_SoundnessMutantsStaleAndUrule",
    "G9_CrossReplayAndOrthogonalAuthority",
]


class DuplicateJsonKeyError(ValueError):
    """Raised whenever a JSON object contains duplicate keys at any nesting level."""


class WriteIsolationHaltError(RuntimeError):
    """Raised BEFORE any file open/write if an output target violates Q-I1-04 / F-T24-05 / CAL-I1-06."""


def _strict_no_duplicate_keys_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in pairs:
        if k in out:
            raise DuplicateJsonKeyError(f"Duplicate JSON object key rejected: {k!r}")
        out[k] = v
    return out


def strict_json_loads(raw_text: str) -> Any:
    return json.loads(raw_text, object_pairs_hook=_strict_no_duplicate_keys_hook)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path) -> tuple[int, str]:
    raw = path.read_bytes()
    return len(raw), sha256_bytes(raw)


def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def canonical_json_sha256(obj: Any) -> str:
    return sha256_bytes(canonical_json_bytes(obj))


def path_has_symlink_or_reparse_point(path: Path) -> tuple[bool, str]:
    cur = path
    visited: list[Path] = []
    while True:
        visited.append(cur)
        if cur.parent == cur:
            break
        cur = cur.parent

    for p in reversed(visited):
        try:
            if p.is_symlink():
                return True, f"SYMLINK_DETECTED:{p}"
            if p.exists():
                st = os.lstat(p)
                attrs = getattr(st, "st_file_attributes", 0)
                if attrs & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
                    return True, f"WINDOWS_REPARSE_OR_JUNCTION_DETECTED:{p}"
        except OSError:
            continue
    return False, ""


def _is_norm_subpath(child_real: str, root_real: str) -> bool:
    c = os.path.normcase(os.path.normpath(child_real))
    r = os.path.normcase(os.path.normpath(root_real))
    if c == r:
        return True
    prefix = r if r.endswith(os.sep) else (r + os.sep)
    return c.startswith(prefix)


def enforce_write_isolation_guard(
    target_path: Path,
    allowed_write_roots: list[Path],
    protected_roots: list[Path],
    protected_device_inodes: set[tuple[int, int]] | None = None,
) -> Path:
    bad_tp, reason_tp = path_has_symlink_or_reparse_point(target_path)
    if bad_tp:
        raise WriteIsolationHaltError(f"HALT_REPARSE_OR_SYMLINK_ON_TARGET: {reason_tp}")

    for awr in allowed_write_roots:
        bad_aw, reason_aw = path_has_symlink_or_reparse_point(awr)
        if bad_aw:
            raise WriteIsolationHaltError(f"HALT_REPARSE_OR_SYMLINK_ON_ALLOWED_ROOT: {reason_aw}")

    target_real = os.path.realpath(target_path)
    allowed_reals = [os.path.realpath(r) for r in allowed_write_roots]
    protected_reals = [os.path.realpath(r) for r in protected_roots]

    for pr in protected_reals:
        if _is_norm_subpath(target_real, pr):
            raise WriteIsolationHaltError(
                f"HALT_FROZEN_PATH_WRITE_ATTEMPT: target={target_real} intersects protected={pr}"
            )

    if not any(_is_norm_subpath(target_real, ar) for ar in allowed_reals):
        raise WriteIsolationHaltError(f"HALT_OUTSIDE_ISOLATED_WRITE_ROOTS: target={target_real}")

    if target_path.exists() and protected_device_inodes:
        st = os.stat(target_path)
        if st.st_ino != 0 and (st.st_dev, st.st_ino) in protected_device_inodes:
            raise WriteIsolationHaltError(f"HALT_HARDLINK_INODE_COLLISION_WITH_FROZEN_ASSET: {target_path}")

    return Path(target_real)


def resolve_upstream_source_file(source_root: Path, row: dict[str, Any]) -> Path:
    ws_cand = source_root / Path(*row["workspaceRelPath"].split("/"))
    if ws_cand.is_file():
        return ws_cand
    sc_cand = source_root / "self_contained_sources" / Path(*row["mirrorRelPath"].split("/"))
    if sc_cand.is_file():
        return sc_cand
    return source_root / Path(*row["mirrorRelPath"].split("/"))


def verify_cmto_generated_audited_compiled_hashes(
    staged_kit_dir: Path,
    env_spec: dict[str, Any],
    a1_audit_receipt: dict[str, Any] | None = None,
) -> tuple[bool, dict[str, Any]]:
    """
    R3-Q3 / Article 4: Enforces exact byte & SHA-256 identity across:
      H_generated (sealed in env_spec) == H_audited (from independent A1-R3 auditor) == H_compiled (staged_kit_dir).
    """
    expected_gen = env_spec.get("cmtoBoundKitLeanFilesGeneratedSha256", {})
    audited_map = (
        a1_audit_receipt.get("auditedKitLeanFilesSha256", {})
        if a1_audit_receipt is not None
        else {}
    )
    rows: list[dict[str, Any]] = []
    mismatches: list[str] = []

    for fn in KIT_I1_R3_LEAN_FILES:
        fp = staged_kit_dir / fn
        if not fp.is_file():
            mismatches.append(f"MISSING_STAGED_COMPILED_FILE:{fn}")
            continue
        c_bytes, h_compiled = sha256_file(fp)
        gen_entry = expected_gen.get(fn, {})
        h_gen = gen_entry.get("sha256_H_generated", "")
        g_bytes = gen_entry.get("bytes", -1)
        h_aud = audited_map.get(fn, {}).get("sha256_H_audited", h_gen if a1_audit_receipt is None else "")
        a_bytes = audited_map.get(fn, {}).get("bytes", g_bytes if a1_audit_receipt is None else -2)

        row_ok = (
            h_gen != ""
            and h_gen == h_aud
            and h_aud == h_compiled
            and g_bytes == a_bytes == c_bytes
        )
        if not row_ok:
            mismatches.append(
                f"HASH_BINDING_MISMATCH:{fn}:gen={h_gen},aud={h_aud},comp={h_compiled}"
            )
        rows.append({
            "file": fn,
            "bytes": c_bytes,
            "H_generated": h_gen,
            "H_audited": h_aud,
            "H_compiled": h_compiled,
            "independentAuditReceiptLoaded": a1_audit_receipt is not None,
            "tripleBindingExactMatch": row_ok,
        })

    all_ok = (len(rows) == len(KIT_I1_R3_LEAN_FILES)) and (len(mismatches) == 0)
    return all_ok, {
        "allKitLeanFilesTripleBound": all_ok,
        "independentAuditReceiptDirectlyChecked": a1_audit_receipt is not None,
        "files": rows,
        "mismatches": mismatches,
    }


# =============================================================================
# Strategy R2-γ: Bowen–Lanford Directed Graph Zeta Inverse `det(I - uA) == 1` & `A^9 == 0`
# =============================================================================

def _mat_mul_int(a: list[list[int]], b: list[list[int]]) -> list[list[int]]:
    n = len(a)
    out = [[0] * n for _ in range(n)]
    for i in range(n):
        for k in range(n):
            aik = a[i][k]
            if aik:
                for j in range(n):
                    out[i][j] += aik * b[k][j]
    return out


def _mat_trace_int(a: list[list[int]]) -> int:
    return sum(a[i][i] for i in range(len(a)))


def compute_bowen_lanford_zeta_and_nilpotency(
    pkg_order: list[str],
    topo: dict[str, list[str]],
) -> dict[str, Any]:
    n = len(pkg_order)
    idx_of = {p: i for i, p in enumerate(pkg_order)}
    adj = [[0] * n for _ in range(n)]
    edge_count = 0
    for p, raw_deps in topo.items():
        if p not in idx_of:
            continue
        i = idx_of[p]
        for d_rel in raw_deps:
            d_name = d_rel.removeprefix("../")
            if d_name in idx_of:
                j = idx_of[d_name]
                adj[i][j] = 1
                edge_count += 1

    traces: list[int] = []
    cur = [row[:] for row in adj]
    nilpotent_index: int | None = None
    for k in range(1, n + 1):
        traces.append(_mat_trace_int(cur))
        if nilpotent_index is None and all(v == 0 for r in cur for v in r):
            nilpotent_index = k
        if k < n:
            cur = _mat_mul_int(cur, adj)

    a_pow_n_is_zero = all(v == 0 for r in cur for v in r)

    coeffs = [1]
    for k in range(1, n + 1):
        s = sum(coeffs[k - m] * traces[m - 1] for m in range(1, k + 1))
        assert s % k == 0
        coeffs.append(-s // k)

    det_identically_one = (coeffs == [1] + [0] * n)
    return {
        "zetaModelKind": "BOWEN_LANFORD_DIRECTED_VERTEX_ADJACENCY_ZETA_INVERSE",
        "distinguishedFromEdgeNonBacktrackingIharaBass": True,
        "claimedFasterThanLinearTopologicalSort": False,
        "packageLayerOnlyDistinctFrom4349ConstantDag": True,
        "nodeCount": n,
        "directedEdgeCount": edge_count,
        "adjacencyMatrix": adj,
        "powerTraces_tr_Ak_k1_to_9": traces,
        "nilpotencyVerified_A9_Equals_Zero": a_pow_n_is_zero,
        "minimalNilpotencyExponent_k": nilpotent_index,
        "bowenLanfordInversePolynomialCoeffs_det_I_minus_uA": coeffs,
        "det_I_minus_uA_IdenticallyOne": det_identically_one,
        "algebraicDagCrossCheckPassed": a_pow_n_is_zero and det_identically_one and all(t == 0 for t in traces),
    }


def verify_active_74_sources_and_9pkg_dag(
    source_root: Path,
    kit_dir: Path,
    m74: dict[str, Any],
    env_spec: dict[str, Any],
) -> tuple[bool, dict[str, Any]]:
    mismatches: list[dict[str, Any]] = []
    for row in m74["sources"]:
        fp = resolve_upstream_source_file(source_root, row)
        if not fp.is_file():
            mismatches.append({"mirrorRelPath": row["mirrorRelPath"], "error": "MISSING_SOURCE"})
            continue
        sz, dig = sha256_file(fp)
        if sz != row["byteLength"] or dig != row["sha256"]:
            mismatches.append({
                "mirrorRelPath": row["mirrorRelPath"],
                "expectedBytes": row["byteLength"],
                "actualBytes": sz,
                "expectedSha256": row["sha256"],
                "actualSha256": dig,
            })

    pkg_order: list[str] = env_spec["transitive9PackageColdBuildContract"]["packageOrder"]
    topo: dict[str, list[str]] = m74["relativeLakePathTopology9Packages"]
    dag_errors: list[str] = []

    if len(pkg_order) != 9 or set(pkg_order) != set(topo.keys()):
        dag_errors.append("Package order set != 9-package topology keys")
    else:
        seen_pkgs: set[str] = set()
        for pkg in pkg_order:
            deps = [d.removeprefix("../") for d in topo[pkg]]
            for dep in deps:
                if dep not in seen_pkgs:
                    dag_errors.append(f"Non-topological or cyclic edge: {pkg} -> {dep}")
            seen_pkgs.add(pkg)

    kit_lman = strict_json_loads((kit_dir / "lake-manifest.json").read_text(encoding="utf-8"))
    manifest_pkg_dirs = {Path(p["dir"]).name for p in kit_lman.get("packages", [])}
    expected_upstream_8 = set(pkg_order[:-1])
    if manifest_pkg_dirs != expected_upstream_8:
        dag_errors.append(
            f"KitB4I1R3 lake-manifest upstream dirs {sorted(manifest_pkg_dirs)} != {sorted(expected_upstream_8)}"
        )

    zeta_report = compute_bowen_lanford_zeta_and_nilpotency(pkg_order, topo) if not dag_errors else {
        "algebraicDagCrossCheckPassed": False
    }
    if not zeta_report.get("algebraicDagCrossCheckPassed"):
        dag_errors.append("Bowen-Lanford algebraic DAG cross-check failed")

    ok = (len(mismatches) == 0) and (len(dag_errors) == 0) and (len(m74["sources"]) == 74)
    return ok, {
        "upstreamSourcesVerifiedCount": len(m74["sources"]) - len(mismatches),
        "expectedUpstreamSourcesCount": 74,
        "transitiveLakePackagesVerifiedCount": len(pkg_order) if not dag_errors else 0,
        "packageTopologicalOrder": pkg_order,
        "bowenLanfordAlgebraicCrossCheck_R2_gamma": zeta_report,
        "sourceMismatches": mismatches,
        "dagErrors": dag_errors,
        "allPassed": ok,
    }


def verify_zero_preexisting_build_artifacts(work_root: Path) -> tuple[bool, list[str]]:
    hits: list[str] = []
    for root_str, dirnames, filenames in os.walk(work_root):
        rel_root = Path(root_str).relative_to(work_root).as_posix()
        for d in dirnames:
            if d in FORBIDDEN_PREBUILD_DIR_NAMES:
                hits.append(f"DIR:{rel_root}/{d}")
        for fn in filenames:
            suf = Path(fn).suffix.lower()
            if suf in FORBIDDEN_PREBUILD_SUFFIXES:
                hits.append(f"FILE:{rel_root}/{fn}")
    return (len(hits) == 0), hits


def build_sanitized_lean_env() -> tuple[dict[str, str] | None, dict[str, Any]]:
    env = os.environ.copy()
    for var in ["LEAN_PATH", "LEAN_SRC_PATH", "LAKE_HOME", "LAKE_CACHE_DIR", "LAKE_OVERRIDE"]:
        env.pop(var, None)

    home = env.get("USERPROFILE") or env.get("HOME") or ""
    elan_bin = Path(home) / ".elan" / "bin"
    if elan_bin.is_dir():
        env["PATH"] = str(elan_bin) + os.pathsep + env.get("PATH", "")
    env["ELAN_TOOLCHAIN"] = "leanprover/lean4:v4.33.1"

    lean_exe = shutil.which("lean", path=env.get("PATH"))
    lake_exe = shutil.which("lake", path=env.get("PATH"))
    elan_exe = shutil.which("elan", path=env.get("PATH"))
    if not lean_exe or not lake_exe:
        return None, {"error": "LEAN_OR_LAKE_NOT_FOUND_ON_PATH"}

    ver_proc = subprocess.run([lean_exe, "--version"], env=env, capture_output=True, text=True, encoding="utf-8")
    ver_out = (ver_proc.stdout or "").strip()
    if ver_proc.returncode != 0 or "4.33.1" not in ver_out:
        return None, {"error": "TOOLCHAIN_VERSION_MISMATCH", "versionOutput": ver_out}

    lake_proc = subprocess.run([lake_exe, "--version"], env=env, capture_output=True, text=True, encoding="utf-8")
    lake_ver_out = (lake_proc.stdout or "").strip()

    _, shim_lean_sha = sha256_file(Path(lean_exe))
    resolved_lean_path = lean_exe
    resolved_lean_sha = shim_lean_sha
    resolved_lake_path = lake_exe
    _, resolved_lake_sha = sha256_file(Path(lake_exe))

    if elan_exe:
        for tool_name in ("lean", "lake"):
            w = subprocess.run([elan_exe, "which", tool_name], env=env, capture_output=True, text=True, encoding="utf-8")
            if w.returncode == 0 and w.stdout.strip():
                rp = Path(w.stdout.strip())
                if rp.is_file():
                    _, rsha = sha256_file(rp)
                    if tool_name == "lean":
                        resolved_lean_path = str(rp)
                        resolved_lean_sha = rsha
                    else:
                        resolved_lake_path = str(rp)
                        resolved_lake_sha = rsha

    meta: dict[str, Any] = {
        "hostPlatformString": platform.platform(),
        "pythonVersion": platform.python_version(),
        "leanVersionOutput": ver_out,
        "leanCommit819816bVerified": ("819816b2e0a3bf405af45ae5c7af2491d8f5bee6" in ver_out),
        "lakeVersionOutput": lake_ver_out,
        "elanShimLeanSha256": shim_lean_sha,
        "resolvedLeanBinaryPath": resolved_lean_path,
        "resolvedLeanBinarySha256": resolved_lean_sha,
        "resolvedLakeBinaryPath": resolved_lake_path,
        "resolvedLakeBinarySha256": resolved_lake_sha,
    }
    if hasattr(os, "getuid"):
        meta["posixUid"] = os.getuid()
        meta["posixGid"] = os.getgid()
        meta["posixGroups"] = list(os.getgroups())
    return env, meta


def _restore_writable_tree(root: Path) -> None:
    for r, _, files in os.walk(root):
        rp = Path(r)
        try:
            os.chmod(rp, stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
        except OSError:
            pass
        for fn in files:
            fp = rp / fn
            try:
                os.chmod(fp, stat.S_IWRITE | stat.S_IREAD)
            except OSError:
                pass


def count_warnings_and_errors(build_text: str) -> tuple[int, int]:
    warnings = sum(1 for ln in build_text.splitlines() if "warning:" in ln.lower())
    errors = sum(1 for ln in build_text.splitlines() if "error:" in ln.lower())
    return warnings, errors


def make_orthogonal_trace_node_r3(
    gate_id: str,
    root_id: str,
    attempt_id: str,
    predecessor_ids: list[str],
    compile_state: str,
    compile_exit_code: int | None,
    compile_error_count: int,
    linter_warning_count: int,
    zero_warning_policy_state: str,
    execution_state: str,
    process_exit_code: int | None,
    observation_json_state: str,
    observation_json_sha256: str | None,
    spec_comparison_state: str,
    failure_diagnostics: list[str],
    next_gate_eligible: bool,
) -> dict[str, Any]:
    return {
        "gateId": gate_id,
        "rootId": root_id,
        "attemptId": attempt_id,
        "predecessorIds": predecessor_ids,
        "compileState": compile_state,
        "compileProcessExitCode": compile_exit_code,
        "compileErrorCount": compile_error_count,
        "linterWarningCount": linter_warning_count,
        "zeroWarningPolicyState": zero_warning_policy_state,
        "executionState": execution_state,
        "processExitCode": process_exit_code,
        "observationJsonState": observation_json_state,
        "observationJsonSha256": observation_json_sha256,
        "specComparisonState": spec_comparison_state,
        "failureDiagnostics": failure_diagnostics,
        "nextGateEligible": next_gate_eligible,
    }


def evaluate_orthogonal_gate_trace_eligibility(trace_nodes: list[dict[str, Any]]) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if not trace_nodes:
        return False, ["EMPTY_EXECUTION_TRACE"]

    for node in trace_nodes:
        gid = node.get("gateId", "<unknown>")
        c_st = node.get("compileState")
        zw_st = node.get("zeroWarningPolicyState")
        e_st = node.get("executionState")
        o_st = node.get("observationJsonState")
        s_st = node.get("specComparisonState")
        ec = node.get("processExitCode")
        nxt = node.get("nextGateEligible")

        if c_st not in ("BUILD_COMPLETED", "NOT_APPLICABLE"):
            reasons.append(f"{gid}: compileState={c_st} != BUILD_COMPLETED")
        if zw_st not in ("POLICY_PASSED", "NOT_APPLICABLE"):
            reasons.append(f"{gid}: zeroWarningPolicyState={zw_st} != POLICY_PASSED")
        if e_st != "EXECUTION_COMPLETED":
            reasons.append(f"{gid}: executionState={e_st} != EXECUTION_COMPLETED")
        if ec not in (0, None):
            reasons.append(f"{gid}: processExitCode={ec} != 0")
        if o_st == "OBSERVATION_MISSING":
            reasons.append(f"{gid}: OBSERVATION_MISSING")
        if s_st == "SPEC_MISMATCHED":
            reasons.append(f"{gid}: SPEC_MISMATCHED")
        if nxt is not True:
            reasons.append(f"{gid}: nextGateEligible is not True")

    return (len(reasons) == 0), reasons


def validate_a10_authority_gate(
    trace_nodes: list[dict[str, Any]],
    calibrations_21_all_caught: bool,
    claimed_a10_eligible: bool,
) -> tuple[bool, str]:
    trace_ok, trace_reasons = evaluate_orthogonal_gate_trace_eligibility(trace_nodes)
    must_be_eligible = trace_ok and calibrations_21_all_caught
    if claimed_a10_eligible and not must_be_eligible:
        first_err = trace_reasons[0] if trace_reasons else "CALIBRATION_21_NOT_ALL_CAUGHT"
        return False, f"UNAUTHORIZED_A10_ELIGIBILITY_GRANT: {first_err}"
    return True, "OK"


def run_single_isolated_9pkg_cold_replay_r3(
    replay_id: str,
    attempt_id: str,
    source_root: Path,
    kit_dir: Path,
    m74: dict[str, Any],
    env_spec: dict[str, Any],
    oracle: dict[str, Any],
    h_s: str,
    t24_oracle_sha: str,
    r0_failed_oracle_sha: str,
    r1_policy_failed_oracle_sha: str,
    r2_generator_failed_oracle_sha: str,
    oracle_path: Path,
    lean_env: dict[str, str],
    allowed_write_roots: list[Path],
    protected_roots: list[Path],
    a1_audit_receipt: dict[str, Any] | None = None,
    log_out_path: Path | None = None,
    obs_out_path: Path | None = None,
    failed_obs_out_path: Path | None = None,
) -> tuple[bool, dict[str, Any], list[dict[str, Any]], dict[str, Any] | None]:
    for p_chk in (log_out_path, obs_out_path, failed_obs_out_path):
        if p_chk is not None:
            enforce_write_isolation_guard(p_chk, allowed_write_roots, protected_roots)

    lake_exe = shutil.which("lake", path=lean_env.get("PATH"))
    assert lake_exe is not None

    _, pre_oracle_sha = sha256_file(oracle_path)
    ts_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    trace_nodes: list[dict[str, Any]] = []

    tmp_dir_obj = tempfile.TemporaryDirectory(prefix=f"principia_b4_i1_r3_{replay_id}_")
    tmp_root = Path(tmp_dir_obj.name)
    try:
        tmp_research = tmp_root / "research"
        staged_digests: list[tuple[Path, int, str]] = []

        for row in m74["sources"]:
            src_fp = resolve_upstream_source_file(source_root, row)
            dst_fp = tmp_research / Path(*row["mirrorRelPath"].split("/"))
            dst_fp.parent.mkdir(parents=True, exist_ok=True)
            raw_b = src_fp.read_bytes()
            dst_fp.write_bytes(raw_b)
            staged_digests.append((dst_fp, len(raw_b), sha256_bytes(raw_b)))

        tmp_kit = tmp_research / "principia_omega_cell_c1_p1b2b_b4_i1_verify_kit_r3"
        tmp_kit.mkdir(parents=True, exist_ok=True)
        for kfn in KIT_I1_R3_LEAN_FILES:
            raw_b = (kit_dir / kfn).read_bytes()
            dst_fp = tmp_kit / kfn
            dst_fp.write_bytes(raw_b)
            staged_digests.append((dst_fp, len(raw_b), sha256_bytes(raw_b)))

        # R3-Q3: Enforce H_generated == H_audited == H_compiled BEFORE compilation!
        triple_pre_ok, triple_pre_rep = verify_cmto_generated_audited_compiled_hashes(
            tmp_kit, env_spec, a1_audit_receipt
        )
        zero_cache_ok, prebuild_hits = verify_zero_preexisting_build_artifacts(tmp_root)
        preflight_ok = zero_cache_ok and triple_pre_ok
        preflight_diags = list(prebuild_hits) + list(triple_pre_rep["mismatches"])

        trace_nodes.append(make_orthogonal_trace_node_r3(
            f"{replay_id}_A3_ZeroCacheAndTripleHashPreflight",
            str(tmp_root),
            attempt_id,
            ["G0_R3", "A0_R3", "A1_R3", "A2_R3", "PRE_R3"],
            "NOT_APPLICABLE",
            None,
            0,
            0,
            "NOT_APPLICABLE",
            "EXECUTION_COMPLETED" if preflight_ok else "EXECUTION_FAILED",
            0 if preflight_ok else 1,
            "NOT_APPLICABLE",
            None,
            "SPEC_MATCHED" if preflight_ok else "SPEC_MISMATCHED",
            preflight_diags,
            preflight_ok,
        ))
        if not preflight_ok:
            return False, {
                "replayId": replay_id,
                "error": "PREFLIGHT_ZERO_CACHE_OR_TRIPLE_HASH_FAILED",
                "details": preflight_diags,
            }, trace_nodes, None

        for s_fp, _, _ in staged_digests:
            if s_fp.suffix == ".lean" or s_fp.name == "lean-toolchain":
                os.chmod(s_fp, stat.S_IREAD)

        tmp_b4_dir = tmp_research / "principia_omega_cell_c1_p1b2b_b4_higher_composition_lean4"
        (tmp_research / "principia_omega_cell_c1_p1b2b_b4_i0_evidence").mkdir(parents=True, exist_ok=True)

        t_build_start = time.time()
        proc_b4_build = subprocess.run(
            [lake_exe, "build"],
            cwd=str(tmp_b4_dir),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        proc_kit_build = subprocess.run(
            [lake_exe, "build"],
            cwd=str(tmp_kit),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        build_secs = round(time.time() - t_build_start, 3)

        # R3-Q3: Re-verify H_generated == H_audited == H_compiled AFTER compilation!
        triple_post_ok, triple_post_rep = verify_cmto_generated_audited_compiled_hashes(
            tmp_kit, env_spec, a1_audit_receipt
        )

        b4_out = (proc_b4_build.stdout or "") + ("\n" + proc_b4_build.stderr if proc_b4_build.stderr else "")
        kit_out = (proc_kit_build.stdout or "") + ("\n" + proc_kit_build.stderr if proc_kit_build.stderr else "")
        combined_log = (
            f"# PRINCIPIA B4 ACT-I1 R3 — Isolated 9-Package Cold Build Replay Log ({replay_id})\n"
            f"# Timestamp (UTC): {ts_utc}\n"
            f"# Isolated Work Root: {tmp_root}\n"
            f"# Pre-Build Artifact Hits: 0 (Zero-Cache Verified)\n"
            f"# R3-Q3 Triple Hash Binding (Pre/Post Build): {triple_pre_ok and triple_post_ok}\n"
            f"# Step A (8 Packages `P1A0..B4` `lake build`) Exit Code: {proc_b4_build.returncode}\n"
            f"{b4_out}\n"
            f"# Step B (9th Package `KitB4I1-R3` `lake build`) Exit Code: {proc_kit_build.returncode}\n"
            f"{kit_out}\n"
            f"# Total Cold Build Seconds: {build_secs}\n"
        ).replace("\r\n", "\n")

        if log_out_path is not None:
            log_out_path.write_bytes(combined_log.encode("utf-8"))
        log_sha = sha256_bytes(combined_log.encode("utf-8"))

        w_b4, e_b4 = count_warnings_and_errors(b4_out)
        w_kit, e_kit = count_warnings_and_errors(kit_out)
        total_w = w_b4 + w_kit
        total_e = e_b4 + e_kit
        comb_exit = 0 if (proc_b4_build.returncode == 0 and proc_kit_build.returncode == 0) else max(proc_b4_build.returncode, proc_kit_build.returncode, 1)

        expected_roots: list[str] = env_spec["transitive9PackageColdBuildContract"]["expectedOleanRoots"]
        found_olean_roots: set[str] = set()
        total_fresh_oleans = 0
        for r_str, _, fns in os.walk(tmp_research):
            for fn in fns:
                if fn.endswith(".olean"):
                    fp = Path(r_str) / fn
                    if fp.stat().st_mtime >= (t_build_start - 5.0):
                        total_fresh_oleans += 1
                        stem = fn[:-6]
                        if stem in expected_roots:
                            found_olean_roots.add(stem)
        missing_olean_roots = sorted(set(expected_roots) - found_olean_roots)

        compile_completed = (comb_exit == 0) and (total_e == 0) and (len(missing_olean_roots) == 0) and triple_post_ok
        zero_warning_ok = (total_w == 0)
        a4_gate_pass = compile_completed and zero_warning_ok

        a4_diags: list[str] = list(missing_olean_roots) + list(triple_post_rep["mismatches"])
        if not zero_warning_ok:
            a4_diags.append(f"ZERO_WARNING_POLICY_FAILED: {total_w} warning(s)")

        trace_nodes.append(make_orthogonal_trace_node_r3(
            f"{replay_id}_A4_9PkgColdBuild",
            str(tmp_root),
            attempt_id,
            [f"{replay_id}_A3_ZeroCacheAndTripleHashPreflight"],
            "BUILD_COMPLETED" if compile_completed else "BUILD_FAILED",
            comb_exit,
            total_e,
            total_w,
            "POLICY_PASSED" if zero_warning_ok else "POLICY_FAILED",
            "EXECUTION_COMPLETED" if a4_gate_pass else "EXECUTION_FAILED",
            comb_exit,
            "NOT_APPLICABLE",
            None,
            "SPEC_MATCHED" if a4_gate_pass else "SPEC_MISMATCHED",
            a4_diags,
            a4_gate_pass,
        ))
        if not a4_gate_pass:
            trace_nodes.append(make_orthogonal_trace_node_r3(
                f"{replay_id}_A5_to_A9_ObserverAndSpec",
                str(tmp_root),
                attempt_id,
                [f"{replay_id}_A4_9PkgColdBuild"],
                "BLOCKED_BY_PREDECESSOR",
                None,
                0,
                0,
                "NOT_APPLICABLE",
                "BLOCKED_BY_PREDECESSOR",
                None,
                "OBSERVATION_MISSING",
                None,
                "NOT_EVALUATED",
                ["Blocked by A4 cold build or zero-warning policy failure"],
                False,
            ))
            return False, {
                "replayId": replay_id,
                "compileState": "BUILD_COMPLETED" if compile_completed else "BUILD_FAILED",
                "zeroWarningPolicyState": "POLICY_PASSED" if zero_warning_ok else "POLICY_FAILED",
                "linterWarningCount": total_w,
                "rawBuildLogSha256": log_sha,
            }, trace_nodes, None

        t_obs_start = time.time()
        proc_w_aud = subprocess.run([lake_exe, "exe", "AuditB4AxiomsAndDag"], cwd=str(tmp_b4_dir), env=lean_env, capture_output=True, text=True, encoding="utf-8", errors="replace")
        proc_w_run = subprocess.run([lake_exe, "exe", "RunB4SoundnessAndMutants"], cwd=str(tmp_b4_dir), env=lean_env, capture_output=True, text=True, encoding="utf-8", errors="replace")
        worker_exec_ok = (proc_w_aud.returncode == 0) and (proc_w_run.returncode == 0)
        trace_nodes.append(make_orthogonal_trace_node_r3(
            f"{replay_id}_WorkerAuditAndSuite",
            str(tmp_root),
            attempt_id,
            [f"{replay_id}_A4_9PkgColdBuild"],
            "BUILD_COMPLETED",
            0,
            0,
            0,
            "POLICY_PASSED",
            "EXECUTION_COMPLETED" if worker_exec_ok else "EXECUTION_FAILED",
            0 if worker_exec_ok else max(proc_w_aud.returncode, proc_w_run.returncode, 1),
            "NOT_APPLICABLE",
            None,
            "SPEC_MATCHED" if worker_exec_ok else "SPEC_MISMATCHED",
            [] if worker_exec_ok else ["Worker audit or suite non-zero exit"],
            worker_exec_ok,
        ))

        _, mid_oracle_sha = sha256_file(oracle_path)
        oracle_match_str = "true" if mid_oracle_sha == pre_oracle_sha else "false"
        tmp_obs_json = tmp_kit / f"obs_{replay_id}.json"

        proc_obs = subprocess.run(
            [
                lake_exe,
                "exe",
                "ExternalObsB4I1R3",
                "--replay-id",
                replay_id,
                "--h-sources-sha",
                h_s,
                "--t24-oracle-sha",
                t24_oracle_sha,
                "--r0-failed-orc-sha",
                r0_failed_oracle_sha,
                "--oracle-sha",
                pre_oracle_sha,
                "--oracle-match",
                oracle_match_str,
                "--out-json",
                str(tmp_obs_json),
            ],
            cwd=str(tmp_kit),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        obs_secs = round(time.time() - t_obs_start, 3)
        _, post_oracle_sha = sha256_file(oracle_path)

        staged_sources_unchanged = all(
            sha256_file(s_fp) == (exp_sz, exp_sha) for s_fp, exp_sz, exp_sha in staged_digests
        )

        obs_exists = tmp_obs_json.is_file()
        obs_state = "OBSERVATION_PRESENT" if obs_exists else "OBSERVATION_MISSING"
        obs_sha: str | None = None
        obs_obj: dict[str, Any] | None = None
        spec_ok = False
        spec_errs: list[str] = []

        if obs_exists:
            raw_obs_bytes = tmp_obs_json.read_bytes().replace(b"\r\n", b"\n")
            obs_sha = sha256_bytes(raw_obs_bytes)
            obs_obj = strict_json_loads(raw_obs_bytes.decode("utf-8"))
            spec_ok, spec_errs, _ = validate_single_observation_against_spec_r3(
                replay_id,
                obs_obj,
                oracle,
                env_spec,
                h_s,
                pre_oracle_sha,
                t24_oracle_sha,
                r0_failed_oracle_sha,
                r1_policy_failed_oracle_sha,
                r2_generator_failed_oracle_sha,
            )
            if proc_obs.returncode == 0 and spec_ok:
                if obs_out_path is not None:
                    obs_out_path.write_bytes(raw_obs_bytes)
            else:
                if failed_obs_out_path is not None:
                    failed_obs_out_path.write_bytes(raw_obs_bytes)
        else:
            spec_errs.append(f"{replay_id}: OBSERVATION_MISSING (stderr={proc_obs.stderr.strip()[:240]})")

        step_all_ok = (
            worker_exec_ok
            and (proc_obs.returncode == 0)
            and obs_exists
            and spec_ok
            and staged_sources_unchanged
            and triple_pre_ok
            and triple_post_ok
            and (pre_oracle_sha == post_oracle_sha)
        )
        trace_nodes.append(make_orthogonal_trace_node_r3(
            f"{replay_id}_A5_to_A9_ObserverAndSpec",
            str(tmp_root),
            attempt_id,
            [f"{replay_id}_WorkerAuditAndSuite"],
            "BUILD_COMPLETED",
            0,
            0,
            0,
            "POLICY_PASSED",
            "EXECUTION_COMPLETED" if proc_obs.returncode == 0 else "EXECUTION_FAILED",
            proc_obs.returncode,
            obs_state,
            obs_sha,
            "SPEC_MATCHED" if (obs_exists and spec_ok) else ("NOT_EVALUATED" if not obs_exists else "SPEC_MISMATCHED"),
            spec_errs,
            step_all_ok,
        ))

        meta = {
            "replayId": replay_id,
            "attemptId": attempt_id,
            "startedAtUtc": ts_utc,
            "isolatedWorkRoot": str(tmp_root),
            "preBuildZeroCacheVerified": True,
            "cmtoTripleHashBinding_R3_Q3": triple_post_rep,
            "compileState": "BUILD_COMPLETED",
            "compileProcessExitCode": 0,
            "compileErrorCount": 0,
            "linterWarningCount": 0,
            "zeroWarningPolicyState": "POLICY_PASSED",
            "coldBuildQualified9Packages": True,
            "verifiedFreshOleanRoots9": sorted(found_olean_roots),
            "totalFreshOleanFilesBuilt": total_fresh_oleans,
            "coldBuildSeconds": build_secs,
            "observerAndSuiteSeconds": obs_secs,
            "workerAuditExitCode": proc_w_aud.returncode,
            "workerSuiteExitCode": proc_w_run.returncode,
            "kitObserverExitCode": proc_obs.returncode,
            "kitObserverStdout": (proc_obs.stdout or "").strip(),
            "observationJsonState": obs_state,
            "rawBuildLogSha256": log_sha,
            "rawObservationSha256": obs_sha,
            "preRunOracleSha256": pre_oracle_sha,
            "postRunOracleSha256": post_oracle_sha,
            "staged79PureSourcesUnchanged": staged_sources_unchanged,
            "specMatched": spec_ok,
            "specValidationErrors": spec_errs,
        }
        return step_all_ok, meta, trace_nodes, (obs_obj if step_all_ok else None)
    finally:
        _restore_writable_tree(tmp_root)
        tmp_dir_obj.cleanup()


def project_cansem_r3(obs: dict[str, Any], env_spec: dict[str, Any]) -> dict[str, Any]:
    contract = env_spec["canSemProjectionContract"]
    excluded = set(contract["preDeclaredExcludedNonSemanticFields"])
    included = list(contract["preDeclaredIncludedCanonicalSemanticFields"])

    expected_all = excluded | set(included)
    actual_all = set(obs.keys())
    if actual_all != expected_all:
        extra = sorted(actual_all - expected_all)
        missing = sorted(expected_all - actual_all)
        raise ValueError(f"Observation top-level keys mismatch CanSem R3 contract: extra={extra}, missing={missing}")

    return {k: copy.deepcopy(obs[k]) for k in included}


def validate_single_observation_against_spec_r3(
    tag: str,
    obs: dict[str, Any],
    oracle: dict[str, Any],
    env_spec: dict[str, Any],
    expected_h_s: str,
    expected_h_o_r3: str,
    expected_t24_oracle_sha: str,
    expected_r0_failed_oracle_sha: str,
    expected_r1_policy_failed_oracle_sha: str,
    expected_r2_generator_failed_oracle_sha: str,
) -> tuple[bool, list[str], dict[str, int]]:
    g4_errs: list[str] = []  # G4_OracleTemporalAndQuadrupleLineage
    g5_errs: list[str] = []  # G5_Exact63TheoremSetAndOrder
    g6_errs: list[str] = []  # G6_KernelTypePinAndAxiomClosure
    g7_errs: list[str] = []  # G7_TypedAnchor5TupleAndLayer2Scope
    g8_errs: list[str] = []  # G8_SoundnessMutantsStaleAndUrule

    allowed_axioms = set(env_spec["allowedStandardAxioms"])
    forbidden_axioms = set(env_spec["forbiddenAxioms"])

    # --- G4: Oracle Temporal & Quadruple I1 Lineage (`T24 -> R0 -> R1 -> R2 -> R3`) ---
    if obs.get("leanVersionExact") != env_spec["pinnedToolchain"]["expectedLeanVersionExact"]:
        g4_errs.append(f"{tag}: leanVersionExact != 4.33.1")
    if obs.get("sha256Fips180SelfTestVerified") is not True:
        g4_errs.append(f"{tag}: sha256Fips180SelfTestVerified is not True")
    if obs.get("sourceManifestSha256_H_S") != expected_h_s:
        g4_errs.append(f"{tag}: sourceManifestSha256_H_S != {expected_h_s}")
    if obs.get("t24PrecedentOracleSha256") != expected_t24_oracle_sha:
        g4_errs.append(f"{tag}: t24PrecedentOracleSha256 != T24 anchor")

    obs_r0_sha = obs.get("preservedR0FailedOracleSha256", "")
    obs_r3_sha = obs.get("oraclePreRunSha256_H_O_I1_R3", "")
    anchors = oracle["temporalAndFailureLineageAnchors"]
    orc_r1_anchor = anchors.get("preservedR1PolicyFailedOracleSha256", "")
    orc_r2_anchor = anchors.get("preservedR2GeneratorFailedOracleSha256", "")

    if obs_r0_sha != expected_r0_failed_oracle_sha:
        g4_errs.append(f"{tag}: R0_FAILED_ORACLE_LINEAGE_MISMATCH")
    if orc_r1_anchor != expected_r1_policy_failed_oracle_sha:
        g4_errs.append(f"{tag}: R1_POLICY_FAILED_ORACLE_LINEAGE_MISMATCH")
    if orc_r2_anchor != expected_r2_generator_failed_oracle_sha:
        g4_errs.append(f"{tag}: R2_GENERATOR_FAILED_ORACLE_LINEAGE_MISMATCH")
    if obs_r3_sha != expected_h_o_r3:
        g4_errs.append(f"{tag}: R3_ACTIVE_ORACLE_SHA_MISMATCH")
    if len({obs_r0_sha, orc_r1_anchor, orc_r2_anchor, obs_r3_sha}) != 4:
        g4_errs.append(f"{tag}: UNAUTHORIZED_ORACLE_LINEAGE_COLLAPSE")
    if obs.get("oraclePostRunSha256MatchesPreRun") is not True:
        g4_errs.append(f"{tag}: oraclePostRunSha256MatchesPreRun is not True")

    # --- G5: Exact 63-Theorem Set, Uniqueness & Sequence ---
    pins = obs.get("headline63AxiomClosures", [])
    spec_63 = oracle["expectedHeadline63Specifications"]
    expected_thm_list = [s["theoremName"] for s in spec_63]
    expected_pin_list = [s["pinTheoremName"] for s in spec_63]
    expected_thm_set = set(expected_thm_list)

    obs_thm_list = [r.get("theoremName", "") for r in pins]
    obs_pin_list = [r.get("pinTheoremName", "") for r in pins]

    if len(pins) != 63:
        g5_errs.append(f"{tag}: headline theorem count {len(pins)} != 63")
    if len(set(obs_thm_list)) != len(obs_thm_list):
        g5_errs.append(f"{tag}: DUPLICATE_THEOREM_IDENTIFIERS_DETECTED")
    if len(set(obs_pin_list)) != len(obs_pin_list):
        g5_errs.append(f"{tag}: DUPLICATE_PIN_IDENTIFIERS_DETECTED")
    if set(obs_thm_list) != expected_thm_set:
        g5_errs.append(f"{tag}: THEOREM_SET_MISMATCH_VS_SPEC")
    if obs_thm_list != expected_thm_list or obs_pin_list != expected_pin_list:
        g5_errs.append(f"{tag}: ORDERED_63_THEOREM_PIN_SEQUENCE_MISMATCH")

    # --- G6: Kernel `isDefEq` Type Pin, Pretty Signature & Axiom Closures ---
    if obs.get("headline63TypePinsAllVerified") is not True:
        g6_errs.append(f"{tag}: headline63TypePinsAllVerified is not True")
    spec_by_thm = {s["theoremName"]: s for s in spec_63}
    for row in pins:
        tname = row.get("theoremName", "<unknown>")
        if row.get("kernelIsDefEqVerified") is not True:
            g6_errs.append(f"{tag}: kernelIsDefEqVerified false on {tname}")
        if row.get("isTheoremInfo") is not True:
            g6_errs.append(f"{tag}: isTheoremInfo false on {tname}")
        axs = row.get("transitiveAxioms", [])
        for a in axs:
            if a in forbidden_axioms or a not in allowed_axioms:
                g6_errs.append(f"{tag}: forbidden/non-standard axiom {a} in {tname}")
        if tname in spec_by_thm:
            sp = spec_by_thm[tname]
            if row.get("pinTheoremName") != sp["pinTheoremName"]:
                g6_errs.append(f"{tag}: pin mismatch on {tname}")
            sig = row.get("kernelPrettySignature", "")
            if sig != sp["expectedKernelPrettySignature"] or sha256_bytes(sig.encode("utf-8")) != sp["expectedKernelPrettySignatureSha256"]:
                g6_errs.append(f"{tag}: kernel signature drift on {tname}")
            if sorted(axs) != sp["expectedTransitiveAxioms"]:
                g6_errs.append(f"{tag}: transitive axiom closure drift on {tname}")

    kit_rows = obs.get("kit5TheoremAxiomClosures", [])
    if [r.get("theoremName") for r in kit_rows] != oracle["expectedKit5TheoremNames"]:
        g6_errs.append(f"{tag}: kit5TheoremNames mismatch")
    for kr in kit_rows:
        if kr.get("isTheoremInfo") is not True:
            g6_errs.append(f"{tag}: kit theorem not thmInfo")
        for a in kr.get("transitiveAxioms", []):
            if a in forbidden_axioms or a not in allowed_axioms:
                g6_errs.append(f"{tag}: invalid axiom {a} in kit theorem")

    # --- G7: Typed 5-Tuple Declaration Provenance `Bind(c)` & Layer-2 Scope ---
    l2 = obs.get("layer2SemanticAudit", {})
    exp_l2 = oracle["expectedLayer2SemanticAudit"]
    if l2.get("fullStackSemanticIndependenceClaimed") is not False:
        g7_errs.append(f"{tag}: OVERCLAIMED_FULL_STACK_SEMANTIC_INDEPENDENCE")
    if l2.get("independenceScope") != exp_l2["independenceScope"]:
        g7_errs.append(f"{tag}: invalid Layer-2 independenceScope")
    if l2.get("depSetNormalizationRule") != exp_l2["depSetNormalizationRule"]:
        g7_errs.append(f"{tag}: depSetNormalizationRule mismatch")
    if l2.get("disjointFromWorkerTopSpec") is not True or l2.get("disjointFromAllExecutableCheckers") is not True:
        g7_errs.append(f"{tag}: Layer-2 top-spec or checker disjointness failed")
    if l2.get("r0MisboundNameAbsentInEnv") is not True:
        g7_errs.append(f"{tag}: r0MisboundNameAbsentInEnv false")
    if l2.get("all5SharedAnchorsTypedProvenanceVerified") is not True:
        g7_errs.append(f"{tag}: all5SharedAnchorsTypedProvenanceVerified false")

    obs_anchors = l2.get("boundSharedLowerAnchors5", [])
    exp_anchors = exp_l2["expectedSharedLowerAnchors5TupleBind"]
    exp_anc_names = [a["canonicalName"] for a in exp_anchors]
    obs_anc_names = [a.get("canonicalName", "") for a in obs_anchors]

    for a_row in obs_anchors:
        if a_row.get("existsInEnvironment") is not True:
            g7_errs.append(f"{tag}: NONEXISTENT_CANONICAL_CONSTANT:{a_row.get('canonicalName')}")
    if len(obs_anchors) != 5 or len(set(obs_anc_names)) != 5 or obs_anc_names != exp_anc_names:
        g7_errs.append(f"{tag}: SHARED_ANCHOR_IDENTIFIER_SET_MISMATCH")

    exp_anc_map = {a["canonicalName"]: a for a in exp_anchors}
    for a_row in obs_anchors:
        cname = a_row.get("canonicalName", "")
        if cname in exp_anc_map:
            ea = exp_anc_map[cname]
            if a_row.get("anchorPinName") != ea["expectedAnchorPinName"]:
                g7_errs.append(f"{tag}: ANCHOR_PIN_NAME_MISMATCH:{cname}")
            if a_row.get("kernelIsDefEqAnchorPinVerified") is not True:
                g7_errs.append(f"{tag}: ANCHOR_KERNEL_ISDEFEQ_PIN_FAILED:{cname}")
            if a_row.get("definingModule") != ea["definingModule"]:
                g7_errs.append(f"{tag}: ANCHOR_DEFINING_MODULE_MISMATCH:{cname}")
            if a_row.get("kernelPrettyType") != ea["kernelPrettyType"] or a_row.get("kernelPrettyTypeSha256") != ea["kernelPrettyTypeSha256"]:
                g7_errs.append(f"{tag}: ANCHOR_TYPE_SIGNATURE_MISMATCH:{cname}")
            if a_row.get("directDepCount") != ea["directDepCount"] or a_row.get("directDepSetSha256_H_direct") != ea["directDepSetSha256_H_direct"]:
                g7_errs.append(f"{tag}: ANCHOR_DIRECT_DEPS_HASH_MISMATCH:{cname}")
            if a_row.get("transitiveConeCount") != ea["transitiveConeCount"] or a_row.get("transitiveDepConeSha256_H_transitive") != ea["transitiveDepConeSha256_H_transitive"]:
                g7_errs.append(f"{tag}: ANCHOR_TRANSITIVE_CONE_HASH_MISMATCH:{cname}")
            if a_row.get("presentInBothLayer2AndWorkerCones") is not True:
                g7_errs.append(f"{tag}: ANCHOR_NOT_SHARED_IN_BOTH_CONES:{cname}")

    direct_consts = set(l2.get("layer2DirectBodyConstants", []))
    for fb in exp_l2["forbiddenDirectWorkerTopSpecs"]:
        if fb in direct_consts:
            g7_errs.append(f"{tag}: forbidden worker top-spec {fb} referenced in Layer-2 body")

    # --- G8: Soundness, Mutants, Stale-State, `|U_rule| = 0`, Anti-Circularity, Consumer ---
    pos_rows = obs.get("live14PositiveObservations", [])
    if [r.get("id") for r in pos_rows] != oracle["positiveWitnessIds"] or not all(r.get("passed") is True for r in pos_rows):
        g8_errs.append(f"{tag}: live14PositiveObservations failed")

    ce_rows = obs.get("live37CounterexampleSubcaseObservations", [])
    if [r.get("id") for r in ce_rows] != oracle["counterexampleIds"] or not all(r.get("passed") is True for r in ce_rows):
        g8_errs.append(f"{tag}: live37CounterexampleSubcaseObservations failed")

    reg_rows = obs.get("registered12MutantObservations", [])
    if [r.get("mutantId") for r in reg_rows] != oracle["registeredMutantIds"] or not all(r.get("killed") is True for r in reg_rows):
        g8_errs.append(f"{tag}: registered12MutantObservations failed")

    e2e_rows = obs.get("endToEnd10SingleFaultMutantObservations", [])
    if [r.get("mutantId") for r in e2e_rows] != oracle["endToEndMutantIds"] or not all(
        r.get("killed") is True and r.get("preservesPosB4_01") is True for r in e2e_rows
    ):
        g8_errs.append(f"{tag}: endToEnd10SingleFaultMutantObservations failed")

    stale_rows = obs.get("staleState6InvalidationObservations", [])
    if [r.get("probeId") for r in stale_rows] != oracle["staleStateInvalidationIds"] or not all(r.get("passed") is True for r in stale_rows):
        g8_errs.append(f"{tag}: staleState6InvalidationObservations failed")

    if obs.get("equivalentMutantEQ01Verified") is not True:
        g8_errs.append(f"{tag}: equivalentMutantEQ01Verified false")
    if obs.get("privateConstructorSealNC01Verified") is not True:
        g8_errs.append(f"{tag}: privateConstructorSealNC01Verified false")
    if obs.get("unclassifiedRelevantDeclarationCount") != 0:
        g8_errs.append(f"{tag}: unclassifiedRelevantDeclarationCount != 0")
    if obs.get("exhaustiveDeclarationClassificationCounts") != oracle["expectedExhaustiveClassificationCounts"]:
        g8_errs.append(f"{tag}: exhaustiveDeclarationClassificationCounts mismatch")
    if obs.get("semanticConeDisjointFromExecutableCheckers") is not True:
        g8_errs.append(f"{tag}: semanticConeDisjointFromExecutableCheckers false")

    cons = obs.get("provenanceBoundConsumerChecks", {})
    if cons.get("unboundSpoofPossible") is not True or cons.get("provenanceBoundConsumerBlocksSpoofAndAcceptsValid") is not True:
        g8_errs.append(f"{tag}: provenanceBoundConsumerChecks failed")

    try:
        _ = project_cansem_r3(obs, env_spec)
    except ValueError as exc:
        g8_errs.append(f"{tag}: CanSem R3 projection error: {exc}")

    all_errs = g4_errs + g5_errs + g6_errs + g7_errs + g8_errs
    flags = {
        "G4_OracleTemporalAndQuadrupleLineage": 1 if g4_errs else 0,
        "G5_Exact63TheoremSetAndOrder": 1 if g5_errs else 0,
        "G6_KernelTypePinAndAxiomClosure": 1 if g6_errs else 0,
        "G7_TypedAnchor5TupleAndLayer2Scope": 1 if g7_errs else 0,
        "G8_SoundnessMutantsStaleAndUrule": 1 if g8_errs else 0,
    }
    return (len(all_errs) == 0), all_errs, flags


def validate_replay_pair_against_spec_r3(
    obs_r1: dict[str, Any],
    obs_r2: dict[str, Any],
    oracle: dict[str, Any],
    env_spec: dict[str, Any],
    expected_h_s: str,
    expected_h_o_r3: str,
    expected_t24_oracle_sha: str,
    expected_r0_failed_oracle_sha: str,
    expected_r1_policy_failed_oracle_sha: str,
    expected_r2_generator_failed_oracle_sha: str,
    tag1: str = "R1",
    tag2: str = "R2",
) -> tuple[bool, list[str], str, str, dict[str, int]]:
    ok1, errs1, fl1 = validate_single_observation_against_spec_r3(
        tag1, obs_r1, oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    ok2, errs2, fl2 = validate_single_observation_against_spec_r3(
        tag2, obs_r2, oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    errors = errs1 + errs2
    g9_err = 0

    can1_sha = ""
    can2_sha = ""
    try:
        can1_sha = canonical_json_sha256(project_cansem_r3(obs_r1, env_spec))
        can2_sha = canonical_json_sha256(project_cansem_r3(obs_r2, env_spec))
        if can1_sha != can2_sha:
            errors.append(f"CanSem({tag1}) != CanSem({tag2}): {can1_sha} != {can2_sha}")
            g9_err = 1
    except ValueError as exc:
        errors.append(f"CanSem pair projection failure: {exc}")
        g9_err = 1

    merged_flags = {
        "G1_StrictJsonParser": 0,
        "G2_ZeroPrebuildCache": 0,
        "G3_WriteIsolationAndReparse": 0,
        "G4_OracleTemporalAndQuadrupleLineage": max(fl1["G4_OracleTemporalAndQuadrupleLineage"], fl2["G4_OracleTemporalAndQuadrupleLineage"]),
        "G5_Exact63TheoremSetAndOrder": max(fl1["G5_Exact63TheoremSetAndOrder"], fl2["G5_Exact63TheoremSetAndOrder"]),
        "G6_KernelTypePinAndAxiomClosure": max(fl1["G6_KernelTypePinAndAxiomClosure"], fl2["G6_KernelTypePinAndAxiomClosure"]),
        "G7_TypedAnchor5TupleAndLayer2Scope": max(fl1["G7_TypedAnchor5TupleAndLayer2Scope"], fl2["G7_TypedAnchor5TupleAndLayer2Scope"]),
        "G8_SoundnessMutantsStaleAndUrule": max(fl1["G8_SoundnessMutantsStaleAndUrule"], fl2["G8_SoundnessMutantsStaleAndUrule"]),
        "G9_CrossReplayAndOrthogonalAuthority": g9_err,
    }
    return (ok1 and ok2 and len(errors) == 0), errors, can1_sha, can2_sha, merged_flags


def gf2_rank(bin_matrix: list[list[int]]) -> int:
    if not bin_matrix or not bin_matrix[0]:
        return 0
    m = [row[:] for row in bin_matrix]
    rows = len(m)
    cols = len(m[0])
    rank = 0
    for c in range(cols):
        pivot = None
        for r in range(rank, rows):
            if m[r][c] & 1:
                pivot = r
                break
        if pivot is None:
            continue
        m[rank], m[pivot] = m[pivot], m[rank]
        for r in range(rows):
            if r != rank and (m[r][c] & 1):
                for j in range(c, cols):
                    m[r][j] ^= m[rank][j]
        rank += 1
    return rank


def run_exec_b4_r1_08_strict_json_suite() -> dict[str, Any]:
    cases: list[dict[str, Any]] = []
    valid_payload = '{"verdict": "PASS", "nested": {"count": 63, "items": [{"a": 1}, {"b": 2}]}}'
    parsed_valid = strict_json_loads(valid_payload)
    cases.append({
        "caseId": "JSON-STRICT-01-VALID",
        "expected": "ACCEPT",
        "passed": parsed_valid["verdict"] == "PASS" and parsed_valid["nested"]["count"] == 63,
    })

    for cid, payload in [
        ("JSON-STRICT-02-TOP-DUP-CE29", '{"verdict": "REJECT", "verdict": "FORGED_PASS"}'),
        ("JSON-STRICT-03-NESTED-DUP", '{"header": {"ok": true, "inner": {"x": 1, "x": 2}}}'),
        ("JSON-STRICT-04-ARRAY-OBJ-DUP", '{"rows": [{"id": "A"}, {"id": "B", "id": "C"}]}'),
        ("JSON-STRICT-05-UNICODE-ESCAPE-DUP-CE36", '{"verdict": "REJECT", "verdic\\u0074": "FORGED_PASS"}'),
    ]:
        try:
            strict_json_loads(payload)
            ok = False
        except DuplicateJsonKeyError:
            ok = True
        cases.append({"caseId": cid, "expected": "REJECT_DUP", "passed": ok})

    return {
        "contractId": "EXEC-B4-R1-08",
        "cpythonStdlibFormalRefinementStatus": "HELD",
        "totalCases": len(cases),
        "passedCases": sum(1 for c in cases if c["passed"]),
        "allPassed": all(c["passed"] for c in cases),
        "cases": cases,
    }


def run_all_21_calibrations_and_response_matrix(
    obs_r1: dict[str, Any],
    obs_r2: dict[str, Any],
    oracle: dict[str, Any],
    env_spec: dict[str, Any],
    expected_h_s: str,
    expected_h_o_r3: str,
    expected_t24_oracle_sha: str,
    expected_r0_failed_oracle_sha: str,
    expected_r1_policy_failed_oracle_sha: str,
    expected_r2_generator_failed_oracle_sha: str,
) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    matrix_rows: list[dict[str, Any]] = []

    def record_obs_pair_fault(cal_id: str, desc: str, m1: dict[str, Any], m2: dict[str, Any]) -> None:
        ok, errs, _, _, flags = validate_replay_pair_against_spec_r3(
            m1, m2, oracle, env_spec, expected_h_s, expected_h_o_r3,
            expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
            expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
        )
        caught = (not ok) and len(errs) > 0
        results.append({
            "calibrationId": cal_id,
            "injectedFault": desc,
            "validatorRejectedAsExpected": caught,
            "firstDiagnostic": errs[0] if errs else "UNCAUGHT",
        })
        matrix_rows.append({
            "calibrationId": cal_id,
            "responses": {g: flags[g] for g in GUARD_COLUMNS_9},
        })

    # 1..7: CAL-B4-01 .. CAL-B4-07
    f1 = copy.deepcopy(obs_r1)
    f1["oraclePostRunSha256MatchesPreRun"] = False
    record_obs_pair_fault("CAL-B4-01", "Post-run precommitted R3 oracle SHA mismatch", f1, copy.deepcopy(obs_r2))

    f2 = copy.deepcopy(obs_r1)
    f2["headline63AxiomClosures"][17]["kernelIsDefEqVerified"] = False
    record_obs_pair_fault("CAL-B4-02", "Broken kernel isDefEq pin on Pin_18_T_D0_A4_07", f2, copy.deepcopy(obs_r2))

    f3 = copy.deepcopy(obs_r1)
    f3["headline63AxiomClosures"][40]["transitiveAxioms"].append("sorryAx")
    record_obs_pair_fault("CAL-B4-03", "Injected sorryAx into Master Soundness axiom closure", f3, copy.deepcopy(obs_r2))

    f4 = copy.deepcopy(obs_r1)
    f4["headline63AxiomClosures"][9]["transitiveAxioms"].append("Lean.ofReduceBool")
    record_obs_pair_fault("CAL-B4-04", "Injected Lean.ofReduceBool (native_decide) trust axiom", f4, copy.deepcopy(obs_r2))

    f5 = copy.deepcopy(obs_r1)
    f5["unclassifiedRelevantDeclarationCount"] = 1
    record_obs_pair_fault("CAL-B4-05", "Unclassified B4 constant leak (|U_rule| = 1)", f5, copy.deepcopy(obs_r2))

    f6 = copy.deepcopy(obs_r1)
    f6["endToEnd10SingleFaultMutantObservations"][6]["killed"] = False
    record_obs_pair_fault("CAL-B4-06", "Surviving end-to-end mutant E2E-B4-07", f6, copy.deepcopy(obs_r2))

    f7_r2 = copy.deepcopy(obs_r2)
    f7_r2["layer2SemanticAudit"]["sharedTransitiveConeSize"] += 1
    record_obs_pair_fault("CAL-B4-07", "Cross-replay CanSem(R1) != CanSem(R2) drift", copy.deepcopy(obs_r1), f7_r2)

    # 8: CAL-B4-08
    try:
        strict_json_loads('{"allChecksPassed": false, "allChecksPassed": true}')
        cal8_ok, cal8_diag = False, "UNCAUGHT"
    except DuplicateJsonKeyError as exc:
        cal8_ok, cal8_diag = True, str(exc)
    results.append({
        "calibrationId": "CAL-B4-08",
        "injectedFault": "Duplicate-key JSON spoofing payload (CE-B4-29 / EXEC-B4-R1-08)",
        "validatorRejectedAsExpected": cal8_ok,
        "firstDiagnostic": cal8_diag,
    })
    matrix_rows.append({
        "calibrationId": "CAL-B4-08",
        "responses": {
            "G1_StrictJsonParser": 1 if cal8_ok else 0,
            **{g: "NOT_OBSERVED" for g in GUARD_COLUMNS_9[1:]},
        },
    })

    # 9..15: CAL-I1-01 .. CAL-I1-07
    c1 = copy.deepcopy(obs_r1)
    c1["headline63AxiomClosures"][62] = copy.deepcopy(c1["headline63AxiomClosures"][0])
    record_obs_pair_fault("CAL-I1-01", "Duplicate theorem identifier filling 63 slots", c1, copy.deepcopy(obs_r2))

    c2 = copy.deepcopy(obs_r1)
    c2["headline63AxiomClosures"][17]["theoremName"] = "OmegaCellC1P1B2BB4.T_IMPERSONATOR_SUBSTITUTE"
    record_obs_pair_fault("CAL-I1-02", "Substitute theorem identifier while keeping 63 unique entries", c2, copy.deepcopy(obs_r2))

    with tempfile.TemporaryDirectory(prefix="cal_i1_03_cache_") as td:
        td_path = Path(td)
        stale_olean = td_path / "research" / "principia_omega_cell_c1_p1a0_lean4" / ".lake" / "build" / "lib" / "lean" / "OmegaCellC1P1A0.olean"
        stale_olean.parent.mkdir(parents=True, exist_ok=True)
        stale_olean.write_bytes(b"CACHED_OLEAN")
        z_ok, z_hits = verify_zero_preexisting_build_artifacts(td_path)
    cal_i1_03_ok = (not z_ok) and len(z_hits) > 0
    results.append({
        "calibrationId": "CAL-I1-03",
        "injectedFault": "Pre-existing transitive dependency build artifact (.lake/build/.../OmegaCellC1P1A0.olean)",
        "validatorRejectedAsExpected": cal_i1_03_ok,
        "firstDiagnostic": f"PREEXISTING_BUILD_CACHE_DETECTED: {z_hits[0]}" if z_hits else "UNCAUGHT",
    })
    matrix_rows.append({
        "calibrationId": "CAL-I1-03",
        "responses": {
            "G1_StrictJsonParser": 0,
            "G2_ZeroPrebuildCache": 1 if cal_i1_03_ok else 0,
            **{g: "NOT_OBSERVED" for g in GUARD_COLUMNS_9[2:]},
        },
    })

    c4 = copy.deepcopy(obs_r1)
    c4["t24PrecedentOracleSha256"] = "0" * 64
    record_obs_pair_fault("CAL-I1-04", "T24 precedent oracle SHA-256 mismatch", c4, copy.deepcopy(obs_r2))

    c5 = copy.deepcopy(obs_r1)
    c5["layer2SemanticAudit"]["independenceScope"] = "FULL_STACK_SEMANTIC_INDEPENDENCE"
    c5["layer2SemanticAudit"]["fullStackSemanticIndependenceClaimed"] = True
    record_obs_pair_fault("CAL-I1-05", "Misclassify Layer-2 shared lower semantics as full-stack independent", c5, copy.deepcopy(obs_r2))

    with tempfile.TemporaryDirectory(prefix="cal_i1_06_iso_") as td6:
        td6_root = Path(td6)
        fake_frozen_i0 = td6_root / "principia_omega_cell_c1_p1b2b_b4_i0_evidence"
        fake_allowed_r3 = td6_root / "principia_omega_cell_c1_p1b2b_b4_i1_r3_evidence"
        fake_frozen_i0.mkdir(parents=True, exist_ok=True)
        fake_allowed_r3.mkdir(parents=True, exist_ok=True)

        try:
            enforce_write_isolation_guard(fake_frozen_i0 / "forged.json", [fake_allowed_r3], [fake_frozen_i0])
            direct_halted, direct_msg = False, "UNCAUGHT"
        except WriteIsolationHaltError as exc:
            direct_halted, direct_msg = True, str(exc)

        try:
            enforce_write_isolation_guard(
                fake_allowed_r3 / ".." / "principia_omega_cell_c1_p1b2b_b4_i0_evidence" / "escape.json",
                [fake_allowed_r3],
                [fake_frozen_i0],
            )
            trav_halted = False
        except WriteIsolationHaltError:
            trav_halted = True

        link_dir = fake_allowed_r3 / "linked_i0_trap"
        if os.name == "nt":
            subprocess.run(["cmd", "/c", "mklink", "/J", str(link_dir), str(fake_frozen_i0)], capture_output=True)
        else:
            os.symlink(fake_frozen_i0, link_dir)
        try:
            enforce_write_isolation_guard(link_dir / "junction_escape.json", [fake_allowed_r3], [fake_frozen_i0])
            reparse_halted = False
        except WriteIsolationHaltError:
            reparse_halted = True
        finally:
            if os.name == "nt" and link_dir.exists():
                subprocess.run(["cmd", "/c", "rmdir", str(link_dir)], capture_output=True)
            elif link_dir.is_symlink():
                link_dir.unlink()

    cal6_ok = direct_halted and trav_halted and reparse_halted
    results.append({
        "calibrationId": "CAL-I1-06",
        "injectedFault": "Write replay result to frozen path (direct + .. traversal + symlink/Windows junction)",
        "validatorRejectedAsExpected": cal6_ok,
        "firstDiagnostic": direct_msg if cal6_ok else "UNCAUGHT",
    })
    matrix_rows.append({
        "calibrationId": "CAL-I1-06",
        "responses": {
            "G1_StrictJsonParser": 0,
            "G2_ZeroPrebuildCache": 0,
            "G3_WriteIsolationAndReparse": 1 if cal6_ok else 0,
            **{g: "NOT_OBSERVED" for g in GUARD_COLUMNS_9[3:]},
        },
    })

    c7_r1 = copy.deepcopy(obs_r1)
    c7_r2 = copy.deepcopy(obs_r2)
    c7_r1["headline63AxiomClosures"] = c7_r1["headline63AxiomClosures"][:62]
    c7_r2["headline63AxiomClosures"] = c7_r2["headline63AxiomClosures"][:62]
    record_obs_pair_fault("CAL-I1-07", "Identical missing theorem set (62/63) in both R1 and R2", c7_r1, c7_r2)

    # 16..21: CAL-I1-R1-01 .. CAL-I1-R1-06
    r1_c1 = copy.deepcopy(obs_r1)
    r1_c1["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["canonicalName"] = "OmegaCellC1P1B2BB1.InEffDom"
    r1_c1["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["existsInEnvironment"] = False
    record_obs_pair_fault(
        "CAL-I1-R1-01",
        "Specify non-existent canonical constant name OmegaCellC1P1B2BB1.InEffDom (exact R0 defect)",
        r1_c1,
        copy.deepcopy(obs_r2),
    )

    r1_c2 = copy.deepcopy(obs_r1)
    r1_c2["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["canonicalName"] = "OmegaCellC1P1B2BA0.DomNzGuards"
    record_obs_pair_fault(
        "CAL-I1-R1-02",
        "Substitute existing wrong declaration OmegaCellC1P1B2BA0.DomNzGuards for InEffDom",
        r1_c2,
        copy.deepcopy(obs_r2),
    )

    r1_c3a = copy.deepcopy(obs_r1)
    r1_c3a["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["kernelIsDefEqAnchorPinVerified"] = False
    ok3a, errs3a, _, _, fl3 = validate_replay_pair_against_spec_r3(
        r1_c3a, copy.deepcopy(obs_r2), oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    r1_c3b = copy.deepcopy(obs_r1)
    r1_c3b["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["definingModule"] = "OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics"
    ok3b, errs3b, _, _, _ = validate_replay_pair_against_spec_r3(
        r1_c3b, copy.deepcopy(obs_r2), oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    r1_c3c = copy.deepcopy(obs_r1)
    r1_c3c["layer2SemanticAudit"]["boundSharedLowerAnchors5"][3]["transitiveDepConeSha256_H_transitive"] = "F" * 64
    ok3c, errs3c, _, _, _ = validate_replay_pair_against_spec_r3(
        r1_c3c, copy.deepcopy(obs_r2), oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    c3_all = (not ok3a) and (not ok3b) and (not ok3c)
    results.append({
        "calibrationId": "CAL-I1-R1-03",
        "injectedFault": "Correct constant name with mismatched kernel isDefEq type, definingModule M(c), or H_transitive(c)",
        "validatorRejectedAsExpected": c3_all,
        "firstDiagnostic": f"{errs3a[0]} | {errs3b[0]} | {errs3c[0]}" if c3_all else "UNCAUGHT",
    })
    matrix_rows.append({"calibrationId": "CAL-I1-R1-03", "responses": {g: fl3[g] for g in GUARD_COLUMNS_9}})

    r1_c4a = copy.deepcopy(obs_r1)
    r1_c4a["preservedR0FailedOracleSha256"] = expected_h_o_r3
    ok4a, errs4a, _, _, fl4 = validate_replay_pair_against_spec_r3(
        r1_c4a, copy.deepcopy(obs_r2), oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    r1_c4b = copy.deepcopy(obs_r1)
    r1_c4b["oraclePreRunSha256_H_O_I1_R3"] = expected_r0_failed_oracle_sha
    ok4b, errs4b, _, _, _ = validate_replay_pair_against_spec_r3(
        r1_c4b, copy.deepcopy(obs_r2), oracle, env_spec, expected_h_s, expected_h_o_r3,
        expected_t24_oracle_sha, expected_r0_failed_oracle_sha,
        expected_r1_policy_failed_oracle_sha, expected_r2_generator_failed_oracle_sha,
    )
    c4_all = (not ok4a) and (not ok4b)
    results.append({
        "calibrationId": "CAL-I1-R1-04",
        "injectedFault": "Unauthorized replacement/collapse of R0/R1/R2 failed oracle lineage slots with R3 oracle",
        "validatorRejectedAsExpected": c4_all,
        "firstDiagnostic": f"{errs4a[0]} | {errs4b[0]}" if c4_all else "UNCAUGHT",
    })
    matrix_rows.append({"calibrationId": "CAL-I1-R1-04", "responses": {g: fl4[g] for g in GUARD_COLUMNS_9}})

    forged_trace_r1_warn = [
        make_orthogonal_trace_node_r3(
            "RL1_A4_9PkgColdBuild",
            "/tmp/fake_rl1",
            "attempt_cal",
            [],
            "BUILD_COMPLETED",
            0,
            0,
            1,
            "POLICY_FAILED",
            "EXECUTION_FAILED",
            0,
            "NOT_APPLICABLE",
            None,
            "SPEC_MISMATCHED",
            ["ZERO_WARNING_POLICY_FAILED: 1 warning(s)"],
            True,
        ),
    ]
    tr5_ok, tr5_reasons = evaluate_orthogonal_gate_trace_eligibility(forged_trace_r1_warn)
    cal_r1_05_ok = (not tr5_ok) and len(tr5_reasons) > 0
    results.append({
        "calibrationId": "CAL-I1-R1-05",
        "injectedFault": "Classify BUILD_COMPLETED (ExitCode=0) as overall pass despite zeroWarningPolicyState=POLICY_FAILED or EXECUTION_FAILED",
        "validatorRejectedAsExpected": cal_r1_05_ok,
        "firstDiagnostic": tr5_reasons[0] if tr5_reasons else "UNCAUGHT",
    })
    matrix_rows.append({
        "calibrationId": "CAL-I1-R1-05",
        "responses": {
            **{g: 0 for g in GUARD_COLUMNS_9[:8]},
            "G9_CrossReplayAndOrthogonalAuthority": 1 if cal_r1_05_ok else 0,
        },
    })

    a10_ok_a, a10_msg_a = validate_a10_authority_gate(forged_trace_r1_warn, True, True)
    clean_node = [
        make_orthogonal_trace_node_r3(
            "RL1_A4_9PkgColdBuild", "/tmp/ok", "att", [], "BUILD_COMPLETED", 0, 0, 0,
            "POLICY_PASSED", "EXECUTION_COMPLETED", 0, "NOT_APPLICABLE", None, "SPEC_MATCHED", [], True
        )
    ]
    a10_ok_b, a10_msg_b = validate_a10_authority_gate(clean_node, False, True)
    c6_all = (not a10_ok_a) and (not a10_ok_b)
    results.append({
        "calibrationId": "CAL-I1-R1-06",
        "injectedFault": "Grant A10 external execution eligibility while local gate or calibration failed",
        "validatorRejectedAsExpected": c6_all,
        "firstDiagnostic": f"{a10_msg_a} | {a10_msg_b}" if c6_all else "UNCAUGHT",
    })
    matrix_rows.append({
        "calibrationId": "CAL-I1-R1-06",
        "responses": {
            **{g: 0 for g in GUARD_COLUMNS_9[:8]},
            "G9_CrossReplayAndOrthogonalAuthority": 1 if c6_all else 0,
        },
    })

    detected_rows = sum(
        1 for mr in matrix_rows if any(v == 1 for v in mr["responses"].values())
    )
    distinct_patterns = len({
        tuple(mr["responses"][g] for g in GUARD_COLUMNS_9)
        for mr in matrix_rows
    })
    bool_projected = [
        [1 if mr["responses"][g] == 1 else 0 for g in GUARD_COLUMNS_9]
        for mr in matrix_rows
    ]
    rank_f2 = gf2_rank(bool_projected)

    all_21_caught = all(r["validatorRejectedAsExpected"] for r in results) and len(results) == 21
    return {
        "totalCalibrations": len(results),
        "caughtCalibrations": sum(1 for r in results if r["validatorRejectedAsExpected"]),
        "inheritedB4CalibrationsCaught_8": sum(1 for r in results[:8] if r["validatorRejectedAsExpected"]),
        "t24CalibrationsCaught_7": sum(1 for r in results[8:15] if r["validatorRejectedAsExpected"]),
        "newR1CalibrationsCaught_6": sum(1 for r in results[15:] if r["validatorRejectedAsExpected"]),
        "all21Caught": all_21_caught,
        "results": results,
        "interventionalFaultGuardResponseMatrix_R2_beta": {
            "matrixName": "Interventional Fault–Guard Response Matrix",
            "generalFaultSpaceCompletenessClaimed": False,
            "pearlDoCalculusTheoremClaimed": False,
            "guardColumns9": GUARD_COLUMNS_9,
            "rowCount": len(matrix_rows),
            "C_detect_Ratio": round(detected_rows / 21.0, 6),
            "C_detect_Exact": f"{detected_rows}/21",
            "C_distinguish_Ratio": round(distinct_patterns / 21.0, 6),
            "C_distinguish_Exact": f"{distinct_patterns}/21",
            "rankOverGF2_ObservedProjected": rank_f2,
            "maxPossibleRankOver9Guards": 9,
            "rows": matrix_rows,
        },
    }
