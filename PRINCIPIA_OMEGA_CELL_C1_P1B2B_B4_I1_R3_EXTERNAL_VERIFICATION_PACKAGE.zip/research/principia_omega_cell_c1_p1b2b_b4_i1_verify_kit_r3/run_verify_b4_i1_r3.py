#!/usr/bin/env python3
"""
PRINCIPIA Ω-CELL-C1-P1B2B-B4 — ACT-I1 R3 Detached External Replay & Authority Closure CLI (`KitB4I1-R3`)
Driver: run_verify_b4_i1_r3.py

Modes:
  1. `--mode pre-r3-check`        : Authorized isolated syntax/type/linter preflight (`W=0, E=0`) +
                                    `H_generated == H_audited == H_compiled` check (`R3-Q3`) +
                                    unmodified R1 vs R3 elaborated Core `Expr` `nu_alpha_rho` verification (`R3-Q5`).
  2. `--mode local-double-replay` : Disjoint 9-pkg cold replays `RL1_R3` & `RL2_R3` + `21` calibrations + `21x9` response matrix.
  3. `--mode single-replay`       : Isolated 9-pkg cold replay + `21` calibrations (`RE1` or `RE2` on fresh Linux VM).
  4. `--mode verify-external-pair`: Closure VM verification (`if: always()`, collects failure evidence without false authority).
"""

from __future__ import annotations

import argparse
import copy
import datetime
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path
from typing import Any

from audit_b4_i1_r3_core import (
    KIT_I1_R3_LEAN_FILES,
    build_sanitized_lean_env,
    canonical_json_sha256,
    count_warnings_and_errors,
    enforce_write_isolation_guard,
    evaluate_orthogonal_gate_trace_eligibility,
    project_cansem_r3,
    resolve_upstream_source_file,
    run_all_21_calibrations_and_response_matrix,
    run_exec_b4_r1_08_strict_json_suite,
    run_single_isolated_9pkg_cold_replay_r3,
    sha256_bytes,
    sha256_file,
    strict_json_loads,
    validate_a10_authority_gate,
    validate_replay_pair_against_spec_r3,
    verify_active_74_sources_and_9pkg_dag,
    verify_cmto_generated_audited_compiled_hashes,
)

WORK_ID_R3 = (
    "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B4_ACT_I1_R3_"
    "CERTIFIED_MINIMAL_TRANSFORMATION_AND_DETACHED_EXTERNAL_REPLAY"
)

INSPECT_CORE_EXPR_SINGLE_LEAN = """import Lean
open Lean

def biTag : BinderInfo → String
  | .default => "def"
  | .implicit => "imp"
  | .strictImplicit => "simp"
  | .instImplicit => "inst"

def litTag : Literal → String
  | .natVal n => s!"nat:{n}"
  | .strVal s => s!"str:{s}"

partial def eraseBindersSexp : Expr → String
  | .bvar i => s!"(bvar {i})"
  | .sort u => s!"(sort {u})"
  | .const n us =>
      let uStr := String.intercalate "," (us.map toString)
      s!"(const {n} [{uStr}])"
  | .app f a => s!"(app {eraseBindersSexp f} {eraseBindersSexp a})"
  | .lam _ t b bi => s!"(lam {biTag bi} {eraseBindersSexp t} {eraseBindersSexp b})"
  | .forallE _ t b bi => s!"(forall {biTag bi} {eraseBindersSexp t} {eraseBindersSexp b})"
  | .letE _ t v b nonDep => s!"(let {nonDep} {eraseBindersSexp t} {eraseBindersSexp v} {eraseBindersSexp b})"
  | .lit l => s!"(lit {litTag l})"
  | .mdata _ e => eraseBindersSexp e
  | .proj s i e => s!"(proj {s} {i} {eraseBindersSexp e})"
  | .fvar id => s!"(fvar {id.name})"
  | .mvar id => s!"(mvar {id.name})"

def dumpDeclJson (env : Environment) (declName : Name) : Option Json :=
  match env.find? declName with
  | some (.defnInfo v) =>
      let used := (v.value.getUsedConstants.toList.map Name.toString).mergeSort (· < ·)
      some (Json.mkObj [
        ("name", Json.str declName.toString),
        ("kind", Json.str "defnInfo"),
        ("typeSexp", Json.str (eraseBindersSexp v.type)),
        ("valueSexp", Json.str (eraseBindersSexp v.value)),
        ("usedConstants", Json.arr (used.map Json.str).toArray)
      ])
  | some (.thmInfo v) =>
      let used := (v.value.getUsedConstants.toList.map Name.toString).mergeSort (· < ·)
      some (Json.mkObj [
        ("name", Json.str declName.toString),
        ("kind", Json.str "thmInfo"),
        ("typeSexp", Json.str (eraseBindersSexp v.type)),
        ("valueSexp", Json.str (eraseBindersSexp v.value)),
        ("usedConstants", Json.arr (used.map Json.str).toArray)
      ])
  | _ => none

def main (args : List String) : IO UInt32 := do
  let (modArg, outPath) := match args with
    | m :: o :: _ => (m, o)
    | [m] => (m, "core_expr_dump.json")
    | [] => ("ExternalObsB4I1R3", "core_expr_dump.json")
  let modName : Name :=
    if modArg == "ExternalObsB4I1R1" then `ExternalObsB4I1R1 else `ExternalObsB4I1R3
  initSearchPath (← findSysroot)
  let rawEnv ← importModules #[{ module := modName, importAll := true }] {}
  let env := rawEnv.setExporting false
  match env.find? `inspectSharedAnchorBind5 with
  | some (.defnInfo v) =>
      let targetType := eraseBindersSexp v.type
      let targetVal  := eraseBindersSexp v.value
      let usedList   := v.value.getUsedConstants.toList
      let usedStrs   := (usedList.map Name.toString).mergeSort (· < ·)
      let mut auxArr : Array Json := #[]
      for us in usedStrs do
        if (us.startsWith "_private.ExternalObsB4I1") || (us == "checkPinAndPrettyType") then
          for c in usedList do
            if c.toString == us then
              match dumpDeclJson env c with
              | some j => auxArr := auxArr.push j
              | none   => pure ()
      let out := Json.mkObj [
        ("module", Json.str modArg),
        ("targetDeclaration", Json.str "inspectSharedAnchorBind5"),
        ("typeSexp", Json.str targetType),
        ("valueSexp", Json.str targetVal),
        ("directUsedConstants", Json.arr (usedStrs.map Json.str).toArray),
        ("inspectedAuxDeclarations", Json.arr auxArr)
      ]
      IO.FS.writeFile outPath (out.pretty ++ "\\n")
      return 0
  | _ => return 1
"""


def write_json_lf(
    target: Path,
    obj: dict[str, Any],
    allowed_roots: list[Path],
    protected_roots: list[Path],
) -> tuple[int, str]:
    enforce_write_isolation_guard(target, allowed_roots, protected_roots)
    raw = (json.dumps(obj, indent=2, ensure_ascii=False).replace("\r\n", "\n") + "\n").encode("utf-8")
    target.write_bytes(raw)
    return len(raw), sha256_bytes(raw)


def compute_protected_roots_for_source_root(source_root: Path, t24_zip_path: Path | None) -> list[Path]:
    """
    Protects ALL upstream packages, ALL B4 ACT-I0 directories, AND ALL R0, R1, R2 directories!
    """
    roots: list[Path] = []
    res_dir = source_root / "research"
    if res_dir.is_dir():
        for child in res_dir.iterdir():
            if child.name not in (
                "principia_omega_cell_c1_p1b2b_b4_i1_r3_evidence",
                "principia_omega_cell_c1_p1b2b_b4_i1_verify_kit_r3",
            ):
                roots.append(child)
    sc_dir = source_root / "self_contained_sources"
    if sc_dir.exists():
        roots.append(sc_dir)
    if t24_zip_path is not None and t24_zip_path.exists():
        roots.append(t24_zip_path)
    return roots


def _restore_writable_tree(root: Path) -> None:
    for r, _, files in os.walk(root):
        rp = Path(r)
        try:
            os.chmod(rp, stat.S_IWRITE | stat.S_IREAD | stat.S_IEXEC)
        except OSError:
            pass
        for fn in files:
            fp = rp / fn
            try:
                os.chmod(fp, stat.S_IWRITE | stat.S_IREAD)
            except OSError:
                pass


def apply_strict_r1_to_r3_private_rho(sexp: str) -> tuple[str, list[tuple[str, str]]]:
    """
    R3-Q5: Applies ONLY the explicitly permitted module-private auxiliary prefix mapping:
      _private.ExternalObsB4I1R1.0.<suffix>  -->  _private.ExternalObsB4I1R3.0.<suffix>
    Does NOT erase or alter any user or library constant names!
    """
    import re

    pairs: list[tuple[str, str]] = []
    seen: set[str] = set()
    for m in re.finditer(r"_private\.ExternalObsB4I1R1\.0\.[A-Za-z0-9_'.]+", sexp):
        old_c = m.group(0)
        new_c = old_c.replace("_private.ExternalObsB4I1R1.0.", "_private.ExternalObsB4I1R3.0.", 1)
        if old_c not in seen:
            seen.add(old_c)
            pairs.append((old_c, new_c))
    mapped = sexp.replace("_private.ExternalObsB4I1R1.0.", "_private.ExternalObsB4I1R3.0.")
    return mapped, pairs


def main() -> int:
    parser = argparse.ArgumentParser(description="PRINCIPIA B4 ACT-I1 R3 Verifier")
    parser.add_argument(
        "--mode",
        choices=["pre-r3-check", "local-double-replay", "single-replay", "verify-external-pair"],
        required=True,
    )
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--t24-zip-path", type=Path, default=None)
    parser.add_argument("--r0-oracle-path", type=Path, default=None)
    parser.add_argument("--r1-oracle-path", type=Path, default=None)
    parser.add_argument("--r2-oracle-path", type=Path, default=None)
    parser.add_argument("--r1-kit-dir", type=Path, default=None)
    parser.add_argument("--a1-audit-receipt-path", type=Path, default=None)
    parser.add_argument("--replay-id", type=str, default="RE1")
    parser.add_argument("--attempt-id", type=str, default="1")
    parser.add_argument("--re1-dir", type=Path, default=None)
    parser.add_argument("--re2-dir", type=Path, default=None)
    parser.add_argument("--expected-local-cansem-sha256", type=str, default="")
    parser.add_argument("--executed-workflow-sha256", type=str, default="")
    parser.add_argument("--executed-workflow-bytes", type=int, default=0)
    parser.add_argument("--bundled-workflow-sha256", type=str, default="")
    args = parser.parse_args()

    kit_dir = Path(__file__).resolve().parent
    source_root = args.source_root.resolve()
    evidence_dir = args.evidence_dir.resolve()
    protected_roots = compute_protected_roots_for_source_root(source_root, args.t24_zip_path)
    protected_roots.append(kit_dir)
    allowed_roots = [evidence_dir]

    enforce_write_isolation_guard(evidence_dir / "_probe_guard.json", allowed_roots, protected_roots)
    evidence_dir.mkdir(parents=True, exist_ok=True)

    m74_path = kit_dir / "manifest_active_replay_74_sources.json"
    oracle_path = kit_dir / "b4_i1_r3_precommitted_oracle.json"
    env_spec_path = kit_dir / "b4_i1_r3_environment_and_cansem_spec.json"

    _, h_s_sha = sha256_file(m74_path)
    _, h_o_pre_sha = sha256_file(oracle_path)
    _, h_e_sha = sha256_file(env_spec_path)

    m74 = strict_json_loads(m74_path.read_text(encoding="utf-8"))
    oracle = strict_json_loads(oracle_path.read_text(encoding="utf-8"))
    env_spec = strict_json_loads(env_spec_path.read_text(encoding="utf-8"))

    a1_audit_receipt: dict[str, Any] | None = None
    default_a1_path = evidence_dir / "i1_r3_a1_cmto_independent_audit_receipt.json"
    a1_path = args.a1_audit_receipt_path or (default_a1_path if default_a1_path.is_file() else None)
    if a1_path is not None and a1_path.is_file():
        a1_audit_receipt = strict_json_loads(a1_path.read_text(encoding="utf-8"))

    anchors = oracle["temporalAndFailureLineageAnchors"]
    t24_expected_zip_sha = anchors["t24SubmissionZipSha256"]
    t24_expected_i0_oracle_sha = anchors["t24EmbeddedI0OracleSha256"]
    r0_expected_failed_oracle_sha = anchors["preservedR0FailedOracleSha256"]
    r1_expected_policy_failed_oracle_sha = anchors["preservedR1PolicyFailedOracleSha256"]
    r2_expected_generator_failed_oracle_sha = anchors["preservedR2GeneratorFailedOracleSha256"]

    t24_direct_verified = False
    if args.t24_zip_path is not None:
        t24_sz, t24_sha = sha256_file(args.t24_zip_path)
        if t24_sz != 1100116 or t24_sha != t24_expected_zip_sha:
            print(f"[CRITICAL] T24 precedent archive hash mismatch: {t24_sha}", file=sys.stderr)
            return 1
        with zipfile.ZipFile(args.t24_zip_path, "r") as z24:
            emb_i0_orc = z24.read(
                "research/principia_omega_cell_c1_p1b2b_b4_i0_verify_kit_r0/b4_i0_precommitted_oracle.json"
            )
            if sha256_bytes(emb_i0_orc) != t24_expected_i0_oracle_sha:
                print("[CRITICAL] T24 embedded I0 oracle hash mismatch!", file=sys.stderr)
                return 1
        t24_direct_verified = True

    r0_r1_r2_oracles_direct_verified = False
    if (
        args.r0_oracle_path is not None
        and args.r1_oracle_path is not None
        and args.r2_oracle_path is not None
    ):
        _, r0_actual_sha = sha256_file(args.r0_oracle_path)
        _, r1_actual_sha = sha256_file(args.r1_oracle_path)
        _, r2_actual_sha = sha256_file(args.r2_oracle_path)
        if (
            r0_actual_sha != r0_expected_failed_oracle_sha
            or r1_actual_sha != r1_expected_policy_failed_oracle_sha
            or r2_actual_sha != r2_expected_generator_failed_oracle_sha
            or len({r0_actual_sha, r1_actual_sha, r2_actual_sha, h_o_pre_sha}) != 4
        ):
            print("[CRITICAL] Quadruple I1 oracle lineage mismatch!", file=sys.stderr)
            return 1
        r0_r1_r2_oracles_direct_verified = True

    dag_ok, dag_report = verify_active_74_sources_and_9pkg_dag(source_root, kit_dir, m74, env_spec)
    if not dag_ok:
        write_json_lf(evidence_dir / "i1_r3_failure_dag_report.json", dag_report, allowed_roots, protected_roots)
        print(f"[CRITICAL] 74-source / 9-package DAG preflight failed: {dag_report}", file=sys.stderr)
        return 1

    lean_env, env_meta = build_sanitized_lean_env()
    if lean_env is None:
        print(f"[CRITICAL] Lean 4.33.1 toolchain error: {env_meta}", file=sys.stderr)
        return 1

    # =========================================================================
    # MODE 0: `PRE-R3` Syntax/Type/Linter Preflight + `H_gen == H_aud == H_comp` + `R3-Q5` Core `Expr` Check
    # =========================================================================
    if args.mode == "pre-r3-check":
        lake_exe = shutil.which("lake", path=lean_env.get("PATH"))
        assert lake_exe is not None
        tmp_dir_obj = tempfile.TemporaryDirectory(prefix="principia_b4_i1_r3_PRE_")
        tmp_root = Path(tmp_dir_obj.name)
        try:
            tmp_res = tmp_root / "research"
            for row in m74["sources"]:
                src_fp = resolve_upstream_source_file(source_root, row)
                dst_fp = tmp_res / Path(*row["mirrorRelPath"].split("/"))
                dst_fp.parent.mkdir(parents=True, exist_ok=True)
                dst_fp.write_bytes(src_fp.read_bytes())

            tmp_kit_r3 = tmp_res / "principia_omega_cell_c1_p1b2b_b4_i1_verify_kit_r3"
            tmp_kit_r3.mkdir(parents=True, exist_ok=True)
            for kfn in KIT_I1_R3_LEAN_FILES:
                (tmp_kit_r3 / kfn).write_bytes((kit_dir / kfn).read_bytes())

            # R3-Q3: Verify H_generated == H_audited == H_compiled BEFORE build!
            triple_pre_ok, triple_pre_rep = verify_cmto_generated_audited_compiled_hashes(
                tmp_kit_r3, env_spec, a1_audit_receipt
            )

            # Phase A: Pure `KitB4I1-R3` cold build (`0` extra files -> strict `W=0, E=0` check!)
            t0 = time.time()
            p_kit = subprocess.run(
                [lake_exe, "build"],
                cwd=str(tmp_kit_r3),
                env=lean_env,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            pre_secs = round(time.time() - t0, 3)
            pre_out = (p_kit.stdout or "") + ("\n" + p_kit.stderr if p_kit.stderr else "")
            w_cnt, e_cnt = count_warnings_and_errors(pre_out)

            # R3-Q3: Verify H_generated == H_audited == H_compiled AFTER build!
            triple_post_ok, triple_post_rep = verify_cmto_generated_audited_compiled_hashes(
                tmp_kit_r3, env_spec, a1_audit_receipt
            )

            log_file = evidence_dir / "i1_r3_pre_syntax_type_linter.log"
            enforce_write_isolation_guard(log_file, allowed_roots, protected_roots)
            log_file.write_bytes(pre_out.replace("\r\n", "\n").encode("utf-8"))
            _, log_sha = sha256_file(log_file)

            pre_build_pass = (
                (p_kit.returncode == 0)
                and (w_cnt == 0)
                and (e_cnt == 0)
                and triple_pre_ok
                and triple_post_ok
            )

            # Phase B (`R3-Q5`): Elaborate UNMODIFIED `R1` (`ExternalObsB4I1R1.lean`) in a separate sibling kit dir
            # and compare the actual elaborated Core `Expr` of `inspectSharedAnchorBind5` + all mapped private
            # auxiliaries under explicit verified correspondence `rho`!
            r3_q5_report: dict[str, Any] = {
                "targetDeclaration": "inspectSharedAnchorBind5",
                "comparisonExecuted": False,
                "syntacticSourceSliceIdentical": False,
                "unmappedStrictCoreDeBruijnIdentical_nu_alpha": False,
                "rhoMappedCoreDeBruijnIdentical_nu_alpha_rho": False,
                "allMappedPrivateAuxDefinitionsTypeAndBodyVerified": False,
                "checkPinAndPrettyTypePreservedUpToDiagnosticTag": False,
                "permittedCorrespondence_rho": [],
                "r3TargetTypeDeBruijnSha256": "",
                "r3TargetValueDeBruijnSha256": "",
                "exactKolmogorovComplexityZeroBitsClaimed": False,
                "exactKolmogorovComplexityStatus": "HELD_UNCOMPUTABLE_O_1_THEORETICAL_CONTEXT_ONLY",
            }

            if pre_build_pass and args.r1_kit_dir is not None and args.r1_kit_dir.is_dir():
                r1_lean_files = [
                    "lean-toolchain",
                    "lakefile.toml",
                    "lake-manifest.json",
                    "ExternalSpecPinB4I1R1.lean",
                    "ExternalObsB4I1R1.lean",
                ]
                tmp_kit_r1 = tmp_res / "principia_omega_cell_c1_p1b2b_b4_i1_verify_kit_r1"
                tmp_kit_r1.mkdir(parents=True, exist_ok=True)
                for fn1 in r1_lean_files:
                    (tmp_kit_r1 / fn1).write_bytes((args.r1_kit_dir / fn1).read_bytes())

                _, r1_staged_obs_sha = sha256_file(tmp_kit_r1 / "ExternalObsB4I1R1.lean")
                assert r1_staged_obs_sha == "D7CE5E5A3C7778DCB5BE074ACB9359D8F85173EF7651C887ED63B7B987EA24B7"

                # Build unmodified R1 kit (expected: ExitCode=0, E=0, W=1 on line 293!)
                p_r1_build = subprocess.run(
                    [lake_exe, "build"],
                    cwd=str(tmp_kit_r1),
                    env=lean_env,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                if p_r1_build.returncode == 0:
                    (tmp_kit_r1 / "InspectCoreExprSingle.lean").write_bytes(INSPECT_CORE_EXPR_SINGLE_LEAN.encode("utf-8"))
                    (tmp_kit_r3 / "InspectCoreExprSingle.lean").write_bytes(INSPECT_CORE_EXPR_SINGLE_LEAN.encode("utf-8"))

                    dump_r1_path = tmp_kit_r1 / "dump_r1.json"
                    dump_r3_path = tmp_kit_r3 / "dump_r3.json"

                    p_d1 = subprocess.run(
                        [lake_exe, "env", "lean", "--run", "InspectCoreExprSingle.lean", "ExternalObsB4I1R1", str(dump_r1_path)],
                        cwd=str(tmp_kit_r1),
                        env=lean_env,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                    )
                    p_d3 = subprocess.run(
                        [lake_exe, "env", "lean", "--run", "InspectCoreExprSingle.lean", "ExternalObsB4I1R3", str(dump_r3_path)],
                        cwd=str(tmp_kit_r3),
                        env=lean_env,
                        capture_output=True,
                        text=True,
                        encoding="utf-8",
                        errors="replace",
                    )
                    if p_d1.returncode == 0 and p_d3.returncode == 0 and dump_r1_path.is_file() and dump_r3_path.is_file():
                        d1 = strict_json_loads(dump_r1_path.read_text(encoding="utf-8"))
                        d3 = strict_json_loads(dump_r3_path.read_text(encoding="utf-8"))

                        unmapped_eq = (d1["typeSexp"] == d3["typeSexp"]) and (d1["valueSexp"] == d3["valueSexp"])
                        mapped_t1, pairs_t = apply_strict_r1_to_r3_private_rho(d1["typeSexp"])
                        mapped_v1, pairs_v = apply_strict_r1_to_r3_private_rho(d1["valueSexp"])
                        rho_target_eq = (mapped_t1 == d3["typeSexp"]) and (mapped_v1 == d3["valueSexp"])

                        aux1_map = {a["name"]: a for a in d1["inspectedAuxDeclarations"]}
                        aux3_map = {a["name"]: a for a in d3["inspectedAuxDeclarations"]}

                        all_rho_pairs = list(dict.fromkeys(pairs_t + pairs_v))
                        aux_verifications: list[dict[str, Any]] = []
                        all_priv_aux_ok = True
                        for old_priv, new_priv in all_rho_pairs:
                            a1_obj = aux1_map.get(old_priv)
                            a3_obj = aux3_map.get(new_priv)
                            if a1_obj is None or a3_obj is None:
                                all_priv_aux_ok = False
                                aux_verifications.append({
                                    "r1Constant": old_priv,
                                    "r3Constant": new_priv,
                                    "foundInBothEnvironments": False,
                                    "typeAndValueDeBruijnEqualUnderRho": False,
                                })
                            else:
                                mt, _ = apply_strict_r1_to_r3_private_rho(a1_obj["typeSexp"])
                                mv, _ = apply_strict_r1_to_r3_private_rho(a1_obj["valueSexp"])
                                eq_aux = (mt == a3_obj["typeSexp"]) and (mv == a3_obj["valueSexp"])
                                if not eq_aux:
                                    all_priv_aux_ok = False
                                aux_verifications.append({
                                    "r1Constant": old_priv,
                                    "r3Constant": new_priv,
                                    "foundInBothEnvironments": True,
                                    "kind": a3_obj["kind"],
                                    "typeAndValueDeBruijnEqualUnderRho": eq_aux,
                                    "r3ValueDeBruijnSha256": sha256_bytes(a3_obj["valueSexp"].encode("utf-8")),
                                })

                        # Also check `checkPinAndPrettyType` preservation in the actual compiled Core `Expr`!
                        cp1 = aux1_map.get("checkPinAndPrettyType")
                        cp3 = aux3_map.get("checkPinAndPrettyType")
                        cp_ok = False
                        if cp1 is not None and cp3 is not None:
                            cp1_t_m, _ = apply_strict_r1_to_r3_private_rho(cp1["typeSexp"])
                            cp1_v_m, _ = apply_strict_r1_to_r3_private_rho(
                                cp1["valueSexp"].replace("(lit str:<KitB4I1R1>)", "(lit str:<KitB4I1R3>)")
                            )
                            cp_ok = (cp1_t_m == cp3["typeSexp"]) and (cp1_v_m == cp3["valueSexp"])

                        r3_q5_report = {
                            "targetDeclaration": "inspectSharedAnchorBind5",
                            "comparisonExecuted": True,
                            "r1OriginalSourceSha256Verified": r1_staged_obs_sha,
                            "syntacticSourceSliceIdentical": False,
                            "unmappedStrictCoreDeBruijnIdentical_nu_alpha": unmapped_eq,
                            "rhoMappedCoreDeBruijnIdentical_nu_alpha_rho": rho_target_eq and all_priv_aux_ok,
                            "allMappedPrivateAuxDefinitionsTypeAndBodyVerified": all_priv_aux_ok,
                            "checkPinAndPrettyTypePreservedUpToDiagnosticTag": cp_ok,
                            "permittedCorrespondence_rho": aux_verifications,
                            "r3TargetTypeDeBruijnSha256": sha256_bytes(d3["typeSexp"].encode("utf-8")),
                            "r3TargetValueDeBruijnSha256": sha256_bytes(d3["valueSexp"].encode("utf-8")),
                            "exactKolmogorovComplexityZeroBitsClaimed": False,
                            "exactKolmogorovComplexityStatus": "HELD_UNCOMPUTABLE_O_1_THEORETICAL_CONTEXT_ONLY",
                        }

            _, h_o_post = sha256_file(oracle_path)
            core_expr_ok = (
                r3_q5_report["comparisonExecuted"] is True
                and r3_q5_report["rhoMappedCoreDeBruijnIdentical_nu_alpha_rho"] is True
                and r3_q5_report["allMappedPrivateAuxDefinitionsTypeAndBodyVerified"] is True
                and r3_q5_report["checkPinAndPrettyTypePreservedUpToDiagnosticTag"] is True
            )
            pre_all_ok = pre_build_pass and core_expr_ok and (h_o_pre_sha == h_o_post)

            pre_receipt = {
                "receiptSchema": "principia.omega.p1b2b.b4.act_i1_r3.pre_r3_syntax_type_linter_and_core_expr.v1",
                "workId": WORK_ID_R3,
                "verifiedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "compileProcessExitCode": p_kit.returncode,
                "compileState": "BUILD_COMPLETED" if (p_kit.returncode == 0 and e_cnt == 0) else "BUILD_FAILED",
                "compileErrorCount": e_cnt,
                "linterWarningCount": w_cnt,
                "zeroWarningPolicyState": "POLICY_PASSED" if w_cnt == 0 else "POLICY_FAILED",
                "cmtoTripleHashBinding_R3_Q3": triple_post_rep,
                "preR3AllPassed": pre_all_ok,
                "preR3BuildSeconds": pre_secs,
                "rawPreBuildLogSha256": log_sha,
                "elaboratedCoreExprEquivalenceLevels_R3_Q5": r3_q5_report,
            }
            write_json_lf(
                evidence_dir / "i1_r3_pre_syntax_type_linter_receipt.json",
                pre_receipt,
                allowed_roots,
                protected_roots,
            )
            print(json.dumps(pre_receipt, indent=2, ensure_ascii=False))
            return 0 if pre_all_ok else 1
        finally:
            _restore_writable_tree(tmp_root)
            tmp_dir_obj.cleanup()

    # =========================================================================
    # MODE 1: Single Isolated 9-Package Cold Replay + 21 Calibrations (`RE1` or `RE2` on fresh Linux VM)
    # =========================================================================
    if args.mode == "single-replay":
        rid = args.replay_id
        ok, rep_meta, trace_nodes, obs_obj = run_single_isolated_9pkg_cold_replay_r3(
            replay_id=rid,
            attempt_id=args.attempt_id,
            source_root=source_root,
            kit_dir=kit_dir,
            m74=m74,
            env_spec=env_spec,
            oracle=oracle,
            h_s=h_s_sha,
            t24_oracle_sha=t24_expected_i0_oracle_sha,
            r0_failed_oracle_sha=r0_expected_failed_oracle_sha,
            r1_policy_failed_oracle_sha=r1_expected_policy_failed_oracle_sha,
            r2_generator_failed_oracle_sha=r2_expected_generator_failed_oracle_sha,
            oracle_path=oracle_path,
            lean_env=lean_env,
            allowed_write_roots=allowed_roots,
            protected_roots=protected_roots,
            a1_audit_receipt=a1_audit_receipt,
            log_out_path=evidence_dir / f"i1_r3_clean_replay_{rid}.log",
            obs_out_path=evidence_dir / f"i1_r3_live_observation_{rid}.json",
            failed_obs_out_path=evidence_dir / f"i1_r3_failed_observation_{rid}.json",
        )
        cal_21_rep: dict[str, Any] = {"all21Caught": False, "caughtCalibrations": 0, "totalCalibrations": 21}
        strict_json_rep = run_exec_b4_r1_08_strict_json_suite()
        can_sha = ""
        spec_errs = list(rep_meta.get("specValidationErrors", []))

        if ok and obs_obj is not None:
            can_sha = canonical_json_sha256(project_cansem_r3(obs_obj, env_spec))
            if args.expected_local_cansem_sha256 and can_sha != args.expected_local_cansem_sha256.upper():
                ok = False
                spec_errs.append(f"{rid}: CanSem {can_sha} != expected local CanSem")
            cal_21_rep = run_all_21_calibrations_and_response_matrix(
                obs_obj,
                copy.deepcopy(obs_obj),
                oracle,
                env_spec,
                h_s_sha,
                h_o_pre_sha,
                t24_expected_i0_oracle_sha,
                r0_expected_failed_oracle_sha,
                r1_expected_policy_failed_oracle_sha,
                r2_expected_generator_failed_oracle_sha,
            )

        _, h_o_post_sha = sha256_file(oracle_path)
        trace_ok, trace_errs = evaluate_orthogonal_gate_trace_eligibility(trace_nodes)
        runner_all_ok = (
            ok
            and trace_ok
            and strict_json_rep["allPassed"]
            and cal_21_rep["all21Caught"]
            and (h_o_post_sha == h_o_pre_sha)
        )
        full_meta = {
            "replayId": rid,
            "attemptId": args.attempt_id,
            "hostEnvironment": env_meta,
            "dagAndSourcePreflight": dag_report,
            "replayExecution": rep_meta,
            "epistemicExecutionTrace": trace_nodes,
            "traceEligibilityPassed": trace_ok,
            "traceFailureReasons": trace_errs,
            "specValidationPassed": runner_all_ok,
            "specValidationErrors": spec_errs,
            "canSemSha256": can_sha,
            "execB4R108StrictJsonPassed": strict_json_rep["allPassed"],
            "calibration21Summary": {
                "totalCalibrations": cal_21_rep["totalCalibrations"],
                "caughtCalibrations": cal_21_rep["caughtCalibrations"],
                "all21Caught": cal_21_rep["all21Caught"],
            },
        }
        write_json_lf(evidence_dir / f"i1_r3_single_replay_meta_{rid}.json", full_meta, allowed_roots, protected_roots)
        print(f"SINGLE_REPLAY_R3_DONE id={rid} all_ok={runner_all_ok} cansem={can_sha} cal21={cal_21_rep['caughtCalibrations']}/21")
        return 0 if runner_all_ok else 1

    # =========================================================================
    # MODE 2: Closure VM Verification (`RE1` + `RE2` — collects failure evidence without false authority)
    # =========================================================================
    if args.mode == "verify-external-pair":
        re1_dir = args.re1_dir.resolve() if args.re1_dir else Path(".")
        re2_dir = args.re2_dir.resolve() if args.re2_dir else Path(".")

        closure_errors: list[str] = []
        re1_obs_path = re1_dir / "i1_r3_live_observation_RE1.json"
        re2_obs_path = re2_dir / "i1_r3_live_observation_RE2.json"
        re1_meta_path = re1_dir / "i1_r3_single_replay_meta_RE1.json"
        re2_meta_path = re2_dir / "i1_r3_single_replay_meta_RE2.json"
        re1_iso_path = re1_dir / "linux_principal_isolation_RE1.json"
        re2_iso_path = re2_dir / "linux_principal_isolation_RE2.json"

        meta_re1 = strict_json_loads(re1_meta_path.read_text(encoding="utf-8")) if re1_meta_path.is_file() else None
        meta_re2 = strict_json_loads(re2_meta_path.read_text(encoding="utf-8")) if re2_meta_path.is_file() else None
        iso_re1 = strict_json_loads(re1_iso_path.read_text(encoding="utf-8")) if re1_iso_path.is_file() else None
        iso_re2 = strict_json_loads(re2_iso_path.read_text(encoding="utf-8")) if re2_iso_path.is_file() else None

        if not re1_obs_path.is_file():
            closure_errors.append("RE1: OBSERVATION_MISSING")
        if not re2_obs_path.is_file():
            closure_errors.append("RE2: OBSERVATION_MISSING")

        pair_ok = False
        can_re1_sha = ""
        can_re2_sha = ""
        strict_json_rep = run_exec_b4_r1_08_strict_json_suite()
        cal_21_rep: dict[str, Any] = {"all21Caught": False, "caughtCalibrations": 0, "totalCalibrations": 21}

        if re1_obs_path.is_file() and re2_obs_path.is_file():
            obs_re1 = strict_json_loads(re1_obs_path.read_text(encoding="utf-8"))
            obs_re2 = strict_json_loads(re2_obs_path.read_text(encoding="utf-8"))
            pair_ok, pair_errs, can_re1_sha, can_re2_sha, _ = validate_replay_pair_against_spec_r3(
                obs_re1,
                obs_re2,
                oracle,
                env_spec,
                h_s_sha,
                h_o_pre_sha,
                t24_expected_i0_oracle_sha,
                r0_expected_failed_oracle_sha,
                r1_expected_policy_failed_oracle_sha,
                r2_expected_generator_failed_oracle_sha,
                tag1="RE1",
                tag2="RE2",
            )
            closure_errors.extend(pair_errs)
            cal_21_rep = run_all_21_calibrations_and_response_matrix(
                obs_re1,
                obs_re2,
                oracle,
                env_spec,
                h_s_sha,
                h_o_pre_sha,
                t24_expected_i0_oracle_sha,
                r0_expected_failed_oracle_sha,
                r1_expected_policy_failed_oracle_sha,
                r2_expected_generator_failed_oracle_sha,
            )

        expected_loc = args.expected_local_cansem_sha256.strip().upper()
        cross_os_match = (expected_loc != "") and (can_re1_sha == expected_loc) and (can_re2_sha == expected_loc)
        if not cross_os_match:
            closure_errors.append(f"Cross-OS CanSem mismatch: RE1={can_re1_sha}, RE2={can_re2_sha}, Local={expected_loc}")

        wf_gate_ok = (
            args.executed_workflow_sha256 != ""
            and args.executed_workflow_sha256.upper() == args.bundled_workflow_sha256.upper()
        )
        if not wf_gate_ok:
            closure_errors.append("Workflow byte gate failed in Closure VM")

        iso_ok = (
            iso_re1 is not None
            and iso_re2 is not None
            and iso_re1.get("allPrincipalIsolationProbesPassed") is True
            and iso_re2.get("allPrincipalIsolationProbesPassed") is True
        )
        if not iso_ok:
            closure_errors.append("Dedicated Linux principal isolation receipt missing or failed on RE1/RE2")

        _, h_o_post_sha = sha256_file(oracle_path)
        overall_ext_ok = (
            len(closure_errors) == 0
            and strict_json_rep["allPassed"]
            and pair_ok
            and cross_os_match
            and wf_gate_ok
            and iso_ok
            and cal_21_rep["all21Caught"]
            and (h_o_pre_sha == h_o_post_sha)
            and (meta_re1 is not None and meta_re1.get("specValidationPassed") is True)
            and (meta_re2 is not None and meta_re2.get("specValidationPassed") is True)
        )

        ext_receipt = {
            "receiptSchema": "principia.omega.p1b2b.b4.act_i1_r3.external_linux_authority_closure.v1",
            "workId": WORK_ID_R3,
            "verifiedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "allExternalChecksPassed": overall_ext_ok,
            "closureAuthorityGranted": overall_ext_ok,
            "closureHostEnvironment": env_meta,
            "workflowByteIdentityGate": {
                "executedWorkflowBytes": args.executed_workflow_bytes,
                "executedWorkflowSha256": args.executed_workflow_sha256.upper(),
                "bundledWorkflowSha256": args.bundled_workflow_sha256.upper(),
                "exactMatch": wf_gate_ok,
            },
            "pinnedLineageDigests": {
                "sourceManifestSha256_H_S": h_s_sha,
                "environmentSpecSha256_H_E_I1_R3": h_e_sha,
                "t24PrecedentOracleSha256": t24_expected_i0_oracle_sha,
                "preservedR0FailedOracleSha256": r0_expected_failed_oracle_sha,
                "preservedR1PolicyFailedOracleSha256": r1_expected_policy_failed_oracle_sha,
                "preservedR2GeneratorFailedOracleSha256": r2_expected_generator_failed_oracle_sha,
                "preRunOracleSha256_H_O_I1_R3": h_o_pre_sha,
                "postRunOracleSha256_H_O_I1_R3": h_o_post_sha,
                "expectedLocalCanSemSha256": expected_loc,
                "externalCanSem_RE1_Sha256": can_re1_sha,
                "externalCanSem_RE2_Sha256": can_re2_sha,
                "quadCanSemExactIdentity_RL1_RL2_RE1_RE2": cross_os_match and (can_re1_sha == can_re2_sha),
            },
            "linuxPrincipalIsolation": {
                "allPassed": iso_ok,
                "RE1": iso_re1,
                "RE2": iso_re2,
            },
            "runner1_RE1_Meta": meta_re1,
            "runner2_RE2_Meta": meta_re2,
            "validationErrors": closure_errors,
            "execB4R108StrictJsonRuntimeContract": strict_json_rep,
            "calibration21ScenarioSuite": cal_21_rep,
        }
        _, h_r_ext = write_json_lf(
            evidence_dir / "external_b4_i1_r3_authority_closure_receipt.json",
            ext_receipt,
            allowed_roots,
            protected_roots,
        )
        print(f"EXTERNAL_CLOSURE_R3_DONE ALL_OK={overall_ext_ok} CANSEM={can_re1_sha} H_R_EXT={h_r_ext}")
        return 0 if overall_ext_ok else 1

    # =========================================================================
    # MODE 3: Local Disjoint 2-Root 9-Package Cold Double Replay (`RL1_R3` & `RL2_R3`) + 21 Calibrations
    # =========================================================================
    strict_json_rep = run_exec_b4_r1_08_strict_json_suite()

    ok_rl1, meta_rl1, trace_rl1, obs_rl1 = run_single_isolated_9pkg_cold_replay_r3(
        replay_id="RL1_R3",
        attempt_id="LOCAL_R3_ATTEMPT_1",
        source_root=source_root,
        kit_dir=kit_dir,
        m74=m74,
        env_spec=env_spec,
        oracle=oracle,
        h_s=h_s_sha,
        t24_oracle_sha=t24_expected_i0_oracle_sha,
        r0_failed_oracle_sha=r0_expected_failed_oracle_sha,
        r1_policy_failed_oracle_sha=r1_expected_policy_failed_oracle_sha,
        r2_generator_failed_oracle_sha=r2_expected_generator_failed_oracle_sha,
        oracle_path=oracle_path,
        lean_env=lean_env,
        allowed_write_roots=allowed_roots,
        protected_roots=protected_roots,
        a1_audit_receipt=a1_audit_receipt,
        log_out_path=evidence_dir / "i1_r3_local_cold_replay_RL1.log",
        obs_out_path=evidence_dir / "i1_r3_local_live_observation_RL1.json",
        failed_obs_out_path=evidence_dir / "i1_r3_local_failed_observation_RL1.json",
    )
    ok_rl2, meta_rl2, trace_rl2, obs_rl2 = run_single_isolated_9pkg_cold_replay_r3(
        replay_id="RL2_R3",
        attempt_id="LOCAL_R3_ATTEMPT_1",
        source_root=source_root,
        kit_dir=kit_dir,
        m74=m74,
        env_spec=env_spec,
        oracle=oracle,
        h_s=h_s_sha,
        t24_oracle_sha=t24_expected_i0_oracle_sha,
        r0_failed_oracle_sha=r0_expected_failed_oracle_sha,
        r1_policy_failed_oracle_sha=r1_expected_policy_failed_oracle_sha,
        r2_generator_failed_oracle_sha=r2_expected_generator_failed_oracle_sha,
        oracle_path=oracle_path,
        lean_env=lean_env,
        allowed_write_roots=allowed_roots,
        protected_roots=protected_roots,
        a1_audit_receipt=a1_audit_receipt,
        log_out_path=evidence_dir / "i1_r3_local_cold_replay_RL2.log",
        obs_out_path=evidence_dir / "i1_r3_local_live_observation_RL2.json",
        failed_obs_out_path=evidence_dir / "i1_r3_local_failed_observation_RL2.json",
    )

    combined_trace = trace_rl1 + trace_rl2
    trace_ok, trace_reasons = evaluate_orthogonal_gate_trace_eligibility(combined_trace)

    if not ok_rl1 or not ok_rl2 or obs_rl1 is None or obs_rl2 is None or not trace_ok:
        fail_obj = {
            "rl1": meta_rl1,
            "rl2": meta_rl2,
            "epistemicExecutionTrace": combined_trace,
            "traceFailureReasons": trace_reasons,
            "a10ExternalExecutionEligible": False,
        }
        write_json_lf(evidence_dir / "i1_r3_local_failure_halt.json", fail_obj, allowed_roots, protected_roots)
        print(f"[CRITICAL] Local R3 cold replay failed: {fail_obj}", file=sys.stderr)
        return 1

    disjoint_work_roots = meta_rl1["isolatedWorkRoot"] != meta_rl2["isolatedWorkRoot"]

    pair_ok, pair_errs, can_rl1_sha, can_rl2_sha, _ = validate_replay_pair_against_spec_r3(
        obs_rl1,
        obs_rl2,
        oracle,
        env_spec,
        h_s_sha,
        h_o_pre_sha,
        t24_expected_i0_oracle_sha,
        r0_expected_failed_oracle_sha,
        r1_expected_policy_failed_oracle_sha,
        r2_expected_generator_failed_oracle_sha,
        tag1="RL1_R3",
        tag2="RL2_R3",
    )

    cal_21_rep = run_all_21_calibrations_and_response_matrix(
        obs_rl1,
        obs_rl2,
        oracle,
        env_spec,
        h_s_sha,
        h_o_pre_sha,
        t24_expected_i0_oracle_sha,
        r0_expected_failed_oracle_sha,
        r1_expected_policy_failed_oracle_sha,
        r2_expected_generator_failed_oracle_sha,
    )
    _, h_o_post_sha = sha256_file(oracle_path)

    local_all_ok = (
        t24_direct_verified
        and r0_r1_r2_oracles_direct_verified
        and (a1_audit_receipt is not None and a1_audit_receipt.get("cmtoIndependentAuditPassed") is True)
        and dag_ok
        and disjoint_work_roots
        and trace_ok
        and strict_json_rep["allPassed"]
        and pair_ok
        and (can_rl1_sha == can_rl2_sha)
        and cal_21_rep["all21Caught"]
        and (h_o_pre_sha == h_o_post_sha)
    )
    a10_gate_ok, _ = validate_a10_authority_gate(combined_trace, cal_21_rep["all21Caught"], local_all_ok)
    local_all_ok = local_all_ok and a10_gate_ok

    trace_receipt = {
        "receiptSchema": "principia.omega.p1b2b.b4.act_i1_r3.epistemic_execution_trace.v1",
        "workId": WORK_ID_R3,
        "verifiedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "traceEligibilityPassed": trace_ok,
        "traceFailureReasons": trace_reasons,
        "a10ExternalExecutionEligible": local_all_ok,
        "nodes": combined_trace,
    }
    write_json_lf(
        evidence_dir / "i1_r3_epistemic_execution_trace.json",
        trace_receipt,
        allowed_roots,
        protected_roots,
    )

    local_master = {
        "receiptSchema": "principia.omega.p1b2b.b4.act_i1_r3.local_a3_to_a9_and_21_calibrations_receipt.v1",
        "workId": WORK_ID_R3,
        "verifiedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "allLocalGatesA1ToA9Passed": local_all_ok,
        "a10ExternalExecutionEligible": local_all_ok,
        "hostEnvironment": env_meta,
        "windowsProtection3LayerScope_F_I1_R0_05": {
            "layer1_FileContentSha256Immutability": "VERIFIED",
            "layer2_ReadOnlyAttributeAndPathReparseGuard": "VERIFIED",
            "layer3_LocalWindowsMultiPrincipalKernelAclIsolation": "SAME_USER_ACL_NOT_CLAIMED",
        },
        "pinnedDigests": {
            "t24PrecedentZipSha256": t24_expected_zip_sha,
            "t24EmbeddedI0OracleSha256": t24_expected_i0_oracle_sha,
            "preservedR0FailedOracleSha256": r0_expected_failed_oracle_sha,
            "preservedR1PolicyFailedOracleSha256": r1_expected_policy_failed_oracle_sha,
            "preservedR2GeneratorFailedOracleSha256": r2_expected_generator_failed_oracle_sha,
            "sourceManifest74Sha256_H_S": h_s_sha,
            "environmentSpecSha256_H_E_I1_R3": h_e_sha,
            "preRunOracleSha256_H_O_I1_R3": h_o_pre_sha,
            "postRunOracleSha256_H_O_I1_R3": h_o_post_sha,
            "canSem_RL1_R3_Sha256": can_rl1_sha,
            "canSem_RL2_R3_Sha256": can_rl2_sha,
            "canSem_RL1_Equals_RL2": can_rl1_sha == can_rl2_sha,
        },
        "dag9PackageVerification": dag_report,
        "replayRL1_R3": meta_rl1,
        "replayRL2_R3": meta_rl2,
        "validationErrors": pair_errs,
        "execB4R108StrictJsonRuntimeContract": strict_json_rep,
        "calibration21ScenarioSuite": cal_21_rep,
    }
    _, local_master_sha = write_json_lf(
        evidence_dir / "i1_r3_local_a3_to_a9_master_receipt.json",
        local_master,
        allowed_roots,
        protected_roots,
    )

    print(json.dumps({
        "status": "LOCAL_R3_A1_TO_A9_AND_21_CALIBRATIONS_VERIFIED" if local_all_ok else "LOCAL_R3_FAILED_HALT",
        "allLocalGatesPassed": local_all_ok,
        "a10ExternalExecutionEligible": local_all_ok,
        "canSem_RL1_R3_Sha256": can_rl1_sha,
        "canSem_RL2_R3_Sha256": can_rl2_sha,
        "rl1BuildSeconds": meta_rl1["coldBuildSeconds"],
        "rl2BuildSeconds": meta_rl2["coldBuildSeconds"],
        "calibrationsCaught": f"{cal_21_rep['caughtCalibrations']}/{cal_21_rep['totalCalibrations']}",
        "responseMatrixDetect": cal_21_rep["interventionalFaultGuardResponseMatrix_R2_beta"]["C_detect_Exact"],
        "responseMatrixDistinguish": cal_21_rep["interventionalFaultGuardResponseMatrix_R2_beta"]["C_distinguish_Exact"],
        "responseMatrixGF2Rank": cal_21_rep["interventionalFaultGuardResponseMatrix_R2_beta"]["rankOverGF2_ObservedProjected"],
        "localMasterReceiptSha256": local_master_sha,
    }, indent=2, ensure_ascii=False))
    return 0 if local_all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
