# PRINCIPIA `Ω-CELL-C1-P1B2B-B4` — Detached `Born-T21` VerifyKit `KitB4I1-R3` (`ACT-I1 R3`)

- **Work ID**: `PRINCIPIA_OMEGA_CELL_C1_P1B2B_B4_ACT_I1_R3_CERTIFIED_MINIMAL_TRANSFORMATION_AND_DETACHED_EXTERNAL_REPLAY`
- **Pinned Toolchain**: `leanprover/lean4:v4.33.1` (`commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6`)
- **Preserved Failure Lineages**: `R0` (`18` files), `R1` (`18` files), and `R2` (`20` files) preserved `0 B` modified (`321` total deduplicated protected files).
- **Source Branching (`CMTO`)**: Branched strictly from `R1` original (`ExternalObsB4I1R1.lean`, `D7CE5E5A...`), replacing `ciOrig -> _ciOrig` solely inside `inspectSharedAnchorBind5` (line `293`) while preserving `checkPinAndPrettyType` (line `278`) untouched (`B4` kernel change `0 B`).
- **Enforced Conditions**: `77` mandatory conditions, `21` calibrations (`21 x 9` Interventional Fault–Guard Response Matrix), `H_generated == H_audited == H_compiled` triple binding (`R3-Q3`), Bowen–Lanford algebraic DAG cross-check, and Frozen-State Noninterference Algebra.
